/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Notification = ({ className }) => {
  return (
    <svg
      className={`notification ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M8.01242 1.94002C5.80575 1.94002 4.01242 3.73335 4.01242 5.94002V7.86668C4.01242 8.27335 3.83908 8.89335 3.63242 9.24002L2.86575 10.5134C2.39242 11.3 2.71908 12.1734 3.58575 12.4667C6.45908 13.4267 9.55908 13.4267 12.4324 12.4667C13.2391 12.2 13.5924 11.2467 13.1524 10.5134L12.3857 9.24002C12.1857 8.89335 12.0124 8.27335 12.0124 7.86668V5.94002C12.0124 3.74002 10.2124 1.94002 8.01242 1.94002Z"
        stroke="black"
        strokeLinecap="round"
        strokeMiterlimit="10"
      />

      <path
        className="path"
        d="M9.24401 2.13329C9.03734 2.07329 8.82401 2.02662 8.60401 1.99996C7.96401 1.91996 7.35068 1.96662 6.77734 2.13329C6.97068 1.63996 7.45068 1.29329 8.01068 1.29329C8.57068 1.29329 9.05068 1.63996 9.24401 2.13329Z"
        stroke="black"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeMiterlimit="10"
      />

      <path
        className="path"
        d="M10.0117 12.7067C10.0117 13.8067 9.11172 14.7067 8.01172 14.7067C7.46505 14.7067 6.95838 14.48 6.59838 14.12C6.23838 13.76 6.01172 13.2534 6.01172 12.7067"
        stroke="black"
        strokeMiterlimit="10"
      />
    </svg>
  );
};
