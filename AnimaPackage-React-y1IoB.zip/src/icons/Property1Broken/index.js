export { Property1Broken } from "./Property1Broken";
