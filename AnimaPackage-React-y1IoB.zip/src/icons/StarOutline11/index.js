export { StarOutline11 } from "./StarOutline11";
