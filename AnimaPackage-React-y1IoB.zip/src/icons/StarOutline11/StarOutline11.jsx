/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";

export const StarOutline11 = ({
  color = "url(#paint0_linear_51_4191)",
  className,
}) => {
  return (
    <svg
      className={`star-outline-11 ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_51_4193)">
        <path
          className="path"
          d="M10.4725 5.79804L12.3125 5.9567C13.1927 6.0326 13.5493 7.12914 12.8821 7.70824L11.4877 8.91839C11.208 9.16117 11.0853 9.53868 11.169 9.8995L11.5854 11.6953C11.785 12.5564 10.8513 13.2341 10.0945 12.7774L8.51641 11.8249C8.19862 11.6331 7.80073 11.6331 7.48294 11.8249L5.90867 12.7751C5.15136 13.2321 4.21713 12.5532 4.41809 11.6917L4.83588 9.90081C4.92021 9.53931 4.79737 9.16085 4.5168 8.9178L3.1244 7.71156C2.4558 7.13235 2.81321 6.03409 3.69464 5.95931L5.52548 5.80399C5.89505 5.77263 6.21692 5.53929 6.36166 5.19779L7.07965 3.50374C7.42414 2.69095 8.57595 2.69064 8.92088 3.50324L9.6379 5.19246C9.78255 5.53325 10.1036 5.76623 10.4725 5.79804Z"
          fill={color}
        />
      </g>

      <defs className="defs">
        <linearGradient
          className="linear-gradient"
          gradientUnits="userSpaceOnUse"
          id="paint0_linear_51_4193"
          x1="1.33301"
          x2="14.6663"
          y1="7.66634"
          y2="7.66634"
        >
          <stop className="stop" stopColor="#5AD9EA" />

          <stop className="stop" offset="1" stopColor="#89CDFA" />
        </linearGradient>

        <clipPath className="clip-path" id="clip0_51_4193">
          <rect className="rect" fill="white" height="16" width="16" />
        </clipPath>
      </defs>
    </svg>
  );
};

StarOutline11.propTypes = {
  color: PropTypes.string,
};
