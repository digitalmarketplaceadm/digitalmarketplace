/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Notification5 = ({ className }) => {
  return (
    <svg
      className={`notification-5 ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 25 24"
      width="25"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M12.8936 2.91003C9.58362 2.91003 6.89362 5.60003 6.89362 8.91003V11.8C6.89362 12.41 6.63362 13.34 6.32362 13.86L5.17362 15.77C4.46362 16.95 4.95362 18.26 6.25362 18.7C10.5636 20.14 15.2136 20.14 19.5236 18.7C20.7336 18.3 21.2636 16.87 20.6036 15.77L19.4536 13.86C19.1536 13.34 18.8936 12.41 18.8936 11.8V8.91003C18.8936 5.61003 16.1936 2.91003 12.8936 2.91003Z"
        stroke="#535353"
        strokeLinecap="round"
        strokeMiterlimit="10"
        strokeWidth="1.5"
      />

      <path
        className="path"
        d="M14.743 3.19994C14.433 3.10994 14.113 3.03994 13.783 2.99994C12.823 2.87994 11.903 2.94994 11.043 3.19994C11.333 2.45994 12.053 1.93994 12.893 1.93994C13.733 1.93994 14.453 2.45994 14.743 3.19994Z"
        stroke="#535353"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeMiterlimit="10"
        strokeWidth="1.5"
      />

      <path
        className="path"
        d="M15.8945 19.0601C15.8945 20.7101 14.5445 22.0601 12.8945 22.0601C12.0745 22.0601 11.3145 21.7201 10.7745 21.1801C10.2345 20.6401 9.89453 19.8801 9.89453 19.0601"
        stroke="#535353"
        strokeMiterlimit="10"
        strokeWidth="1.5"
      />
    </svg>
  );
};
