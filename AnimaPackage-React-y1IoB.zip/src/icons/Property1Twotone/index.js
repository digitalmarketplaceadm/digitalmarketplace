export { Property1Twotone } from "./Property1Twotone";
