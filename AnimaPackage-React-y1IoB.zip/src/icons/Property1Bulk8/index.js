export { Property1Bulk8 } from "./Property1Bulk8";
