/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";

export const StarOutline41 = ({
  color = "url(#paint0_linear_64_2620)",
  className,
}) => {
  return (
    <svg
      className={`star-outline-41 ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_64_2618)">
        <path
          className="path"
          d="M10.4715 5.79804L12.3115 5.9567C13.1918 6.0326 13.5483 7.12914 12.8811 7.70824L11.4867 8.91839C11.207 9.16117 11.0844 9.53868 11.168 9.8995L11.5844 11.6953C11.7841 12.5564 10.8503 13.2341 10.0935 12.7774L8.51543 11.8249C8.19764 11.6331 7.79975 11.6331 7.48196 11.8249L5.9077 12.7751C5.15038 13.2321 4.21615 12.5532 4.41711 11.6917L4.83491 9.90081C4.91924 9.53931 4.79639 9.16085 4.51583 8.9178L3.12343 7.71156C2.45483 7.13235 2.81224 6.03409 3.69366 5.95931L5.5245 5.80399C5.89408 5.77263 6.21594 5.53929 6.36068 5.19779L7.07867 3.50374C7.42316 2.69095 8.57497 2.69064 8.9199 3.50324L9.63692 5.19246C9.78158 5.53325 10.1027 5.76623 10.4715 5.79804Z"
          fill={color}
        />
      </g>

      <defs className="defs">
        <linearGradient
          className="linear-gradient"
          gradientUnits="userSpaceOnUse"
          id="paint0_linear_64_2618"
          x1="1.33203"
          x2="14.6654"
          y1="7.66634"
          y2="7.66634"
        >
          <stop className="stop" stopColor="#5AD9EA" />

          <stop className="stop" offset="1" stopColor="#89CDFA" />
        </linearGradient>

        <clipPath className="clip-path" id="clip0_64_2618">
          <rect className="rect" fill="white" height="16" width="16" />
        </clipPath>
      </defs>
    </svg>
  );
};

StarOutline41.propTypes = {
  color: PropTypes.string,
};
