export { StarOutline41 } from "./StarOutline41";
