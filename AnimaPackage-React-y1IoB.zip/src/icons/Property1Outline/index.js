export { Property1Outline } from "./Property1Outline";
