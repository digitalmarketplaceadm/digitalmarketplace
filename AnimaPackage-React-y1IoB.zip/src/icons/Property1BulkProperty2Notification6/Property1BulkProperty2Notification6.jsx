/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Property1BulkProperty2Notification6 = ({ className }) => {
  return (
    <svg
      className={`property-1-bulk-property-2-notification-6 ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 24 24"
      width="24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M19.34 14.49L18.34 12.83C18.13 12.46 17.94 11.76 17.94 11.35V8.81999C17.94 5.55999 15.29 2.89999 12.02 2.89999C8.75 2.89999 6.1 5.55999 6.1 8.81999V11.35C6.1 11.76 5.91 12.46 5.7 12.82L4.69 14.49C4.29 15.16 4.2 15.9 4.45 16.58C4.69 17.25 5.26 17.77 6 18.02C7.94 18.68 9.98 19 12.02 19C14.06 19 16.1 18.68 18.04 18.03C18.74 17.8 19.28 17.27 19.54 16.58C19.8 15.89 19.73 15.13 19.34 14.49Z"
        fill="#292D32"
        opacity="0.4"
      />

      <path
        className="path"
        d="M14.25 3.32C13.56 3.05 12.81 2.9 12.02 2.9C11.24 2.9 10.49 3.04 9.8 3.32C10.23 2.51 11.08 2 12.02 2C12.97 2 13.81 2.51 14.25 3.32Z"
        fill="#292D32"
      />

      <path
        className="path"
        d="M14.83 20.01C14.41 21.17 13.3 22 12 22C11.21 22 10.43 21.68 9.87999 21.11C9.55999 20.81 9.31999 20.41 9.17999 20C9.30999 20.02 9.43999 20.03 9.57999 20.05C9.80999 20.08 10.05 20.11 10.29 20.13C10.86 20.18 11.44 20.21 12.02 20.21C12.59 20.21 13.16 20.18 13.72 20.13C13.93 20.11 14.14 20.1 14.34 20.07C14.5 20.05 14.66 20.03 14.83 20.01Z"
        fill="#292D32"
      />

      <g className="g" opacity="0" />
    </svg>
  );
};
