export { SearchNormal38 } from "./SearchNormal38";
