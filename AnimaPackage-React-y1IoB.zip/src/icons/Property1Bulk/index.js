export { Property1Bulk } from "./Property1Bulk";
