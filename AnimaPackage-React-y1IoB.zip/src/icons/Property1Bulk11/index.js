export { Property1Bulk11 } from "./Property1Bulk11";
