export { SearchNormal24 } from "./SearchNormal24";
