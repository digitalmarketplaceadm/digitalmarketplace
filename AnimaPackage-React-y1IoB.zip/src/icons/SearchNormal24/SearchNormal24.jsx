/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";

export const SearchNormal24 = ({ color = "#232323", className }) => {
  return (
    <svg
      className={`search-normal-24 ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M7.66927 13.9999C11.1671 13.9999 14.0026 11.1644 14.0026 7.66659C14.0026 4.16878 11.1671 1.33325 7.66927 1.33325C4.17147 1.33325 1.33594 4.16878 1.33594 7.66659C1.33594 11.1644 4.17147 13.9999 7.66927 13.9999Z"
        stroke={color}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.5"
      />

      <path
        className="path"
        d="M14.6693 14.6666L13.3359 13.3333"
        stroke={color}
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.5"
      />
    </svg>
  );
};

SearchNormal24.propTypes = {
  color: PropTypes.string,
};
