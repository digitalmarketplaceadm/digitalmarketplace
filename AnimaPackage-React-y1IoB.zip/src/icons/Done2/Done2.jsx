/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Done2 = ({ className }) => {
  return (
    <svg
      className={`done-2 ${className}`}
      fill="none"
      height="13"
      viewBox="0 0 12 13"
      width="12"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_435_567)">
        <path
          className="path"
          d="M4.5002 8.5998L2.4002 6.4998L1.7002 7.1998L4.5002 9.9998L10.5002 3.9998L9.8002 3.2998L4.5002 8.5998Z"
          fill="white"
        />
      </g>

      <defs className="defs">
        <clipPath className="clip-path" id="clip0_435_567">
          <rect
            className="rect"
            fill="white"
            height="12"
            transform="translate(0 0.5)"
            width="12"
          />
        </clipPath>
      </defs>
    </svg>
  );
};
