export { SearchNormal1 } from "./SearchNormal1";
