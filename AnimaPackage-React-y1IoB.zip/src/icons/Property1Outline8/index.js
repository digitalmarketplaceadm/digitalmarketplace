export { Property1Outline8 } from "./Property1Outline8";
