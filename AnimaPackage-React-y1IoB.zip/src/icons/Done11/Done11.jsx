/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Done11 = ({ className }) => {
  return (
    <svg
      className={`done-11 ${className}`}
      fill="none"
      height="12"
      viewBox="0 0 12 12"
      width="12"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_435_147)">
        <path
          className="path"
          d="M4.5002 8.0998L2.4002 5.9998L1.7002 6.6998L4.5002 9.4998L10.5002 3.4998L9.8002 2.7998L4.5002 8.0998Z"
          fill="white"
        />
      </g>

      <defs className="defs">
        <clipPath className="clip-path" id="clip0_435_147">
          <rect className="rect" fill="white" height="12" width="12" />
        </clipPath>
      </defs>
    </svg>
  );
};
