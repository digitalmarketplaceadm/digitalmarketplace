export { StarOutline15 } from "./StarOutline15";
