/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const StarOutline15 = ({ className }) => {
  return (
    <svg
      className={`star-outline-15 ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_398_6376)">
        <path
          className="path"
          d="M7.53906 3.69922C7.70052 3.31828 8.21679 3.29382 8.42285 3.62695L8.45996 3.69824L9.17676 5.3877C9.36659 5.83493 9.75887 6.15877 10.2246 6.26465L10.4287 6.2959L12.2686 6.45508C12.6811 6.49065 12.8638 6.97447 12.6104 7.27344L12.5537 7.33105L11.1592 8.54102C10.7921 8.85963 10.6054 9.33269 10.6484 9.80859L10.6807 10.0127L11.0977 11.8086C11.1909 12.212 10.7864 12.5349 10.4238 12.3857L10.3516 12.3496L8.77344 11.3965C8.3563 11.1449 7.84726 11.1138 7.40723 11.3027L7.22363 11.3965L5.64941 12.3467C5.29439 12.561 4.86142 12.2762 4.8916 11.8848L4.9043 11.8057L5.32227 10.0146C5.43294 9.54025 5.30562 9.04585 4.99023 8.68555L4.84277 8.54004L3.45117 7.33398C3.13784 7.06254 3.2749 6.56306 3.65625 6.4707L3.73633 6.45801L5.56641 6.30176C6.05147 6.2606 6.4821 5.98794 6.72754 5.57715L6.82129 5.39258L7.53906 3.69922Z"
          stroke="#7B8081"
        />
      </g>

      <defs className="defs">
        <clipPath className="clip-path" id="clip0_398_6376">
          <rect className="rect" fill="white" height="16" width="16" />
        </clipPath>
      </defs>
    </svg>
  );
};
