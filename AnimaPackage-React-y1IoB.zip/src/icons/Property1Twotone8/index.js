export { Property1Twotone8 } from "./Property1Twotone8";
