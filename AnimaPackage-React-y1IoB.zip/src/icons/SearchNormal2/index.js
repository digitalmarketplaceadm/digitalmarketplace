export { SearchNormal2 } from "./SearchNormal2";
