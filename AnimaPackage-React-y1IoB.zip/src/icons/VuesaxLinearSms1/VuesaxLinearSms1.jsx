/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const VuesaxLinearSms1 = ({ className }) => {
  return (
    <svg
      className={`vuesax-linear-sms-1 ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M11.332 13.6667H4.66536C2.66536 13.6667 1.33203 12.6667 1.33203 10.3333V5.66666C1.33203 3.33333 2.66536 2.33333 4.66536 2.33333H11.332C13.332 2.33333 14.6654 3.33333 14.6654 5.66666V10.3333C14.6654 12.6667 13.332 13.6667 11.332 13.6667Z"
        stroke="black"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeMiterlimit="10"
      />

      <path
        className="path"
        d="M11.3346 6L9.24797 7.66667C8.5613 8.21333 7.43463 8.21333 6.74797 7.66667L4.66797 6"
        stroke="black"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeMiterlimit="10"
      />
    </svg>
  );
};
