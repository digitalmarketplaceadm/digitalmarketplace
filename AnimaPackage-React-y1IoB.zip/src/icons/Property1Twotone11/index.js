export { Property1Twotone11 } from "./Property1Twotone11";
