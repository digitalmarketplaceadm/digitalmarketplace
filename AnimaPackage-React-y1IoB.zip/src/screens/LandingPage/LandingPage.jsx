import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const LandingPage = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="landing-page"
      style={{
        alignItems:
          screenWidth < 1440
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        minWidth:
          screenWidth < 1440
            ? "393px"
            : screenWidth >= 1440
              ? "1440px"
              : undefined,
      }}
    >
      {screenWidth < 1440 && (
        <>
          <StatusBar
            batteryClassName="status-bar-104"
            className="status-bar-102"
            combinedShape="/img/combined-shape-16.svg"
            containerClassName="status-bar-103"
            property1="dark"
            wiFi="/img/wi-fi-16.svg"
          />
          <div className="frame-745">
            <div className="group-141">
              <div className="overlap">
                <div className="overlap-group-14">
                  <div className="frame-746">
                    <p className="text-wrapper-360">
                      Sell digital goods
                      <br />
                      without a technical hassle.
                    </p>

                    <p className="text-wrapper-361">
                      Brand&nbsp;&nbsp;is the ultimate platform for selling your
                      ebooks, software, and all kinds of digital products. If
                      you can save it, you can sell it. Everything you need to
                      sell your creations and expand your business, all in one
                      place.
                    </p>

                    <div className="subscribe-field">
                      <input
                        className="enter-your-email"
                        placeholder="Enter your email here"
                      />

                      <div className="frame-747">
                        <div className="text-wrapper-362">Get Started</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-748">
                    <img
                      className="image-37"
                      alt="Image"
                      src="/img/image-16.png"
                    />

                    <div className="frame-749">
                      <div className="text-wrapper-363">Digital Downloads</div>
                    </div>
                  </div>

                  <div className="frame-750">
                    <img
                      className="rectangle-3"
                      alt="Rectangle"
                      src="/img/rectangle-5425-9.svg"
                    />

                    <div className="frame-751">
                      <div className="text-wrapper-364">Coaching</div>
                    </div>
                  </div>
                </div>

                <div className="frame-752">
                  <img
                    className="rectangle-4"
                    alt="Rectangle"
                    src="/img/rectangle-5425-8.png"
                  />

                  <div className="frame-753">
                    <div className="text-wrapper-365">Physical Products</div>
                  </div>
                </div>
              </div>

              <div className="frame-754">
                <img
                  className="rectangle-5"
                  alt="Rectangle"
                  src="/img/rectangle-5425-10.svg"
                />

                <div className="frame-755">
                  <div className="text-wrapper-366">Memberships</div>
                </div>
              </div>

              <div className="frame-756">
                <img
                  className="rectangle-6"
                  alt="Rectangle"
                  src="/img/rectangle-5425-11.svg"
                />

                <div className="frame-757">
                  <div className="text-wrapper-367">Online Courses</div>
                </div>
              </div>
            </div>

            <div className="menu-alt-svgrepo-wrapper">
              <img
                className="menu-alt-svgrepo"
                alt="Menu alt svgrepo"
                src="/img/menu-alt-1-svgrepo-com-2.svg"
              />
            </div>
          </div>

          <div className="frame-758">
            <div className="div-11">
              <div className="text-wrapper-360">All-in-one platform</div>

              <p className="text-wrapper-361">
                Everything you need to build, expand, and run your business with
                ease.
              </p>
            </div>

            <img className="image-38" alt="Image" src="/img/image-17-2.png" />

            <div className="frame-759">
              <div className="feature-card">
                <div className="div-11">
                  <div className="text-wrapper-368">Digital downloads</div>

                  <p className="text-wrapper-369">
                    Sell any kind of digital product—ebooks, software, design
                    assets, templates, videos, music, and more. If you can save
                    it, you can sell it.
                  </p>

                  <div className="frame-760">
                    <div className="text-wrapper-370">Learn More</div>

                    <img
                      className="arrow-up-right"
                      alt="Arrow up right"
                      src="/img/arrow-up-right-svgrepo-com-14.svg"
                    />
                  </div>
                </div>
              </div>

              <div className="feature-card">
                <div className="div-11">
                  <div className="text-wrapper-368">Online courses</div>

                  <p className="text-wrapper-371">
                    Match with influencers that align with your brand vision and
                    values.
                  </p>

                  <div className="frame-760">
                    <div className="text-wrapper-370">Learn More</div>

                    <img
                      className="arrow-up-right"
                      alt="Arrow up right"
                      src="/img/arrow-up-right-svgrepo-com-14.svg"
                    />
                  </div>
                </div>
              </div>

              <div className="feature-card">
                <div className="div-11">
                  <div className="text-wrapper-368">Coaching</div>

                  <p className="text-wrapper-369">
                    Build and sell online courses with interactive features,
                    including videos, downloadable files, quizzes, and
                    assignments. Schedule drip content and reward learners with
                    completion certificates.
                  </p>

                  <div className="frame-760">
                    <div className="text-wrapper-370">Learn More</div>

                    <img
                      className="arrow-up-right"
                      alt="Arrow up right"
                      src="/img/arrow-up-right-svgrepo-com-16.svg"
                    />
                  </div>
                </div>
              </div>

              <div className="feature-card">
                <div className="div-11">
                  <div className="text-wrapper-368">Memberships</div>

                  <p className="text-wrapper-369">
                    Enable recurring payments for your digital products or
                    membership community. Easily manage subscribers and provide
                    seamless access.
                  </p>

                  <div className="frame-760">
                    <div className="text-wrapper-370">Learn More</div>

                    <img
                      className="arrow-up-right"
                      alt="Arrow up right"
                      src="/img/arrow-up-right-svgrepo-com-16.svg"
                    />
                  </div>
                </div>
              </div>

              <div className="feature-card">
                <div className="div-11">
                  <div className="text-wrapper-368">Physical products</div>

                  <p className="text-wrapper-369">
                    Sell and track inventory for any physical products. Easily
                    manage your store, fulfill orders, run promotions, and more.
                  </p>

                  <div className="frame-760">
                    <div className="text-wrapper-370">Learn More</div>

                    <img
                      className="arrow-up-right"
                      alt="Arrow up right"
                      src="/img/arrow-up-right-svgrepo-com-16.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-761">
            <div className="div-11">
              <div className="text-wrapper-360">Your store, your way</div>

              <p className="text-wrapper-361">
                Smart features designed to make your brand stand out.
              </p>
            </div>

            <img className="image-38" alt="Image" src="/img/image-18-2.png" />

            <div className="frame-759">
              <div className="info-wrapper">
                <div className="info">
                  <div className="text-wrapper-368">Digital downloads</div>

                  <p className="text-wrapper-369">
                    Create your website in minutes with ease.
                  </p>
                </div>
              </div>

              <div className="info">
                <div className="text-wrapper-368">Connect a custom domain</div>

                <p className="text-wrapper-369">
                  Strengthen your brand by connecting your own domain to Payhip
                  for free—whether it’s your main domain or a subdomain.
                </p>
              </div>

              <div className="info">
                <p className="text-wrapper-368">
                  Embed on your existing website
                </p>

                <p className="text-wrapper-369">
                  Integrate powerful features and seamless, high-converting
                  checkout into your existing website with ease.
                </p>
              </div>
            </div>
          </div>

          <div className="frame-762">
            <div className="div-11">
              <div className="text-wrapper-360">Testimonial</div>

              <p className="text-wrapper-372">
                We empower creators to grow their business and transform their
                passion into profit.
              </p>
            </div>

            <div className="frame-763">
              <div className="frame-764">
                <div className="frame-765">
                  <img
                    className="group-142"
                    alt="Group"
                    src="/img/vector-1-18.png"
                  />

                  <div className="frame-766">
                    <p className="text-wrapper-373">
                      This platform has completely transformed the way I sell
                      digital products. The setup was effortless, and the
                      built-in tools helped me grow my business faster than I
                      imagined. Highly recommended!
                    </p>

                    <div className="frame-767">
                      <img
                        className="ellipse-33"
                        alt="Ellipse"
                        src="/img/vector-1-18.png"
                      />

                      <div className="frame-768">
                        <div className="text-wrapper-374">Alex Carter</div>

                        <div className="text-wrapper-375">
                          Founder of Digital Creations
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="frame-769">
                <div className="frame-770">
                  <img
                    className="group-143"
                    alt="Group"
                    src="/img/group-7.png"
                  />

                  <div className="frame-771">
                    <p className="text-wrapper-376">
                      An absolute game-changer for my business! The seamless
                      setup and powerful features made selling digital products
                      effortless. Highly recommended!
                    </p>

                    <div className="frame-767">
                      <img
                        className="ellipse-34"
                        alt="Ellipse"
                        src="/img/ellipse-2-2.png"
                      />

                      <div className="frame-768">
                        <div className="text-wrapper-374">Samantha Reed</div>

                        <div className="text-wrapper-375">
                          CEO of Creative Hub
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="frame-769">
                <div className="frame-770">
                  <img
                    className="group-144"
                    alt="Group"
                    src="/img/group-8.png"
                  />

                  <div className="frame-771">
                    <p className="text-wrapper-376">
                      Managing my online store has never been easier. From
                      automated sales tracking to smooth customer experience,
                      everything just works!
                    </p>

                    <div className="frame-767">
                      <img
                        className="ellipse-35"
                        alt="Ellipse"
                        src="/img/vector-1-18.png"
                      />

                      <div className="frame-768">
                        <div className="text-wrapper-374">James Porter</div>

                        <div className="text-wrapper-375">
                          Founder of Elite Templates
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-772">
            <div className="frame-773">
              <div className="frame-774">
                <div className="group-145">
                  <div className="digital-download-wrapper">
                    <div className="digital-download">DIGITAL DOWNLOAD</div>
                  </div>
                </div>

                <div className="text-wrapper-377">ONLINE COURSE</div>

                <div className="text-wrapper-377">COACHING</div>

                <div className="text-wrapper-378">MEMBERSHIP</div>

                <div className="text-wrapper-378">PHYSICAL PRODUCTS</div>
              </div>

              <div className="frame-775">
                <div className="frame-776">
                  <img
                    className="image-39"
                    alt="Image"
                    src="/img/image-19.png"
                  />

                  <div className="frame-777">
                    <div className="title-8">Transitioning Vegan Cookbook</div>

                    <div className="text-3">
                      <div className="element-service-3">
                        <div className="description-6">$10.00</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-778">
                  <img
                    className="image-39"
                    alt="Image"
                    src="/img/image-20.png"
                  />

                  <div className="frame-777">
                    <div className="title-8">Simple Science Fitness</div>

                    <div className="text-3">
                      <div className="element-service-3">
                        <div className="description-6">$10.00</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-778">
                  <img
                    className="image-40"
                    alt="Image"
                    src="/img/image-21-2x.png"
                  />

                  <div className="frame-777">
                    <div className="title-8">Dujitsu</div>

                    <div className="text-3">
                      <div className="element-service-3">
                        <div className="description-6">$10.00</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-762">
            <div className="div-11">
              <p className="text-wrapper-360">Get the help you need</p>

              <p className="text-wrapper-361">
                We&#39;re here for you, every step of the way.
              </p>
            </div>

            <img className="image-38" alt="Image" src="/img/image-22.png" />

            <div className="frame-759">
              <div className="feature-card">
                <div className="div-11">
                  <div className="text-wrapper-368">Support</div>

                  <p className="text-wrapper-369">
                    If you need any help or encounter any difficulties, our
                    support team is available 24/7 to assist you.
                  </p>

                  <div className="frame-760">
                    <div className="text-wrapper-370">Learn More</div>

                    <img
                      className="arrow-up-right"
                      alt="Arrow up right"
                      src="/img/arrow-up-right-svgrepo-com-19.svg"
                    />
                  </div>
                </div>
              </div>

              <div className="feature-card">
                <div className="div-11">
                  <div className="text-wrapper-368">Help center</div>

                  <p className="text-wrapper-371">
                    There are articles on every aspect in the help center that
                    can help you with your problem.
                  </p>

                  <div className="frame-760">
                    <div className="text-wrapper-370">Learn More</div>

                    <img
                      className="arrow-up-right"
                      alt="Arrow up right"
                      src="/img/arrow-up-right-svgrepo-com-19.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-779">
            <div className="frame-780">
              <img className="logo-2" alt="Logo" src="/img/logo-87-5.svg" />

              <div className="nav">
                <div className="text-wrapper-379">Home</div>

                <div className="text-wrapper-380">Subject</div>

                <div className="text-wrapper-380">Subject</div>
              </div>

              <div className="group-146">
                <img
                  className="ic-baseline-facebook"
                  alt="Ic baseline facebook"
                  src="/img/ic-baseline-facebook-5.svg"
                />

                <img
                  className="ph-instagram-logo"
                  alt="Ph instagram logo"
                  src="/img/ph-instagram-logo-fill-5.svg"
                />

                <img
                  className="entypo-social"
                  alt="Entypo social"
                  src="/img/entypo-social-linkedin-with-circle-5.svg"
                />
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-37"
            lineClassName="home-indicator-38"
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <>
          <div className="frame-781">
            <div className="rectangle-7" />

            <div className="frame-782">
              <div className="frame-783">
                <div className="text-wrapper-381">Home</div>
              </div>

              <div className="frame-784">
                <div className="text-wrapper-382">For Brands</div>
              </div>

              <div className="frame-785">
                <div className="text-wrapper-382">For Creators</div>
              </div>

              <div className="frame-784">
                <div className="text-wrapper-382">Pricing</div>
              </div>

              <div className="frame-785">
                <div className="text-wrapper-382">Case Studies</div>
              </div>

              <div className="frame-784">
                <div className="text-wrapper-382">Blog</div>
              </div>

              <div className="frame-784">
                <div className="text-wrapper-382">Contact Us</div>
              </div>
            </div>

            <div className="frame-786">
              <div className="frame-787">
                <div className="text-wrapper-383">Log In</div>
              </div>

              <div className="frame-788">
                <div className="text-wrapper-381">Sign Up</div>
              </div>
            </div>
          </div>

          <img
            className="frame-789"
            alt="Frame"
            src="/img/frame-1597882468-2.png"
          />

          <img
            className="frame-789"
            alt="Frame"
            src="/img/frame-1597882470-2.png"
          />

          <img
            className="frame-789"
            alt="Frame"
            src="/img/frame-1597882475-2.png"
          />

          <img
            className="frame-789"
            alt="Frame"
            src="/img/frame-1597882473-2.png"
          />

          <img
            className="frame-789"
            alt="Frame"
            src="/img/frame-1597882476-2.png"
          />

          <img
            className="frame-789"
            alt="Frame"
            src="/img/frame-1597882477-2.png"
          />

          <div className="frame-790">
            <div className="frame-791">
              <div className="logo-wrapper">
                <img className="logo-3" alt="Logo" src="/img/logo-87-4.svg" />
              </div>

              <div className="nav-2">
                <div className="text-wrapper-384">Home</div>

                <div className="text-wrapper-385">Subject</div>

                <div className="text-wrapper-385">Subject</div>
              </div>

              <div className="frame-792">
                <div className="group-146">
                  <img
                    className="ic-baseline-facebook"
                    alt="Ic baseline facebook"
                    src="/img/ic-baseline-facebook-4.svg"
                  />

                  <img
                    className="ph-instagram-logo"
                    alt="Ph instagram logo"
                    src="/img/ph-instagram-logo-fill-4.svg"
                  />

                  <img
                    className="entypo-social"
                    alt="Entypo social"
                    src="/img/entypo-social-linkedin-with-circle-4.svg"
                  />
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
