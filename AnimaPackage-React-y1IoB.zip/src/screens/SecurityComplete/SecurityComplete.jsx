import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal } from "../../icons/SearchNormal";
import "./style.css";

export const SecurityComplete = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-complete"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        height:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "956px"
            : screenWidth >= 1440
              ? "1024px"
              : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-29"} ${screenWidth >= 393 && screenWidth < 1440 && "class-30"}`}
            className={`${screenWidth < 393 && "class-31"} ${screenWidth >= 393 && screenWidth < 1440 && "class-32"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-18.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-19.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-27"} ${screenWidth >= 393 && screenWidth < 1440 && "class-28"}`}
            property1="dark"
            wiFi="/img/wi-fi-18.svg"
          />
          <div className="frame-87">
            <div className="back-icon-button-3">
              <div className="vuesax-outline-arrow-4" />
            </div>

            <div className="frame-88">
              <div className="text-wrapper-52">Complete your profile</div>
            </div>
          </div>

          <div className="frame-89">
            <div className="frame-90">
              <div className="frame-91">
                <div className="text-wrapper-53">Incomplete</div>
              </div>

              <div className="text-wrapper-54">Tax Information</div>

              <p className="text-wrapper-55">
                Get Charged the right amount of tax on your earnings.
              </p>

              <div className="frame-92">
                <div className="text-wrapper-56">Complete Now</div>
              </div>
            </div>

            <div className="frame-93">
              <div className="frame-91">
                <div className="text-wrapper-53">Incomplete</div>
              </div>

              <div className="text-wrapper-54">Payment Method</div>

              <p className="text-wrapper-55">
                Let us know where you would like your earnings paid.
              </p>

              <div className="frame-92">
                <div className="text-wrapper-56">Complete Now</div>
              </div>
            </div>

            <div className="frame-93">
              <div className="frame-91">
                <div className="text-wrapper-53">Incomplete</div>
              </div>

              <div className="text-wrapper-54">Trader Declaration</div>

              <p className="text-wrapper-55">
                We need to Understand if you’re operating as Trader on our
                platform.
              </p>

              <div className="frame-92">
                <div className="text-wrapper-56">Complete Now</div>
              </div>
            </div>

            <div className="frame-93">
              <div className="frame-91">
                <div className="text-wrapper-53">Incomplete</div>
              </div>

              <div className="text-wrapper-54">ID Check</div>

              <p className="text-wrapper-55">
                It is critical for us to confirm the identities of our authors.
              </p>

              <div className="frame-92">
                <div className="text-wrapper-56">Complete Now</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-2"
            lineClassName={`${screenWidth < 393 && "class-33"} ${screenWidth >= 393 && screenWidth < 1440 && "class-34"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-94">
          <div className="frame-95">
            <div className="frame-96">
              <div className="frame-97">
                <div className="frame-98">
                  <div className="frame-99">
                    <div className="text-wrapper-57">LOGO</div>
                  </div>
                </div>

                <div className="frame-100">
                  <div className="frame-101">
                    <img
                      className="img-4"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-58">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-96">
                <div className="frame-96">
                  <div className="frame-102">
                    <div className="img-4">
                      <div className="vuesax-linear-gift-2">
                        <img
                          className="gift-4"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-59">Products</div>
                  </div>

                  <div className="frame-102">
                    <img
                      className="img-4"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-59">Collaborators</div>
                  </div>

                  <div className="frame-102">
                    <img
                      className="img-4"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-59">Checkout</div>
                  </div>

                  <div className="frame-102">
                    <img
                      className="img-4"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-59">Emails</div>
                  </div>

                  <div className="frame-102">
                    <img
                      className="img-4"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-59">Workflows</div>
                  </div>

                  <div className="frame-102">
                    <img
                      className="img-4"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-8.svg"
                    />

                    <div className="text-wrapper-59">Sales</div>
                  </div>

                  <div className="frame-102">
                    <img
                      className="img-4"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-59">Analytics</div>
                  </div>

                  <div className="frame-102">
                    <img
                      className="img-4"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-59">Payouts</div>
                  </div>

                  <div className="frame-102">
                    <img
                      className="img-4"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-59">Library</div>
                  </div>
                </div>

                <div className="frame-102">
                  <img
                    className="img-4"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-59">Settings</div>
                </div>

                <div className="frame-102">
                  <img
                    className="img-4"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-59">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-103">
            <div className="frame-104">
              <div className="frame-105">
                <div className="frame-106">
                  <div className="text-wrapper-60">Search</div>

                  <SearchNormal
                    className="property-1-linear-11"
                    color="#232323"
                  />
                </div>
              </div>

              <div className="frame-107">
                <div className="text-wrapper-61">Login</div>
              </div>

              <div className="frame-108">
                <div className="text-wrapper-62">Sign Up</div>
              </div>
            </div>

            <div className="frame-109">
              <div className="frame-110">
                <div className="back-icon-button-3">
                  <div className="vuesax-outline-arrow-4" />
                </div>

                <div className="frame-111">
                  <div className="text-wrapper-63">Complete your profile</div>

                  <p className="text-wrapper-64">
                    Complete your profile by filling in all the necessary
                    details, such as your personal information, preferences, and
                    interests, to help ensure that you get the most personalized
                    experience and connect with others more effectively.
                  </p>
                </div>
              </div>

              <div className="frame-112">
                <div className="frame-113">
                  <div className="frame-114">
                    <div className="frame-115">
                      <div className="text-wrapper-53">Incomplete</div>
                    </div>

                    <div className="text-wrapper-54">Tax Information</div>

                    <p className="text-wrapper-65">
                      Get Charged the right amount of tax on your earnings.
                    </p>

                    <div className="frame-116">
                      <div className="text-wrapper-56">Complete Now</div>
                    </div>
                  </div>
                </div>

                <div className="frame-117">
                  <div className="frame-91">
                    <div className="text-wrapper-53">Incomplete</div>
                  </div>

                  <div className="text-wrapper-54">Payment Method</div>

                  <p className="text-wrapper-65">
                    Let us know where you would like your earnings paid.
                  </p>

                  <div className="frame-92">
                    <div className="text-wrapper-56">Complete Now</div>
                  </div>
                </div>

                <div className="frame-118">
                  <div className="frame-91">
                    <div className="text-wrapper-53">Incomplete</div>
                  </div>

                  <div className="text-wrapper-54">Trader Declaration</div>

                  <p className="text-wrapper-55">
                    We need to Understand if you’re operating as Trader on our
                    platform.
                  </p>

                  <div className="frame-92">
                    <div className="text-wrapper-56">Complete Now</div>
                  </div>
                </div>

                <div className="frame-117">
                  <div className="frame-91">
                    <div className="text-wrapper-53">Incomplete</div>
                  </div>

                  <div className="text-wrapper-54">ID Check</div>

                  <p className="text-wrapper-65">
                    It is critical for us to confirm the identities of our
                    authors.
                  </p>

                  <div className="frame-92">
                    <div className="text-wrapper-56">Complete Now</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
