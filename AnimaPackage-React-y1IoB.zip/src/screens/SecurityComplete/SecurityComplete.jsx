import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const SecurityComplete = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-complete"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        height:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "956px"
            : screenWidth >= 1440
              ? "1024px"
              : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-57"} ${screenWidth >= 393 && screenWidth < 1440 && "class-58"}`}
            className={`${screenWidth < 393 && "class-59"} ${screenWidth >= 393 && screenWidth < 1440 && "class-60"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-18.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-19.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-61"} ${screenWidth >= 393 && screenWidth < 1440 && "class-62"}`}
            property1="dark"
            wiFi="/img/wi-fi-18.svg"
          />
          <div className="frame-386">
            <div className="back-icon-button-10">
              <div className="vuesax-outline-arrow-11" />
            </div>

            <div className="frame-387">
              <div className="text-wrapper-261">Complete your profile</div>
            </div>
          </div>

          <div className="frame-388">
            <div className="frame-389">
              <div className="frame-390">
                <div className="text-wrapper-262">Incomplete</div>
              </div>

              <div className="text-wrapper-263">Tax Information</div>

              <p className="text-wrapper-264">
                Get Charged the right amount of tax on your earnings.
              </p>

              <div className="frame-391">
                <div className="text-wrapper-265">Complete Now</div>
              </div>
            </div>

            <div className="frame-392">
              <div className="frame-390">
                <div className="text-wrapper-262">Incomplete</div>
              </div>

              <div className="text-wrapper-263">Payment Method</div>

              <p className="text-wrapper-264">
                Let us know where you would like your earnings paid.
              </p>

              <div className="frame-391">
                <div className="text-wrapper-265">Complete Now</div>
              </div>
            </div>

            <div className="frame-392">
              <div className="frame-390">
                <div className="text-wrapper-262">Incomplete</div>
              </div>

              <div className="text-wrapper-263">Trader Declaration</div>

              <p className="text-wrapper-264">
                We need to Understand if you’re operating as Trader on our
                platform.
              </p>

              <div className="frame-391">
                <div className="text-wrapper-265">Complete Now</div>
              </div>
            </div>

            <div className="frame-392">
              <div className="frame-390">
                <div className="text-wrapper-262">Incomplete</div>
              </div>

              <div className="text-wrapper-263">ID Check</div>

              <p className="text-wrapper-264">
                It is critical for us to confirm the identities of our authors.
              </p>

              <div className="frame-391">
                <div className="text-wrapper-265">Complete Now</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-11"
            lineClassName={`${screenWidth < 393 && "class-63"} ${screenWidth >= 393 && screenWidth < 1440 && "class-64"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-393">
          <div className="frame-394">
            <div className="frame-395">
              <div className="frame-396">
                <div className="frame-397">
                  <div className="frame-398">
                    <div className="text-wrapper-266">LOGO</div>
                  </div>
                </div>

                <div className="frame-399">
                  <div className="frame-400">
                    <img
                      className="img-20"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-267">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-395">
                <div className="frame-395">
                  <div className="frame-401">
                    <div className="img-20">
                      <div className="vuesax-linear-gift-9">
                        <img
                          className="gift-11"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-268">Products</div>
                  </div>

                  <div className="frame-401">
                    <img
                      className="img-20"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-268">Collaborators</div>
                  </div>

                  <div className="frame-401">
                    <img
                      className="img-20"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-268">Checkout</div>
                  </div>

                  <div className="frame-401">
                    <img
                      className="img-20"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-268">Emails</div>
                  </div>

                  <div className="frame-401">
                    <img
                      className="img-20"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-268">Workflows</div>
                  </div>

                  <div className="frame-401">
                    <img
                      className="img-20"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-8.svg"
                    />

                    <div className="text-wrapper-268">Sales</div>
                  </div>

                  <div className="frame-401">
                    <img
                      className="img-20"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-268">Analytics</div>
                  </div>

                  <div className="frame-401">
                    <img
                      className="img-20"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-268">Payouts</div>
                  </div>

                  <div className="frame-401">
                    <img
                      className="img-20"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-268">Library</div>
                  </div>
                </div>

                <div className="frame-401">
                  <img
                    className="img-20"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-268">Settings</div>
                </div>

                <div className="frame-401">
                  <img
                    className="img-20"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-268">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-402">
            <div className="frame-403">
              <div className="frame-404">
                <div className="frame-405">
                  <div className="text-wrapper-269">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-406">
                <div className="text-wrapper-270">Login</div>
              </div>

              <div className="frame-407">
                <div className="text-wrapper-271">Sign Up</div>
              </div>
            </div>

            <div className="frame-408">
              <div className="frame-409">
                <div className="back-icon-button-10">
                  <div className="vuesax-outline-arrow-11" />
                </div>

                <div className="frame-410">
                  <div className="text-wrapper-272">Complete your profile</div>

                  <p className="text-wrapper-273">
                    Complete your profile by filling in all the necessary
                    details, such as your personal information, preferences, and
                    interests, to help ensure that you get the most personalized
                    experience and connect with others more effectively.
                  </p>
                </div>
              </div>

              <div className="frame-411">
                <div className="frame-412">
                  <div className="frame-413">
                    <div className="frame-414">
                      <div className="text-wrapper-262">Incomplete</div>
                    </div>

                    <div className="text-wrapper-263">Tax Information</div>

                    <p className="text-wrapper-274">
                      Get Charged the right amount of tax on your earnings.
                    </p>

                    <div className="frame-415">
                      <div className="text-wrapper-265">Complete Now</div>
                    </div>
                  </div>
                </div>

                <div className="frame-416">
                  <div className="frame-390">
                    <div className="text-wrapper-262">Incomplete</div>
                  </div>

                  <div className="text-wrapper-263">Payment Method</div>

                  <p className="text-wrapper-274">
                    Let us know where you would like your earnings paid.
                  </p>

                  <div className="frame-391">
                    <div className="text-wrapper-265">Complete Now</div>
                  </div>
                </div>

                <div className="frame-417">
                  <div className="frame-390">
                    <div className="text-wrapper-262">Incomplete</div>
                  </div>

                  <div className="text-wrapper-263">Trader Declaration</div>

                  <p className="text-wrapper-264">
                    We need to Understand if you’re operating as Trader on our
                    platform.
                  </p>

                  <div className="frame-391">
                    <div className="text-wrapper-265">Complete Now</div>
                  </div>
                </div>

                <div className="frame-416">
                  <div className="frame-390">
                    <div className="text-wrapper-262">Incomplete</div>
                  </div>

                  <div className="text-wrapper-263">ID Check</div>

                  <p className="text-wrapper-274">
                    It is critical for us to confirm the identities of our
                    authors.
                  </p>

                  <div className="frame-391">
                    <div className="text-wrapper-265">Complete Now</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
