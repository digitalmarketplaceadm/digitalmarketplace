import React from "react";
import { Link } from "react-router-dom";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const SecurityComplete = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-complete"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        height:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "956px"
            : screenWidth >= 1440
              ? "1024px"
              : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-11"} ${screenWidth >= 393 && screenWidth < 1440 && "class-12"}`}
            className={`${screenWidth < 393 && "class-9"} ${screenWidth >= 393 && screenWidth < 1440 && "class-10"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-38.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-39.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-13"} ${screenWidth >= 393 && screenWidth < 1440 && "class-14"}`}
            property1="dark"
            wiFi="/img/wi-fi-23.svg"
          />
          <div className="frame-135">
            <div className="back-icon-button-9">
              <div className="vuesax-outline-arrow-5" />
            </div>

            <div className="frame-136">
              <div className="text-wrapper-76">Complete your profile</div>
            </div>
          </div>

          <div className="frame-137">
            <div className="frame-138">
              <div className="frame-139">
                <div className="text-wrapper-77">Incomplete</div>
              </div>

              <div className="text-wrapper-78">Tax Information</div>

              <p className="text-wrapper-79">
                Get Charged the right amount of tax on your earnings.
              </p>

              <div className="frame-140">
                <div className="text-wrapper-80">Complete Now</div>
              </div>
            </div>

            <div className="frame-141">
              <div className="frame-139">
                <div className="text-wrapper-77">Incomplete</div>
              </div>

              <div className="text-wrapper-78">Payment Method</div>

              <p className="text-wrapper-79">
                Let us know where you would like your earnings paid.
              </p>

              <div className="frame-140">
                <div className="text-wrapper-80">Complete Now</div>
              </div>
            </div>

            <div className="frame-141">
              <div className="frame-139">
                <div className="text-wrapper-77">Incomplete</div>
              </div>

              <div className="text-wrapper-78">Trader Declaration</div>

              <p className="text-wrapper-79">
                We need to Understand if you’re operating as Trader on our
                platform.
              </p>

              <div className="frame-140">
                <div className="text-wrapper-80">Complete Now</div>
              </div>
            </div>

            <div className="frame-141">
              <div className="frame-139">
                <div className="text-wrapper-77">Incomplete</div>
              </div>

              <div className="text-wrapper-78">ID Check</div>

              <p className="text-wrapper-79">
                It is critical for us to confirm the identities of our authors.
              </p>

              <div className="frame-140">
                <div className="text-wrapper-80">Complete Now</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-10"
            lineClassName={`${screenWidth < 393 && "class-15"} ${screenWidth >= 393 && screenWidth < 1440 && "class-16"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-142">
          <div className="frame-143">
            <div className="frame-144">
              <div className="frame-145">
                <div className="frame-146">
                  <div className="frame-147">
                    <div className="text-wrapper-81">LOGO</div>
                  </div>
                </div>

                <div className="frame-148">
                  <div className="frame-149">
                    <img
                      className="img-11"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-11.svg"
                    />

                    <div className="text-wrapper-82">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-144">
                <div className="frame-144">
                  <Link className="frame-150" to="/products-1">
                    <div className="img-11">
                      <div className="vuesax-linear-gift-3">
                        <img
                          className="gift-6"
                          alt="Gift"
                          src="/img/gift-8.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-83">Products</div>
                  </Link>

                  <div className="frame-150">
                    <img
                      className="img-11"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-5.svg"
                    />

                    <div className="text-wrapper-83">Collaborators</div>
                  </div>

                  <div className="frame-150">
                    <img
                      className="img-11"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-6-3.svg"
                    />

                    <div className="text-wrapper-83">Checkout</div>
                  </div>

                  <div className="frame-150">
                    <img
                      className="img-11"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-83">Emails</div>
                  </div>

                  <div className="frame-150">
                    <img
                      className="img-11"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-8.svg"
                    />

                    <div className="text-wrapper-83">Workflows</div>
                  </div>

                  <div className="frame-150">
                    <img
                      className="img-11"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-10.svg"
                    />

                    <div className="text-wrapper-83">Sales</div>
                  </div>

                  <div className="frame-150">
                    <img
                      className="img-11"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-83">Analytics</div>
                  </div>

                  <div className="frame-150">
                    <img
                      className="img-11"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-10.svg"
                    />

                    <div className="text-wrapper-83">Payouts</div>
                  </div>

                  <div className="frame-150">
                    <img
                      className="img-11"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-8.svg"
                    />

                    <div className="text-wrapper-83">Library</div>
                  </div>
                </div>

                <div className="frame-150">
                  <img
                    className="img-11"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-5.svg"
                  />

                  <div className="text-wrapper-83">Settings</div>
                </div>

                <div className="frame-150">
                  <img
                    className="img-11"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-83">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-151">
            <div className="frame-152">
              <div className="frame-153">
                <div className="frame-154">
                  <div className="text-wrapper-84">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-155">
                <div className="text-wrapper-85">Login</div>
              </div>

              <div className="frame-156">
                <div className="text-wrapper-86">Sign Up</div>
              </div>
            </div>

            <div className="frame-157">
              <div className="frame-158">
                <div className="back-icon-button-9">
                  <div className="vuesax-outline-arrow-5" />
                </div>

                <div className="frame-159">
                  <div className="text-wrapper-87">Complete your profile</div>

                  <p className="text-wrapper-88">
                    Complete your profile by filling in all the necessary
                    details, such as your personal information, preferences, and
                    interests, to help ensure that you get the most personalized
                    experience and connect with others more effectively.
                  </p>
                </div>
              </div>

              <div className="frame-160">
                <div className="frame-161">
                  <div className="frame-162">
                    <div className="frame-163">
                      <div className="text-wrapper-77">Incomplete</div>
                    </div>

                    <div className="text-wrapper-78">Tax Information</div>

                    <p className="text-wrapper-89">
                      Get Charged the right amount of tax on your earnings.
                    </p>

                    <div className="frame-164">
                      <div className="text-wrapper-80">Complete Now</div>
                    </div>
                  </div>
                </div>

                <div className="frame-165">
                  <div className="frame-139">
                    <div className="text-wrapper-77">Incomplete</div>
                  </div>

                  <div className="text-wrapper-78">Payment Method</div>

                  <p className="text-wrapper-89">
                    Let us know where you would like your earnings paid.
                  </p>

                  <div className="frame-140">
                    <div className="text-wrapper-80">Complete Now</div>
                  </div>
                </div>

                <div className="frame-166">
                  <div className="frame-139">
                    <div className="text-wrapper-77">Incomplete</div>
                  </div>

                  <div className="text-wrapper-78">Trader Declaration</div>

                  <p className="text-wrapper-79">
                    We need to Understand if you’re operating as Trader on our
                    platform.
                  </p>

                  <div className="frame-140">
                    <div className="text-wrapper-80">Complete Now</div>
                  </div>
                </div>

                <div className="frame-165">
                  <div className="frame-139">
                    <div className="text-wrapper-77">Incomplete</div>
                  </div>

                  <div className="text-wrapper-78">ID Check</div>

                  <p className="text-wrapper-89">
                    It is critical for us to confirm the identities of our
                    authors.
                  </p>

                  <div className="frame-140">
                    <div className="text-wrapper-80">Complete Now</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
