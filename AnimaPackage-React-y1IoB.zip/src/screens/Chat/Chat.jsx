import React from "react";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const Chat = () => {
  return (
    <div className="chat">
      <StatusBar
        actionClassName="status-bar-69"
        batteryClassName="status-bar-72"
        className="status-bar-68"
        combinedShape="/img/combined-shape-2.svg"
        containerClassName="status-bar-71"
        property1="dark"
        rectangleClassName="status-bar-73"
        timeClassName="status-bar-70"
        wiFi="/img/wi-fi-2.svg"
      />
      <div className="frame-374">
        <div className="back-icon-button-25">
          <div className="vuesax-outline-arrow-14" />
        </div>

        <div className="frame-375">
          <img
            className="ellipse-15"
            alt="Ellipse"
            src="/img/ellipse-52-2x.png"
          />

          <div className="frame-376">
            <div className="text-wrapper-182">Ethan Carter</div>

            <div className="frame-377">
              <div className="ellipse-16" />

              <div className="text-wrapper-183">Online</div>
            </div>
          </div>
        </div>
      </div>

      <div className="image-23">
        <div className="frame-378">
          <div className="text-wrapper-184">Yesterday</div>

          <div className="frame-379">
            <img
              className="ellipse-15"
              alt="Ellipse"
              src="/img/ellipse-52-2x.png"
            />

            <div className="frame-380">
              <div className="frame-381">
                <p className="text-wrapper-185">
                  I have a big project in mind.
                </p>
              </div>

              <div className="text-wrapper-186">1:05pm</div>
            </div>
          </div>

          <div className="frame-382">
            <div className="frame-383">
              <div className="text-wrapper-187">that sounds great!</div>
            </div>

            <div className="text-wrapper-188">1:02pm</div>
          </div>

          <div className="frame-382">
            <div className="frame-383">
              <div className="text-wrapper-187">that sounds great!</div>
            </div>

            <div className="frame-383">
              <p className="text-wrapper-187">
                let me know what’s in your mind
              </p>
            </div>

            <div className="text-wrapper-188">1:02pm</div>
          </div>

          <div className="frame-379">
            <img
              className="ellipse-15"
              alt="Ellipse"
              src="/img/ellipse-52-2x.png"
            />

            <div className="frame-380">
              <div className="frame-381">
                <p className="text-wrapper-185">
                  I’d like to have a booking website
                </p>
              </div>

              <div className="frame-384">
                <div className="text-wrapper-185">similar to AirBnB</div>
              </div>

              <div className="text-wrapper-189">1:05pm</div>
            </div>
          </div>

          <div className="frame-385">
            <div className="frame-382">
              <div className="frame-386">
                <p className="text-wrapper-190">
                  great! just send me the whole documents for this website
                </p>
              </div>
            </div>

            <div className="text-wrapper-188">1:02pm</div>
          </div>

          <div className="text-wrapper-184">Today</div>

          <div className="frame-379">
            <img
              className="ellipse-15"
              alt="Ellipse"
              src="/img/ellipse-52-2x.png"
            />

            <div className="frame-380">
              <div className="frame-381">
                <p className="text-wrapper-191">
                  I jut sent to your email , let me know if you received it
                </p>
              </div>

              <div className="text-wrapper-186">6:01am</div>
            </div>
          </div>

          <div className="frame-382">
            <div className="frame-382">
              <div className="frame-383">
                <div className="text-wrapper-187">Received!</div>
              </div>
            </div>

            <div className="text-wrapper-188">1:02pm</div>
          </div>

          <div className="frame-379">
            <img
              className="ellipse-15"
              alt="Ellipse"
              src="/img/ellipse-52-2x.png"
            />

            <div className="frame-380">
              <div className="frame-381">
                <p className="text-wrapper-185">
                  let me know if you have questions!
                </p>
              </div>

              <div className="text-wrapper-189">9:01am</div>
            </div>
          </div>
        </div>
      </div>

      <div className="frame-387">
        <div className="frame-388">
          <img
            className="group-wrapper-2"
            alt="Plus svgrepo com"
            src="/img/plus-svgrepo-com.svg"
          />

          <div className="group-wrapper-2">
            <img
              className="group-73"
              alt="Group"
              src="/img/group-1272630336.png"
            />
          </div>

          <div className="group-wrapper-2">
            <img
              className="group-74"
              alt="Group"
              src="/img/group-1272630337-1.png"
            />
          </div>

          <div className="microphone-svgrepo">
            <img className="group-75" alt="Group" src="/img/group-289574.png" />
          </div>

          <div className="frame-389">
            <div className="text-wrapper-192">Hi I saw som.</div>

            <img className="vector-51" alt="Vector" src="/img/vector-92.svg" />
          </div>

          <div className="vector-wrapper">
            <img className="vector-52" alt="Vector" src="/img/vector-93.svg" />
          </div>
        </div>
      </div>

      <HomeIndicator
        className="home-indicator-27"
        lineClassName="home-indicator-28"
        property1="dark"
      />
    </div>
  );
};
