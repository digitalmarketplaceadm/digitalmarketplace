import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const Home = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="home"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "var(--variable-collection-white-duplicate)"
            : screenWidth >= 1440
              ? "var(--variable-collection-fill-duplicate)"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "100vh"
            : screenWidth >= 1440
              ? "1024px"
              : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-29"} ${screenWidth >= 393 && screenWidth < 1440 && "class-30"}`}
            className={`${screenWidth < 393 && "class-27"} ${screenWidth >= 393 && screenWidth < 1440 && "class-28"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-22.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-26.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-31"} ${screenWidth >= 393 && screenWidth < 1440 && "class-32"}`}
            property1="dark"
            rectangleClassName="status-bar-77"
            timeClassName="status-bar-76"
            wiFi="/img/wi-fi-22.svg"
          />
          <div className="frame-451">
            <div className="back-icon-button-28">
              <div className="img-23">
                <div className="notification-10">
                  <div className="vuesax-linear-10">
                    <div className="notification-11">
                      <img
                        className="group-92"
                        alt="Group"
                        src={
                          screenWidth < 393
                            ? "/img/group-33845-3.png"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/group-33845-1.png"
                              : undefined
                        }
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="back-icon-button-28">
              <img
                className="img-23"
                alt="Messenger fill"
                src={
                  screenWidth < 393
                    ? "/img/messenger-fill-svgrepo-com-3.svg"
                    : screenWidth >= 393 && screenWidth < 1440
                      ? "/img/messenger-fill-svgrepo-com-1-2.svg"
                      : undefined
                }
              />
            </div>
          </div>

          <div className="frame-452">
            <div className="frame-453">
              <div className="text-wrapper-223">Welcome to Gumroad!</div>
            </div>

            <div className="frame-454">
              <div className="frame-455">
                <div className="text-wrapper-224">Search</div>

                <SearchNormal property1="linear" />
              </div>
            </div>

            <div className="frame-456">
              <div className="frame-457">
                <div className="frame-458">
                  <img
                    className="img-24"
                    alt="Category svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/category-svgrepo-com-2.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/category-svgrepo-com.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="text-wrapper-225">Categories</div>
              </div>

              <div className="frame-457">
                <div className="frame-458">
                  <img
                    className="img-24"
                    alt="Pencil svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/pencil-svgrepo-com-7.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/pencil-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="text-wrapper-225">Publish</div>
              </div>

              <div className="frame-457">
                <div className="frame-458">
                  <div className="img-24">
                    <img
                      className="group-93"
                      alt="Group"
                      src={
                        screenWidth < 393
                          ? "/img/group-40.png"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/group-36.png"
                            : undefined
                      }
                    />
                  </div>
                </div>

                <div className="text-wrapper-225">Answer</div>
              </div>
            </div>
          </div>

          <div className="frame-459">
            <div className="BNB-9">
              <div className="navigation-menu-10">
                <img
                  className="home-svgrepo-com-7"
                  alt="Home svgrepo com"
                  src={
                    screenWidth < 393
                      ? "/img/home-svgrepo-com-3.svg"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "/img/home-svgrepo-com-1-3.svg"
                        : undefined
                  }
                />

                <div
                  className="text-wrapper-226"
                  style={{
                    marginLeft: screenWidth < 393 ? "-5.20px" : undefined,
                    marginRight: screenWidth < 393 ? "-5.20px" : undefined,
                  }}
                >
                  Home
                </div>
              </div>

              <div className="navigation-menu-10">
                <SearchNormal property1="linear" />
                <div
                  className="text-wrapper-227"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-7.70px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-0.40px"
                          : undefined,
                    marginRight:
                      screenWidth < 393
                        ? "-7.70px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-0.40px"
                          : undefined,
                  }}
                >
                  Search
                </div>
              </div>

              <div className="navigation-menu-10">
                <div
                  className="group-94"
                  style={{
                    backgroundImage:
                      screenWidth < 393
                        ? "url(/img/cart-svgrepo-com-9.svg)"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "url(/img/cart-svgrepo-com-7.svg)"
                          : undefined,
                  }}
                />

                <div
                  className="text-wrapper-228"
                  style={{
                    marginLeft: screenWidth < 393 ? "-0.20px" : undefined,
                    marginRight: screenWidth < 393 ? "-0.20px" : undefined,
                  }}
                >
                  Cart
                </div>
              </div>

              <div className="navigation-menu-10">
                <div className="home-svgrepo-com-7">
                  <div className="frame-460">
                    <div className="headset-svgrepo-com-6">
                      <div className="overlap-group-9">
                        <img
                          className="vector-67"
                          alt="Vector"
                          src={
                            screenWidth < 393
                              ? "/img/vector-56.svg"
                              : screenWidth >= 393 && screenWidth < 1440
                                ? "/img/vector-50.svg"
                                : undefined
                          }
                        />

                        <img
                          className="vector-68"
                          alt="Vector"
                          src={
                            screenWidth < 393
                              ? "/img/vector-57.svg"
                              : screenWidth >= 393 && screenWidth < 1440
                                ? "/img/vector-51.svg"
                                : undefined
                          }
                        />

                        <img
                          className="vector-69"
                          alt="Vector"
                          src={
                            screenWidth < 393
                              ? "/img/vector-58.svg"
                              : screenWidth >= 393 && screenWidth < 1440
                                ? "/img/vector-52.svg"
                                : undefined
                          }
                        />

                        <img
                          className="vector-70"
                          alt="Vector"
                          src={
                            screenWidth < 393
                              ? "/img/vector-59.svg"
                              : screenWidth >= 393 && screenWidth < 1440
                                ? "/img/vector-53.svg"
                                : undefined
                          }
                        />

                        <img
                          className="vector-71"
                          alt="Vector"
                          src={
                            screenWidth < 393
                              ? "/img/vector-60.svg"
                              : screenWidth >= 393 && screenWidth < 1440
                                ? "/img/vector-54.svg"
                                : undefined
                          }
                        />

                        <img
                          className="vector-72"
                          alt="Vector"
                          src={
                            screenWidth < 393
                              ? "/img/vector-61.svg"
                              : screenWidth >= 393 && screenWidth < 1440
                                ? "/img/vector-55.svg"
                                : undefined
                          }
                        />

                        <img
                          className="group-95"
                          alt="Group"
                          src={
                            screenWidth < 393
                              ? "/img/group-41.png"
                              : screenWidth >= 393 && screenWidth < 1440
                                ? "/img/group-37.png"
                                : undefined
                          }
                        />

                        <img
                          className="group-96"
                          alt="Group"
                          src={
                            screenWidth < 393
                              ? "/img/group-42.png"
                              : screenWidth >= 393 && screenWidth < 1440
                                ? "/img/group-38.png"
                                : undefined
                          }
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div
                  className="text-wrapper-229"
                  style={{
                    marginLeft: screenWidth < 393 ? "-1.20px" : undefined,
                    marginRight: screenWidth < 393 ? "-1.20px" : undefined,
                  }}
                >
                  Help
                </div>
              </div>

              <div className="navigation-menu-10">
                <img
                  className="image-27"
                  alt="Image"
                  src="/img/image-6-2x.png"
                />

                <div
                  className="text-wrapper-230"
                  style={{
                    marginLeft: screenWidth < 393 ? "-6.20px" : undefined,
                    marginRight: screenWidth < 393 ? "-6.20px" : undefined,
                  }}
                >
                  Profile
                </div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-30"
            lineClassName={`${screenWidth < 393 && "class-33"} ${screenWidth >= 393 && screenWidth < 1440 && "class-34"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-461">
          <div className="frame-462">
            <div className="frame-463">
              <div className="frame-464">
                <div className="frame-465">
                  <div className="frame-466">
                    <div className="text-wrapper-231">LOGO</div>
                  </div>
                </div>
              </div>

              <div className="frame-463">
                <div className="frame-463">
                  <div className="frame-467">
                    <div className="frame-468">
                      <img
                        className="home-svgrepo-com-7"
                        alt="Home svgrepo com"
                        src="/img/home-svgrepo-com-2-2.svg"
                      />

                      <div className="text-wrapper-232">Home</div>
                    </div>

                    <div className="frame-468">
                      <img
                        className="img-25"
                        alt="Security safe"
                        src="/img/security-safe-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-233">Security</div>
                    </div>

                    <div className="frame-468">
                      <div className="gift-19">
                        <div className="vuesax-linear-gift-11">
                          <img
                            className="gift-20"
                            alt="Gift"
                            src="/img/gift-6-2.png"
                          />
                        </div>
                      </div>

                      <div className="text-wrapper-233">Products</div>
                    </div>

                    <div className="frame-468">
                      <img
                        className="img-25"
                        alt="Advertising svgrepo"
                        src="/img/advertising-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-233">Marketing</div>
                    </div>

                    <div className="frame-468">
                      <img
                        className="img-25"
                        alt="Cart large svgrepo"
                        src="/img/cart-large-4-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-233">Your Store</div>
                    </div>

                    <div className="frame-468">
                      <img
                        className="img-25"
                        alt="People svgrepo com"
                        src="/img/people-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-233">Collaborators</div>
                    </div>

                    <div className="frame-468">
                      <div className="group-97" />

                      <div className="text-wrapper-233">Checkout</div>
                    </div>

                    <div className="frame-468">
                      <div className="img-25">
                        <div className="email-svgrepo-9">
                          <div className="page-10" />
                        </div>
                      </div>

                      <div className="text-wrapper-233">Emails</div>
                    </div>

                    <div className="frame-468">
                      <img
                        className="img-25"
                        alt="Flow parallel"
                        src="/img/flow-parallel-svgrepo-com-6-3.svg"
                      />

                      <div className="text-wrapper-233">Workflows</div>
                    </div>

                    <div className="frame-468">
                      <img
                        className="img-25"
                        alt="Coin svgrepo com"
                        src="/img/coin-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-233">Sales</div>
                    </div>

                    <div className="frame-468">
                      <img
                        className="img-25"
                        alt="Graph svgrepo com"
                        src="/img/graph-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-233">Analytics</div>
                    </div>

                    <div className="frame-468">
                      <img
                        className="img-25"
                        alt="Coin svgrepo com"
                        src="/img/coin-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-233">Payouts</div>
                    </div>

                    <div className="frame-468">
                      <img
                        className="img-25"
                        alt="Book bookmark"
                        src="/img/book-bookmark-minimalistic-svgrepo-com-6-3.svg"
                      />

                      <div className="text-wrapper-233">Library</div>
                    </div>
                  </div>
                </div>

                <div className="frame-468">
                  <img
                    className="img-25"
                    alt="Setting svgrepo"
                    src="/img/setting-2-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-233">Settings</div>
                </div>

                <div className="frame-468">
                  <img
                    className="img-25"
                    alt="Open book svgrepo"
                    src="/img/open-book-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-233">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-469">
            <div className="frame-470">
              <div className="frame-471">
                <div className="frame-455">
                  <div className="text-wrapper-224">Real Estate</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="back-icon-button-29">
                <div className="img-25">
                  <div className="vuesax-linear-11">
                    <div className="notification-12">
                      <img
                        className="group-98"
                        alt="Group"
                        src="/img/group-33845.png"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="back-icon-button-29">
                <img
                  className="img-25"
                  alt="Messenger fill"
                  src="/img/messenger-fill-svgrepo-com-2-2.svg"
                />
              </div>

              <div className="frame-472">
                <div className="frame-473">
                  <img
                    className="ellipse-26"
                    alt="Ellipse"
                    src="/img/ellipse-52.png"
                  />

                  <div className="frame-474">
                    <div className="text-wrapper-234">Lenny White</div>
                  </div>
                </div>

                <img
                  className="img-23"
                  alt="Expand more"
                  src="/img/expand-more-1-4.svg"
                />
              </div>
            </div>

            <div className="frame-475">
              <div className="text-wrapper-235">Welcome to Gumroad!</div>

              <div className="frame-454">
                <div className="frame-455">
                  <div className="text-wrapper-224">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-476">
                <div className="frame-477">
                  <div className="frame-478">
                    <img
                      className="answer-public"
                      alt="Category svgrepo com"
                      src="/img/category-svgrepo-com-1.svg"
                    />
                  </div>

                  <div className="text-wrapper-234">Search</div>
                </div>

                <div className="frame-477">
                  <div className="frame-478">
                    <img
                      className="pencil-svgrepo-com"
                      alt="Pencil svgrepo com"
                      src="/img/pencil-svgrepo-com-6.svg"
                    />
                  </div>

                  <div className="text-wrapper-236">Publish</div>
                </div>

                <div className="frame-477">
                  <div className="frame-478">
                    <div className="answer-public">
                      <img
                        className="group-99"
                        alt="Group"
                        src="/img/group-39.png"
                      />
                    </div>
                  </div>

                  <div className="text-wrapper-236">Answer</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
