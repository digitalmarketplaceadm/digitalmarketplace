import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal } from "../../icons/SearchNormal";
import { SearchNormal2 } from "../../icons/SearchNormal2";
import { VuesaxLinearSms1 } from "../../icons/VuesaxLinearSms1";
import "./style.css";

export const Home = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="home"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        height: screenWidth >= 1440 ? "1024px" : undefined,
        minHeight:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "100vh"
            : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-45"} ${screenWidth >= 393 && screenWidth < 1440 && "class-46"}`}
            className={`${screenWidth < 393 && "class-47"} ${screenWidth >= 393 && screenWidth < 1440 && "class-48"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-2.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-3.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-43"} ${screenWidth >= 393 && screenWidth < 1440 && "class-44"}`}
            property1="dark"
            wiFi="/img/wi-fi-2.svg"
          />
          <div className="frame-154">
            <div className="back-icon-button-5">
              <VuesaxLinearSms1 className="instance-node-2" />
            </div>

            <div className="back-icon-button-5">
              <div className="frame-155" />
            </div>
          </div>

          <div className="frame-156">
            <div className="frame-157">
              <div className="text-wrapper-83">Welcome to Gumroad!</div>
            </div>

            <div className="frame-158">
              <div className="frame-159">
                <div className="text-wrapper-84">Search</div>

                <SearchNormal2 className="instance-node-2" />
              </div>
            </div>

            <div className="frame-160">
              <div className="frame-161">
                <div className="frame-162">
                  <div
                    className="category-svgrepo-com"
                    style={{
                      backgroundImage:
                        screenWidth < 393
                          ? "url(/img/clip-path-group-1.png)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(/img/clip-path-group-2.png)"
                            : undefined,
                    }}
                  />
                </div>

                <div className="text-wrapper-85">Categories</div>
              </div>

              <div className="frame-161">
                <div className="frame-162">
                  <img
                    className="img-11"
                    alt="Pen square svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/pen-square-svgrepo-com-1.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/pen-square-svgrepo-com-2.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="text-wrapper-85">Publish</div>
              </div>

              <div className="frame-161">
                <div className="frame-162">
                  <img
                    className="img-11"
                    alt="Check square svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/check-square-svgrepo-com-1.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/check-square-svgrepo-com-2.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="text-wrapper-85">Answer</div>
              </div>
            </div>
          </div>

          <div
            className="frame-163"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-2">
              {screenWidth < 393 && (
                <div className="frame-164">
                  <div className="navigation-menu-home-wrapper">
                    <div className="navigation-menu-home-3">
                      <img
                        className="img-12"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-1.svg"
                      />

                      <div className="text-wrapper-86">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-3">
                    <SearchNormal className="img-13" color="#535353" />
                    <div className="text-wrapper-87">Search</div>
                  </div>

                  <div className="navigation-menu-3">
                    <img
                      className="img-13"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-88">Cart</div>
                  </div>

                  <div className="navigation-menu-3">
                    <img
                      className="img-13"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-89">Help</div>
                  </div>

                  <div className="navigation-menu-3">
                    <img className="image-3" alt="Image" src="/img/image.png" />

                    <div className="text-wrapper-90">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1440 && (
                <>
                  <div className="navigation-menu-home-wrapper">
                    <div className="navigation-menu-home-3">
                      <img
                        className="img-12"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-1.svg"
                      />

                      <div className="text-wrapper-86">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-3">
                    <SearchNormal className="img-12" color="#535353" />
                    <div className="text-wrapper-91">Search</div>
                  </div>

                  <div className="navigation-menu-3">
                    <img
                      className="img-12"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-1.svg"
                    />

                    <div className="text-wrapper-92">Cart</div>
                  </div>

                  <div className="navigation-menu-3">
                    <img
                      className="img-12"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-1.svg"
                    />

                    <div className="text-wrapper-92">Help</div>
                  </div>

                  <div className="navigation-menu-3">
                    <img className="image-4" alt="Image" src="/img/image.png" />

                    <div className="text-wrapper-93">Profile</div>
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-4"
            lineClassName={`${screenWidth < 393 && "class-49"} ${screenWidth >= 393 && screenWidth < 1440 && "class-50"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-165">
          <div className="frame-166">
            <div className="frame-167">
              <div className="frame-168">
                <div className="frame-169">
                  <div className="frame-170">
                    <div className="text-wrapper-94">LOGO</div>
                  </div>
                </div>

                <div className="frame-171">
                  <div className="frame-172">
                    <img
                      className="img-14"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-95">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-167">
                <div className="frame-167">
                  <div className="frame-173">
                    <div className="img-14">
                      <div className="vuesax-linear-gift-4">
                        <img
                          className="gift-6"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-96">Products</div>
                  </div>

                  <div className="frame-173">
                    <img
                      className="img-14"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-96">Collaborators</div>
                  </div>

                  <div className="frame-173">
                    <img
                      className="img-14"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-96">Checkout</div>
                  </div>

                  <div className="frame-173">
                    <img
                      className="img-14"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-96">Emails</div>
                  </div>

                  <div className="frame-173">
                    <img
                      className="img-14"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-96">Workflows</div>
                  </div>

                  <div className="frame-173">
                    <img
                      className="img-14"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-96">Sales</div>
                  </div>

                  <div className="frame-173">
                    <img
                      className="img-14"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-96">Analytics</div>
                  </div>

                  <div className="frame-173">
                    <img
                      className="img-14"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-96">Payouts</div>
                  </div>

                  <div className="frame-173">
                    <img
                      className="img-14"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-96">Library</div>
                  </div>
                </div>

                <div className="frame-173">
                  <img
                    className="img-14"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-96">Settings</div>
                </div>

                <div className="frame-173">
                  <img
                    className="img-14"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-96">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-174">
            <div className="frame-175">
              <div className="frame-176">
                <div className="frame-159">
                  <div className="text-wrapper-84">Search</div>

                  <SearchNormal className="instance-node-2" color="#232323" />
                </div>
              </div>

              <div className="frame-177">
                <div className="text-wrapper-97">Login</div>
              </div>

              <div className="frame-178">
                <div className="text-wrapper-98">Sign Up</div>
              </div>
            </div>

            <div className="frame-179">
              <div className="text-wrapper-99">Welcome to Gumroad!</div>

              <div className="frame-158">
                <div className="frame-159">
                  <div className="text-wrapper-84">Search</div>

                  <SearchNormal className="instance-node-2" color="#232323" />
                </div>
              </div>

              <div className="frame-180">
                <div className="frame-181">
                  <div className="frame-182">
                    <div className="category-svgrepo-com-2" />
                  </div>

                  <div className="text-wrapper-100">Search</div>
                </div>

                <div className="frame-181">
                  <div className="frame-182">
                    <img
                      className="img-15"
                      alt="Pen square svgrepo"
                      src="/img/pen-square-svgrepo-com.svg"
                    />
                  </div>

                  <div className="text-wrapper-101">Publish</div>
                </div>

                <div className="frame-181">
                  <div className="frame-182">
                    <img
                      className="img-15"
                      alt="Check square svgrepo"
                      src="/img/check-square-svgrepo-com.svg"
                    />
                  </div>

                  <div className="text-wrapper-101">Answer</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
