import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal24 } from "../../icons/SearchNormal24";
import "./style.css";

export const Home = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="home"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        height: screenWidth >= 1440 ? "1024px" : undefined,
        minHeight:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "100vh"
            : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-73"} ${screenWidth >= 393 && screenWidth < 1440 && "class-74"}`}
            className={`${screenWidth < 393 && "class-75"} ${screenWidth >= 393 && screenWidth < 1440 && "class-76"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-2.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-3.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-77"} ${screenWidth >= 393 && screenWidth < 1440 && "class-78"}`}
            property1="dark"
            wiFi="/img/wi-fi-2.svg"
          />
          <div className="frame-455">
            <div className="back-icon-button-12">
              <img
                className="vuesax-linear-sms"
                alt="Vuesax linear sms"
                src="/img/vuesax-linear-sms-1.svg"
              />
            </div>

            <div className="back-icon-button-12">
              <div className="frame-456" />
            </div>
          </div>

          <div className="frame-457">
            <div className="frame-458">
              <div className="text-wrapper-292">Welcome to Gumroad!</div>
            </div>

            <div className="frame-459">
              <div className="frame-460">
                <div className="text-wrapper-293">Search</div>

                <SearchNormal property1="linear" />
              </div>
            </div>

            <div className="frame-461">
              <div className="frame-462">
                <div className="frame-463">
                  <div
                    className="category-svgrepo-com"
                    style={{
                      backgroundImage:
                        screenWidth < 393
                          ? "url(/img/clip-path-group-1.png)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(/img/clip-path-group-2.png)"
                            : undefined,
                    }}
                  />
                </div>

                <div className="text-wrapper-294">Categories</div>
              </div>

              <div className="frame-462">
                <div className="frame-463">
                  <img
                    className="img-27"
                    alt="Pen square svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/pen-square-svgrepo-com-1.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/pen-square-svgrepo-com-2.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="text-wrapper-294">Publish</div>
              </div>

              <div className="frame-462">
                <div className="frame-463">
                  <img
                    className="img-27"
                    alt="Check square svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/check-square-svgrepo-com-1.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/check-square-svgrepo-com-2.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="text-wrapper-294">Answer</div>
              </div>
            </div>
          </div>

          <div
            className="frame-464"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-6">
              {screenWidth < 393 && (
                <div className="frame-465">
                  <div className="navigation-menu-home-10">
                    <div className="navigation-menu-home-11">
                      <img
                        className="img-28"
                        alt="Home angle svgrepo"
                        src="/img/image.svg"
                      />

                      <div className="text-wrapper-295">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-11">
                    <SearchNormal24 className="img-29" color="#535353" />
                    <div className="text-wrapper-296">Search</div>
                  </div>

                  <div className="navigation-menu-11">
                    <img
                      className="img-29"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-297">Cart</div>
                  </div>

                  <div className="navigation-menu-11">
                    <img
                      className="img-29"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-298">Help</div>
                  </div>

                  <div className="navigation-menu-11">
                    <img
                      className="image-25"
                      alt="Image"
                      src="/img/image.png"
                    />

                    <div className="text-wrapper-299">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1440 && (
                <>
                  <div className="navigation-menu-home-10">
                    <div className="navigation-menu-home-11">
                      <img
                        className="img-28"
                        alt="Home angle svgrepo"
                        src="/img/image.svg"
                      />

                      <div className="text-wrapper-295">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-11">
                    <SearchNormal24 className="img-28" color="#535353" />
                    <div className="text-wrapper-300">Search</div>
                  </div>

                  <div className="navigation-menu-11">
                    <img
                      className="img-28"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-1.svg"
                    />

                    <div className="text-wrapper-301">Cart</div>
                  </div>

                  <div className="navigation-menu-11">
                    <img
                      className="img-28"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-1.svg"
                    />

                    <div className="text-wrapper-301">Help</div>
                  </div>

                  <div className="navigation-menu-11">
                    <img
                      className="image-26"
                      alt="Image"
                      src="/img/image.png"
                    />

                    <div className="text-wrapper-302">Profile</div>
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-13"
            lineClassName={`${screenWidth < 393 && "class-79"} ${screenWidth >= 393 && screenWidth < 1440 && "class-80"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-466">
          <div className="frame-467">
            <div className="frame-468">
              <div className="frame-469">
                <div className="frame-470">
                  <div className="frame-471">
                    <div className="text-wrapper-303">LOGO</div>
                  </div>
                </div>

                <div className="frame-472">
                  <div className="frame-473">
                    <img
                      className="img-30"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-304">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-468">
                <div className="frame-468">
                  <div className="frame-474">
                    <div className="img-30">
                      <div className="vuesax-linear-gift-11">
                        <img
                          className="gift-13"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-305">Products</div>
                  </div>

                  <div className="frame-474">
                    <img
                      className="img-30"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-305">Collaborators</div>
                  </div>

                  <div className="frame-474">
                    <img
                      className="img-30"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-305">Checkout</div>
                  </div>

                  <div className="frame-474">
                    <img
                      className="img-30"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-305">Emails</div>
                  </div>

                  <div className="frame-474">
                    <img
                      className="img-30"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-305">Workflows</div>
                  </div>

                  <div className="frame-474">
                    <img
                      className="img-30"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-305">Sales</div>
                  </div>

                  <div className="frame-474">
                    <img
                      className="img-30"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-305">Analytics</div>
                  </div>

                  <div className="frame-474">
                    <img
                      className="img-30"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-305">Payouts</div>
                  </div>

                  <div className="frame-474">
                    <img
                      className="img-30"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-305">Library</div>
                  </div>
                </div>

                <div className="frame-474">
                  <img
                    className="img-30"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-305">Settings</div>
                </div>

                <div className="frame-474">
                  <img
                    className="img-30"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-305">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-475">
            <div className="frame-476">
              <div className="frame-477">
                <div className="frame-460">
                  <div className="text-wrapper-293">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-478">
                <div className="text-wrapper-306">Login</div>
              </div>

              <div className="frame-479">
                <div className="text-wrapper-307">Sign Up</div>
              </div>
            </div>

            <div className="frame-480">
              <div className="text-wrapper-308">Welcome to Gumroad!</div>

              <div className="frame-459">
                <div className="frame-460">
                  <div className="text-wrapper-293">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-481">
                <div className="frame-482">
                  <div className="frame-483">
                    <div className="category-svgrepo-com-2" />
                  </div>

                  <div className="text-wrapper-309">Search</div>
                </div>

                <div className="frame-482">
                  <div className="frame-483">
                    <img
                      className="img-31"
                      alt="Pen square svgrepo"
                      src="/img/pen-square-svgrepo-com.svg"
                    />
                  </div>

                  <div className="text-wrapper-310">Publish</div>
                </div>

                <div className="frame-482">
                  <div className="frame-483">
                    <img
                      className="img-31"
                      alt="Check square svgrepo"
                      src="/img/check-square-svgrepo-com.svg"
                    />
                  </div>

                  <div className="text-wrapper-310">Answer</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
