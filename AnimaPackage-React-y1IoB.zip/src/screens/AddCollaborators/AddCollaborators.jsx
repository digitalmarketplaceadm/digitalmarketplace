import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { Switch } from "../../components/Switch";
import { Done2 } from "../../icons/Done2";
import { Done11 } from "../../icons/Done11";
import { SearchNormal24 } from "../../icons/SearchNormal24";
import "./style.css";

export const AddCollaborators = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="add-collaborators"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-3"} ${screenWidth >= 393 && screenWidth < 1440 && "class-4"}`}
            className={`${screenWidth < 393 && "class-5"} ${screenWidth >= 393 && screenWidth < 1440 && "class-6"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-20.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-21.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-7"} ${screenWidth >= 393 && screenWidth < 1440 && "class-8"}`}
            property1="dark"
            wiFi="/img/wi-fi-20.svg"
          />
          <div className="frame-67">
            <div className="vuesax-outline-arrow-wrapper">
              <div className="vuesax-outline-arrow-2" />
            </div>

            <div className="frame-68">
              <div className="text-wrapper-32">Add Collaborators</div>
            </div>
          </div>

          <div className="frame-69">
            <div className="frame-70">
              <div className="frame-71">
                <div className="input-13">
                  <label className="email-s" htmlFor="input-2">
                    Email(s)
                  </label>

                  <input
                    className="input-14"
                    id="input-2"
                    placeholder="Enter email address"
                    type="email"
                  />
                </div>
              </div>

              <div className="frame-71">
                <div className="text-wrapper-33">Products</div>

                <div className="frame-72">
                  <div className="default-circle-2" />

                  <div className="text-wrapper-34">Select all Product</div>
                </div>
              </div>

              <div className="frame-73">
                <div className="frame-74">
                  <div className="default-circle-2" />

                  <div className="frame-75">
                    <img
                      className="image-7"
                      alt="Image"
                      src="/img/image-17.png"
                    />

                    <div className="text-wrapper-35">
                      Real Estate Landing Page
                    </div>
                  </div>
                </div>

                <div
                  className="input-15"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-36">50</div>

                  <div className="text-wrapper-37">%</div>
                </div>

                <div
                  className="frame-76"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <Switch
                    className={`${screenWidth < 393 && "class-9"} ${screenWidth >= 393 && screenWidth < 1440 && "class-10"}`}
                    copy={false}
                    size="medium"
                    status="off"
                    title={false}
                  />
                  <div
                    className="text-wrapper-38"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>

              <div className="frame-73">
                <div className="frame-74">
                  <div className="checkbox">
                    <Done11 className="done" />
                  </div>

                  <div className="frame-75">
                    <img
                      className="image-8"
                      alt="Image"
                      src="/img/image-18.png"
                    />

                    <div className="text-wrapper-35">
                      Business Pro Landing Page
                    </div>
                  </div>
                </div>

                <div
                  className="input-16"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-36">50</div>

                  <div className="text-wrapper-37">%</div>
                </div>

                <div
                  className="frame-77"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <Switch
                    className={`${screenWidth < 393 && "class-11"} ${screenWidth >= 393 && screenWidth < 1440 && "class-12"}`}
                    copy={false}
                    size="medium"
                    status="on"
                    title={false}
                  />
                  <div
                    className="text-wrapper-39"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>

              <div className="frame-73">
                <div className="frame-74">
                  <div className="default-circle-2" />

                  <div className="frame-75">
                    <img
                      className="image-7"
                      alt="Image"
                      src="/img/image-44.png"
                    />

                    <div className="text-wrapper-40">SaaS Starter Page</div>
                  </div>
                </div>

                <div
                  className="input-17"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-36">50</div>

                  <div className="text-wrapper-37">%</div>
                </div>

                <div
                  className="frame-78"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <Switch
                    className={`${screenWidth < 393 && "class-9"} ${screenWidth >= 393 && screenWidth < 1440 && "class-10"}`}
                    copy={false}
                    size="medium"
                    status="off"
                    title={false}
                  />
                  <div
                    className="text-wrapper-41"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>

              <div className="frame-73">
                <div className="frame-74">
                  <div className="default-circle-2" />

                  <div className="frame-75">
                    <img
                      className="image-7"
                      alt="Image"
                      src="/img/image-29.png"
                    />

                    <div className="text-wrapper-35">
                      Event Promo Landing Page
                    </div>
                  </div>
                </div>

                <div
                  className="input-18"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-36">50</div>

                  <div className="text-wrapper-37">%</div>
                </div>

                <div
                  className="frame-79"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <Switch
                    className={`${screenWidth < 393 && "class-9"} ${screenWidth >= 393 && screenWidth < 1440 && "class-10"}`}
                    copy={false}
                    size="medium"
                    status="off"
                    title={false}
                  />
                  <div
                    className="text-wrapper-42"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>

              <div className="frame-73">
                <div className="frame-74">
                  <div className="checkbox">
                    <Done11 className="done" />
                  </div>

                  <div className="frame-75">
                    <img
                      className="image-7"
                      alt="Image"
                      src="/img/image-30.png"
                    />

                    <div className="text-wrapper-35">Tech Conference Page</div>
                  </div>
                </div>

                <div
                  className="input-19"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-36">50</div>

                  <div className="text-wrapper-37">%</div>
                </div>

                <div
                  className="frame-80"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <Switch
                    className={`${screenWidth < 393 && "class-11"} ${screenWidth >= 393 && screenWidth < 1440 && "class-12"}`}
                    copy={false}
                    size="medium"
                    status="on"
                    title={false}
                  />
                  <div
                    className="text-wrapper-43"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>

              <div className="frame-73">
                <div className="frame-74">
                  <div className="checkbox">
                    <Done11 className="done" />
                  </div>

                  <div className="frame-75">
                    <img
                      className="image-7"
                      alt="Image"
                      src="/img/image-47.png"
                    />

                    <div className="text-wrapper-40">Creative Portfolio</div>
                  </div>
                </div>

                <div
                  className="input-20"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-36">50</div>

                  <div className="text-wrapper-37">%</div>
                </div>

                <div
                  className="frame-81"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <Switch
                    className={`${screenWidth < 393 && "class-11"} ${screenWidth >= 393 && screenWidth < 1440 && "class-12"}`}
                    copy={false}
                    size="medium"
                    status="on"
                    title={false}
                  />
                  <div
                    className="text-wrapper-44"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>

              <div className="frame-73">
                <div className="frame-74">
                  <div className="default-circle-2" />

                  <div className="frame-75">
                    <img
                      className="image-7"
                      alt="Image"
                      src="/img/image-32.png"
                    />

                    <div className="text-wrapper-35">Webinar Funnel Page</div>
                  </div>
                </div>

                <div
                  className="input-21"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-36">50</div>

                  <div className="text-wrapper-37">%</div>
                </div>

                <div
                  className="frame-82"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <Switch
                    className={`${screenWidth < 393 && "class-9"} ${screenWidth >= 393 && screenWidth < 1440 && "class-10"}`}
                    copy={false}
                    size="medium"
                    status="off"
                    title={false}
                  />
                  <div
                    className="text-wrapper-45"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            className="frame-83"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-2">
              {screenWidth < 393 && (
                <div className="frame-84">
                  <div className="navigation-menu-home-wrapper">
                    <div className="navigation-menu-home-3">
                      <img
                        className="img-5"
                        alt="Home angle svgrepo"
                        src="/img/image.svg"
                      />

                      <div className="text-wrapper-46">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-3">
                    <SearchNormal24 className="img-6" color="#535353" />
                    <div className="text-wrapper-47">Search</div>
                  </div>

                  <div className="navigation-menu-3">
                    <img
                      className="img-6"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-48">Cart</div>
                  </div>

                  <div className="navigation-menu-3">
                    <img
                      className="img-6"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-5.svg"
                    />

                    <div className="text-wrapper-49">Help</div>
                  </div>

                  <div className="navigation-menu-3">
                    <img className="image-9" alt="Image" src="/img/image.png" />

                    <div className="text-wrapper-50">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1440 && (
                <>
                  <div className="navigation-menu-home-wrapper">
                    <div className="navigation-menu-home-3">
                      <img
                        className="img-5"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-11.svg"
                      />

                      <div className="text-wrapper-46">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-4">
                    <SearchNormal24 className="img-5" color="#535353" />
                  </div>

                  <div className="navigation-menu-4">
                    <img
                      className="img-5"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-7.svg"
                    />
                  </div>

                  <div className="navigation-menu-4">
                    <div className="frame-85">
                      <div className="ellipse-2" />
                    </div>
                  </div>

                  <div className="navigation-menu-4">
                    <img
                      className="image-10"
                      alt="Image"
                      src="/img/image.png"
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-2"
            lineClassName={`${screenWidth < 393 && "class-13"} ${screenWidth >= 393 && screenWidth < 1440 && "class-14"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-86">
          <div className="frame-87">
            <div className="frame-88">
              <div className="frame-89">
                <div className="frame-90">
                  <div className="frame-91">
                    <div className="text-wrapper-51">LOGO</div>
                  </div>
                </div>

                <div className="frame-92">
                  <div className="frame-93">
                    <img
                      className="img-7"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-10.svg"
                    />

                    <div className="text-wrapper-52">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-88">
                <div className="frame-88">
                  <div className="frame-94">
                    <div className="img-7">
                      <div className="gift-wrapper">
                        <img
                          className="gift-2"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-53">Products</div>
                  </div>

                  <div className="frame-94">
                    <img
                      className="img-7"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-53">Collaborators</div>
                  </div>

                  <div className="frame-94">
                    <img
                      className="img-7"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-53">Checkout</div>
                  </div>

                  <div className="frame-94">
                    <img
                      className="img-7"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-53">Emails</div>
                  </div>

                  <div className="frame-94">
                    <img
                      className="img-7"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-53">Workflows</div>
                  </div>

                  <div className="frame-94">
                    <img
                      className="img-7"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-53">Sales</div>
                  </div>

                  <div className="frame-94">
                    <img
                      className="img-7"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-53">Analytics</div>
                  </div>

                  <div className="frame-94">
                    <img
                      className="img-7"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-53">Payouts</div>
                  </div>

                  <div className="frame-94">
                    <img
                      className="img-7"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-53">Library</div>
                  </div>
                </div>

                <div className="frame-94">
                  <img
                    className="img-7"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-53">Settings</div>
                </div>

                <div className="frame-94">
                  <img
                    className="img-7"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-53">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-95">
            <div className="frame-96">
              <div className="frame-97">
                <div className="frame-98">
                  <div className="text-wrapper-54">Search</div>

                  <SearchNormal24
                    className="search-normal-24"
                    color="#232323"
                  />
                </div>
              </div>

              <div className="frame-99">
                <div className="text-wrapper-55">Login</div>
              </div>

              <div className="frame-100">
                <div className="text-wrapper-56">Sign Up</div>
              </div>
            </div>

            <div className="frame-101">
              <div className="frame-102">
                <div className="vuesax-outline-arrow-wrapper">
                  <div className="vuesax-outline-arrow-2" />
                </div>

                <div className="frame-103">
                  <div className="text-wrapper-57">Add Collaborators</div>

                  <p className="text-wrapper-58">
                    Selling digital products is even better with a team! Invite
                    collaborators to help you manage, create, and sell your
                    landing pages, templates, or digital assets effortlessly.
                  </p>
                </div>
              </div>

              <div className="frame-104">
                <div className="frame-71">
                  <div className="input-13">
                    <label className="email-s" htmlFor="input-4">
                      Email(s)
                    </label>

                    <input
                      className="input-22"
                      id="input-4"
                      placeholder="Enter email address"
                      type="email"
                    />
                  </div>
                </div>

                <div className="frame-71">
                  <div className="text-wrapper-59">Products</div>

                  <div className="frame-105">
                    <div className="default-circle-2" />

                    <div className="text-wrapper-34">Select all Product</div>
                  </div>
                </div>

                <div className="frame-106">
                  <div className="frame-107">
                    <div className="default-circle-2" />

                    <div className="frame-75">
                      <img
                        className="image-11"
                        alt="Image"
                        src="/img/image-33.png"
                      />

                      <div className="text-wrapper-60">
                        Real Estate Landing Page
                      </div>
                    </div>
                  </div>

                  <div className="input-23">
                    <div className="text-wrapper-36">50</div>

                    <div className="text-wrapper-37">%</div>
                  </div>

                  <div className="frame-108">
                    <Switch
                      className="switch-5"
                      copy={false}
                      size="medium"
                      status="off"
                      title={false}
                    />
                    <div className="text-wrapper-61">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-106">
                  <div className="frame-107">
                    <div className="checkbox">
                      <Done2 className="done" />
                    </div>

                    <div className="frame-109">
                      <img
                        className="image-12"
                        alt="Image"
                        src="/img/image-34.png"
                      />

                      <div className="text-wrapper-60">
                        Business Pro Landing Page
                      </div>
                    </div>
                  </div>

                  <div className="input-23">
                    <div className="text-wrapper-36">50</div>

                    <div className="text-wrapper-37">%</div>
                  </div>

                  <div className="frame-110">
                    <Switch
                      className="switch-6"
                      copy={false}
                      size="medium"
                      status="on"
                      title={false}
                    />
                    <div className="text-wrapper-62">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-106">
                  <div className="frame-107">
                    <div className="default-circle-2" />

                    <div className="frame-111">
                      <img
                        className="image-11"
                        alt="Image"
                        src="/img/image-35.png"
                      />

                      <div className="text-wrapper-60">SaaS Starter Page</div>
                    </div>
                  </div>

                  <div className="input-23">
                    <div className="text-wrapper-36">50</div>

                    <div className="text-wrapper-37">%</div>
                  </div>

                  <div className="frame-112">
                    <Switch
                      className="switch-5"
                      copy={false}
                      size="medium"
                      status="off"
                      title={false}
                    />
                    <div className="text-wrapper-63">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-106">
                  <div className="frame-107">
                    <div className="checkbox">
                      <Done11 className="done" />
                    </div>

                    <div className="frame-111">
                      <img
                        className="image-11"
                        alt="Image"
                        src="/img/image-36.png"
                      />

                      <div className="text-wrapper-60">Minimal Portfolio</div>
                    </div>
                  </div>

                  <div className="input-23">
                    <div className="text-wrapper-36">50</div>

                    <div className="text-wrapper-37">%</div>
                  </div>

                  <div className="frame-113">
                    <Switch
                      className="switch-6"
                      copy={false}
                      size="medium"
                      status="on"
                      title={false}
                    />
                    <div className="text-wrapper-64">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-106">
                  <div className="frame-107">
                    <div className="default-circle-2" />

                    <div className="frame-111">
                      <img
                        className="image-11"
                        alt="Image"
                        src="/img/image-37.png"
                      />

                      <div className="text-wrapper-60">Startup One-Pager</div>
                    </div>
                  </div>

                  <div className="input-23">
                    <div className="text-wrapper-36">50</div>

                    <div className="text-wrapper-37">%</div>
                  </div>

                  <div className="frame-114">
                    <Switch
                      className="switch-5"
                      copy={false}
                      size="medium"
                      status="off"
                      title={false}
                    />
                    <div className="text-wrapper-65">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-106">
                  <div className="frame-107">
                    <div className="checkbox">
                      <Done11 className="done" />
                    </div>

                    <div className="frame-111">
                      <img
                        className="image-11"
                        alt="Image"
                        src="/img/image-38.png"
                      />

                      <div className="text-wrapper-66">
                        Event Promo Landing Page
                      </div>
                    </div>
                  </div>

                  <div className="input-23">
                    <div className="text-wrapper-36">50</div>

                    <div className="text-wrapper-37">%</div>
                  </div>

                  <div className="frame-115">
                    <Switch
                      className="switch-6"
                      copy={false}
                      size="medium"
                      status="on"
                      title={false}
                    />
                    <div className="text-wrapper-67">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-106">
                  <div className="frame-107">
                    <div className="checkbox">
                      <Done11 className="done" />
                    </div>

                    <div className="frame-111">
                      <img
                        className="image-11"
                        alt="Image"
                        src="/img/image-39.png"
                      />

                      <div className="text-wrapper-60">
                        Tech Conference Page
                      </div>
                    </div>
                  </div>

                  <div className="input-23">
                    <div className="text-wrapper-36">50</div>

                    <div className="text-wrapper-37">%</div>
                  </div>

                  <div className="frame-116">
                    <Switch
                      className="switch-6"
                      copy={false}
                      size="medium"
                      status="on"
                      title={false}
                    />
                    <div className="text-wrapper-68">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-106">
                  <div className="frame-107">
                    <div className="default-circle-2" />

                    <div className="frame-111">
                      <img
                        className="image-11"
                        alt="Image"
                        src="/img/image-40.png"
                      />

                      <div className="text-wrapper-60">Creative Portfolio</div>
                    </div>
                  </div>

                  <div className="input-23">
                    <div className="text-wrapper-36">50</div>

                    <div className="text-wrapper-37">%</div>
                  </div>

                  <div className="frame-117">
                    <Switch
                      className="switch-5"
                      copy={false}
                      size="medium"
                      status="off"
                      title={false}
                    />
                    <div className="text-wrapper-69">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-106">
                  <div className="frame-107">
                    <div className="checkbox">
                      <Done11 className="done" />
                    </div>

                    <div className="frame-111">
                      <img
                        className="image-11"
                        alt="Image"
                        src="/img/image-41.png"
                      />

                      <div className="text-wrapper-60">Webinar Funnel Page</div>
                    </div>
                  </div>

                  <div className="input-23">
                    <div className="text-wrapper-36">50</div>

                    <div className="text-wrapper-37">%</div>
                  </div>

                  <div className="frame-118">
                    <Switch
                      className="switch-6"
                      copy={false}
                      size="medium"
                      status="on"
                      title={false}
                    />
                    <div className="text-wrapper-70">Show as co-creator</div>
                  </div>
                </div>
              </div>

              <div className="CTA">
                <div className="frame-119">
                  <div className="text-wrapper-71">Cancel</div>
                </div>

                <div className="frame-99">
                  <div className="text-wrapper-72">Save</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
