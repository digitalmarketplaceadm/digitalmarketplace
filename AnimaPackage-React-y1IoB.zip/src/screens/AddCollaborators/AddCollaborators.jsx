import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const AddCollaborators = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="add-collaborators"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-75"} ${screenWidth >= 393 && screenWidth < 1440 && "class-76"}`}
            className={`${screenWidth < 393 && "class-73"} ${screenWidth >= 393 && screenWidth < 1440 && "class-74"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-20-2.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-21.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-77"} ${screenWidth >= 393 && screenWidth < 1440 && "class-78"}`}
            property1="dark"
            wiFi="/img/wi-fi-20.svg"
          />
          <div className="frame-863">
            <div className="back-icon-button-39">
              <div className="vuesax-outline-arrow-21" />
            </div>

            <div className="frame-864">
              <div className="text-wrapper-416">Add Collaborators</div>
            </div>
          </div>

          <div className="frame-865">
            <div className="frame-866">
              <div className="frame-867">
                <div className="input-54">
                  <label className="email-s" htmlFor="input-2">
                    Email(s)
                  </label>

                  <input
                    className="input-55"
                    id="input-2"
                    placeholder="Enter email address"
                    type="email"
                  />
                </div>
              </div>

              <div className="frame-867">
                <div className="text-wrapper-417">Products</div>

                <div className="frame-868">
                  <div className="default-circle-9" />

                  <div className="text-wrapper-418">Select all Product</div>
                </div>
              </div>

              <div className="frame-869">
                <div className="frame-870">
                  <div className="default-circle-9" />

                  <div className="frame-871">
                    <img
                      className="image-47"
                      alt="Image"
                      src="/img/image-42.png"
                    />

                    <div className="text-wrapper-419">
                      Real Estate Landing Page
                    </div>
                  </div>
                </div>

                <div
                  className="input-56"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-420">50</div>

                  <div className="text-wrapper-421">%</div>
                </div>

                <div
                  className="frame-872"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <div
                    className="switch-6"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-39.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-28.00px"
                            : undefined,
                    }}
                  >
                    <div className="switch-7" />
                  </div>

                  <div
                    className="text-wrapper-422"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>

              <div className="frame-869">
                <div className="frame-870">
                  <div className="checkbox">
                    <img
                      className="done"
                      alt="Done"
                      src={
                        screenWidth < 393
                          ? "/img/done-7.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/done-10.svg"
                            : undefined
                      }
                    />
                  </div>

                  <div className="frame-871">
                    <img
                      className="image-48"
                      alt="Image"
                      src="/img/image-43.png"
                    />

                    <div className="text-wrapper-419">
                      Business Pro Landing Page
                    </div>
                  </div>
                </div>

                <div
                  className="input-57"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-420">50</div>

                  <div className="text-wrapper-421">%</div>
                </div>

                <div
                  className="frame-873"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <div
                    className="switch-8"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-39.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-28.00px"
                            : undefined,
                    }}
                  >
                    <div className="switch-9" />
                  </div>

                  <div
                    className="text-wrapper-423"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>

              <div className="frame-869">
                <div className="frame-870">
                  <div className="default-circle-9" />

                  <div className="frame-871">
                    <img
                      className="image-47"
                      alt="Image"
                      src="/img/image-44.png"
                    />

                    <div className="text-wrapper-424">SaaS Starter Page</div>
                  </div>
                </div>

                <div
                  className="input-58"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-420">50</div>

                  <div className="text-wrapper-421">%</div>
                </div>

                <div
                  className="frame-874"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <div
                    className="switch-10"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-39.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-28.00px"
                            : undefined,
                    }}
                  >
                    <div className="switch-7" />
                  </div>

                  <div
                    className="text-wrapper-425"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>

              <div className="frame-869">
                <div className="frame-870">
                  <div className="default-circle-9" />

                  <div className="frame-871">
                    <img
                      className="image-47"
                      alt="Image"
                      src="/img/image-45.png"
                    />

                    <div className="text-wrapper-419">
                      Event Promo Landing Page
                    </div>
                  </div>
                </div>

                <div
                  className="input-59"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-420">50</div>

                  <div className="text-wrapper-421">%</div>
                </div>

                <div
                  className="frame-875"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <div
                    className="switch-11"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-39.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-28.00px"
                            : undefined,
                    }}
                  >
                    <div className="switch-7" />
                  </div>

                  <div
                    className="text-wrapper-426"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>

              <div className="frame-869">
                <div className="frame-870">
                  <div className="checkbox">
                    <img
                      className="done"
                      alt="Done"
                      src={
                        screenWidth < 393
                          ? "/img/done-8.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/done-11.svg"
                            : undefined
                      }
                    />
                  </div>

                  <div className="frame-871">
                    <img
                      className="image-47"
                      alt="Image"
                      src="/img/image-46.png"
                    />

                    <div className="text-wrapper-419">Tech Conference Page</div>
                  </div>
                </div>

                <div
                  className="input-60"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-420">50</div>

                  <div className="text-wrapper-421">%</div>
                </div>

                <div
                  className="frame-876"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <div
                    className="switch-12"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-39.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-28.00px"
                            : undefined,
                    }}
                  >
                    <div className="switch-9" />
                  </div>

                  <div
                    className="text-wrapper-427"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>

              <div className="frame-869">
                <div className="frame-870">
                  <div className="checkbox">
                    <img
                      className="done"
                      alt="Done"
                      src={
                        screenWidth < 393
                          ? "/img/done-9.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/done-12.svg"
                            : undefined
                      }
                    />
                  </div>

                  <div className="frame-871">
                    <img
                      className="image-47"
                      alt="Image"
                      src="/img/image-47.png"
                    />

                    <div className="text-wrapper-424">Creative Portfolio</div>
                  </div>
                </div>

                <div
                  className="input-61"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-420">50</div>

                  <div className="text-wrapper-421">%</div>
                </div>

                <div
                  className="frame-877"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <div
                    className="switch-13"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-39.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-28.00px"
                            : undefined,
                    }}
                  >
                    <div className="switch-9" />
                  </div>

                  <div
                    className="text-wrapper-428"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>

              <div className="frame-869">
                <div className="frame-870">
                  <div className="default-circle-9" />

                  <div className="frame-871">
                    <img
                      className="image-47"
                      alt="Image"
                      src="/img/image-48.png"
                    />

                    <div className="text-wrapper-419">Webinar Funnel Page</div>
                  </div>
                </div>

                <div
                  className="input-62"
                  style={{
                    marginRight: screenWidth < 393 ? "-37.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-420">50</div>

                  <div className="text-wrapper-421">%</div>
                </div>

                <div
                  className="frame-878"
                  style={{
                    marginRight: screenWidth < 393 ? "-62.00px" : undefined,
                  }}
                >
                  <div
                    className="switch-14"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-39.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-28.00px"
                            : undefined,
                    }}
                  >
                    <div className="switch-7" />
                  </div>

                  <div
                    className="text-wrapper-429"
                    style={{
                      marginRight:
                        screenWidth < 393
                          ? "-187.00px"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "-176.00px"
                            : undefined,
                    }}
                  >
                    Show as co-creator
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            className="frame-879"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-17">
              {screenWidth < 393 && (
                <div className="frame-880">
                  <div className="navigation-menu-home-14">
                    <div className="navigation-menu-home-15">
                      <img
                        className="img-47"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-430">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-22">
                    <SearchNormal property1="linear" />
                    <div className="text-wrapper-431">Search</div>
                  </div>

                  <div className="navigation-menu-22">
                    <img
                      className="img-48"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-432">Cart</div>
                  </div>

                  <div className="navigation-menu-22">
                    <img
                      className="img-48"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-5.svg"
                    />

                    <div className="text-wrapper-433">Help</div>
                  </div>

                  <div className="navigation-menu-22">
                    <img
                      className="image-49"
                      alt="Image"
                      src="/img/image-6.png"
                    />

                    <div className="text-wrapper-434">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1440 && (
                <>
                  <div className="navigation-menu-home-14">
                    <div className="navigation-menu-home-15">
                      <img
                        className="img-47"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-15.svg"
                      />

                      <div className="text-wrapper-430">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-23">
                    <SearchNormal property1="linear" />
                  </div>

                  <div className="navigation-menu-23">
                    <img
                      className="img-47"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-7.svg"
                    />
                  </div>

                  <div className="navigation-menu-23">
                    <div className="frame-881">
                      <div className="ellipse-37" />
                    </div>
                  </div>

                  <div className="navigation-menu-23">
                    <img
                      className="image-50"
                      alt="Image"
                      src="/img/image-6.png"
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-40"
            lineClassName={`${screenWidth < 393 && "class-79"} ${screenWidth >= 393 && screenWidth < 1440 && "class-80"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-882">
          <div className="frame-883">
            <div className="frame-884">
              <div className="frame-885">
                <div className="frame-886">
                  <div className="frame-887">
                    <div className="text-wrapper-435">LOGO</div>
                  </div>
                </div>

                <div className="frame-888">
                  <div className="frame-889">
                    <img
                      className="img-49"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-10.svg"
                    />

                    <div className="text-wrapper-436">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-884">
                <div className="frame-884">
                  <div className="frame-890">
                    <div className="img-49">
                      <div className="vuesax-linear-gift-18">
                        <img
                          className="gift-28"
                          alt="Gift"
                          src="/img/gift-9.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-437">Products</div>
                  </div>

                  <div className="frame-890">
                    <img
                      className="img-49"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-6-2.svg"
                    />

                    <div className="text-wrapper-437">Collaborators</div>
                  </div>

                  <div className="frame-890">
                    <img
                      className="img-49"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-6-3.svg"
                    />

                    <div className="text-wrapper-437">Checkout</div>
                  </div>

                  <div className="frame-890">
                    <img
                      className="img-49"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-437">Emails</div>
                  </div>

                  <div className="frame-890">
                    <img
                      className="img-49"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-6-2.svg"
                    />

                    <div className="text-wrapper-437">Workflows</div>
                  </div>

                  <div className="frame-890">
                    <img
                      className="img-49"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12-2.svg"
                    />

                    <div className="text-wrapper-437">Sales</div>
                  </div>

                  <div className="frame-890">
                    <img
                      className="img-49"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-437">Analytics</div>
                  </div>

                  <div className="frame-890">
                    <img
                      className="img-49"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12-2.svg"
                    />

                    <div className="text-wrapper-437">Payouts</div>
                  </div>

                  <div className="frame-890">
                    <img
                      className="img-49"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-437">Library</div>
                  </div>
                </div>

                <div className="frame-890">
                  <img
                    className="img-49"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-437">Settings</div>
                </div>

                <div className="frame-890">
                  <img
                    className="img-49"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-437">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-891">
            <div className="frame-892">
              <div className="frame-893">
                <div className="frame-894">
                  <div className="text-wrapper-438">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-895">
                <div className="text-wrapper-439">Login</div>
              </div>

              <div className="frame-896">
                <div className="text-wrapper-440">Sign Up</div>
              </div>
            </div>

            <div className="frame-897">
              <div className="frame-898">
                <div className="back-icon-button-39">
                  <div className="vuesax-outline-arrow-21" />
                </div>

                <div className="frame-899">
                  <div className="text-wrapper-441">Add Collaborators</div>

                  <p className="text-wrapper-442">
                    Selling digital products is even better with a team! Invite
                    collaborators to help you manage, create, and sell your
                    landing pages, templates, or digital assets effortlessly.
                  </p>
                </div>
              </div>

              <div className="frame-900">
                <div className="frame-867">
                  <div className="input-54">
                    <label className="email-s" htmlFor="input-4">
                      Email(s)
                    </label>

                    <input
                      className="input-63"
                      id="input-4"
                      placeholder="Enter email address"
                      type="email"
                    />
                  </div>
                </div>

                <div className="frame-867">
                  <div className="text-wrapper-443">Products</div>

                  <div className="frame-901">
                    <div className="default-circle-9" />

                    <div className="text-wrapper-418">Select all Product</div>
                  </div>
                </div>

                <div className="frame-902">
                  <div className="frame-903">
                    <div className="default-circle-9" />

                    <div className="frame-871">
                      <img
                        className="image-51"
                        alt="Image"
                        src="/img/image-33.png"
                      />

                      <div className="text-wrapper-444">
                        Real Estate Landing Page
                      </div>
                    </div>
                  </div>

                  <div className="input-64">
                    <div className="text-wrapper-420">50</div>

                    <div className="text-wrapper-421">%</div>
                  </div>

                  <div className="frame-904">
                    <div className="switch-15">
                      <div className="switch-7" />
                    </div>

                    <div className="text-wrapper-445">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-902">
                  <div className="frame-903">
                    <div className="checkbox">
                      <img className="done" alt="Done" src="/img/done-2.svg" />
                    </div>

                    <div className="frame-905">
                      <img
                        className="image-52"
                        alt="Image"
                        src="/img/image-34.png"
                      />

                      <div className="text-wrapper-444">
                        Business Pro Landing Page
                      </div>
                    </div>
                  </div>

                  <div className="input-64">
                    <div className="text-wrapper-420">50</div>

                    <div className="text-wrapper-421">%</div>
                  </div>

                  <div className="frame-906">
                    <div className="switch-16">
                      <div className="switch-9" />
                    </div>

                    <div className="text-wrapper-446">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-902">
                  <div className="frame-903">
                    <div className="default-circle-9" />

                    <div className="frame-907">
                      <img
                        className="image-51"
                        alt="Image"
                        src="/img/image-35.png"
                      />

                      <div className="text-wrapper-444">SaaS Starter Page</div>
                    </div>
                  </div>

                  <div className="input-64">
                    <div className="text-wrapper-420">50</div>

                    <div className="text-wrapper-421">%</div>
                  </div>

                  <div className="frame-908">
                    <div className="switch-17">
                      <div className="switch-7" />
                    </div>

                    <div className="text-wrapper-447">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-902">
                  <div className="frame-903">
                    <div className="checkbox">
                      <img className="done" alt="Done" src="/img/done-3.svg" />
                    </div>

                    <div className="frame-907">
                      <img
                        className="image-51"
                        alt="Image"
                        src="/img/image-36.png"
                      />

                      <div className="text-wrapper-444">Minimal Portfolio</div>
                    </div>
                  </div>

                  <div className="input-64">
                    <div className="text-wrapper-420">50</div>

                    <div className="text-wrapper-421">%</div>
                  </div>

                  <div className="frame-909">
                    <div className="switch-18">
                      <div className="switch-9" />
                    </div>

                    <div className="text-wrapper-448">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-902">
                  <div className="frame-903">
                    <div className="default-circle-9" />

                    <div className="frame-907">
                      <img
                        className="image-51"
                        alt="Image"
                        src="/img/image-37.png"
                      />

                      <div className="text-wrapper-444">Startup One-Pager</div>
                    </div>
                  </div>

                  <div className="input-64">
                    <div className="text-wrapper-420">50</div>

                    <div className="text-wrapper-421">%</div>
                  </div>

                  <div className="frame-910">
                    <div className="switch-19">
                      <div className="switch-7" />
                    </div>

                    <div className="text-wrapper-449">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-902">
                  <div className="frame-903">
                    <div className="checkbox">
                      <img className="done" alt="Done" src="/img/done-4.svg" />
                    </div>

                    <div className="frame-907">
                      <img
                        className="image-51"
                        alt="Image"
                        src="/img/image-38.png"
                      />

                      <div className="text-wrapper-450">
                        Event Promo Landing Page
                      </div>
                    </div>
                  </div>

                  <div className="input-64">
                    <div className="text-wrapper-420">50</div>

                    <div className="text-wrapper-421">%</div>
                  </div>

                  <div className="frame-911">
                    <div className="switch-20">
                      <div className="switch-9" />
                    </div>

                    <div className="text-wrapper-451">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-902">
                  <div className="frame-903">
                    <div className="checkbox">
                      <img className="done" alt="Done" src="/img/done-5.svg" />
                    </div>

                    <div className="frame-907">
                      <img
                        className="image-51"
                        alt="Image"
                        src="/img/image-39.png"
                      />

                      <div className="text-wrapper-444">
                        Tech Conference Page
                      </div>
                    </div>
                  </div>

                  <div className="input-64">
                    <div className="text-wrapper-420">50</div>

                    <div className="text-wrapper-421">%</div>
                  </div>

                  <div className="frame-912">
                    <div className="switch-21">
                      <div className="switch-9" />
                    </div>

                    <div className="text-wrapper-452">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-902">
                  <div className="frame-903">
                    <div className="default-circle-9" />

                    <div className="frame-907">
                      <img
                        className="image-51"
                        alt="Image"
                        src="/img/image-40.png"
                      />

                      <div className="text-wrapper-444">Creative Portfolio</div>
                    </div>
                  </div>

                  <div className="input-64">
                    <div className="text-wrapper-420">50</div>

                    <div className="text-wrapper-421">%</div>
                  </div>

                  <div className="frame-913">
                    <div className="switch-22">
                      <div className="switch-7" />
                    </div>

                    <div className="text-wrapper-453">Show as co-creator</div>
                  </div>
                </div>

                <div className="frame-902">
                  <div className="frame-903">
                    <div className="checkbox">
                      <img className="done" alt="Done" src="/img/done-6.svg" />
                    </div>

                    <div className="frame-907">
                      <img
                        className="image-51"
                        alt="Image"
                        src="/img/image-41.png"
                      />

                      <div className="text-wrapper-444">
                        Webinar Funnel Page
                      </div>
                    </div>
                  </div>

                  <div className="input-64">
                    <div className="text-wrapper-420">50</div>

                    <div className="text-wrapper-421">%</div>
                  </div>

                  <div className="frame-914">
                    <div className="switch-23">
                      <div className="switch-9" />
                    </div>

                    <div className="text-wrapper-454">Show as co-creator</div>
                  </div>
                </div>
              </div>

              <div className="CTA-9">
                <div className="frame-915">
                  <div className="text-wrapper-455">Cancel</div>
                </div>

                <div className="frame-895">
                  <div className="text-wrapper-456">Save</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
