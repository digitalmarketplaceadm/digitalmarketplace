import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const AdvanceSettings = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="advance-settings"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393
            ? "center"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393
            ? "#ffffff"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393
            ? "column"
            : undefined,
        gap:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
        minHeight:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "100vh"
            : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1200
              ? "393px"
              : screenWidth >= 1200 && screenWidth < 1440
                ? "1200px"
                : screenWidth >= 1440
                  ? "1440px"
                  : undefined,
        padding:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-41"} ${screenWidth >= 393 && screenWidth < 1200 && "class-42"}`}
            className={`${screenWidth < 393 && "class-39"} ${screenWidth >= 393 && screenWidth < 1200 && "class-40"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-31.svg"
                : screenWidth >= 393 && screenWidth < 1200
                  ? "/img/combined-shape-32.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-43"} ${screenWidth >= 393 && screenWidth < 1200 && "class-44"}`}
            property1="dark"
            rectangleClassName="status-bar-95"
            timeClassName="status-bar-94"
            wiFi="/img/wi-fi-31.svg"
          />
          <div className="frame-530">
            <div className="back-icon-button-34">
              <div className="vuesax-outline-arrow-16" />
            </div>

            <div className="frame-531">
              <div className="text-wrapper-257">Account settings</div>

              <p className="text-wrapper-258">
                Edit your account details here such as payment details, name,
                download limits etc.
              </p>
            </div>
          </div>

          <div className="frame-532">
            <div className="div-9">
              <div className="frame-533">
                <div className="frame-534">
                  <div className="text-wrapper-259">Store</div>

                  <img
                    className="vector-82"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28999.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-11537.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-535">
                  <div className="text-wrapper-259">Payment Details</div>

                  <img
                    className="vector-83"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-29052.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-11590.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-536">
                  <div className="text-wrapper-259">Billing &amp; Invoices</div>

                  <img
                    className="vector-84"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-29175.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-11713.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-537"
                  style={{
                    marginRight: screenWidth < 393 ? "-51.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-259">Taxes</div>

                  <img
                    className="vector-85"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-29301.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-11839.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-538"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-127.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-54.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-259">Shipping</div>

                  <img
                    className="vector-86"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-29354.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-11892.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-539"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-261.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-188.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-260">Advance settings</div>

                  <img
                    className="vector-87"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-29430.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-11968.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-540"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-371.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-298.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-259">Login settings</div>

                  <img
                    className="vector-88"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-29564.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-12102.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-541"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-464.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-391.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-259">Developers</div>

                  <img
                    className="vector-89"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-29674.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-12212.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>
              </div>
            </div>

            <div className="div-9">
              <div className="text-wrapper-261">Protect your PDF files</div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-262">
                    Stamp the buyer&#39;s email on the top left of each page of
                    your PDF for files below 250MB.
                  </p>
                </div>
              </div>
            </div>

            <div className="div-9">
              <div className="text-wrapper-261">Email Notifications</div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-262">
                    {" "}
                    Send me a notification email everytime one of my products is
                    sold
                  </p>
                </div>
              </div>
            </div>

            <div className="div-9">
              <div className="text-wrapper-261">Inventory Notifications</div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-262">
                    {" "}
                    Send me a notification email if my physical product
                    inventory falls below a certain level
                  </p>
                </div>
              </div>
            </div>

            <div
              className="input-16"
              style={{
                alignSelf: screenWidth < 393 ? "stretch" : undefined,
                width:
                  screenWidth < 393
                    ? "100%"
                    : screenWidth >= 393 && screenWidth < 1200
                      ? "361px"
                      : undefined,
              }}
            >
              <div className="text-wrapper-261">Download Limit</div>

              <div className="input-17">
                <div className="text-wrapper-263">5</div>
              </div>
            </div>

            <div
              className="input-18"
              style={{
                alignSelf: screenWidth < 393 ? "stretch" : undefined,
                width:
                  screenWidth < 393
                    ? "100%"
                    : screenWidth >= 393 && screenWidth < 1200
                      ? "361px"
                      : undefined,
              }}
            >
              <div className="text-wrapper-261">Google Analytics</div>

              <div className="input-17">
                <p className="text-wrapper-263">
                  Enter Google analytics unique ID
                </p>
              </div>
            </div>

            <div
              className="input-19"
              style={{
                alignSelf: screenWidth < 393 ? "stretch" : undefined,
                width:
                  screenWidth < 393
                    ? "100%"
                    : screenWidth >= 393 && screenWidth < 1200
                      ? "361px"
                      : undefined,
              }}
            >
              <div className="text-wrapper-261">Facebook Pixel</div>

              <div className="input-17">
                <div className="text-wrapper-263">Enter Facebook Pixel ID</div>
              </div>
            </div>

            <div className="div-9">
              <div className="text-wrapper-261">Store Units</div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-5" />

                  <div className="text-wrapper-264">Imperial</div>
                </div>
              </div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-5" />

                  <div className="text-wrapper-264">Metric</div>
                </div>
              </div>
            </div>

            <div className="div-9">
              <div className="text-wrapper-261">Checkout Settings</div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-262">
                    {" "}
                    Redirect customers to a particular webpage when they
                    successfully complete the checkout
                  </p>
                </div>
              </div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-262">
                    Collect customer first and last name during digital product
                    checkout
                  </p>
                </div>
              </div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-264">
                    Enable gifting for digital products
                  </p>
                </div>
              </div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-262">
                    Display your own questions for customers to answer during
                    checkout
                  </p>
                </div>
              </div>
            </div>

            <div className="div-9">
              <div className="text-wrapper-261">Course Settings</div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-262">
                    {" "}
                    Send me a notification email anytime course student posts a
                    comment on my course
                  </p>
                </div>
              </div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-262">
                    {" "}
                    Send my course students a notification email when someone
                    replies to their comment
                  </p>
                </div>
              </div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-262">
                    {" "}
                    Allow people who have a free preview version of my course to
                    post comments
                  </p>
                </div>
              </div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-262">
                    {" "}
                    Send me a notification email when course student submits
                    file for assignment lesson
                  </p>
                </div>
              </div>
            </div>

            <div className="div-9">
              <div className="text-wrapper-261">
                Logo &amp; Invoice Settings
              </div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-262">
                    {" "}
                    Add your logo on invoices and email receipts that customers
                    receive
                  </p>
                </div>
              </div>

              <div className="frame-542">
                <div className="frame-543">
                  <div className="default-circle-4" />

                  <p className="text-wrapper-262">
                    {" "}
                    Add your business address on invoices that customers receive
                  </p>
                </div>
              </div>
            </div>

            <input
              className="input-20"
              style={{
                marginLeft: screenWidth < 393 ? "-36.50px" : undefined,
                marginRight: screenWidth < 393 ? "-36.50px" : undefined,
              }}
              placeholder="Email Receipt"
              type="email"
            />

            <div
              className="input-21"
              style={{
                alignSelf: screenWidth < 393 ? "stretch" : undefined,
                width:
                  screenWidth < 393
                    ? "100%"
                    : screenWidth >= 393 && screenWidth < 1200
                      ? "361px"
                      : undefined,
              }}
            >
              <div className="text-wrapper-261">Subject</div>

              <div className="input-17">
                <p className="text-wrapper-263">
                  Add sales tax on top of product price
                </p>
              </div>
            </div>

            <div
              className="input-22"
              style={{
                alignSelf: screenWidth < 393 ? "stretch" : undefined,
                width:
                  screenWidth < 393
                    ? "100%"
                    : screenWidth >= 393 && screenWidth < 1200
                      ? "361px"
                      : undefined,
              }}
            >
              <div className="text-wrapper-261">Message</div>

              <div className="input-17">
                <p className="text-wrapper-263">
                  Add sales tax on top of product price
                </p>
              </div>
            </div>

            <div className="CTA-5">
              <div
                className="frame-544"
                style={{
                  flex: screenWidth < 393 ? "1" : undefined,
                  flexGrow: screenWidth < 393 ? "1" : undefined,
                  width:
                    screenWidth >= 393 && screenWidth < 1200
                      ? "172.5px"
                      : undefined,
                }}
              >
                <div className="text-wrapper-265">Cancel</div>
              </div>

              <div
                className="frame-545"
                style={{
                  flex: screenWidth < 393 ? "1" : undefined,
                  flexGrow: screenWidth < 393 ? "1" : undefined,
                  width:
                    screenWidth >= 393 && screenWidth < 1200
                      ? "172.5px"
                      : undefined,
                }}
              >
                <div className="text-wrapper-266">Save</div>
              </div>
            </div>
          </div>

          <div
            className="frame-546"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1200
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-12">
              {screenWidth < 393 && (
                <div className="frame-547">
                  <div className="navigation-menu-home-4">
                    <div className="navigation-menu-home-5">
                      <img
                        className="img-34"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-267">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-13">
                    <SearchNormal property1="linear" />
                    <div className="text-wrapper-268">Search</div>
                  </div>

                  <div className="navigation-menu-13">
                    <img
                      className="img-35"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-269">Cart</div>
                  </div>

                  <div className="navigation-menu-13">
                    <img
                      className="img-35"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-270">Help</div>
                  </div>

                  <div className="navigation-menu-13">
                    <img
                      className="image-30"
                      alt="Image"
                      src="/img/image-6.png"
                    />

                    <div className="text-wrapper-271">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1200 && (
                <>
                  <div className="navigation-menu-home-4">
                    <div className="navigation-menu-home-5">
                      <div className="frame-548" />

                      <div className="text-wrapper-267">Profile</div>
                    </div>
                  </div>

                  <div className="navigation-menu-14">
                    <SearchNormal property1="linear" />
                  </div>

                  <div className="navigation-menu-14">
                    <img
                      className="img-34"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-9.svg"
                    />
                  </div>

                  <div className="navigation-menu-14">
                    <div className="frame-549">
                      <div className="ellipse-29" />
                    </div>
                  </div>

                  <div className="navigation-menu-14">
                    <img
                      className="image-31"
                      alt="Image"
                      src="/img/image-6.png"
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-33"
            lineClassName={`${screenWidth < 393 && "class-45"} ${screenWidth >= 393 && screenWidth < 1200 && "class-46"}`}
            property1="dark"
          />
        </>
      )}

      {((screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440) && (
        <div className="frame-550">
          <div className="frame-551">
            <div className="frame-552">
              <div className="frame-553">
                <div className="frame-554">
                  <div className="frame-555">
                    <div className="text-wrapper-272">LOGO</div>
                  </div>
                </div>

                <div className="div-9">
                  <div className="frame-556">
                    <img
                      className="img-36"
                      alt="Home angle svgrepo"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/home-angle-svgrepo-com-15-2.svg"
                          : screenWidth >= 1440
                            ? "/img/home-angle-svgrepo-com-14-2.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-273">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-552">
                <div className="frame-552">
                  <div className="frame-557">
                    <div className="img-36">
                      <div className="vuesax-linear-gift-13">
                        <img
                          className="gift-23"
                          alt="Gift"
                          src={
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "/img/gift-7.png"
                              : screenWidth >= 1440
                                ? "/img/gift-6-2x.png"
                                : undefined
                          }
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-274">Products</div>
                  </div>

                  <div className="frame-557">
                    <img
                      className="img-36"
                      alt="Users group two"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/users-group-two-rounded-svgrepo-com-7.svg"
                          : screenWidth >= 1440
                            ? "/img/users-group-two-rounded-svgrepo-com-6.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-274">Collaborators</div>
                  </div>

                  <div className="frame-557">
                    <img
                      className="img-36"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-6-2.svg"
                    />

                    <div className="text-wrapper-274">Checkout</div>
                  </div>

                  <div className="frame-557">
                    <img
                      className="img-36"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-274">Emails</div>
                  </div>

                  <div className="frame-557">
                    <img
                      className="img-36"
                      alt="Flow parallel"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/flow-parallel-svgrepo-com-7-2.svg"
                          : screenWidth >= 1440
                            ? "/img/flow-parallel-svgrepo-com-6.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-274">Workflows</div>
                  </div>

                  <div className="frame-557">
                    <img
                      className="img-36"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-14.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-12.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-274">Sales</div>
                  </div>

                  <div className="frame-557">
                    <img
                      className="img-36"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-274">Analytics</div>
                  </div>

                  <div className="frame-557">
                    <img
                      className="img-36"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-14.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-12.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-274">Payouts</div>
                  </div>

                  <div className="frame-557">
                    <img
                      className="img-36"
                      alt="Book bookmark"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/book-bookmark-minimalistic-svgrepo-com-7.svg"
                          : screenWidth >= 1440
                            ? "/img/book-bookmark-minimalistic-svgrepo-com-6-2.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-274">Library</div>
                  </div>
                </div>

                <div className="frame-557">
                  <img
                    className="img-36"
                    alt="Settings svgrepo com"
                    src={
                      screenWidth >= 1200 && screenWidth < 1440
                        ? "/img/settings-svgrepo-com-7.svg"
                        : screenWidth >= 1440
                          ? "/img/settings-svgrepo-com-6-2.svg"
                          : undefined
                    }
                  />

                  <div className="text-wrapper-274">Settings</div>
                </div>

                <div className="frame-557">
                  <img
                    className="img-36"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-6-2.svg"
                  />

                  <div className="text-wrapper-274">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-558">
            <div className="frame-559">
              <div className="frame-560">
                <div className="frame-561">
                  <div className="text-wrapper-275">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-562">
                <div className="text-wrapper-266">Login</div>
              </div>

              <div className="frame-563">
                <div className="text-wrapper-276">Sign Up</div>
              </div>
            </div>

            <div className="frame-564">
              <div className="frame-543">
                <div className="back-icon-button-34">
                  <div className="vuesax-outline-arrow-16" />
                </div>

                <div className="frame-531">
                  <div className="text-wrapper-277">Account settings</div>

                  <p className="text-wrapper-278">
                    Edit your account details here such as payment details,
                    name, download limits etc.
                  </p>
                </div>
              </div>

              <div className="frame-533">
                <div className="frame-565">
                  <div className="text-wrapper-279">Store</div>

                  <img
                    className="vector-90"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-49970.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-8926.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-566">
                  <div className="text-wrapper-279">Payment Details</div>

                  <img
                    className="vector-91"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-50028.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-8868.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-567">
                  <div className="text-wrapper-279">Billing &amp; Invoices</div>

                  <img
                    className="vector-92"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-50167.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-8729.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-568">
                  <div className="text-wrapper-279">Taxes</div>

                  <img
                    className="vector-93"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-50309.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-8587.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-569">
                  <div className="text-wrapper-279">Shipping</div>

                  <img
                    className="vector-94"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-50367.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-8529.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-570">
                  <div className="text-wrapper-280">Advance settings</div>

                  <img
                    className="vector-95"
                    alt="Vector"
                    src={
                      screenWidth >= 1200 && screenWidth < 1440
                        ? "/img/vector-1-152.svg"
                        : screenWidth >= 1440
                          ? "/img/vector-1-128.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-571">
                  <div className="text-wrapper-279">Login settings</div>

                  <img
                    className="vector-96"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-50599.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-8297.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-572">
                  <div className="text-wrapper-279">Developers</div>

                  <img
                    className="vector-97"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-50723.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-8173.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>
              </div>

              <div className="frame-573">
                <div className="frame-533">
                  <div className="input-23">
                    <div className="text-wrapper-281">
                      Protect your PDF files
                    </div>

                    <div className="frame-543">
                      <div className="default-circle-4" />

                      <p className="text-wrapper-282">
                        Stamp the buyer&#39;s email on the top left of each page
                        of your PDF for files below 250MB.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="frame-533">
                  <div className="input-23">
                    <div className="text-wrapper-281">Email Notifications</div>

                    <div className="frame-543">
                      <div className="default-circle-4" />

                      <p className="text-wrapper-282">
                        {" "}
                        Send me a notification email everytime one of my
                        products is sold
                      </p>
                    </div>
                  </div>
                </div>

                <div className="frame-533">
                  <div className="input-23">
                    <div className="text-wrapper-281">
                      Inventory Notifications
                    </div>

                    <div className="frame-543">
                      <div className="default-circle-4" />

                      <p className="text-wrapper-282">
                        {" "}
                        Send me a notification email if my physical product
                        inventory falls below a certain level
                      </p>
                    </div>
                  </div>
                </div>

                <div className="frame-533">
                  <div className="frame-574">
                    <div className="input-23">
                      <div className="text-wrapper-281">Download Limit</div>

                      <div className="input-17">
                        <div className="text-wrapper-263">5</div>

                        <img
                          className="expand-more-3"
                          alt="Expand more"
                          src={
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "/img/expand-more-9.svg"
                              : screenWidth >= 1440
                                ? "/img/expand-more-4-3.svg"
                                : undefined
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <div className="input-23">
                    <div className="text-wrapper-281">Google Analytics</div>

                    <div className="input-17">
                      <p className="text-wrapper-263">
                        Enter Google analytics unique ID
                      </p>

                      <img
                        className="expand-more-3"
                        alt="Expand more"
                        src={
                          screenWidth >= 1200 && screenWidth < 1440
                            ? "/img/expand-more-10.svg"
                            : screenWidth >= 1440
                              ? "/img/expand-more-5-2.svg"
                              : undefined
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="frame-533">
                  <div className="input-23">
                    <div className="text-wrapper-281">Facebook Pixel</div>

                    <div className="input-17">
                      <div className="text-wrapper-263">
                        Enter Facebook Pixel ID
                      </div>

                      <img
                        className="expand-more-3"
                        alt="Expand more"
                        src={
                          screenWidth >= 1200 && screenWidth < 1440
                            ? "/img/expand-more-11.svg"
                            : screenWidth >= 1440
                              ? "/img/expand-more-6-2.svg"
                              : undefined
                        }
                      />
                    </div>
                  </div>

                  <div className="input-23">
                    <div className="text-wrapper-281">Store Units</div>

                    <div className="frame-542">
                      <div className="frame-543">
                        <div className="default-circle-6" />

                        <div className="text-wrapper-282">Imperial</div>
                      </div>
                    </div>

                    <div className="frame-542">
                      <div className="frame-543">
                        <div className="default-circle-6" />

                        <div className="text-wrapper-282">Metric</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-533">
                  <div className="input-23">
                    <div className="text-wrapper-281">Checkout Settings</div>

                    <div className="frame-542">
                      <div className="frame-543">
                        <div className="default-circle-4" />

                        <p className="text-wrapper-282">
                          {" "}
                          Redirect customers to a particular webpage when they
                          successfully complete the checkout
                        </p>
                      </div>
                    </div>

                    <div className="frame-542">
                      <div className="frame-543">
                        <div className="default-circle-4" />

                        <p className="text-wrapper-282">
                          Collect customer first and last name during digital
                          product checkout
                        </p>
                      </div>
                    </div>

                    <div className="frame-542">
                      <div className="frame-543">
                        <div className="default-circle-4" />

                        <p className="text-wrapper-282">
                          Enable gifting for digital products
                        </p>
                      </div>
                    </div>

                    <div className="frame-542">
                      <div className="frame-543">
                        <div className="default-circle-4" />

                        <p className="text-wrapper-282">
                          Display your own questions for customers to answer
                          during checkout
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="div-9">
                  <div className="text-wrapper-281">Course Settings</div>

                  <div className="frame-542">
                    <div className="frame-543">
                      <div className="default-circle-4" />

                      <p className="text-wrapper-282">
                        {" "}
                        Send me a notification email anytime course student
                        posts a comment on my course
                      </p>
                    </div>
                  </div>

                  <div className="frame-542">
                    <div className="frame-543">
                      <div className="default-circle-4" />

                      <p className="text-wrapper-282">
                        {" "}
                        Send my course students a notification email when
                        someone replies to their comment
                      </p>
                    </div>
                  </div>

                  <div className="frame-542">
                    <div className="frame-543">
                      <div className="default-circle-4" />

                      <p className="text-wrapper-282">
                        {" "}
                        Allow people who have a free preview version of my
                        course to post comments
                      </p>
                    </div>
                  </div>

                  <div className="frame-542">
                    <div className="frame-543">
                      <div className="default-circle-4" />

                      <p className="text-wrapper-282">
                        {" "}
                        Send me a notification email when course student submits
                        file for assignment lesson
                      </p>
                    </div>
                  </div>
                </div>

                <div className="div-9">
                  <div className="text-wrapper-281">
                    Logo &amp; Invoice Settings
                  </div>

                  <div className="frame-542">
                    <div className="frame-543">
                      <div className="default-circle-4" />

                      <p className="text-wrapper-282">
                        {" "}
                        Add your logo on invoices and email receipts that
                        customers receive
                      </p>
                    </div>
                  </div>

                  <div className="frame-542">
                    <div className="frame-543">
                      <div className="default-circle-4" />

                      <p className="text-wrapper-282">
                        {" "}
                        Add your business address on invoices that customers
                        receive
                      </p>
                    </div>
                  </div>
                </div>

                <div className="frame-575">
                  <input
                    className="input-24"
                    placeholder="Email Receipt"
                    type="email"
                  />
                </div>

                <div className="frame-575">
                  <div className="input-23">
                    <div className="text-wrapper-281">Subject:</div>

                    <div className="input-17">
                      <p className="text-wrapper-263">
                        Add sales tax on top of product price
                      </p>

                      <img
                        className="expand-more-3"
                        alt="Expand more"
                        src={
                          screenWidth >= 1200 && screenWidth < 1440
                            ? "/img/expand-more-12.svg"
                            : screenWidth >= 1440
                              ? "/img/expand-more-7-3.svg"
                              : undefined
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="frame-575">
                  <div className="input-23">
                    <div className="text-wrapper-281">Message:</div>

                    <div className="input-17">
                      <p className="text-wrapper-263">
                        Add sales tax on top of product price
                      </p>

                      <img
                        className="expand-more-3"
                        alt="Expand more"
                        src={
                          screenWidth >= 1200 && screenWidth < 1440
                            ? "/img/expand-more-13-2.svg"
                            : screenWidth >= 1440
                              ? "/img/expand-more-8-2.svg"
                              : undefined
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="CTA-5">
                  <div className="frame-576">
                    <div className="text-wrapper-265">Cancel</div>
                  </div>

                  <div className="frame-577">
                    <div className="text-wrapper-266">Save</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
