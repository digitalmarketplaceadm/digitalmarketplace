import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const SecurityTaxScreen = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-tax-screen"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        height: screenWidth >= 1440 ? "1024px" : undefined,
        minHeight:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "100vh"
            : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-109"} ${screenWidth >= 393 && screenWidth < 1440 && "class-110"}`}
            className={`${screenWidth < 393 && "class-107"} ${screenWidth >= 393 && screenWidth < 1440 && "class-108"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-38.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-39.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-111"} ${screenWidth >= 393 && screenWidth < 1440 && "class-112"}`}
            property1="dark"
            wiFi="/img/wi-fi-38.svg"
          />
          <div className="frame-1104">
            <div className="back-icon-button-47">
              <div className="vuesax-outline-arrow-28" />
            </div>

            <div className="frame-1105">
              <div className="text-wrapper-560">Tax Information</div>
            </div>
          </div>

          <div className="frame-1106">
            <div className="frame-1107">
              <div className="div-17">
                <div className="text-wrapper-561">Country</div>

                <div className="input-73">
                  <div className="text-wrapper-562">Select your country</div>

                  <img
                    className="expand-more-7"
                    alt="Expand more"
                    src={
                      screenWidth < 393
                        ? "/img/expand-more-4-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/expand-more-5.svg"
                          : undefined
                    }
                  />
                </div>
              </div>

              <div className="frame-1108">
                <div className="input-74">
                  <div className="text-wrapper-563">E-mail Newsletters</div>

                  <div className="frame-1109">
                    <div className="default-circle-14" />

                    <p className="send-me-tips-trends">
                      Send me tips, trends, freebies, updates, &amp; offers. You
                      can unsubscribe at any tie.
                    </p>
                  </div>
                </div>
              </div>

              <div className="frame-1108">
                <div className="input-74">
                  <div className="div-17">
                    <div className="text-wrapper-563">
                      Terms &amp; Conditions
                    </div>
                  </div>

                  <div className="frame-1109">
                    <div className="default-circle-14" />

                    <p className="i-have-read-and">
                      <span className="text-wrapper-564">
                        I have read and agree to the{" "}
                      </span>

                      <span className="text-wrapper-565">
                        Terms &amp; Conditions.
                      </span>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="CTA-16">
              <div className="frame-1110">
                <div className="text-wrapper-566">Cancel</div>
              </div>

              <div className="frame-1111">
                <div className="text-wrapper-567">Next</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-47"
            lineClassName={`${screenWidth < 393 && "class-113"} ${screenWidth >= 393 && screenWidth < 1440 && "class-114"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-1112">
          <div className="frame-1113">
            <div className="frame-1114">
              <div className="frame-1115">
                <div className="frame-1116">
                  <div className="frame-1117">
                    <div className="text-wrapper-568">LOGO</div>
                  </div>
                </div>

                <div className="div-17">
                  <div className="frame-1118">
                    <img
                      className="img-58"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-17.svg"
                    />

                    <div className="text-wrapper-569">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-1114">
                <div className="frame-1114">
                  <div className="frame-1119">
                    <div className="img-58">
                      <div className="vuesax-linear-gift-25">
                        <img
                          className="gift-35"
                          alt="Gift"
                          src="/img/gift-9.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-570">Products</div>
                  </div>

                  <div className="frame-1119">
                    <img
                      className="img-58"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-570">Collaborators</div>
                  </div>

                  <div className="frame-1119">
                    <img
                      className="img-58"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-9-2.svg"
                    />

                    <div className="text-wrapper-570">Checkout</div>
                  </div>

                  <div className="frame-1119">
                    <img
                      className="img-58"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-570">Emails</div>
                  </div>

                  <div className="frame-1119">
                    <img
                      className="img-58"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-570">Workflows</div>
                  </div>

                  <div className="frame-1119">
                    <img
                      className="img-58"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-18.svg"
                    />

                    <div className="text-wrapper-570">Sales</div>
                  </div>

                  <div className="frame-1119">
                    <img
                      className="img-58"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-570">Analytics</div>
                  </div>

                  <div className="frame-1119">
                    <img
                      className="img-58"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-19.svg"
                    />

                    <div className="text-wrapper-570">Payouts</div>
                  </div>

                  <div className="frame-1119">
                    <img
                      className="img-58"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-570">Library</div>
                  </div>
                </div>

                <div className="frame-1119">
                  <img
                    className="img-58"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-9.svg"
                  />

                  <div className="text-wrapper-570">Settings</div>
                </div>

                <div className="frame-1119">
                  <img
                    className="img-58"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-9.svg"
                  />

                  <div className="text-wrapper-570">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-1120">
            <div className="frame-1121">
              <div className="frame-1122">
                <div className="frame-1123">
                  <div className="text-wrapper-571">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-1124">
                <div className="text-wrapper-572">Login</div>
              </div>

              <div className="frame-1125">
                <div className="text-wrapper-573">Sign Up</div>
              </div>
            </div>

            <div className="frame-1126">
              <div className="frame-1127">
                <div className="back-icon-button-47">
                  <div className="vuesax-outline-arrow-28" />
                </div>

                <div className="div-18">
                  <div className="text-wrapper-574">Tax Information</div>

                  <p className="text-wrapper-575">
                    Tax information refers to essential details related to an
                    individual’s or entity’s tax obligations, filings, and
                    compliance with government tax laws.
                  </p>
                </div>
              </div>

              <div className="frame-1107">
                <div className="input-75">
                  <div className="text-wrapper-561">Country</div>

                  <div className="input-76">
                    <div className="text-wrapper-576">Select your country</div>

                    <img
                      className="expand-more-7"
                      alt="Expand more"
                      src="/img/expand-more-3-2.svg"
                    />
                  </div>
                </div>

                <div className="frame-1128">
                  <div className="div-18">
                    <div className="text-wrapper-577">E-mail Newsletters</div>

                    <div className="frame-1129">
                      <div className="default-circle-14" />

                      <p className="send-me-tips-trends-2">
                        Send me tips, trends, freebies, updates, &amp; offers.
                        You can unsubscribe at any tie.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="frame-1128">
                  <div className="div-18">
                    <div className="terms-conditions-wrapper">
                      <div className="text-wrapper-577">
                        Terms &amp; Conditions
                      </div>
                    </div>

                    <div className="frame-1129">
                      <div className="default-circle-14" />

                      <p className="i-have-read-and-2">
                        <span className="text-wrapper-564">
                          I have read and agree to the{" "}
                        </span>

                        <span className="text-wrapper-565">
                          Terms &amp; Conditions.
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="CTA-16">
                <div className="frame-1130">
                  <div className="text-wrapper-566">Cancel</div>
                </div>

                <div className="frame-1131">
                  <div className="text-wrapper-567">Next</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
