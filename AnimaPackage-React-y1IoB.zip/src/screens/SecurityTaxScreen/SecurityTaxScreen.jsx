import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const SecurityTaxScreen = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-tax-screen"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        height: screenWidth >= 1440 ? "1024px" : undefined,
        minHeight:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "100vh"
            : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-49"} ${screenWidth >= 393 && screenWidth < 1440 && "class-50"}`}
            className={`${screenWidth < 393 && "class-51"} ${screenWidth >= 393 && screenWidth < 1440 && "class-52"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-18.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-19.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-53"} ${screenWidth >= 393 && screenWidth < 1440 && "class-54"}`}
            property1="dark"
            wiFi="/img/wi-fi-18.svg"
          />
          <div className="frame-358">
            <div className="back-icon-button-9">
              <div className="vuesax-outline-arrow-10" />
            </div>

            <div className="frame-359">
              <div className="text-wrapper-243">Tax Information</div>
            </div>
          </div>

          <div className="frame-360">
            <div className="frame-361">
              <div className="div-9">
                <div className="text-wrapper-244">Country</div>

                <div className="input-50">
                  <div className="text-wrapper-245">Select your country</div>

                  <img
                    className="expand-more-2"
                    alt="Expand more"
                    src={
                      screenWidth < 393
                        ? "/img/expand-more-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/expand-more-5.svg"
                          : undefined
                    }
                  />
                </div>
              </div>

              <div className="frame-362">
                <div className="input-51">
                  <div className="text-wrapper-246">E-mail Newsletters</div>

                  <div className="frame-363">
                    <div className="default-circle-7" />

                    <p className="send-me-tips-trends">
                      Send me tips, trends, freebies, updates, &amp; offers. You
                      can unsubscribe at any tie.
                    </p>
                  </div>
                </div>
              </div>

              <div className="frame-362">
                <div className="input-51">
                  <div className="div-9">
                    <div className="text-wrapper-246">
                      Terms &amp; Conditions
                    </div>
                  </div>

                  <div className="frame-363">
                    <div className="default-circle-7" />

                    <p className="i-have-read-and">
                      <span className="text-wrapper-247">
                        I have read and agree to the{" "}
                      </span>

                      <span className="text-wrapper-248">
                        Terms &amp; Conditions.
                      </span>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="CTA-8">
              <div className="frame-364">
                <div className="text-wrapper-249">Cancel</div>
              </div>

              <div className="frame-365">
                <div className="text-wrapper-250">Next</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-10"
            lineClassName={`${screenWidth < 393 && "class-55"} ${screenWidth >= 393 && screenWidth < 1440 && "class-56"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-366">
          <div className="frame-367">
            <div className="frame-368">
              <div className="frame-369">
                <div className="frame-370">
                  <div className="frame-371">
                    <div className="text-wrapper-251">LOGO</div>
                  </div>
                </div>

                <div className="div-9">
                  <div className="frame-372">
                    <img
                      className="img-19"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-252">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-368">
                <div className="frame-368">
                  <div className="frame-373">
                    <div className="img-19">
                      <div className="vuesax-linear-gift-8">
                        <img
                          className="gift-10"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-253">Products</div>
                  </div>

                  <div className="frame-373">
                    <img
                      className="img-19"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-253">Collaborators</div>
                  </div>

                  <div className="frame-373">
                    <img
                      className="img-19"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-253">Checkout</div>
                  </div>

                  <div className="frame-373">
                    <img
                      className="img-19"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-253">Emails</div>
                  </div>

                  <div className="frame-373">
                    <img
                      className="img-19"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-253">Workflows</div>
                  </div>

                  <div className="frame-373">
                    <img
                      className="img-19"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-8.svg"
                    />

                    <div className="text-wrapper-253">Sales</div>
                  </div>

                  <div className="frame-373">
                    <img
                      className="img-19"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-253">Analytics</div>
                  </div>

                  <div className="frame-373">
                    <img
                      className="img-19"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-253">Payouts</div>
                  </div>

                  <div className="frame-373">
                    <img
                      className="img-19"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-253">Library</div>
                  </div>
                </div>

                <div className="frame-373">
                  <img
                    className="img-19"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-253">Settings</div>
                </div>

                <div className="frame-373">
                  <img
                    className="img-19"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-253">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-374">
            <div className="frame-375">
              <div className="frame-376">
                <div className="frame-377">
                  <div className="text-wrapper-254">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-378">
                <div className="text-wrapper-255">Login</div>
              </div>

              <div className="frame-379">
                <div className="text-wrapper-256">Sign Up</div>
              </div>
            </div>

            <div className="frame-380">
              <div className="frame-381">
                <div className="back-icon-button-9">
                  <div className="vuesax-outline-arrow-10" />
                </div>

                <div className="div-10">
                  <div className="text-wrapper-257">Tax Information</div>

                  <p className="text-wrapper-258">
                    Tax information refers to essential details related to an
                    individual’s or entity’s tax obligations, filings, and
                    compliance with government tax laws.
                  </p>
                </div>
              </div>

              <div className="frame-361">
                <div className="input-52">
                  <div className="text-wrapper-244">Country</div>

                  <div className="input-53">
                    <div className="text-wrapper-259">Select your country</div>

                    <img
                      className="expand-more-2"
                      alt="Expand more"
                      src="/img/expand-more-3.svg"
                    />
                  </div>
                </div>

                <div className="frame-382">
                  <div className="div-10">
                    <div className="text-wrapper-260">E-mail Newsletters</div>

                    <div className="frame-383">
                      <div className="default-circle-7" />

                      <p className="send-me-tips-trends-2">
                        Send me tips, trends, freebies, updates, &amp; offers.
                        You can unsubscribe at any tie.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="frame-382">
                  <div className="div-10">
                    <div className="terms-conditions-wrapper">
                      <div className="text-wrapper-260">
                        Terms &amp; Conditions
                      </div>
                    </div>

                    <div className="frame-383">
                      <div className="default-circle-7" />

                      <p className="i-have-read-and-2">
                        <span className="text-wrapper-247">
                          I have read and agree to the{" "}
                        </span>

                        <span className="text-wrapper-248">
                          Terms &amp; Conditions.
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="CTA-8">
                <div className="frame-384">
                  <div className="text-wrapper-249">Cancel</div>
                </div>

                <div className="frame-385">
                  <div className="text-wrapper-250">Next</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
