import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal } from "../../icons/SearchNormal";
import "./style.css";

export const SecurityTaxScreen = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-tax-screen"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        height: screenWidth >= 1440 ? "1024px" : undefined,
        minHeight:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "100vh"
            : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-21"} ${screenWidth >= 393 && screenWidth < 1440 && "class-22"}`}
            className={`${screenWidth < 393 && "class-23"} ${screenWidth >= 393 && screenWidth < 1440 && "class-24"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-18.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-19.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-19"} ${screenWidth >= 393 && screenWidth < 1440 && "class-20"}`}
            property1="dark"
            wiFi="/img/wi-fi-18.svg"
          />
          <div className="frame-59">
            <div className="back-icon-button-2">
              <div className="vuesax-outline-arrow-3" />
            </div>

            <div className="frame-60">
              <div className="text-wrapper-35">Tax Information</div>
            </div>
          </div>

          <div className="frame-61">
            <div className="frame-62">
              <div className="div-4">
                <div className="text-wrapper-36">Country</div>

                <div className="input-8">
                  <div className="text-wrapper-37">Select your country</div>

                  <img
                    className="expand-more-2"
                    alt="Expand more"
                    src={
                      screenWidth < 393
                        ? "/img/expand-more-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/expand-more-5.svg"
                          : undefined
                    }
                  />
                </div>
              </div>

              <div className="frame-63">
                <div className="input-9">
                  <div className="text-wrapper-38">E-mail Newsletters</div>

                  <div className="frame-64">
                    <div className="default-circle-3" />

                    <p className="send-me-tips-trends">
                      Send me tips, trends, freebies, updates, &amp; offers. You
                      can unsubscribe at any tie.
                    </p>
                  </div>
                </div>
              </div>

              <div className="frame-63">
                <div className="input-9">
                  <div className="div-4">
                    <div className="text-wrapper-38">
                      Terms &amp; Conditions
                    </div>
                  </div>

                  <div className="frame-64">
                    <div className="default-circle-3" />

                    <p className="i-have-read-and">
                      <span className="span">
                        I have read and agree to the{" "}
                      </span>

                      <span className="text-wrapper-39">
                        Terms &amp; Conditions.
                      </span>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="CTA-5">
              <div className="frame-65">
                <div className="text-wrapper-40">Cancel</div>
              </div>

              <div className="frame-66">
                <div className="text-wrapper-41">Next</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="instance-node"
            lineClassName={`${screenWidth < 393 && "class-25"} ${screenWidth >= 393 && screenWidth < 1440 && "class-26"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-67">
          <div className="frame-68">
            <div className="frame-69">
              <div className="frame-70">
                <div className="frame-71">
                  <div className="frame-72">
                    <div className="text-wrapper-42">LOGO</div>
                  </div>
                </div>

                <div className="div-4">
                  <div className="frame-73">
                    <img
                      className="img-3"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-43">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-69">
                <div className="frame-69">
                  <div className="frame-74">
                    <div className="img-3">
                      <div className="img-wrapper">
                        <img
                          className="gift-3"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-44">Products</div>
                  </div>

                  <div className="frame-74">
                    <img
                      className="img-3"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-44">Collaborators</div>
                  </div>

                  <div className="frame-74">
                    <img
                      className="img-3"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-44">Checkout</div>
                  </div>

                  <div className="frame-74">
                    <img
                      className="img-3"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-44">Emails</div>
                  </div>

                  <div className="frame-74">
                    <img
                      className="img-3"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-44">Workflows</div>
                  </div>

                  <div className="frame-74">
                    <img
                      className="img-3"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-8.svg"
                    />

                    <div className="text-wrapper-44">Sales</div>
                  </div>

                  <div className="frame-74">
                    <img
                      className="img-3"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-44">Analytics</div>
                  </div>

                  <div className="frame-74">
                    <img
                      className="img-3"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-44">Payouts</div>
                  </div>

                  <div className="frame-74">
                    <img
                      className="img-3"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-44">Library</div>
                  </div>
                </div>

                <div className="frame-74">
                  <img
                    className="img-3"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-44">Settings</div>
                </div>

                <div className="frame-74">
                  <img
                    className="img-3"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-44">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-75">
            <div className="frame-76">
              <div className="frame-77">
                <div className="frame-78">
                  <div className="text-wrapper-45">Search</div>

                  <SearchNormal className="search-normal-5" color="#232323" />
                </div>
              </div>

              <div className="frame-79">
                <div className="text-wrapper-46">Login</div>
              </div>

              <div className="frame-80">
                <div className="text-wrapper-47">Sign Up</div>
              </div>
            </div>

            <div className="frame-81">
              <div className="frame-82">
                <div className="back-icon-button-2">
                  <div className="vuesax-outline-arrow-3" />
                </div>

                <div className="div-5">
                  <div className="text-wrapper-48">Tax Information</div>

                  <p className="text-wrapper-49">
                    Tax information refers to essential details related to an
                    individual’s or entity’s tax obligations, filings, and
                    compliance with government tax laws.
                  </p>
                </div>
              </div>

              <div className="frame-62">
                <div className="input-10">
                  <div className="text-wrapper-36">Country</div>

                  <div className="input-11">
                    <div className="text-wrapper-50">Select your country</div>

                    <img
                      className="expand-more-2"
                      alt="Expand more"
                      src="/img/expand-more-3.svg"
                    />
                  </div>
                </div>

                <div className="frame-83">
                  <div className="div-5">
                    <div className="text-wrapper-51">E-mail Newsletters</div>

                    <div className="frame-84">
                      <div className="default-circle-3" />

                      <p className="send-me-tips-trends-2">
                        Send me tips, trends, freebies, updates, &amp; offers.
                        You can unsubscribe at any tie.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="frame-83">
                  <div className="div-5">
                    <div className="terms-conditions-wrapper">
                      <div className="text-wrapper-51">
                        Terms &amp; Conditions
                      </div>
                    </div>

                    <div className="frame-84">
                      <div className="default-circle-3" />

                      <p className="i-have-read-and-2">
                        <span className="span">
                          I have read and agree to the{" "}
                        </span>

                        <span className="text-wrapper-39">
                          Terms &amp; Conditions.
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="CTA-5">
                <div className="frame-85">
                  <div className="text-wrapper-40">Cancel</div>
                </div>

                <div className="frame-86">
                  <div className="text-wrapper-41">Next</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
