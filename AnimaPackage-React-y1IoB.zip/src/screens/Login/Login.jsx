import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const Login = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="login"
      style={{
        alignItems:
          screenWidth < 1440
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1440
            ? "var(--variable-collection-white-duplicate)"
            : screenWidth >= 1440
              ? "var(--variable-collection-fill-duplicate)"
              : undefined,
        flexDirection: screenWidth < 1440 ? "column" : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight:
          screenWidth < 1440
            ? "100vh"
            : screenWidth >= 1440
              ? "952px"
              : undefined,
        minWidth:
          screenWidth < 1440
            ? "393px"
            : screenWidth >= 1440
              ? "1440px"
              : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {screenWidth < 1440 && (
        <>
          <StatusBar
            batteryClassName="status-bar-9"
            className="status-bar-6"
            combinedShape="/img/combined-shape-2.svg"
            containerClassName="status-bar-8"
            property1="dark"
            rectangleClassName="status-bar-10"
            timeClassName="status-bar-7"
            wiFi="/img/wi-fi-2.svg"
          />
          <div className="frame-25">
            <div className="frame-26">
              <img className="logo" alt="Logo" src="/img/logo-1.svg" />

              <div className="frame-27">
                <div className="text-wrapper-16">Sign In</div>

                <div className="text-wrapper-17">Welcome back!</div>
              </div>

              <div className="frame-28">
                <div className="frame-29">
                  <div className="input">
                    <input
                      className="email-address"
                      placeholder="Email Address"
                      type="email"
                    />

                    <input
                      className="input-2"
                      placeholder="Enter Email Address"
                      type="email"
                    />
                  </div>

                  <div className="input">
                    <div className="text-wrapper-18">Password</div>

                    <div className="input-3">
                      <div className="text-wrapper-19">Enter Password</div>
                    </div>
                  </div>

                  <div className="frame-30">
                    <div className="frame-31">
                      <div className="rectangle-2" />

                      <div className="text-wrapper-20">Remember Me</div>
                    </div>

                    <div className="text-wrapper-21">Forgot Password?</div>
                  </div>
                </div>
              </div>

              <div className="frame-32">
                <div className="text-wrapper-22">Next</div>
              </div>

              <div className="frame-33">
                <img className="line-2" alt="Line" src="/img/line-21-1.svg" />

                <div className="text-wrapper-23">Or Register with</div>

                <img className="line-2" alt="Line" src="/img/line-20-1.svg" />
              </div>

              <div className="frame-34">
                <div className="frame-35">
                  <div className="social-icon-google">
                    <img
                      className="google-logo"
                      alt="Google logo"
                      src="/img/google-logo-1.svg"
                    />
                  </div>

                  <div className="text-wrapper-24">Sign Up with Google</div>

                  <img
                    className="social-icon-google-2"
                    alt="Social icon google"
                    src="/img/invisible-box-6.png"
                  />
                </div>

                <div className="frame-35">
                  <img
                    className="social-icon-google"
                    alt="Social icon google"
                    src="/img/social-icon-google-5.svg"
                  />

                  <div className="text-wrapper-24">Sign Up with Apple</div>

                  <img
                    className="social-icon-google-2"
                    alt="Social icon google"
                    src="/img/invisible-box-6.png"
                  />
                </div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-3"
            lineClassName="home-indicator-4"
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-36">
          <div className="frame-37">
            <div className="image-wrapper">
              <img className="image-6" alt="Image" src="/img/image-67-2.png" />
            </div>
          </div>

          <div className="frame-37">
            <div className="frame-38">
              <div className="frame-39">
                <img className="logo" alt="Logo" src="/img/logo.svg" />

                <div className="frame-27">
                  <div className="text-wrapper-16">Sign In</div>

                  <div className="text-wrapper-17">Welcome back!</div>
                </div>

                <div className="frame-28">
                  <div className="frame-29">
                    <div className="input">
                      <input
                        className="email-address"
                        placeholder="Email Address"
                        type="email"
                      />

                      <input
                        className="input-2"
                        placeholder="Enter Email Address"
                        type="email"
                      />
                    </div>

                    <div className="input">
                      <div className="text-wrapper-18">Password</div>

                      <div className="input-3">
                        <div className="text-wrapper-19">Enter Password</div>
                      </div>
                    </div>

                    <div className="frame-30">
                      <div className="frame-31">
                        <div className="rectangle-2" />

                        <div className="text-wrapper-20">Remember Me</div>
                      </div>

                      <div className="text-wrapper-21">Forgot Password?</div>
                    </div>
                  </div>
                </div>

                <div className="frame-32">
                  <div className="text-wrapper-22">Next</div>
                </div>

                <div className="frame-33">
                  <img className="line-2" alt="Line" src="/img/line-21.svg" />

                  <div className="text-wrapper-23">Or Register with</div>

                  <img className="line-2" alt="Line" src="/img/line-20.svg" />
                </div>

                <div className="frame-34">
                  <div className="frame-35">
                    <div className="social-icon-google">
                      <img
                        className="google-logo"
                        alt="Google logo"
                        src="/img/google-logo.svg"
                      />
                    </div>

                    <div className="text-wrapper-24">Sign Up with Google</div>

                    <img
                      className="social-icon-google-2"
                      alt="Social icon google"
                      src="/img/social-icon-google-1.png"
                    />
                  </div>

                  <div className="frame-35">
                    <img
                      className="social-icon-google"
                      alt="Social icon google"
                      src="/img/social-icon-google-2.svg"
                    />

                    <div className="text-wrapper-24">Sign Up with Apple</div>

                    <img
                      className="social-icon-google-2"
                      alt="Social icon google"
                      src="/img/social-icon-google-1.png"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
