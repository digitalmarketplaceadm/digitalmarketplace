import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const BillingInvoice = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="billing-invoice"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393
            ? "center"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393
            ? "#ffffff"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393
            ? "column"
            : undefined,
        gap:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
        minHeight:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "100vh"
            : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1200
              ? "393px"
              : screenWidth >= 1200 && screenWidth < 1440
                ? "1200px"
                : screenWidth >= 1440
                  ? "1440px"
                  : undefined,
        padding:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-57"} ${screenWidth >= 393 && screenWidth < 1200 && "class-58"}`}
            className={`${screenWidth < 393 && "class-55"} ${screenWidth >= 393 && screenWidth < 1200 && "class-56"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-31.svg"
                : screenWidth >= 393 && screenWidth < 1200
                  ? "/img/combined-shape-32.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-59"} ${screenWidth >= 393 && screenWidth < 1200 && "class-60"}`}
            property1="dark"
            rectangleClassName="status-bar-99"
            timeClassName="status-bar-98"
            wiFi="/img/wi-fi-31.svg"
          />
          <div className="frame-627">
            <div className="back-icon-button-36">
              <div className="vuesax-outline-arrow-18" />
            </div>

            <div className="frame-628">
              <div className="text-wrapper-309">Account settings</div>

              <p className="text-wrapper-310">
                Edit your account details here such as payment details, name,
                download limits etc.
              </p>
            </div>
          </div>

          <div className="frame-629">
            <div className="frame-wrapper-2">
              <div className="frame-630">
                <div className="frame-631">
                  <div className="text-wrapper-311">Store</div>

                  <img
                    className="vector-115"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-27700.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10238.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-632">
                  <div className="text-wrapper-311">Payment Details</div>

                  <img
                    className="vector-116"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-27753.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10291.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-633"
                  style={{
                    marginRight: screenWidth < 393 ? "-1.00px" : undefined,
                  }}
                >
                  <div className="billing-invoices">Billing &amp; Invoices</div>

                  <img
                    className="vector-117"
                    style={{
                      marginRight:
                        screenWidth >= 393 && screenWidth < 1200
                          ? "-0.75px"
                          : undefined,
                    }}
                    alt="Vector"
                    src={
                      screenWidth < 393
                        ? "/img/vector-1-60.svg"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "/img/vector-1-74.svg"
                          : undefined
                    }
                  />
                </div>

                <div
                  className="frame-634"
                  style={{
                    marginRight: screenWidth < 393 ? "-54.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-311">Taxes</div>

                  <img
                    className="vector-118"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28005.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10543.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-635"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-130.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-57.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-311">Shipping</div>

                  <img
                    className="vector-119"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28058.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10596.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-636"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-261.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-188.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-311">Advance settings</div>

                  <img
                    className="vector-120"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28134.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10672.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-637"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-371.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-298.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-311">Login settings</div>

                  <img
                    className="vector-121"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28265.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10803.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-638"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-464.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-391.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-311">Developers</div>

                  <img
                    className="vector-122"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28375.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10913.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>
              </div>
            </div>

            <div className="frame-639">
              <div className="frame-640">
                <div className="text-wrapper-312">Free Forever</div>
              </div>

              <div className="frame-641">
                <p className="element-mo">
                  <span className="text-wrapper-313">$0/</span>

                  <span className="text-wrapper-314"> mo</span>
                </p>

                <div className="text-wrapper-315">5% transaction fee</div>
              </div>

              <div className="frame-642">
                <div className="text-wrapper-316">Plan Includes:</div>

                <div className="frame-643">
                  <div className="frame-644">
                    <div className="filled-icons-check" />

                    <div className="text-wrapper-317">All features</div>
                  </div>

                  <div className="frame-645">
                    <div className="filled-icons-check" />

                    <div className="text-wrapper-317">Unlimited products</div>
                  </div>

                  <div className="frame-646">
                    <div className="filled-icons-check" />

                    <div className="text-wrapper-317">Unlimited revenue</div>
                  </div>
                </div>
              </div>

              <div className="frame-647">
                <div className="text-wrapper-318">Your Current Plan</div>
              </div>
            </div>

            <div className="frame-639">
              <div className="frame-648">
                <div className="text-wrapper-319">Recommended</div>
              </div>

              <div className="frame-640">
                <div className="text-wrapper-312">Plus</div>
              </div>

              <div className="frame-641">
                <div className="text-wrapper-320">$29 / mo</div>

                <div className="text-wrapper-315">2% transaction fee</div>
              </div>

              <div className="frame-642">
                <div className="text-wrapper-316">Plan Includes:</div>

                <div className="frame-643">
                  <div className="frame-649">
                    <div className="filled-icons-check" />

                    <div className="text-wrapper-317">All features</div>
                  </div>

                  <div className="frame-650">
                    <div className="filled-icons-check" />

                    <div className="text-wrapper-317">Unlimited products</div>
                  </div>

                  <div className="frame-651">
                    <div className="filled-icons-check" />

                    <div className="text-wrapper-317">Unlimited revenue</div>
                  </div>
                </div>
              </div>

              <div className="frame-647">
                <div className="text-wrapper-318">Your Current Plan</div>
              </div>
            </div>

            <div className="frame-639">
              <div className="frame-640">
                <div className="text-wrapper-312">Pro</div>
              </div>

              <div className="frame-641">
                <div className="text-wrapper-320">$99 / mo</div>

                <div className="text-wrapper-315">No transaction fee</div>
              </div>

              <div className="frame-642">
                <div className="text-wrapper-316">Plan Includes:</div>

                <div className="frame-643">
                  <div className="frame-652">
                    <div className="filled-icons-check" />

                    <div className="text-wrapper-317">All features</div>
                  </div>

                  <div className="frame-653">
                    <div className="filled-icons-check" />

                    <div className="text-wrapper-317">Unlimited products</div>
                  </div>

                  <div className="frame-654">
                    <div className="filled-icons-check" />

                    <div className="text-wrapper-317">Unlimited revenue</div>
                  </div>
                </div>
              </div>

              <div className="frame-647">
                <div className="text-wrapper-318">Your Current Plan</div>
              </div>
            </div>

            <div className="CTA-7">
              <div
                className="frame-655"
                style={{
                  flex: screenWidth < 393 ? "1" : undefined,
                  flexGrow: screenWidth < 393 ? "1" : undefined,
                  width:
                    screenWidth >= 393 && screenWidth < 1200
                      ? "172.5px"
                      : undefined,
                }}
              >
                <div className="text-wrapper-321">Cancel</div>
              </div>

              <div
                className="frame-656"
                style={{
                  flex: screenWidth < 393 ? "1" : undefined,
                  flexGrow: screenWidth < 393 ? "1" : undefined,
                  width:
                    screenWidth >= 393 && screenWidth < 1200
                      ? "172.5px"
                      : undefined,
                }}
              >
                <div className="text-wrapper-322">Save</div>
              </div>
            </div>
          </div>

          <div
            className="frame-657"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1200
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-14">
              {screenWidth < 393 && (
                <div className="frame-658">
                  <div className="navigation-menu-home-8">
                    <div className="navigation-menu-home-9">
                      <img
                        className="img-40"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-323">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-17">
                    <SearchNormal property1="linear" />
                    <div className="text-wrapper-324">Search</div>
                  </div>

                  <div className="navigation-menu-17">
                    <img
                      className="img-41"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-325">Cart</div>
                  </div>

                  <div className="navigation-menu-17">
                    <img
                      className="img-41"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-326">Help</div>
                  </div>

                  <div className="navigation-menu-17">
                    <img
                      className="image-34"
                      alt="Image"
                      src="/img/image-6.png"
                    />

                    <div className="text-wrapper-327">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1200 && (
                <>
                  <div className="navigation-menu-home-8">
                    <div className="navigation-menu-home-9">
                      <div className="frame-659" />

                      <div className="text-wrapper-323">Profile</div>
                    </div>
                  </div>

                  <div className="navigation-menu-18">
                    <SearchNormal property1="linear" />
                  </div>

                  <div className="navigation-menu-18">
                    <img
                      className="img-40"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-9.svg"
                    />
                  </div>

                  <div className="navigation-menu-18">
                    <div className="frame-660">
                      <div className="ellipse-31" />
                    </div>
                  </div>

                  <div className="navigation-menu-18">
                    <img
                      className="image-35"
                      alt="Image"
                      src="/img/image-6.png"
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-35"
            lineClassName={`${screenWidth < 393 && "class-61"} ${screenWidth >= 393 && screenWidth < 1200 && "class-62"}`}
            property1="dark"
          />
        </>
      )}

      {((screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440) && (
        <div className="frame-661">
          <div className="frame-662">
            <div className="frame-663">
              <div className="frame-664">
                <div className="frame-665">
                  <div className="frame-666">
                    <div className="text-wrapper-328">LOGO</div>
                  </div>
                </div>

                <div className="frame-wrapper-2">
                  <div className="frame-667">
                    <img
                      className="img-42"
                      alt="Home angle svgrepo"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/home-angle-svgrepo-com-15-2.svg"
                          : screenWidth >= 1440
                            ? "/img/home-angle-svgrepo-com-14-2.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-329">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-663">
                <div className="frame-663">
                  <div className="frame-668">
                    <div className="img-42">
                      <div className="vuesax-linear-gift-15">
                        <img
                          className="gift-25"
                          alt="Gift"
                          src={
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "/img/gift-7.png"
                              : screenWidth >= 1440
                                ? "/img/gift-6-2x.png"
                                : undefined
                          }
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-330">Products</div>
                  </div>

                  <div className="frame-668">
                    <img
                      className="img-42"
                      alt="Users group two"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/users-group-two-rounded-svgrepo-com-7.svg"
                          : screenWidth >= 1440
                            ? "/img/users-group-two-rounded-svgrepo-com-6.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-330">Collaborators</div>
                  </div>

                  <div className="frame-668">
                    <img
                      className="img-42"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-6-2.svg"
                    />

                    <div className="text-wrapper-330">Checkout</div>
                  </div>

                  <div className="frame-668">
                    <img
                      className="img-42"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-330">Emails</div>
                  </div>

                  <div className="frame-668">
                    <img
                      className="img-42"
                      alt="Flow parallel"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/flow-parallel-svgrepo-com-7-2.svg"
                          : screenWidth >= 1440
                            ? "/img/flow-parallel-svgrepo-com-6.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-330">Workflows</div>
                  </div>

                  <div className="frame-668">
                    <img
                      className="img-42"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-14.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-12.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-330">Sales</div>
                  </div>

                  <div className="frame-668">
                    <img
                      className="img-42"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-330">Analytics</div>
                  </div>

                  <div className="frame-668">
                    <img
                      className="img-42"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-14.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-12.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-330">Payouts</div>
                  </div>

                  <div className="frame-668">
                    <img
                      className="img-42"
                      alt="Book bookmark"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/book-bookmark-minimalistic-svgrepo-com-7.svg"
                          : screenWidth >= 1440
                            ? "/img/book-bookmark-minimalistic-svgrepo-com-6-2.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-330">Library</div>
                  </div>
                </div>

                <div className="frame-668">
                  <img
                    className="img-42"
                    alt="Settings svgrepo com"
                    src={
                      screenWidth >= 1200 && screenWidth < 1440
                        ? "/img/settings-svgrepo-com-7.svg"
                        : screenWidth >= 1440
                          ? "/img/settings-svgrepo-com-6-2.svg"
                          : undefined
                    }
                  />

                  <div className="text-wrapper-330">Settings</div>
                </div>

                <div className="frame-668">
                  <img
                    className="img-42"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-6-2.svg"
                  />

                  <div className="text-wrapper-330">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-669">
            <div className="frame-670">
              <div className="frame-671">
                <div className="frame-672">
                  <div className="text-wrapper-331">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-673">
                <div className="text-wrapper-322">Login</div>
              </div>

              <div className="frame-674">
                <div className="text-wrapper-332">Sign Up</div>
              </div>
            </div>

            <div className="frame-675">
              <div className="frame-676">
                <div className="back-icon-button-36">
                  <div className="vuesax-outline-arrow-18" />
                </div>

                <div className="frame-628">
                  <div className="text-wrapper-333">Account settings</div>

                  <p className="text-wrapper-334">
                    Edit your account details here such as payment details,
                    name, download limits etc.
                  </p>
                </div>
              </div>

              <div className="frame-630">
                <div className="frame-677">
                  <div className="text-wrapper-335">Store</div>

                  <img
                    className="vector-123"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-46250.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-13366.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-678">
                  <div className="text-wrapper-335">Payment Details</div>

                  <img
                    className="vector-124"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-46308.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-13308.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-679">
                  <div className="billing-invoices-2">
                    Billing &amp; Invoices
                  </div>

                  <img
                    className="vector-125"
                    alt="Vector"
                    src={
                      screenWidth >= 1200 && screenWidth < 1440
                        ? "/img/vector-1-68.svg"
                        : screenWidth >= 1440
                          ? "/img/vector-1-52-2.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-680">
                  <div className="text-wrapper-335">Taxes</div>

                  <img
                    className="vector-126"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-46589.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-13027.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-681">
                  <div className="text-wrapper-335">Shipping</div>

                  <img
                    className="vector-127"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-46647.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-12969.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-682">
                  <div className="text-wrapper-335">Advance settings</div>

                  <img
                    className="vector-128"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-46731.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-12885.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-683">
                  <div className="text-wrapper-335">Login settings</div>

                  <img
                    className="vector-129"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-46879.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-12737.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-684">
                  <div className="text-wrapper-335">Developers</div>

                  <img
                    className="vector-130"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-47003.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-12613.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>
              </div>

              <div
                className="frame-685"
                style={{
                  alignSelf:
                    screenWidth >= 1200 && screenWidth < 1440
                      ? "stretch"
                      : undefined,
                  width:
                    screenWidth >= 1200 && screenWidth < 1440
                      ? "100%"
                      : screenWidth >= 1440
                        ? "1071px"
                        : undefined,
                }}
              >
                <div className="frame-686">
                  <div className="frame-640">
                    <div className="text-wrapper-336">Free Forever</div>
                  </div>

                  <div className="frame-641">
                    <div className="text-wrapper-337">$0 / mo</div>

                    <div className="text-wrapper-338">5% transaction fee</div>
                  </div>

                  <div className="frame-687">
                    <div className="text-wrapper-339">Plan Includes:</div>

                    <div className="frame-643">
                      <div className="frame-688">
                        <div
                          className="filled-icons-check-2"
                          style={{
                            backgroundImage:
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "url(/img/check-circle-icon-18.png)"
                                : screenWidth >= 1440
                                  ? "url(/img/check-circle-icon.png)"
                                  : undefined,
                          }}
                        />

                        <div className="text-wrapper-317">All features</div>
                      </div>

                      <div className="frame-689">
                        <div
                          className="filled-icons-check-3"
                          style={{
                            backgroundImage:
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "url(/img/check-circle-icon-18.png)"
                                : screenWidth >= 1440
                                  ? "url(/img/check-circle-icon.png)"
                                  : undefined,
                          }}
                        />

                        <div className="text-wrapper-317">
                          Unlimited products
                        </div>
                      </div>

                      <div className="frame-690">
                        <div
                          className="filled-icons-check-4"
                          style={{
                            backgroundImage:
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "url(/img/check-circle-icon-18.png)"
                                : screenWidth >= 1440
                                  ? "url(/img/check-circle-icon.png)"
                                  : undefined,
                          }}
                        />

                        <div className="text-wrapper-317">
                          Unlimited revenue
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-691">
                    <div className="text-wrapper-340">Your Current Plan</div>
                  </div>
                </div>

                <div className="frame-686">
                  <div className="frame-640">
                    <div className="text-wrapper-336">Plus</div>
                  </div>

                  <div className="frame-641">
                    <div className="text-wrapper-337">$29 / mo</div>

                    <div className="text-wrapper-338">2% transaction fee</div>
                  </div>

                  <div className="frame-687">
                    <div className="text-wrapper-339">Plan Includes:</div>

                    <div className="frame-643">
                      <div className="frame-692">
                        <div
                          className="filled-icons-check-5"
                          style={{
                            backgroundImage:
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "url(/img/check-circle-icon-18.png)"
                                : screenWidth >= 1440
                                  ? "url(/img/check-circle-icon-3.png)"
                                  : undefined,
                          }}
                        />

                        <div className="text-wrapper-317">All features</div>
                      </div>

                      <div className="frame-693">
                        <div
                          className="filled-icons-check-6"
                          style={{
                            backgroundImage:
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "url(/img/check-circle-icon-18.png)"
                                : screenWidth >= 1440
                                  ? "url(/img/check-circle-icon-3.png)"
                                  : undefined,
                          }}
                        />

                        <div className="text-wrapper-317">
                          Unlimited products
                        </div>
                      </div>

                      <div className="frame-694">
                        <div
                          className="filled-icons-check-7"
                          style={{
                            backgroundImage:
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "url(/img/check-circle-icon-18.png)"
                                : screenWidth >= 1440
                                  ? "url(/img/check-circle-icon-3.png)"
                                  : undefined,
                          }}
                        />

                        <div className="text-wrapper-317">
                          Unlimited revenue
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-691">
                    <div className="text-wrapper-340">Choose Plan</div>
                  </div>
                </div>

                <div className="frame-686">
                  <div className="frame-640">
                    <div className="text-wrapper-336">Pro</div>
                  </div>

                  <div className="frame-641">
                    <div className="text-wrapper-337">$99 / mo</div>

                    <div className="text-wrapper-338">No transaction fee</div>
                  </div>

                  <div className="frame-687">
                    <div className="text-wrapper-339">Plan Includes:</div>

                    <div className="frame-643">
                      <div className="frame-695">
                        <div
                          className="filled-icons-check-8"
                          style={{
                            backgroundImage:
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "url(/img/check-circle-icon-18.png)"
                                : screenWidth >= 1440
                                  ? "url(/img/check-circle-icon-6.png)"
                                  : undefined,
                          }}
                        />

                        <div className="text-wrapper-317">All features</div>
                      </div>

                      <div className="frame-696">
                        <div
                          className="filled-icons-check-9"
                          style={{
                            backgroundImage:
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "url(/img/check-circle-icon-18.png)"
                                : screenWidth >= 1440
                                  ? "url(/img/check-circle-icon-6.png)"
                                  : undefined,
                          }}
                        />

                        <div className="text-wrapper-317">
                          Unlimited products
                        </div>
                      </div>

                      <div className="frame-697">
                        <div
                          className="filled-icons-check-10"
                          style={{
                            backgroundImage:
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "url(/img/check-circle-icon-18.png)"
                                : screenWidth >= 1440
                                  ? "url(/img/check-circle-icon-6.png)"
                                  : undefined,
                          }}
                        />

                        <div className="text-wrapper-317">
                          Unlimited revenue
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-691">
                    <div className="text-wrapper-340">Choose Plan</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
