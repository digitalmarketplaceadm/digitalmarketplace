import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const Menu = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="menu"
      style={{
        minHeight: screenWidth >= 393 ? "100vh" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393
              ? "393px"
              : undefined,
      }}
    >
      <StatusBar
        actionClassName={`${screenWidth < 393 && "class-23"} ${screenWidth >= 393 && "class-24"}`}
        batteryClassName={`${screenWidth < 393 && "class-21"} ${screenWidth >= 393 && "class-22"}`}
        className={`${screenWidth < 393 && "class-19"} ${screenWidth >= 393 && "class-20"}`}
        combinedShape={
          screenWidth < 393
            ? "/img/combined-shape-22.svg"
            : screenWidth >= 393
              ? "/img/combined-shape-26.svg"
              : undefined
        }
        containerClassName={`${screenWidth < 393 && "class-17"} ${screenWidth >= 393 && "class-18"}`}
        property1="dark"
        rectangleClassName="status-bar-75"
        timeClassName="status-bar-74"
        wiFi="/img/wi-fi-22.svg"
      />
      <div className="frame-435">
        {screenWidth < 393 && (
          <img
            className="img-20"
            alt="Settings svgrepo com"
            src="/img/settings-svgrepo-com-13.svg"
          />
        )}

        {screenWidth >= 393 && (
          <>
            <div className="back-icon-button-27">
              <div className="img-21">
                <div className="vuesax-linear-wrapper">
                  <div className="vuesax-linear-9">
                    <div className="notification-9">
                      <img
                        className="group-84"
                        alt="Group"
                        src="/img/group-33845-1.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="back-icon-button-27">
              <img
                className="img-21"
                alt="Messenger fill"
                src="/img/messenger-fill-svgrepo-com-5-2.svg"
              />
            </div>

            <div className="back-icon-button-27">
              <img
                className="img-21"
                alt="Settings svgrepo com"
                src="/img/settings-svgrepo-com-12.svg"
              />
            </div>
          </>
        )}
      </div>

      <div
        className="frame-436"
        style={{
          flex: screenWidth >= 393 ? "1" : undefined,
          flexGrow: screenWidth >= 393 ? "1" : undefined,
          height: screenWidth < 393 ? "753px" : undefined,
        }}
      >
        <div className="frame-437">
          <img className="image-25" alt="Image" src="/img/image-10.png" />

          <div className="frame-438">
            <div className="text-wrapper-213">William Smith</div>

            <div className="text-wrapper-214">william.smith@gmail.com</div>
          </div>
        </div>

        <div className="frame-439">
          <div className="frame-440">
            <div className="frame-441">
              <div className="frame-442">
                {screenWidth < 393 && (
                  <img
                    className="img-22"
                    alt="Coin svgrepo com"
                    src="/img/coin-svgrepo-com-6.svg"
                  />
                )}

                {screenWidth >= 393 && (
                  <div className="img-22">
                    <div className="wallet-with-money">
                      <div className="overlap-group-6">
                        <div className="group-85">
                          <img
                            className="group-86"
                            alt="Group"
                            src="/img/group-1272630337.png"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="frame-443">
                <div className="text-wrapper-215">Balance</div>
              </div>
            </div>

            <div className="frame-441">
              <div className="frame-442">
                <img
                  className="img-22"
                  alt="Book minimalistic"
                  src={
                    screenWidth < 393
                      ? "/img/book-minimalistic-svgrepo-com-2.svg"
                      : screenWidth >= 393
                        ? "/img/book-minimalistic-svgrepo-com-1.svg"
                        : undefined
                  }
                />
              </div>

              <div className="frame-444">
                <div className="div-8">Library</div>
              </div>
            </div>

            <div className="frame-441">
              <div className="frame-442">
                <img
                  className="img-22"
                  alt="Transaction minus"
                  src={
                    screenWidth < 393
                      ? "/img/transaction-minus-svgrepo-com-2.svg"
                      : screenWidth >= 393
                        ? "/img/transaction-minus-svgrepo-com.svg"
                        : undefined
                  }
                />
              </div>

              <div className="frame-444">
                <div className="div-8">Transaction</div>
              </div>
            </div>
          </div>

          <div className="frame-445">
            <div className="frame-441">
              <div className="frame-442">
                <div className="img-22">
                  <div className="overlap-group-7">
                    <img
                      className="vector-55"
                      alt="Vector"
                      src={
                        screenWidth < 393
                          ? "/img/vector-80.svg"
                          : screenWidth >= 393
                            ? "/img/vector-68.svg"
                            : undefined
                      }
                    />

                    <img
                      className="vector-56"
                      alt="Vector"
                      src={
                        screenWidth < 393
                          ? "/img/vector-81.svg"
                          : screenWidth >= 393
                            ? "/img/vector-69.svg"
                            : undefined
                      }
                    />

                    <img
                      className="vector-57"
                      alt="Vector"
                      src={
                        screenWidth < 393
                          ? "/img/vector-82.svg"
                          : screenWidth >= 393
                            ? "/img/vector-70.svg"
                            : undefined
                      }
                    />

                    <img
                      className="vector-58"
                      alt="Vector"
                      src={
                        screenWidth < 393
                          ? "/img/vector-83.svg"
                          : screenWidth >= 393
                            ? "/img/vector-71.svg"
                            : undefined
                      }
                    />

                    <img
                      className="vector-59"
                      alt="Vector"
                      src={
                        screenWidth < 393
                          ? "/img/vector-84.svg"
                          : screenWidth >= 393
                            ? "/img/vector-72.svg"
                            : undefined
                      }
                    />

                    <img
                      className="vector-60"
                      alt="Vector"
                      src={
                        screenWidth < 393
                          ? "/img/vector-85.svg"
                          : screenWidth >= 393
                            ? "/img/vector-73.svg"
                            : undefined
                      }
                    />

                    <img
                      className="group-87"
                      alt="Group"
                      src={
                        screenWidth < 393
                          ? "/img/group-52.png"
                          : screenWidth >= 393
                            ? "/img/group-46.png"
                            : undefined
                      }
                    />

                    <img
                      className="group-88"
                      alt="Group"
                      src={
                        screenWidth < 393
                          ? "/img/group-53.png"
                          : screenWidth >= 393
                            ? "/img/group-48.png"
                            : undefined
                      }
                    />
                  </div>
                </div>
              </div>

              <div className="frame-443">
                <div className="div-8">
                  {screenWidth < 393 && <>Saved Advisor</>}

                  {screenWidth >= 393 && <>Saved Experts</>}
                </div>
              </div>
            </div>

            <div className="frame-441">
              <div className="frame-442">
                <img
                  className="img-22"
                  alt="Open book svgrepo"
                  src={
                    screenWidth < 393
                      ? "/img/open-book-svgrepo-com-4.svg"
                      : screenWidth >= 393
                        ? "/img/note-svgrepo-com.svg"
                        : undefined
                  }
                />
              </div>

              <div className="frame-444">
                <div className="div-8">Notes</div>
              </div>
            </div>

            <div className="frame-441">
              <div className="frame-442">
                <div
                  className="footprint-svgrepo-2"
                  style={{
                    backgroundImage:
                      screenWidth < 393
                        ? "url(/img/group-54.png)"
                        : screenWidth >= 393
                          ? "url(/img/group-49.png)"
                          : undefined,
                  }}
                />
              </div>

              <div className="frame-444">
                <div className="div-8">Footstep</div>
              </div>
            </div>
          </div>

          <div className="frame-446">
            <div className="frame-446">
              <div className="frame-447">
                <div className="gift-17">
                  <div className="vuesax-linear-gift-10">
                    <img
                      className="gift-18"
                      alt="Gift"
                      src={
                        screenWidth < 393
                          ? "/img/gift-15.png"
                          : screenWidth >= 393
                            ? "/img/gift-14.png"
                            : undefined
                      }
                    />
                  </div>
                </div>

                <div className="text-wrapper-216">Channel</div>
              </div>

              <div className="frame-447">
                <img
                  className="img-20"
                  alt="Graph svgrepo com"
                  src="/img/graph-svgrepo-com.svg"
                />

                <div className="text-wrapper-216">Analytics</div>
              </div>

              <div className="frame-447">
                <img
                  className="img-20"
                  alt="People svgrepo com"
                  src={
                    screenWidth < 393
                      ? "/img/people-svgrepo-com-3.svg"
                      : screenWidth >= 393
                        ? "/img/people-svgrepo-com-2.svg"
                        : undefined
                  }
                />

                <div className="text-wrapper-216">Clients</div>
              </div>

              <div className="frame-447">
                <img
                  className="img-20"
                  alt="Coin svgrepo com"
                  src={
                    screenWidth < 393
                      ? "/img/coin-svgrepo-com-7.svg"
                      : screenWidth >= 393
                        ? "/img/coin-svgrepo-com-4.svg"
                        : undefined
                  }
                />

                <div className="text-wrapper-216">Sales</div>
              </div>

              <div className="frame-447">
                <img
                  className="img-20"
                  alt="Transaction minus"
                  src={
                    screenWidth < 393
                      ? "/img/transaction-minus-svgrepo-com-3.svg"
                      : screenWidth >= 393
                        ? "/img/transaction-minus-svgrepo-com-1.svg"
                        : undefined
                  }
                />

                <div className="text-wrapper-216">Transaction history</div>
              </div>

              <div className="frame-447">
                <img
                  className="img-20"
                  alt="Coin svgrepo com"
                  src={
                    screenWidth < 393
                      ? "/img/coin-svgrepo-com-7.svg"
                      : screenWidth >= 393
                        ? "/img/coin-svgrepo-com-4.svg"
                        : undefined
                  }
                />

                <div className="text-wrapper-216">Cash out</div>
              </div>

              <div className="frame-447">
                <img
                  className="img-20"
                  alt="Open book svgrepo"
                  src="/img/open-book-svgrepo-com-3.svg"
                />

                <div className="text-wrapper-216">Help</div>
              </div>
            </div>
          </div>
        </div>

        <div className="frame-448">
          <div className="text-wrapper-217">Log Out</div>
        </div>
      </div>

      <div className="frame-449">
        <div className="BNB-8">
          <div className="navigation-menu-9">
            <img
              className="home-svgrepo-com-6"
              alt="Home svgrepo com"
              src={
                screenWidth < 393
                  ? "/img/home-svgrepo-com-6-2.svg"
                  : screenWidth >= 393
                    ? "/img/home-svgrepo-com-5.svg"
                    : undefined
              }
            />

            <div
              className="text-wrapper-218"
              style={{
                marginLeft: screenWidth < 393 ? "-5.20px" : undefined,
                marginRight: screenWidth < 393 ? "-5.20px" : undefined,
              }}
            >
              Home
            </div>
          </div>

          <div className="navigation-menu-9">
            <SearchNormal property1="linear" />
            <div
              className="text-wrapper-219"
              style={{
                marginLeft:
                  screenWidth < 393
                    ? "-7.70px"
                    : screenWidth >= 393
                      ? "-0.40px"
                      : undefined,
                marginRight:
                  screenWidth < 393
                    ? "-7.70px"
                    : screenWidth >= 393
                      ? "-0.40px"
                      : undefined,
              }}
            >
              Search
            </div>
          </div>

          <div className="navigation-menu-9">
            <div
              className="group-89"
              style={{
                backgroundImage:
                  screenWidth < 393
                    ? "url(/img/cart-svgrepo-com-9.svg)"
                    : screenWidth >= 393
                      ? "url(/img/cart-svgrepo-com-7.svg)"
                      : undefined,
              }}
            />

            <div
              className="text-wrapper-220"
              style={{
                marginLeft: screenWidth < 393 ? "-0.20px" : undefined,
                marginRight: screenWidth < 393 ? "-0.20px" : undefined,
              }}
            >
              Cart
            </div>
          </div>

          <div className="navigation-menu-9">
            <div className="home-svgrepo-com-6">
              <div className="frame-450">
                <div className="headset-svgrepo-com-5">
                  <div className="overlap-group-8">
                    <img
                      className="vector-61"
                      alt="Vector"
                      src={
                        screenWidth < 393
                          ? "/img/vector-86.svg"
                          : screenWidth >= 393
                            ? "/img/vector-50.svg"
                            : undefined
                      }
                    />

                    <img
                      className="vector-62"
                      alt="Vector"
                      src={
                        screenWidth < 393
                          ? "/img/vector-57.svg"
                          : screenWidth >= 393
                            ? "/img/vector-51.svg"
                            : undefined
                      }
                    />

                    <img
                      className="vector-63"
                      alt="Vector"
                      src={
                        screenWidth < 393
                          ? "/img/vector-58.svg"
                          : screenWidth >= 393
                            ? "/img/vector-52.svg"
                            : undefined
                      }
                    />

                    <img
                      className="vector-64"
                      alt="Vector"
                      src={
                        screenWidth < 393
                          ? "/img/vector-89.svg"
                          : screenWidth >= 393
                            ? "/img/vector-53.svg"
                            : undefined
                      }
                    />

                    <img
                      className="vector-65"
                      alt="Vector"
                      src={
                        screenWidth < 393
                          ? "/img/vector-60.svg"
                          : screenWidth >= 393
                            ? "/img/vector-54.svg"
                            : undefined
                      }
                    />

                    <img
                      className="vector-66"
                      alt="Vector"
                      src={
                        screenWidth < 393
                          ? "/img/vector-61.svg"
                          : screenWidth >= 393
                            ? "/img/vector-55.svg"
                            : undefined
                      }
                    />

                    <img
                      className="group-90"
                      alt="Group"
                      src={
                        screenWidth < 393
                          ? "/img/group-41.png"
                          : screenWidth >= 393
                            ? "/img/group-37.png"
                            : undefined
                      }
                    />

                    <img
                      className="group-91"
                      alt="Group"
                      src={
                        screenWidth < 393
                          ? "/img/group-42.png"
                          : screenWidth >= 393
                            ? "/img/group-38.png"
                            : undefined
                      }
                    />
                  </div>
                </div>
              </div>
            </div>

            <div
              className="text-wrapper-221"
              style={{
                marginLeft: screenWidth < 393 ? "-1.20px" : undefined,
                marginRight: screenWidth < 393 ? "-1.20px" : undefined,
              }}
            >
              Help
            </div>
          </div>

          <div className="navigation-menu-9">
            <img className="image-26" alt="Image" src="/img/image-10.png" />

            <div
              className="text-wrapper-222"
              style={{
                marginLeft: screenWidth < 393 ? "-6.20px" : undefined,
                marginRight: screenWidth < 393 ? "-6.20px" : undefined,
              }}
            >
              Profile
            </div>
          </div>
        </div>
      </div>

      <HomeIndicator
        className="home-indicator-29"
        lineClassName={`${screenWidth < 393 && "class-25"} ${screenWidth >= 393 && "class-26"}`}
        property1="dark"
      />
    </div>
  );
};
