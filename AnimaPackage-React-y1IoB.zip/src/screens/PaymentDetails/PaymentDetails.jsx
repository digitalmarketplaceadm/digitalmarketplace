import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const PaymentDetails = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="payment-details"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393
            ? "center"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393
            ? "#ffffff"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393
            ? "column"
            : undefined,
        gap:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1200
              ? "393px"
              : screenWidth >= 1200 && screenWidth < 1440
                ? "1200px"
                : screenWidth >= 1440
                  ? "1440px"
                  : undefined,
        padding:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-65"} ${screenWidth >= 393 && screenWidth < 1200 && "class-66"}`}
            className={`${screenWidth < 393 && "class-63"} ${screenWidth >= 393 && screenWidth < 1200 && "class-64"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-31.svg"
                : screenWidth >= 393 && screenWidth < 1200
                  ? "/img/combined-shape-32.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-67"} ${screenWidth >= 393 && screenWidth < 1200 && "class-68"}`}
            property1="dark"
            rectangleClassName="status-bar-101"
            timeClassName="status-bar-100"
            wiFi="/img/wi-fi-31.svg"
          />
          <div className="frame-698">
            <div className="back-icon-button-37">
              <div className="vuesax-outline-arrow-19" />
            </div>

            <div className="frame-699">
              <div className="text-wrapper-341">Account settings</div>

              <p className="text-wrapper-342">
                Edit your account details here such as payment details, name,
                download limits etc.
              </p>
            </div>
          </div>

          <div className="frame-700">
            <div className="frame-wrapper-3">
              <div className="frame-701">
                <div className="frame-702">
                  <div className="text-wrapper-343">Store</div>

                  <img
                    className="vector-131"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-27267.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-9805.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-703">
                  <div className="text-wrapper-344">Payment Details</div>

                  <img
                    className="vector-132"
                    alt="Vector"
                    src={
                      screenWidth < 393
                        ? "/img/vector-1-26.svg"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "/img/vector-1-35-2.svg"
                          : undefined
                    }
                  />
                </div>

                <div
                  className="frame-704"
                  style={{
                    marginRight: screenWidth < 393 ? "-1.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-343">Billing &amp; Invoices</div>

                  <img
                    className="vector-133"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-27446.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-9984.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-705"
                  style={{
                    marginRight: screenWidth < 393 ? "-54.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-343">Taxes</div>

                  <img
                    className="vector-134"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-27572.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10110.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-706"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-130.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-57.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-343">Shipping</div>

                  <img
                    className="vector-135"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-27625.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10163.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-707"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-261.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-188.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-343">Advance settings</div>

                  <img
                    className="vector-136"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-27701.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10239.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-708"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-371.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-298.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-343">Login settings</div>

                  <img
                    className="vector-137"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-27832.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10370.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-709"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-464.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-391.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-343">Developers</div>

                  <img
                    className="vector-138"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-27942.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10480.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>
              </div>
            </div>

            <div
              className="input-33"
              style={{
                alignSelf: screenWidth < 393 ? "stretch" : undefined,
                width:
                  screenWidth < 393
                    ? "100%"
                    : screenWidth >= 393 && screenWidth < 1200
                      ? "361px"
                      : undefined,
              }}
            >
              <div className="text-wrapper-345">Your PayPal account</div>

              <div className="frame-710">
                <img
                  className="vector-139"
                  alt="Vector"
                  src="/img/vector-2.svg"
                />

                <div className="text-wrapper-346">Connect Paypal account</div>
              </div>
            </div>

            <div
              className="input-34"
              style={{
                alignSelf: screenWidth < 393 ? "stretch" : undefined,
                width:
                  screenWidth < 393
                    ? "100%"
                    : screenWidth >= 393 && screenWidth < 1200
                      ? "361px"
                      : undefined,
              }}
            >
              <div className="text-wrapper-345">Your Stripe account</div>

              <div className="frame-710">
                <img
                  className="vector-139"
                  alt="Vector"
                  src="/img/vector-2.svg"
                />

                <div className="text-wrapper-346">Connect Stripe account</div>
              </div>
            </div>

            <div
              className="input-35"
              style={{
                alignSelf: screenWidth < 393 ? "stretch" : undefined,
                width:
                  screenWidth < 393
                    ? "100%"
                    : screenWidth >= 393 && screenWidth < 1200
                      ? "361px"
                      : undefined,
              }}
            >
              <div className="text-wrapper-345">Currency</div>

              <div className="input-36">
                <div className="text-wrapper-347">USD</div>
              </div>
            </div>

            <div
              className="input-37"
              style={{
                alignSelf: screenWidth < 393 ? "stretch" : undefined,
                width:
                  screenWidth < 393
                    ? "100%"
                    : screenWidth >= 393 && screenWidth < 1200
                      ? "361px"
                      : undefined,
              }}
            >
              <div className="text-wrapper-345">Statement description</div>

              <div className="input-36">
                <div className="text-wrapper-347">Enter Link</div>
              </div>
            </div>

            <div className="CTA-8">
              <div
                className="frame-711"
                style={{
                  flex: screenWidth < 393 ? "1" : undefined,
                  flexGrow: screenWidth < 393 ? "1" : undefined,
                  width:
                    screenWidth >= 393 && screenWidth < 1200
                      ? "172.5px"
                      : undefined,
                }}
              >
                <div className="text-wrapper-348">Cancel</div>
              </div>

              <div
                className="frame-712"
                style={{
                  flex: screenWidth < 393 ? "1" : undefined,
                  flexGrow: screenWidth < 393 ? "1" : undefined,
                  width:
                    screenWidth >= 393 && screenWidth < 1200
                      ? "172.5px"
                      : undefined,
                }}
              >
                <div className="text-wrapper-346">Save</div>
              </div>
            </div>
          </div>

          <div className="frame-713">
            <div className="BNB-15">
              <div className="navigation-menu-home-10">
                <div className="navigation-menu-home-11">
                  <div className="frame-714" />

                  <div className="text-wrapper-349">Profile</div>
                </div>
              </div>

              <div className="navigation-menu-19">
                <SearchNormal property1="linear" />
              </div>

              <div className="navigation-menu-19">
                <img
                  className="cart-large"
                  style={{
                    marginLeft: screenWidth < 393 ? "-5.00px" : undefined,
                    marginRight: screenWidth < 393 ? "-5.00px" : undefined,
                  }}
                  alt="Cart large"
                  src={
                    screenWidth < 393
                      ? "/img/cart-large-minimalistic-svgrepo-com-8-2.svg"
                      : screenWidth >= 393 && screenWidth < 1200
                        ? "/img/cart-large-minimalistic-svgrepo-com-9.svg"
                        : undefined
                  }
                />
              </div>

              <div className="navigation-menu-19">
                <div
                  className="frame-715"
                  style={{
                    backgroundImage:
                      screenWidth < 393
                        ? "url(/img/notification-7.svg)"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "url(/img/notification-9.svg)"
                          : undefined,
                    marginLeft: screenWidth < 393 ? "-5.00px" : undefined,
                    marginRight: screenWidth < 393 ? "-5.00px" : undefined,
                  }}
                >
                  <div className="ellipse-32" />
                </div>
              </div>

              <div className="navigation-menu-19">
                <img
                  className="image-36"
                  style={{
                    marginLeft: screenWidth < 393 ? "-5.00px" : undefined,
                    marginRight: screenWidth < 393 ? "-5.00px" : undefined,
                  }}
                  alt="Image"
                  src="/img/image-25.png"
                />
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-36"
            lineClassName={`${screenWidth < 393 && "class-69"} ${screenWidth >= 393 && screenWidth < 1200 && "class-70"}`}
            property1="dark"
          />
        </>
      )}

      {((screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440) && (
        <div className="frame-716">
          <div className="frame-717">
            <div className="frame-718">
              <div className="frame-719">
                <div className="frame-720">
                  <div className="frame-721">
                    <div className="text-wrapper-350">LOGO</div>
                  </div>
                </div>

                <div className="frame-wrapper-3">
                  <div className="frame-722">
                    <img
                      className="img-43"
                      alt="Home angle svgrepo"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/home-angle-svgrepo-com-15-2.svg"
                          : screenWidth >= 1440
                            ? "/img/home-angle-svgrepo-com-14-2.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-351">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-718">
                <div className="frame-718">
                  <div className="frame-723">
                    <div className="img-43">
                      <div className="vuesax-linear-gift-16">
                        <img
                          className="gift-26"
                          alt="Gift"
                          src={
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "/img/gift-7.png"
                              : screenWidth >= 1440
                                ? "/img/gift-6-2x.png"
                                : undefined
                          }
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-352">Products</div>
                  </div>

                  <div className="frame-723">
                    <img
                      className="img-43"
                      alt="Users group two"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/users-group-two-rounded-svgrepo-com-7.svg"
                          : screenWidth >= 1440
                            ? "/img/users-group-two-rounded-svgrepo-com-6.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-352">Collaborators</div>
                  </div>

                  <div className="frame-723">
                    <img
                      className="img-43"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-6-2.svg"
                    />

                    <div className="text-wrapper-352">Checkout</div>
                  </div>

                  <div className="frame-723">
                    <img
                      className="img-43"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-352">Emails</div>
                  </div>

                  <div className="frame-723">
                    <img
                      className="img-43"
                      alt="Flow parallel"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/flow-parallel-svgrepo-com-7-2.svg"
                          : screenWidth >= 1440
                            ? "/img/flow-parallel-svgrepo-com-6.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-352">Workflows</div>
                  </div>

                  <div className="frame-723">
                    <img
                      className="img-43"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-14.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-12.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-352">Sales</div>
                  </div>

                  <div className="frame-723">
                    <img
                      className="img-43"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-352">Analytics</div>
                  </div>

                  <div className="frame-723">
                    <img
                      className="img-43"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-14.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-12.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-352">Payouts</div>
                  </div>

                  <div className="frame-723">
                    <img
                      className="img-43"
                      alt="Book bookmark"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/book-bookmark-minimalistic-svgrepo-com-7.svg"
                          : screenWidth >= 1440
                            ? "/img/book-bookmark-minimalistic-svgrepo-com-6-2.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-352">Library</div>
                  </div>
                </div>

                <div className="frame-723">
                  <img
                    className="img-43"
                    alt="Settings svgrepo com"
                    src={
                      screenWidth >= 1200 && screenWidth < 1440
                        ? "/img/settings-svgrepo-com-7.svg"
                        : screenWidth >= 1440
                          ? "/img/settings-svgrepo-com-6-2.svg"
                          : undefined
                    }
                  />

                  <div className="text-wrapper-352">Settings</div>
                </div>

                <div className="frame-723">
                  <img
                    className="img-43"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-6-2.svg"
                  />

                  <div className="text-wrapper-352">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-724">
            <div className="frame-725">
              <div className="frame-726">
                <div className="frame-727">
                  <div className="text-wrapper-353">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-728">
                <div className="text-wrapper-346">Login</div>
              </div>

              <div className="frame-729">
                <div className="text-wrapper-354">Sign Up</div>
              </div>
            </div>

            <div className="frame-730">
              <div className="frame-731">
                <div className="back-icon-button-37">
                  <div className="vuesax-outline-arrow-19" />
                </div>

                <div className="frame-699">
                  <div className="text-wrapper-355">Account settings</div>

                  <p className="text-wrapper-356">
                    Edit your account details here such as payment details,
                    name, download limits etc.
                  </p>
                </div>
              </div>

              <div className="frame-701">
                <div className="frame-732">
                  <div className="text-wrapper-357">Store</div>

                  <img
                    className="vector-140"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-45010.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-14846.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-733">
                  <div className="text-wrapper-358">Payment Details</div>

                  <img
                    className="vector-141"
                    alt="Vector"
                    src={
                      screenWidth >= 1200 && screenWidth < 1440
                        ? "/img/vector-1-43.svg"
                        : screenWidth >= 1440
                          ? "/img/vector-1-19-2.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-734">
                  <div className="text-wrapper-357">Billing &amp; Invoices</div>

                  <img
                    className="vector-142"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-45207.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-14649.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-735">
                  <div className="text-wrapper-357">Taxes</div>

                  <img
                    className="vector-143"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-45349.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-14507.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-736">
                  <div className="text-wrapper-357">Shipping</div>

                  <img
                    className="vector-144"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-45407.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-14449.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-737">
                  <div className="text-wrapper-357">Advance settings</div>

                  <img
                    className="vector-145"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-45491.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-14365.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-738">
                  <div className="text-wrapper-357">Login settings</div>

                  <img
                    className="vector-146"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-45639.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-14217.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-739">
                  <div className="text-wrapper-357">Developers</div>

                  <img
                    className="vector-147"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-45763.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-14093.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>
              </div>

              <div className="frame-740">
                <div className="frame-701">
                  <div className="input-38">
                    <div className="text-wrapper-359">Your PayPal account</div>

                    <div className="frame-741">
                      <img
                        className="vector-139"
                        alt="Vector"
                        src="/img/vector-2.svg"
                      />

                      <div className="text-wrapper-346">
                        Connect Paypal account
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-701">
                  <div className="input-39">
                    <div className="text-wrapper-359">Your Stripe account</div>

                    <div className="frame-741">
                      <img
                        className="vector-139"
                        alt="Vector"
                        src="/img/vector-2.svg"
                      />

                      <div className="text-wrapper-346">
                        Connect Stripe account
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-701">
                  <div className="input-40">
                    <div className="text-wrapper-359">Your Stripe account</div>

                    <div className="input-36">
                      <div className="text-wrapper-347">USD</div>

                      <img
                        className="expand-more-5"
                        alt="Expand more"
                        src={
                          screenWidth >= 1200 && screenWidth < 1440
                            ? "/img/expand-more-1-3.svg"
                            : screenWidth >= 1440
                              ? "/img/expand-more.svg"
                              : undefined
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="frame-742">
                  <div className="input-41">
                    <div className="text-wrapper-359">
                      Statement description
                    </div>

                    <div className="input-36">
                      <div className="text-wrapper-347">Enter Link</div>
                    </div>
                  </div>
                </div>

                <div className="CTA-8">
                  <div className="frame-743">
                    <div className="text-wrapper-348">Cancel</div>
                  </div>

                  <div className="frame-744">
                    <div className="text-wrapper-346">Save</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
