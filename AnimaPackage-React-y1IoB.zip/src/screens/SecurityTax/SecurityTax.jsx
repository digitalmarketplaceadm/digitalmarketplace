import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const SecurityTax = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-tax"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "1022px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-101"} ${screenWidth >= 393 && screenWidth < 1440 && "class-102"}`}
            className={`${screenWidth < 393 && "class-99"} ${screenWidth >= 393 && screenWidth < 1440 && "class-100"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-38.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-39.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-103"} ${screenWidth >= 393 && screenWidth < 1440 && "class-104"}`}
            property1="dark"
            wiFi="/img/wi-fi-38.svg"
          />
          <div className="frame-1073">
            <div className="back-icon-button-46">
              <div className="vuesax-outline-arrow-27" />
            </div>

            <div className="frame-1074">
              <div className="text-wrapper-541">Tax Information</div>
            </div>
          </div>

          <div className="frame-1075">
            <div
              className="stepper"
              style={{
                padding:
                  screenWidth < 393
                    ? "0px 25px"
                    : screenWidth >= 393 && screenWidth < 1440
                      ? "0px 50px"
                      : undefined,
              }}
            >
              <div className="content">
                <div className="frame-1076">
                  <div className="step-number">
                    <div className="text-wrapper-542">01</div>
                  </div>

                  <div className="text-wrapper-543">Tax Information</div>
                </div>
              </div>

              <div
                className="rectangle-10"
                style={{
                  left:
                    screenWidth < 393
                      ? "92px"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "118px"
                        : undefined,
                  width:
                    screenWidth < 393
                      ? "52px"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "77px"
                        : undefined,
                }}
              />

              <div className="content-2">
                <div
                  className="rectangle-11"
                  style={{
                    width:
                      screenWidth < 393
                        ? "61px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "73px"
                          : undefined,
                  }}
                />

                <div className="frame-1076">
                  <div className="element-wrapper">
                    <div className="element">02</div>
                  </div>

                  <div className="text-wrapper-544">Certification</div>
                </div>
              </div>
            </div>

            <div className="frame-1077">
              <div className="frame-1078">
                <div className="frame-1079">
                  <div className="text-wrapper-545">Tax Information</div>
                </div>
              </div>

              <div className="frame-1077">
                <p className="under-u-s-federal">
                  Under U.S. federal tax law, Envato is required to collect U.S.
                  Author tax information via an IRS Form W-9 and report any
                  income paid.
                  <br />
                  <br />
                  If you are a U.S. Person:
                  <br />
                  Regardless of your location, you can submit a Form W-9 to
                  Envato to meet your filing obligation. Generally, there will
                  be no taxes withheld from your Envato earnings. <br />
                  <br />
                  However, if a valid Form W-9 is not submitted, Envato must
                  withhold 24% of your sales proceeds and remit that amount
                  directly to the IRS. For more information, please visit our
                  help center for W-9 articles.
                  <br />
                  <br />
                  If you are not a U.S. Person:
                  <br />
                  You will need to submit a Form W-8. If your country has a tax
                  treaty with the U.S., you may qualify for a reduced or zero
                  withholding rate as outlined in the treaty. If your country
                  does not have a tax treaty with the U.S., a 30% withholding
                  tax will apply to your U.S. income from Envato. For more
                  details, please check our help center for W-8 articles.
                  <br />
                  <br />
                  Although Envato cannot offer tax or legal advice, we will
                  provide the necessary information to help you understand how
                  to comply with U.S. tax laws. If you have further questions
                  after reviewing the IRS guidelines, we recommend contacting
                  your legal or tax advisor.
                  <br />
                  Please indicate if you are a U.S. Person so we can guide you
                  to the appropriate forms.
                </p>
              </div>
            </div>

            <div className="CTA-14">
              <div className="frame-1080">
                <div className="text-wrapper-546">Cancel</div>
              </div>

              <div className="frame-1081">
                <div className="text-wrapper-547">Next</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-46"
            lineClassName={`${screenWidth < 393 && "class-105"} ${screenWidth >= 393 && screenWidth < 1440 && "class-106"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-1082">
          <div className="frame-1083">
            <div className="frame-1084">
              <div className="frame-1085">
                <div className="frame-1086">
                  <div className="frame-1087">
                    <div className="text-wrapper-548">LOGO</div>
                  </div>
                </div>

                <div className="frame-1088">
                  <div className="frame-1089">
                    <img
                      className="img-57"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-17.svg"
                    />

                    <div className="text-wrapper-549">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-1084">
                <div className="frame-1084">
                  <div className="frame-1090">
                    <div className="img-57">
                      <div className="vuesax-linear-gift-24">
                        <img
                          className="gift-34"
                          alt="Gift"
                          src="/img/gift-9.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-550">Products</div>
                  </div>

                  <div className="frame-1090">
                    <img
                      className="img-57"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-550">Collaborators</div>
                  </div>

                  <div className="frame-1090">
                    <img
                      className="img-57"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-9-2.svg"
                    />

                    <div className="text-wrapper-550">Checkout</div>
                  </div>

                  <div className="frame-1090">
                    <img
                      className="img-57"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-550">Emails</div>
                  </div>

                  <div className="frame-1090">
                    <img
                      className="img-57"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-550">Workflows</div>
                  </div>

                  <div className="frame-1090">
                    <img
                      className="img-57"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-18.svg"
                    />

                    <div className="text-wrapper-550">Sales</div>
                  </div>

                  <div className="frame-1090">
                    <img
                      className="img-57"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-550">Analytics</div>
                  </div>

                  <div className="frame-1090">
                    <img
                      className="img-57"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-19.svg"
                    />

                    <div className="text-wrapper-550">Payouts</div>
                  </div>

                  <div className="frame-1090">
                    <img
                      className="img-57"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-550">Library</div>
                  </div>
                </div>

                <div className="frame-1090">
                  <img
                    className="img-57"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-9.svg"
                  />

                  <div className="text-wrapper-550">Settings</div>
                </div>

                <div className="frame-1090">
                  <img
                    className="img-57"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-9.svg"
                  />

                  <div className="text-wrapper-550">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-1091">
            <div className="frame-1092">
              <div className="frame-1093">
                <div className="frame-1094">
                  <div className="text-wrapper-551">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-1095">
                <div className="text-wrapper-552">Login</div>
              </div>

              <div className="frame-1096">
                <div className="text-wrapper-553">Sign Up</div>
              </div>
            </div>

            <div className="frame-1097">
              <div className="frame-1098">
                <div className="back-icon-button-46">
                  <div className="vuesax-outline-arrow-27" />
                </div>

                <div className="frame-1099">
                  <div className="text-wrapper-554">Tax Information</div>

                  <p className="text-wrapper-555">
                    Tax information refers to essential details related to an
                    individual’s or entity’s tax obligations, filings, and
                    compliance with government tax laws.
                  </p>
                </div>
              </div>

              <div className="stepper-2">
                <div className="rectangle-12" />

                <div className="content-3">
                  <div className="rectangle-13" />

                  <div className="frame-1100">
                    <div className="step-number-2">
                      <div className="text-wrapper-556">01</div>
                    </div>

                    <div className="text-wrapper-557">Tax Information</div>
                  </div>
                </div>

                <div className="content-4">
                  <div className="frame-1100">
                    <div className="step-number-3">
                      <div className="element-2">02</div>
                    </div>

                    <div className="text-wrapper-558">Certification</div>
                  </div>
                </div>
              </div>

              <div className="frame-1101">
                <div className="frame-1078">
                  <div className="frame-1079">
                    <div className="text-wrapper-559">Tax Information</div>
                  </div>
                </div>

                <div className="frame-1077">
                  <p className="under-u-s-federal">
                    Under U.S. federal tax law, Envato is required to collect
                    U.S. Author tax information via an IRS Form W-9 and report
                    any income paid.
                    <br />
                    <br />
                    If you are a U.S. Person:
                    <br />
                    Regardless of your location, you can submit a Form W-9 to
                    Envato to meet your filing obligation. Generally, there will
                    be no taxes withheld from your Envato earnings. <br />
                    <br />
                    However, if a valid Form W-9 is not submitted, Envato must
                    withhold 24% of your sales proceeds and remit that amount
                    directly to the IRS. For more information, please visit our
                    help center for W-9 articles.
                    <br />
                    <br />
                    If you are not a U.S. Person:
                    <br />
                    You will need to submit a Form W-8. If your country has a
                    tax treaty with the U.S., you may qualify for a reduced or
                    zero withholding rate as outlined in the treaty. If your
                    country does not have a tax treaty with the U.S., a 30%
                    withholding tax will apply to your U.S. income from Envato.
                    For more details, please check our help center for W-8
                    articles.
                    <br />
                    <br />
                    Although Envato cannot offer tax or legal advice, we will
                    provide the necessary information to help you understand how
                    to comply with U.S. tax laws. If you have further questions
                    after reviewing the IRS guidelines, we recommend contacting
                    your legal or tax advisor.
                    <br />
                    Please indicate if you are a U.S. Person so we can guide you
                    to the appropriate forms.
                  </p>
                </div>
              </div>

              <div className="CTA-15">
                <div className="frame-1102">
                  <div className="text-wrapper-546">Cancel</div>
                </div>

                <div className="frame-1103">
                  <div className="text-wrapper-547">Next</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
