import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal24 } from "../../icons/SearchNormal24";
import "./style.css";

export const SecurityTax = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-tax"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "1022px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-41"} ${screenWidth >= 393 && screenWidth < 1440 && "class-42"}`}
            className={`${screenWidth < 393 && "class-43"} ${screenWidth >= 393 && screenWidth < 1440 && "class-44"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-18.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-19.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-45"} ${screenWidth >= 393 && screenWidth < 1440 && "class-46"}`}
            property1="dark"
            wiFi="/img/wi-fi-18.svg"
          />
          <div className="frame-327">
            <div className="back-icon-button-8">
              <div className="vuesax-outline-arrow-9" />
            </div>

            <div className="frame-328">
              <div className="text-wrapper-224">Tax Information</div>
            </div>
          </div>

          <div className="frame-329">
            <div
              className="stepper"
              style={{
                padding:
                  screenWidth < 393
                    ? "0px 25px"
                    : screenWidth >= 393 && screenWidth < 1440
                      ? "0px 50px"
                      : undefined,
              }}
            >
              <div className="content">
                <div className="frame-330">
                  <div className="step-number">
                    <div className="text-wrapper-225">01</div>
                  </div>

                  <div className="text-wrapper-226">Tax Information</div>
                </div>
              </div>

              <div
                className="rectangle-3"
                style={{
                  left:
                    screenWidth < 393
                      ? "92px"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "118px"
                        : undefined,
                  width:
                    screenWidth < 393
                      ? "52px"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "77px"
                        : undefined,
                }}
              />

              <div className="content-2">
                <div
                  className="rectangle-4"
                  style={{
                    width:
                      screenWidth < 393
                        ? "61px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "73px"
                          : undefined,
                  }}
                />

                <div className="frame-330">
                  <div className="element-wrapper">
                    <div className="element">02</div>
                  </div>

                  <div className="text-wrapper-227">Certification</div>
                </div>
              </div>
            </div>

            <div className="frame-331">
              <div className="frame-332">
                <div className="frame-333">
                  <div className="text-wrapper-228">Tax Information</div>
                </div>
              </div>

              <div className="frame-331">
                <p className="under-u-s-federal">
                  Under U.S. federal tax law, Envato is required to collect U.S.
                  Author tax information via an IRS Form W-9 and report any
                  income paid.
                  <br />
                  <br />
                  If you are a U.S. Person:
                  <br />
                  Regardless of your location, you can submit a Form W-9 to
                  Envato to meet your filing obligation. Generally, there will
                  be no taxes withheld from your Envato earnings. <br />
                  <br />
                  However, if a valid Form W-9 is not submitted, Envato must
                  withhold 24% of your sales proceeds and remit that amount
                  directly to the IRS. For more information, please visit our
                  help center for W-9 articles.
                  <br />
                  <br />
                  If you are not a U.S. Person:
                  <br />
                  You will need to submit a Form W-8. If your country has a tax
                  treaty with the U.S., you may qualify for a reduced or zero
                  withholding rate as outlined in the treaty. If your country
                  does not have a tax treaty with the U.S., a 30% withholding
                  tax will apply to your U.S. income from Envato. For more
                  details, please check our help center for W-8 articles.
                  <br />
                  <br />
                  Although Envato cannot offer tax or legal advice, we will
                  provide the necessary information to help you understand how
                  to comply with U.S. tax laws. If you have further questions
                  after reviewing the IRS guidelines, we recommend contacting
                  your legal or tax advisor.
                  <br />
                  Please indicate if you are a U.S. Person so we can guide you
                  to the appropriate forms.
                </p>
              </div>
            </div>

            <div className="CTA-6">
              <div className="frame-334">
                <div className="text-wrapper-229">Cancel</div>
              </div>

              <div className="frame-335">
                <div className="text-wrapper-230">Next</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-9"
            lineClassName={`${screenWidth < 393 && "class-47"} ${screenWidth >= 393 && screenWidth < 1440 && "class-48"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-336">
          <div className="frame-337">
            <div className="frame-338">
              <div className="frame-339">
                <div className="frame-340">
                  <div className="frame-341">
                    <div className="text-wrapper-231">LOGO</div>
                  </div>
                </div>

                <div className="frame-342">
                  <div className="frame-343">
                    <img
                      className="img-18"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-232">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-338">
                <div className="frame-338">
                  <div className="frame-344">
                    <div className="img-18">
                      <div className="vuesax-linear-gift-7">
                        <img
                          className="gift-9"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-233">Products</div>
                  </div>

                  <div className="frame-344">
                    <img
                      className="img-18"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-233">Collaborators</div>
                  </div>

                  <div className="frame-344">
                    <img
                      className="img-18"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-233">Checkout</div>
                  </div>

                  <div className="frame-344">
                    <img
                      className="img-18"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-233">Emails</div>
                  </div>

                  <div className="frame-344">
                    <img
                      className="img-18"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-233">Workflows</div>
                  </div>

                  <div className="frame-344">
                    <img
                      className="img-18"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-8.svg"
                    />

                    <div className="text-wrapper-233">Sales</div>
                  </div>

                  <div className="frame-344">
                    <img
                      className="img-18"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-233">Analytics</div>
                  </div>

                  <div className="frame-344">
                    <img
                      className="img-18"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-233">Payouts</div>
                  </div>

                  <div className="frame-344">
                    <img
                      className="img-18"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-233">Library</div>
                  </div>
                </div>

                <div className="frame-344">
                  <img
                    className="img-18"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-233">Settings</div>
                </div>

                <div className="frame-344">
                  <img
                    className="img-18"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-233">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-345">
            <div className="frame-346">
              <div className="frame-347">
                <div className="frame-348">
                  <div className="text-wrapper-234">Search</div>

                  <SearchNormal24 className="search-normal-3" color="#232323" />
                </div>
              </div>

              <div className="frame-349">
                <div className="text-wrapper-235">Login</div>
              </div>

              <div className="frame-350">
                <div className="text-wrapper-236">Sign Up</div>
              </div>
            </div>

            <div className="frame-351">
              <div className="frame-352">
                <div className="back-icon-button-8">
                  <div className="vuesax-outline-arrow-9" />
                </div>

                <div className="frame-353">
                  <div className="text-wrapper-237">Tax Information</div>

                  <p className="text-wrapper-238">
                    Tax information refers to essential details related to an
                    individual’s or entity’s tax obligations, filings, and
                    compliance with government tax laws.
                  </p>
                </div>
              </div>

              <div className="stepper-2">
                <div className="rectangle-5" />

                <div className="content-3">
                  <div className="rectangle-6" />

                  <div className="frame-354">
                    <div className="step-number-2">
                      <div className="text-wrapper-239">01</div>
                    </div>

                    <div className="text-wrapper-240">Tax Information</div>
                  </div>
                </div>

                <div className="content-4">
                  <div className="frame-354">
                    <div className="step-number-3">
                      <div className="element-2">02</div>
                    </div>

                    <div className="text-wrapper-241">Certification</div>
                  </div>
                </div>
              </div>

              <div className="frame-355">
                <div className="frame-332">
                  <div className="frame-333">
                    <div className="text-wrapper-242">Tax Information</div>
                  </div>
                </div>

                <div className="frame-331">
                  <p className="under-u-s-federal">
                    Under U.S. federal tax law, Envato is required to collect
                    U.S. Author tax information via an IRS Form W-9 and report
                    any income paid.
                    <br />
                    <br />
                    If you are a U.S. Person:
                    <br />
                    Regardless of your location, you can submit a Form W-9 to
                    Envato to meet your filing obligation. Generally, there will
                    be no taxes withheld from your Envato earnings. <br />
                    <br />
                    However, if a valid Form W-9 is not submitted, Envato must
                    withhold 24% of your sales proceeds and remit that amount
                    directly to the IRS. For more information, please visit our
                    help center for W-9 articles.
                    <br />
                    <br />
                    If you are not a U.S. Person:
                    <br />
                    You will need to submit a Form W-8. If your country has a
                    tax treaty with the U.S., you may qualify for a reduced or
                    zero withholding rate as outlined in the treaty. If your
                    country does not have a tax treaty with the U.S., a 30%
                    withholding tax will apply to your U.S. income from Envato.
                    For more details, please check our help center for W-8
                    articles.
                    <br />
                    <br />
                    Although Envato cannot offer tax or legal advice, we will
                    provide the necessary information to help you understand how
                    to comply with U.S. tax laws. If you have further questions
                    after reviewing the IRS guidelines, we recommend contacting
                    your legal or tax advisor.
                    <br />
                    Please indicate if you are a U.S. Person so we can guide you
                    to the appropriate forms.
                  </p>
                </div>
              </div>

              <div className="CTA-7">
                <div className="frame-356">
                  <div className="text-wrapper-229">Cancel</div>
                </div>

                <div className="frame-357">
                  <div className="text-wrapper-230">Next</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
