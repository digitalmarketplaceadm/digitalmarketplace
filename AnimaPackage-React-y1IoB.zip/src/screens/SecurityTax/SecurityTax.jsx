import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal } from "../../icons/SearchNormal";
import "./style.css";

export const SecurityTax = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-tax"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "1022px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-13"} ${screenWidth >= 393 && screenWidth < 1440 && "class-14"}`}
            className={`${screenWidth < 393 && "class-15"} ${screenWidth >= 393 && screenWidth < 1440 && "class-16"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-18.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-19.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-11"} ${screenWidth >= 393 && screenWidth < 1440 && "class-12"}`}
            property1="dark"
            wiFi="/img/wi-fi-18.svg"
          />
          <div className="frame-28">
            <div className="vuesax-outline-arrow-wrapper">
              <div className="vuesax-outline-arrow-2" />
            </div>

            <div className="frame-29">
              <div className="text-wrapper-16">Tax Information</div>
            </div>
          </div>

          <div className="frame-30">
            <div
              className="stepper"
              style={{
                padding:
                  screenWidth < 393
                    ? "0px 25px"
                    : screenWidth >= 393 && screenWidth < 1440
                      ? "0px 50px"
                      : undefined,
              }}
            >
              <div className="content">
                <div className="frame-31">
                  <div className="step-number">
                    <div className="text-wrapper-17">01</div>
                  </div>

                  <div className="text-wrapper-18">Tax Information</div>
                </div>
              </div>

              <div
                className="rectangle-2"
                style={{
                  left:
                    screenWidth < 393
                      ? "92px"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "118px"
                        : undefined,
                  width:
                    screenWidth < 393
                      ? "52px"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "77px"
                        : undefined,
                }}
              />

              <div className="content-2">
                <div
                  className="rectangle-3"
                  style={{
                    width:
                      screenWidth < 393
                        ? "61px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "73px"
                          : undefined,
                  }}
                />

                <div className="frame-31">
                  <div className="element-wrapper">
                    <div className="element">02</div>
                  </div>

                  <div className="text-wrapper-19">Certification</div>
                </div>
              </div>
            </div>

            <div className="frame-32">
              <div className="frame-33">
                <div className="frame-34">
                  <div className="text-wrapper-20">Tax Information</div>
                </div>
              </div>

              <div className="frame-32">
                <p className="under-u-s-federal">
                  Under U.S. federal tax law, Envato is required to collect U.S.
                  Author tax information via an IRS Form W-9 and report any
                  income paid.
                  <br />
                  <br />
                  If you are a U.S. Person:
                  <br />
                  Regardless of your location, you can submit a Form W-9 to
                  Envato to meet your filing obligation. Generally, there will
                  be no taxes withheld from your Envato earnings. <br />
                  <br />
                  However, if a valid Form W-9 is not submitted, Envato must
                  withhold 24% of your sales proceeds and remit that amount
                  directly to the IRS. For more information, please visit our
                  help center for W-9 articles.
                  <br />
                  <br />
                  If you are not a U.S. Person:
                  <br />
                  You will need to submit a Form W-8. If your country has a tax
                  treaty with the U.S., you may qualify for a reduced or zero
                  withholding rate as outlined in the treaty. If your country
                  does not have a tax treaty with the U.S., a 30% withholding
                  tax will apply to your U.S. income from Envato. For more
                  details, please check our help center for W-8 articles.
                  <br />
                  <br />
                  Although Envato cannot offer tax or legal advice, we will
                  provide the necessary information to help you understand how
                  to comply with U.S. tax laws. If you have further questions
                  after reviewing the IRS guidelines, we recommend contacting
                  your legal or tax advisor.
                  <br />
                  Please indicate if you are a U.S. Person so we can guide you
                  to the appropriate forms.
                </p>
              </div>
            </div>

            <div className="CTA-3">
              <div className="frame-35">
                <div className="text-wrapper-21">Cancel</div>
              </div>

              <div className="frame-36">
                <div className="text-wrapper-22">Next</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-instance"
            lineClassName={`${screenWidth < 393 && "class-17"} ${screenWidth >= 393 && screenWidth < 1440 && "class-18"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-37">
          <div className="frame-38">
            <div className="frame-39">
              <div className="frame-40">
                <div className="frame-41">
                  <div className="frame-42">
                    <div className="text-wrapper-23">LOGO</div>
                  </div>
                </div>

                <div className="frame-43">
                  <div className="frame-44">
                    <img
                      className="img-2"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-24">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-39">
                <div className="frame-39">
                  <div className="frame-45">
                    <div className="img-2">
                      <div className="gift-wrapper">
                        <img
                          className="gift-2"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-25">Products</div>
                  </div>

                  <div className="frame-45">
                    <img
                      className="img-2"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-25">Collaborators</div>
                  </div>

                  <div className="frame-45">
                    <img
                      className="img-2"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-25">Checkout</div>
                  </div>

                  <div className="frame-45">
                    <img
                      className="img-2"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-25">Emails</div>
                  </div>

                  <div className="frame-45">
                    <img
                      className="img-2"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-25">Workflows</div>
                  </div>

                  <div className="frame-45">
                    <img
                      className="img-2"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-8.svg"
                    />

                    <div className="text-wrapper-25">Sales</div>
                  </div>

                  <div className="frame-45">
                    <img
                      className="img-2"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-25">Analytics</div>
                  </div>

                  <div className="frame-45">
                    <img
                      className="img-2"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-25">Payouts</div>
                  </div>

                  <div className="frame-45">
                    <img
                      className="img-2"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-25">Library</div>
                  </div>
                </div>

                <div className="frame-45">
                  <img
                    className="img-2"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-25">Settings</div>
                </div>

                <div className="frame-45">
                  <img
                    className="img-2"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-25">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-46">
            <div className="frame-47">
              <div className="frame-48">
                <div className="frame-49">
                  <div className="text-wrapper-26">Search</div>

                  <SearchNormal className="search-normal-24" color="#232323" />
                </div>
              </div>

              <div className="frame-50">
                <div className="text-wrapper-27">Login</div>
              </div>

              <div className="frame-51">
                <div className="text-wrapper-28">Sign Up</div>
              </div>
            </div>

            <div className="frame-52">
              <div className="frame-53">
                <div className="vuesax-outline-arrow-wrapper">
                  <div className="vuesax-outline-arrow-2" />
                </div>

                <div className="frame-54">
                  <div className="text-wrapper-29">Tax Information</div>

                  <p className="text-wrapper-30">
                    Tax information refers to essential details related to an
                    individual’s or entity’s tax obligations, filings, and
                    compliance with government tax laws.
                  </p>
                </div>
              </div>

              <div className="stepper-2">
                <div className="rectangle-4" />

                <div className="content-3">
                  <div className="rectangle-5" />

                  <div className="frame-55">
                    <div className="step-number-2">
                      <div className="text-wrapper-31">01</div>
                    </div>

                    <div className="text-wrapper-32">Tax Information</div>
                  </div>
                </div>

                <div className="content-4">
                  <div className="frame-55">
                    <div className="step-number-3">
                      <div className="element-2">02</div>
                    </div>

                    <div className="text-wrapper-33">Certification</div>
                  </div>
                </div>
              </div>

              <div className="frame-56">
                <div className="frame-33">
                  <div className="frame-34">
                    <div className="text-wrapper-34">Tax Information</div>
                  </div>
                </div>

                <div className="frame-32">
                  <p className="under-u-s-federal">
                    Under U.S. federal tax law, Envato is required to collect
                    U.S. Author tax information via an IRS Form W-9 and report
                    any income paid.
                    <br />
                    <br />
                    If you are a U.S. Person:
                    <br />
                    Regardless of your location, you can submit a Form W-9 to
                    Envato to meet your filing obligation. Generally, there will
                    be no taxes withheld from your Envato earnings. <br />
                    <br />
                    However, if a valid Form W-9 is not submitted, Envato must
                    withhold 24% of your sales proceeds and remit that amount
                    directly to the IRS. For more information, please visit our
                    help center for W-9 articles.
                    <br />
                    <br />
                    If you are not a U.S. Person:
                    <br />
                    You will need to submit a Form W-8. If your country has a
                    tax treaty with the U.S., you may qualify for a reduced or
                    zero withholding rate as outlined in the treaty. If your
                    country does not have a tax treaty with the U.S., a 30%
                    withholding tax will apply to your U.S. income from Envato.
                    For more details, please check our help center for W-8
                    articles.
                    <br />
                    <br />
                    Although Envato cannot offer tax or legal advice, we will
                    provide the necessary information to help you understand how
                    to comply with U.S. tax laws. If you have further questions
                    after reviewing the IRS guidelines, we recommend contacting
                    your legal or tax advisor.
                    <br />
                    Please indicate if you are a U.S. Person so we can guide you
                    to the appropriate forms.
                  </p>
                </div>
              </div>

              <div className="CTA-4">
                <div className="frame-57">
                  <div className="text-wrapper-21">Cancel</div>
                </div>

                <div className="frame-58">
                  <div className="text-wrapper-22">Next</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
