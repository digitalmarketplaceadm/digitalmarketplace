import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal24 } from "../../icons/SearchNormal24";
import "./style.css";

export const Products = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="products"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-15"} ${screenWidth >= 393 && screenWidth < 1440 && "class-16"}`}
            className={`${screenWidth < 393 && "class-17"} ${screenWidth >= 393 && screenWidth < 1440 && "class-18"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-20.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-21.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-19"} ${screenWidth >= 393 && screenWidth < 1440 && "class-20"}`}
            property1="dark"
            wiFi="/img/wi-fi-20.svg"
          />
          <div className="frame-120">
            <div className="back-icon-button-2">
              <div className="vuesax-outline-arrow-3" />
            </div>

            <div className="frame-121">
              <div className="text-wrapper-73">Products</div>
            </div>
          </div>

          <div className="frame-122">
            <div className="frame-123">
              <div className="frame-124">
                <div className="text-wrapper-74">Products</div>

                <img
                  className="vector-6"
                  alt="Vector"
                  src={
                    screenWidth < 393
                      ? "/img/vector-1-39.svg"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "/img/vector-1-42.svg"
                        : undefined
                  }
                />
              </div>

              <div className="frame-125">
                <div className="text-wrapper-75">Collaborators</div>

                <img
                  className="vector-7"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61469.75px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44007.75px"
                          : undefined,
                  }}
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>

              <div className="frame-124">
                <div className="text-wrapper-76">Reviews</div>

                <img
                  className="vector-8"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61592.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44130.00px"
                          : undefined,
                  }}
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>
            </div>

            <div className="frame-126">
              <div className="div-4">
                <div className="text-wrapper-77">Product Name</div>

                <div
                  className="text-wrapper-78"
                  style={{
                    marginRight: screenWidth < 393 ? "-44.00px" : undefined,
                  }}
                >
                  View
                </div>

                <div
                  className="text-wrapper-79"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  Orders
                </div>

                <div
                  className="text-wrapper-80"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  Price
                </div>

                <div
                  className="text-wrapper-81"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-356.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-283.00px"
                          : undefined,
                  }}
                >
                  Sales
                </div>

                <div
                  className="text-wrapper-82"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-446.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-373.00px"
                          : undefined,
                  }}
                >
                  View
                </div>

                <div
                  className="text-wrapper-83"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-536.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-463.00px"
                          : undefined,
                  }}
                >
                  Share
                </div>

                <div
                  className="text-wrapper-84"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-615.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-542.00px"
                          : undefined,
                  }}
                >
                  Edit
                </div>

                <div
                  className="three-dots-svgrepo-15"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61384.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-43922.00px"
                          : undefined,
                  }}
                />
              </div>

              <div
                className="navbar"
                style={{
                  marginRight:
                    screenWidth < 393
                      ? "-662.00px"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "-589.00px"
                        : undefined,
                }}
              >
                <div className="frame-127">
                  <img
                    className="image-13"
                    alt="Image"
                    src="/img/image-17.png"
                  />

                  <div className="text-wrapper-85">
                    Real Estate Landing Page
                  </div>
                </div>

                <div className="text-wrapper-86">1,200</div>

                <div className="text-wrapper-87">350</div>

                <div className="text-wrapper-88">$29.99</div>

                <div className="text-wrapper-89">$5,000</div>

                <div className="frame-128">
                  <div className="text-wrapper-90">View</div>
                </div>

                <div className="frame-129">
                  <div className="text-wrapper-90">Share</div>
                </div>

                <div className="input-24">
                  <div className="frame-127">
                    <img
                      className="pen-svgrepo-com"
                      style={{
                        marginLeft:
                          screenWidth < 393
                            ? "-62223.00px"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "-44761.00px"
                              : undefined,
                      }}
                      alt="Pen svgrepo com"
                      src="/img/vector-1-18.png"
                    />

                    <div className="text-wrapper-91">Edit</div>
                  </div>
                </div>

                <div
                  className="three-dots-svgrepo-16"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61384.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-43922.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-4">
                <div className="frame-127">
                  <img
                    className="image-14"
                    alt="Image"
                    src="/img/image-18.png"
                  />

                  <div className="text-wrapper-85">
                    Business Pro Landing Page
                  </div>
                </div>

                <div
                  className="text-wrapper-92"
                  style={{
                    marginRight: screenWidth < 393 ? "-36.00px" : undefined,
                  }}
                >
                  4,500
                </div>

                <div
                  className="text-wrapper-93"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-140.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-67.00px"
                          : undefined,
                  }}
                >
                  250
                </div>

                <div
                  className="text-wrapper-94"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-244.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-171.00px"
                          : undefined,
                  }}
                >
                  $50
                </div>

                <div
                  className="text-wrapper-95"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-348.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-275.00px"
                          : undefined,
                  }}
                >
                  $12,500
                </div>

                <div
                  className="frame-130"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-438.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-365.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">View</div>
                </div>

                <div
                  className="frame-131"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-535.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-462.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">Share</div>
                </div>

                <div
                  className="input-25"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-560.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-487.00px"
                          : undefined,
                  }}
                >
                  <div className="frame-132">
                    <img
                      className="pen-svgrepo-com-2"
                      style={{
                        marginLeft:
                          screenWidth < 393
                            ? "-62196.00px"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "-44734.00px"
                              : undefined,
                      }}
                      alt="Pen svgrepo com"
                      src="/img/vector-1-18.png"
                    />

                    <div className="text-wrapper-91">Edit</div>
                  </div>
                </div>

                <div
                  className="three-dots-svgrepo-17"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61384.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-43922.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-4">
                <div className="frame-127">
                  <img
                    className="image-13"
                    alt="Image"
                    src="/img/image-19.png"
                  />

                  <div className="text-wrapper-96">SaaS Starter Page</div>
                </div>

                <div
                  className="text-wrapper-97"
                  style={{
                    marginRight: screenWidth < 393 ? "-36.00px" : undefined,
                  }}
                >
                  3,800
                </div>

                <div
                  className="text-wrapper-98"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-140.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-67.00px"
                          : undefined,
                  }}
                >
                  180
                </div>

                <div
                  className="text-wrapper-99"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-244.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-171.00px"
                          : undefined,
                  }}
                >
                  $50
                </div>

                <div
                  className="text-wrapper-100"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-348.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-275.00px"
                          : undefined,
                  }}
                >
                  $9,000
                </div>

                <div
                  className="frame-133"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-438.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-365.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">View</div>
                </div>

                <div
                  className="frame-134"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-535.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-462.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">Share</div>
                </div>

                <div
                  className="input-26"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-560.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-487.00px"
                          : undefined,
                  }}
                >
                  <div className="frame-132">
                    <img
                      className="pen-svgrepo-com-3"
                      style={{
                        marginLeft:
                          screenWidth < 393
                            ? "-62196.00px"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "-44734.00px"
                              : undefined,
                      }}
                      alt="Pen svgrepo com"
                      src="/img/vector-1-18.png"
                    />

                    <div className="text-wrapper-91">Edit</div>
                  </div>
                </div>

                <div
                  className="three-dots-svgrepo-18"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61384.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-43922.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-4">
                <div className="frame-127">
                  <img
                    className="image-13"
                    alt="Image"
                    src={screenWidth < 393 ? "/img/image-27.png" : undefined}
                  />

                  <div className="text-wrapper-96">Minimal Portfolio</div>
                </div>

                <div
                  className="text-wrapper-101"
                  style={{
                    marginRight: screenWidth < 393 ? "-36.00px" : undefined,
                  }}
                >
                  150
                </div>

                <div
                  className="text-wrapper-102"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-140.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-67.00px"
                          : undefined,
                  }}
                >
                  10
                </div>

                <div
                  className="text-wrapper-103"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-244.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-171.00px"
                          : undefined,
                  }}
                >
                  $50
                </div>

                <div
                  className="text-wrapper-104"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-348.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-275.00px"
                          : undefined,
                  }}
                >
                  $500
                </div>

                <div
                  className="frame-135"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-438.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-365.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">View</div>
                </div>

                <div
                  className="frame-136"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-535.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-462.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">Share</div>
                </div>

                <div
                  className="input-27"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-560.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-487.00px"
                          : undefined,
                  }}
                >
                  <div className="frame-132">
                    <img
                      className="pen-svgrepo-com-4"
                      style={{
                        marginLeft:
                          screenWidth < 393
                            ? "-62196.00px"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "-44734.00px"
                              : undefined,
                      }}
                      alt="Pen svgrepo com"
                      src="/img/vector-1-18.png"
                    />

                    <div className="text-wrapper-91">Edit</div>
                  </div>
                </div>

                <div
                  className="three-dots-svgrepo-19"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61384.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-43922.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-4">
                <div className="frame-127">
                  <img
                    className="image-13"
                    alt="Image"
                    src={screenWidth < 393 ? "/img/image-28.png" : undefined}
                  />

                  <div className="text-wrapper-96">Startup One-Pager</div>
                </div>

                <div
                  className="text-wrapper-105"
                  style={{
                    marginRight: screenWidth < 393 ? "-36.00px" : undefined,
                  }}
                >
                  3,300
                </div>

                <div
                  className="text-wrapper-106"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-140.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-67.00px"
                          : undefined,
                  }}
                >
                  150
                </div>

                <div
                  className="text-wrapper-107"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-244.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-171.00px"
                          : undefined,
                  }}
                >
                  $50
                </div>

                <div
                  className="text-wrapper-108"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-348.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-275.00px"
                          : undefined,
                  }}
                >
                  $7,500
                </div>

                <div
                  className="frame-137"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-438.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-365.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">View</div>
                </div>

                <div
                  className="frame-138"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-535.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-462.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">Share</div>
                </div>

                <div
                  className="input-28"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-560.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-487.00px"
                          : undefined,
                  }}
                >
                  <div className="frame-132">
                    <img
                      className="pen-svgrepo-com-5"
                      style={{
                        marginLeft:
                          screenWidth < 393
                            ? "-62196.00px"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "-44734.00px"
                              : undefined,
                      }}
                      alt="Pen svgrepo com"
                      src="/img/vector-1-18.png"
                    />

                    <div className="text-wrapper-91">Edit</div>
                  </div>
                </div>

                <div
                  className="three-dots-svgrepo-20"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61384.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-43922.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-4">
                <div className="frame-127">
                  <img
                    className="image-13"
                    alt="Image"
                    src={screenWidth < 393 ? "/img/image-29.png" : undefined}
                  />

                  <div className="text-wrapper-85">
                    Event Promo Landing Page
                  </div>
                </div>

                <div
                  className="text-wrapper-109"
                  style={{
                    marginRight: screenWidth < 393 ? "-36.00px" : undefined,
                  }}
                >
                  2,900
                </div>

                <div
                  className="text-wrapper-110"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-140.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-67.00px"
                          : undefined,
                  }}
                >
                  110
                </div>

                <div
                  className="text-wrapper-111"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-244.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-171.00px"
                          : undefined,
                  }}
                >
                  $50
                </div>

                <div
                  className="text-wrapper-112"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-348.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-275.00px"
                          : undefined,
                  }}
                >
                  $5,500
                </div>

                <div
                  className="frame-139"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-438.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-365.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">View</div>
                </div>

                <div
                  className="frame-140"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-535.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-462.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">Share</div>
                </div>

                <div
                  className="input-29"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-560.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-487.00px"
                          : undefined,
                  }}
                >
                  <div className="frame-132">
                    <img
                      className="pen-svgrepo-com-6"
                      style={{
                        marginLeft:
                          screenWidth < 393
                            ? "-62196.00px"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "-44734.00px"
                              : undefined,
                      }}
                      alt="Pen svgrepo com"
                      src="/img/vector-1-18.png"
                    />

                    <div className="text-wrapper-91">Edit</div>
                  </div>
                </div>

                <div
                  className="three-dots-svgrepo-21"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61384.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-43922.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-4">
                <div className="frame-127">
                  <img
                    className="image-13"
                    alt="Image"
                    src={screenWidth < 393 ? "/img/image-30.png" : undefined}
                  />

                  <div className="text-wrapper-85">Tech Conference Page</div>
                </div>

                <div
                  className="text-wrapper-113"
                  style={{
                    marginRight: screenWidth < 393 ? "-36.00px" : undefined,
                  }}
                >
                  1,800
                </div>

                <div
                  className="text-wrapper-114"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-140.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-67.00px"
                          : undefined,
                  }}
                >
                  75
                </div>

                <div
                  className="text-wrapper-115"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-244.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-171.00px"
                          : undefined,
                  }}
                >
                  $50
                </div>

                <div
                  className="text-wrapper-116"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-348.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-275.00px"
                          : undefined,
                  }}
                >
                  $3,750
                </div>

                <div
                  className="frame-141"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-438.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-365.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">View</div>
                </div>

                <div
                  className="frame-142"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-535.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-462.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">Share</div>
                </div>

                <div
                  className="input-30"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-560.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-487.00px"
                          : undefined,
                  }}
                >
                  <div className="frame-132">
                    <img
                      className="pen-svgrepo-com-7"
                      style={{
                        marginLeft:
                          screenWidth < 393
                            ? "-62196.00px"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "-44734.00px"
                              : undefined,
                      }}
                      alt="Pen svgrepo com"
                      src="/img/vector-1-18.png"
                    />

                    <div className="text-wrapper-91">Edit</div>
                  </div>
                </div>

                <div
                  className="three-dots-svgrepo-22"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61384.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-43922.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-4">
                <div className="frame-127">
                  <img
                    className="image-13"
                    alt="Image"
                    src={screenWidth < 393 ? "/img/image-31.png" : undefined}
                  />

                  <div className="text-wrapper-96">Creative Portfolio</div>
                </div>

                <div
                  className="text-wrapper-117"
                  style={{
                    marginRight: screenWidth < 393 ? "-36.00px" : undefined,
                  }}
                >
                  1,200
                </div>

                <div
                  className="text-wrapper-118"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-140.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-67.00px"
                          : undefined,
                  }}
                >
                  50
                </div>

                <div
                  className="text-wrapper-119"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-244.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-171.00px"
                          : undefined,
                  }}
                >
                  $50
                </div>

                <div
                  className="text-wrapper-120"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-348.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-275.00px"
                          : undefined,
                  }}
                >
                  $2,500
                </div>

                <div
                  className="frame-143"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-438.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-365.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">View</div>
                </div>

                <div
                  className="frame-144"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-535.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-462.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">Share</div>
                </div>

                <div
                  className="input-31"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-560.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-487.00px"
                          : undefined,
                  }}
                >
                  <div className="frame-132">
                    <img
                      className="pen-svgrepo-com-8"
                      style={{
                        marginLeft:
                          screenWidth < 393
                            ? "-62196.00px"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "-44734.00px"
                              : undefined,
                      }}
                      alt="Pen svgrepo com"
                      src="/img/vector-1-18.png"
                    />

                    <div className="text-wrapper-91">Edit</div>
                  </div>
                </div>

                <div
                  className="three-dots-svgrepo-23"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61384.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-43922.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-4">
                <div className="frame-127">
                  <img
                    className="image-13"
                    alt="Image"
                    src={screenWidth < 393 ? "/img/image-32.png" : undefined}
                  />

                  <div className="text-wrapper-85">Webinar Funnel Page</div>
                </div>

                <div
                  className="text-wrapper-121"
                  style={{
                    marginRight: screenWidth < 393 ? "-36.00px" : undefined,
                  }}
                >
                  3,000
                </div>

                <div
                  className="text-wrapper-122"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-140.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-67.00px"
                          : undefined,
                  }}
                >
                  140
                </div>

                <div
                  className="text-wrapper-123"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-244.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-171.00px"
                          : undefined,
                  }}
                >
                  $50
                </div>

                <div
                  className="text-wrapper-124"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-348.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-275.00px"
                          : undefined,
                  }}
                >
                  $7,000
                </div>

                <div
                  className="frame-145"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-438.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-365.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">View</div>
                </div>

                <div
                  className="frame-146"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-535.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-462.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-90">Share</div>
                </div>

                <div
                  className="input-32"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-560.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-487.00px"
                          : undefined,
                  }}
                >
                  <div className="frame-132">
                    <img
                      className="pen-svgrepo-com-9"
                      style={{
                        marginLeft:
                          screenWidth < 393
                            ? "-62196.00px"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "-44734.00px"
                              : undefined,
                      }}
                      alt="Pen svgrepo com"
                      src="/img/vector-1-18.png"
                    />

                    <div className="text-wrapper-91">Edit</div>
                  </div>
                </div>

                <div
                  className="three-dots-svgrepo-24"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61384.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-43922.00px"
                          : undefined,
                  }}
                />
              </div>
            </div>
          </div>

          <div
            className="frame-147"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-3">
              {screenWidth < 393 && (
                <div className="frame-148">
                  <div className="navigation-menu-home-4">
                    <div className="navigation-menu-home-5">
                      <img
                        className="img-8"
                        alt="Home angle svgrepo"
                        src="/img/image.svg"
                      />

                      <div className="text-wrapper-125">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-5">
                    <SearchNormal24 className="img-9" color="#535353" />
                    <div className="text-wrapper-126">Search</div>
                  </div>

                  <div className="navigation-menu-5">
                    <img
                      className="img-9"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-127">Cart</div>
                  </div>

                  <div className="navigation-menu-5">
                    <img
                      className="img-9"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-128">Help</div>
                  </div>

                  <div className="navigation-menu-5">
                    <img
                      className="image-15"
                      alt="Image"
                      src="/img/image.png"
                    />

                    <div className="text-wrapper-129">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1440 && (
                <>
                  <div className="navigation-menu-home-4">
                    <div className="navigation-menu-home-5">
                      <img
                        className="img-8"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-11.svg"
                      />

                      <div className="text-wrapper-125">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-6">
                    <SearchNormal24 className="img-8" color="#535353" />
                  </div>

                  <div className="navigation-menu-6">
                    <img
                      className="img-8"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-7.svg"
                    />
                  </div>

                  <div className="navigation-menu-6">
                    <div className="frame-149">
                      <div className="ellipse-3" />
                    </div>
                  </div>

                  <div className="navigation-menu-6">
                    <img
                      className="image-16"
                      alt="Image"
                      src="/img/image.png"
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-3"
            lineClassName={`${screenWidth < 393 && "class-21"} ${screenWidth >= 393 && screenWidth < 1440 && "class-22"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-150">
          <div className="frame-151">
            <div className="frame-152">
              <div className="frame-153">
                <div className="frame-154">
                  <div className="frame-155">
                    <div className="text-wrapper-130">LOGO</div>
                  </div>
                </div>

                <div className="frame-156">
                  <div className="frame-157">
                    <img
                      className="img-10"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-10.svg"
                    />

                    <div className="text-wrapper-131">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-152">
                <div className="frame-152">
                  <div className="frame-158">
                    <div className="img-10">
                      <div className="img-wrapper">
                        <img
                          className="gift-3"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-132">Products</div>
                  </div>

                  <div className="frame-158">
                    <img
                      className="img-10"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-132">Collaborators</div>
                  </div>

                  <div className="frame-158">
                    <img
                      className="img-10"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-132">Checkout</div>
                  </div>

                  <div className="frame-158">
                    <img
                      className="img-10"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-132">Emails</div>
                  </div>

                  <div className="frame-158">
                    <img
                      className="img-10"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-132">Workflows</div>
                  </div>

                  <div className="frame-158">
                    <img
                      className="img-10"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-132">Sales</div>
                  </div>

                  <div className="frame-158">
                    <img
                      className="img-10"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-132">Analytics</div>
                  </div>

                  <div className="frame-158">
                    <img
                      className="img-10"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-132">Payouts</div>
                  </div>

                  <div className="frame-158">
                    <img
                      className="img-10"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-132">Library</div>
                  </div>
                </div>

                <div className="frame-158">
                  <img
                    className="img-10"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-132">Settings</div>
                </div>

                <div className="frame-158">
                  <img
                    className="img-10"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-132">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-159">
            <div className="frame-160">
              <div className="frame-161">
                <div className="frame-162">
                  <div className="text-wrapper-133">Search</div>

                  <SearchNormal24
                    className="pen-svgrepo-com-10"
                    color="#232323"
                  />
                </div>
              </div>

              <div className="frame-163">
                <div className="text-wrapper-134">Login</div>
              </div>

              <div className="frame-164">
                <div className="text-wrapper-135">Sign Up</div>
              </div>
            </div>

            <div className="frame-165">
              <div className="frame-166">
                <div className="back-icon-button-2">
                  <div className="vuesax-outline-arrow-3" />
                </div>

                <div className="frame-167">
                  <div className="text-wrapper-136">Products</div>

                  <div className="text-wrapper-137">9 Products</div>
                </div>
              </div>

              <div className="frame-123">
                <div className="frame-124">
                  <div className="text-wrapper-74">Products</div>

                  <img
                    className="vector-6"
                    alt="Vector"
                    src="/img/vector-1-36.svg"
                  />
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-75">Collaborators</div>

                  <img
                    className="vector-9"
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-124">
                  <div className="text-wrapper-76">Reviews</div>

                  <img
                    className="vector-10"
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>
              </div>

              <div className="frame-168">
                <div className="div-4">
                  <div className="text-wrapper-138">Product Name</div>

                  <div className="text-wrapper-139">View</div>

                  <div className="text-wrapper-139">Orders</div>

                  <div className="text-wrapper-139">Price</div>

                  <div className="text-wrapper-139">Sales</div>

                  <div className="text-wrapper-139">View</div>

                  <div className="text-wrapper-139">Share</div>

                  <div className="text-wrapper-139">Edit</div>

                  <div className="three-dots-svgrepo-25" />
                </div>

                <div className="div-4">
                  <div className="frame-169">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-14.png"
                    />

                    <div className="text-wrapper-140">
                      Real Estate Landing Page
                    </div>
                  </div>

                  <div className="text-wrapper-139">1,200</div>

                  <div className="text-wrapper-139">350</div>

                  <div className="text-wrapper-139">$29.99</div>

                  <div className="text-wrapper-139">$5,000</div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">View</div>
                  </div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">Share</div>
                  </div>

                  <div className="input-33">
                    <div className="frame-127">
                      <img
                        className="pen-svgrepo-com-10"
                        alt="Pen svgrepo com"
                        src="/img/pen-2-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-91">Edit</div>
                    </div>
                  </div>

                  <div className="three-dots-svgrepo-26" />
                </div>

                <div className="div-4">
                  <div className="frame-169">
                    <img
                      className="image-18"
                      alt="Image"
                      src="/img/image-15.png"
                    />

                    <div className="text-wrapper-140">
                      Business Pro Landing Page
                    </div>
                  </div>

                  <div className="text-wrapper-139">4,500</div>

                  <div className="text-wrapper-139">250</div>

                  <div className="text-wrapper-139">$50</div>

                  <div className="text-wrapper-139">$12,500</div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">View</div>
                  </div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">Share</div>
                  </div>

                  <div className="input-34">
                    <div className="frame-127">
                      <img
                        className="pen-svgrepo-com-10"
                        alt="Pen svgrepo com"
                        src="/img/pen-2-svgrepo-com-1.svg"
                      />

                      <div className="text-wrapper-91">Edit</div>
                    </div>
                  </div>

                  <div className="three-dots-svgrepo-26" />
                </div>

                <div className="div-4">
                  <div className="frame-169">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-16.png"
                    />

                    <div className="text-wrapper-140">SaaS Starter Page</div>
                  </div>

                  <div className="text-wrapper-139">3,800</div>

                  <div className="text-wrapper-139">180</div>

                  <div className="text-wrapper-139">$50</div>

                  <div className="text-wrapper-139">$9,000</div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">View</div>
                  </div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">Share</div>
                  </div>

                  <div className="input-35">
                    <div className="frame-127">
                      <img
                        className="pen-svgrepo-com-10"
                        alt="Pen svgrepo com"
                        src="/img/pen-2-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-91">Edit</div>
                    </div>
                  </div>

                  <div className="three-dots-svgrepo-26" />
                </div>

                <div className="div-4">
                  <div className="frame-169">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-21.png"
                    />

                    <div className="text-wrapper-140">Minimal Portfolio</div>
                  </div>

                  <div className="text-wrapper-139">150</div>

                  <div className="text-wrapper-139">10</div>

                  <div className="text-wrapper-139">$50</div>

                  <div className="text-wrapper-139">$500</div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">View</div>
                  </div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">Share</div>
                  </div>

                  <div className="input-36">
                    <div className="frame-127">
                      <img
                        className="pen-svgrepo-com-10"
                        alt="Pen svgrepo com"
                        src="/img/pen-2-svgrepo-com-3.svg"
                      />

                      <div className="text-wrapper-91">Edit</div>
                    </div>
                  </div>

                  <div className="three-dots-svgrepo-26" />
                </div>

                <div className="div-4">
                  <div className="frame-169">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-22.png"
                    />

                    <div className="text-wrapper-140">Startup One-Pager</div>
                  </div>

                  <div className="text-wrapper-139">3,300</div>

                  <div className="text-wrapper-139">150</div>

                  <div className="text-wrapper-139">$50</div>

                  <div className="text-wrapper-139">$7,500</div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">View</div>
                  </div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">Share</div>
                  </div>

                  <div className="input-37">
                    <div className="frame-127">
                      <img
                        className="pen-svgrepo-com-10"
                        alt="Pen svgrepo com"
                        src="/img/pen-2-svgrepo-com-4.svg"
                      />

                      <div className="text-wrapper-91">Edit</div>
                    </div>
                  </div>

                  <div className="three-dots-svgrepo-26" />
                </div>

                <div className="div-4">
                  <div className="frame-169">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-23.png"
                    />

                    <div className="text-wrapper-140">
                      Event Promo Landing Page
                    </div>
                  </div>

                  <div className="text-wrapper-139">2,900</div>

                  <div className="text-wrapper-139">110</div>

                  <div className="text-wrapper-139">$50</div>

                  <div className="text-wrapper-139">$5,500</div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">View</div>
                  </div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">Share</div>
                  </div>

                  <div className="input-38">
                    <div className="frame-127">
                      <img
                        className="pen-svgrepo-com-10"
                        alt="Pen svgrepo com"
                        src="/img/pen-2-svgrepo-com-5.svg"
                      />

                      <div className="text-wrapper-91">Edit</div>
                    </div>
                  </div>

                  <div className="three-dots-svgrepo-26" />
                </div>

                <div className="div-4">
                  <div className="frame-169">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-24.png"
                    />

                    <div className="text-wrapper-140">Tech Conference Page</div>
                  </div>

                  <div className="text-wrapper-139">1,800</div>

                  <div className="text-wrapper-139">75</div>

                  <div className="text-wrapper-139">$50</div>

                  <div className="text-wrapper-139">$3,750</div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">View</div>
                  </div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">Share</div>
                  </div>

                  <div className="input-39">
                    <div className="frame-127">
                      <img
                        className="pen-svgrepo-com-10"
                        alt="Pen svgrepo com"
                        src="/img/pen-2-svgrepo-com-6.svg"
                      />

                      <div className="text-wrapper-91">Edit</div>
                    </div>
                  </div>

                  <div className="three-dots-svgrepo-26" />
                </div>

                <div className="div-4">
                  <div className="frame-169">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-25.png"
                    />

                    <div className="text-wrapper-140">Creative Portfolio</div>
                  </div>

                  <div className="text-wrapper-139">1,200</div>

                  <div className="text-wrapper-139">50</div>

                  <div className="text-wrapper-139">$50</div>

                  <div className="text-wrapper-139">$2,500</div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">View</div>
                  </div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">Share</div>
                  </div>

                  <div className="input-40">
                    <div className="frame-127">
                      <img
                        className="pen-svgrepo-com-10"
                        alt="Pen svgrepo com"
                        src="/img/pen-2-svgrepo-com-7.svg"
                      />

                      <div className="text-wrapper-91">Edit</div>
                    </div>
                  </div>

                  <div className="three-dots-svgrepo-26" />
                </div>

                <div className="div-4">
                  <div className="frame-169">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-26.png"
                    />

                    <div className="text-wrapper-140">Webinar Funnel Page</div>
                  </div>

                  <div className="text-wrapper-139">3,000</div>

                  <div className="text-wrapper-139">140</div>

                  <div className="text-wrapper-139">$50</div>

                  <div className="text-wrapper-139">$7,000</div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">View</div>
                  </div>

                  <div className="frame-170">
                    <div className="text-wrapper-90">Share</div>
                  </div>

                  <div className="input-41">
                    <div className="frame-127">
                      <img
                        className="pen-svgrepo-com-10"
                        alt="Pen svgrepo com"
                        src="/img/pen-2-svgrepo-com-8.svg"
                      />

                      <div className="text-wrapper-91">Edit</div>
                    </div>
                  </div>

                  <div className="three-dots-svgrepo-26" />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
