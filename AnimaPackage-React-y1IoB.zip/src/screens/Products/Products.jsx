import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const Products = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="products"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-3"} ${screenWidth >= 393 && screenWidth < 1440 && "class-4"}`}
            className={`${screenWidth < 393 && "class"} ${screenWidth >= 393 && screenWidth < 1440 && "class-2"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-26-2.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-25.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-5"} ${screenWidth >= 393 && screenWidth < 1440 && "class-6"}`}
            property1="dark"
            wiFi="/img/wi-fi-3.svg"
          />
          <div className="frame-105">
            <div className="back-icon-button-7">
              <div className="vuesax-outline-arrow-4" />
            </div>

            <div className="frame-106">
              <div className="text-wrapper-56">Products</div>
            </div>
          </div>

          <div className="frame-107">
            <div className="frame-108">
              <div className="frame-109">
                <div className="text-wrapper-57">Products</div>

                <img
                  className="vector-13"
                  alt="Vector"
                  src={
                    screenWidth < 393
                      ? "/img/vector-1-25.svg"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "/img/vector-1-22.svg"
                        : undefined
                  }
                />
              </div>

              <div className="frame-110">
                <div className="text-wrapper-58">Collaborators</div>

                <img
                  className="vector-14"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-26909.75px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-9447.75px"
                          : undefined,
                  }}
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>

              <div className="frame-109">
                <div className="text-wrapper-59">Reviews</div>

                <img
                  className="vector-15"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-27032.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-9570.00px"
                          : undefined,
                  }}
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>
            </div>

            <div className="frame-111">
              <div className="group-11">
                <div className="back-icon-button-8">
                  <img
                    className="img-8"
                    alt="Plus large svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/plus-large-svgrepo-com-8.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/plus-large-svgrepo-com-7.svg"
                          : undefined
                    }
                  />
                </div>
              </div>

              <div className="frame-112">
                <div className="text-wrapper-60">Add Products</div>

                <p className="text-wrapper-61">
                  Turn your creativity into profit by adding and selling your
                  digital products effortlessly.
                </p>
              </div>

              <div className="frame-113">
                <div className="text-wrapper-62">Add Products</div>
              </div>
            </div>
          </div>

          <div
            className="frame-114"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-3">
              {screenWidth < 393 && (
                <div className="frame-115">
                  <div className="navigation-menu-home">
                    <div className="navigation-menu-home-2">
                      <img
                        className="img-8"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-63">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-3">
                    <SearchNormal property1="linear" />
                    <div className="text-wrapper-64">Search</div>
                  </div>

                  <div className="navigation-menu-3">
                    <img
                      className="img-9"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-65">Cart</div>
                  </div>

                  <div className="navigation-menu-3">
                    <img
                      className="img-9"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-2.svg"
                    />

                    <div className="text-wrapper-66">Help</div>
                  </div>

                  <div className="navigation-menu-3">
                    <img
                      className="image-10"
                      alt="Image"
                      src="/img/image-4-2.png"
                    />

                    <div className="text-wrapper-67">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1440 && (
                <>
                  <div className="navigation-menu-home">
                    <div className="navigation-menu-home-2">
                      <img
                        className="img-8"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-15.svg"
                      />

                      <div className="text-wrapper-63">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-4">
                    <SearchNormal property1="linear" />
                  </div>

                  <div className="navigation-menu-4">
                    <img
                      className="img-8"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-7.svg"
                    />
                  </div>

                  <div className="navigation-menu-4">
                    <div className="frame-116">
                      <div className="ellipse-5" />
                    </div>
                  </div>

                  <div className="navigation-menu-4">
                    <img
                      className="image-11"
                      alt="Image"
                      src="/img/image-4-2.png"
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-9"
            lineClassName={`${screenWidth < 393 && "class-7"} ${screenWidth >= 393 && screenWidth < 1440 && "class-8"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-117">
          <div className="frame-118">
            <div className="frame-119">
              <div className="frame-120">
                <div className="frame-121">
                  <div className="frame-122">
                    <div className="text-wrapper-68">LOGO</div>
                  </div>
                </div>

                <div className="frame-123">
                  <img
                    className="img-10"
                    alt="Home angle svgrepo"
                    src="/img/home-angle-svgrepo-com-8.svg"
                  />

                  <div className="text-wrapper-69">Home</div>
                </div>
              </div>

              <div className="frame-119">
                <div className="frame-119">
                  <div className="frame-124">
                    <div className="frame-125">
                      <div className="img-10">
                        <div className="vuesax-linear-gift-2">
                          <img
                            className="gift-5"
                            alt="Gift"
                            src="/img/gift-7-2x.png"
                          />
                        </div>
                      </div>

                      <div className="text-wrapper-70">Products</div>
                    </div>
                  </div>

                  <div className="frame-123">
                    <img
                      className="img-10"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-69">Collaborators</div>
                  </div>

                  <div className="frame-123">
                    <img
                      className="img-10"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-9-3.svg"
                    />

                    <div className="text-wrapper-69">Checkout</div>
                  </div>

                  <div className="frame-123">
                    <img
                      className="img-10"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-69">Emails</div>
                  </div>

                  <div className="frame-123">
                    <img
                      className="img-10"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-7.svg"
                    />

                    <div className="text-wrapper-69">Workflows</div>
                  </div>

                  <div className="frame-123">
                    <img
                      className="img-10"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-8.svg"
                    />

                    <div className="text-wrapper-69">Sales</div>
                  </div>

                  <div className="frame-123">
                    <img
                      className="img-10"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-69">Analytics</div>
                  </div>

                  <div className="frame-123">
                    <img
                      className="img-10"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-8.svg"
                    />

                    <div className="text-wrapper-69">Payouts</div>
                  </div>

                  <div className="frame-123">
                    <img
                      className="img-10"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-7-2.svg"
                    />

                    <div className="text-wrapper-69">Library</div>
                  </div>
                </div>

                <div className="frame-123">
                  <img
                    className="img-10"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-69">Settings</div>
                </div>

                <div className="frame-123">
                  <img
                    className="img-10"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-69">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-126">
            <div className="frame-127">
              <div className="frame-128">
                <div className="frame-129">
                  <div className="text-wrapper-71">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-113">
                <div className="text-wrapper-72">Login</div>
              </div>

              <div className="frame-130">
                <div className="text-wrapper-73">Sign Up</div>
              </div>
            </div>

            <div className="frame-131">
              <div className="frame-132">
                <div className="back-icon-button-7">
                  <div className="vuesax-outline-arrow-4" />
                </div>

                <div className="frame-133">
                  <div className="text-wrapper-74">Products</div>

                  <div className="text-wrapper-75">9 Products</div>
                </div>
              </div>

              <div className="frame-108">
                <div className="frame-109">
                  <div className="text-wrapper-57">Products</div>

                  <img
                    className="vector-13"
                    alt="Vector"
                    src="/img/vector-1-19.svg"
                  />
                </div>

                <div className="frame-110">
                  <div className="text-wrapper-58">Collaborators</div>

                  <img
                    className="vector-16"
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-109">
                  <div className="text-wrapper-59">Reviews</div>

                  <img
                    className="vector-17"
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>
              </div>

              <div className="frame-134">
                <div className="group-11">
                  <div className="back-icon-button-8">
                    <img
                      className="img-8"
                      alt="Plus large svgrepo"
                      src="/img/plus-large-svgrepo-com-6.svg"
                    />
                  </div>
                </div>

                <div className="frame-112">
                  <div className="text-wrapper-60">Add Products</div>

                  <p className="text-wrapper-61">
                    Turn your creativity into profit by adding and selling your
                    digital products effortlessly.
                  </p>
                </div>

                <div className="frame-113">
                  <div className="text-wrapper-62">Add Products</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
