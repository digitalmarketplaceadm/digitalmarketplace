import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal24 } from "../../icons/SearchNormal24";
import "./style.css";

export const SecurityPayout = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-payout"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        height:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "956px"
            : undefined,
        minHeight: screenWidth >= 1440 ? "1022px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-31"} ${screenWidth >= 393 && screenWidth < 1440 && "class-32"}`}
            className={`${screenWidth < 393 && "class-33"} ${screenWidth >= 393 && screenWidth < 1440 && "class-34"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-18.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-19.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-35"} ${screenWidth >= 393 && screenWidth < 1440 && "class-36"}`}
            property1="dark"
            wiFi="/img/wi-fi-18.svg"
          />
          <div className="frame-296">
            <div className="back-icon-button-7">
              <div className="vuesax-outline-arrow-8" />
            </div>

            <div className="frame-297">
              <div className="text-wrapper-208">Payout Method</div>
            </div>
          </div>

          <div
            className="frame-298"
            style={{
              marginBottom: screenWidth < 393 ? "-21.00px" : undefined,
            }}
          >
            <div className="frame-299">
              <div className="div-7">
                <div className="text-wrapper-209">Account type</div>

                <div className="input-43">
                  <div className="frame-300">
                    <div className="default-circle-5" />

                    <div className="frame-301">
                      <div className="group-4" />
                    </div>

                    <div className="text-wrapper-210">Bank Transfer</div>
                  </div>
                </div>

                <div className="input-43">
                  <div className="frame-300">
                    <div className="default-circle-5" />

                    <div className="frame-301">
                      <div className="paypal-svgrepo">
                        <div className="page" />
                      </div>
                    </div>

                    <div className="text-wrapper-210">Paypal</div>
                  </div>
                </div>
              </div>

              <div className="div-7">
                <div className="input-44">
                  <div className="text-wrapper-209">Country</div>

                  <div className="input-45">
                    <div className="text-wrapper-211">Select your country</div>

                    <img
                      className="expand-more"
                      alt="Expand more"
                      src={
                        screenWidth < 393
                          ? "/img/expand-more-7.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/expand-more-8.svg"
                            : undefined
                      }
                    />
                  </div>
                </div>

                <div className="input-44">
                  <div className="text-wrapper-209">Swift//BIC</div>

                  <div className="input-45">
                    <div className="text-wrapper-211">Dmitri Ivanov</div>
                  </div>
                </div>

                <div className="input-44">
                  <div className="text-wrapper-209">Bank Address</div>

                  <div className="input-45">
                    <div className="text-wrapper-211">dmitri.ivanov</div>
                  </div>
                </div>

                <div className="input-44">
                  <div className="text-wrapper-209">Bank CIty</div>

                  <div className="input-45">
                    <div className="text-wrapper-211">July 05, 1999</div>
                  </div>
                </div>

                <div className="input-44">
                  <div className="text-wrapper-209">Bank Province/State</div>

                  <div className="input-45">
                    <div className="text-wrapper-211">Select your country</div>
                  </div>
                </div>

                <div className="input-44">
                  <label className="text-wrapper-209" htmlFor="input-1">
                    Account Number
                  </label>

                  <input
                    className="input-46"
                    id="input-1"
                    placeholder="dmitri.ivanov@gmail.com"
                    type="email"
                  />
                </div>

                <div className="input-44">
                  <div className="text-wrapper-209">Name of Account Holder</div>

                  <div className="input-45">
                    <div className="text-wrapper-211">+1 (646) 555-1376</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-302">
              <div className="div-8">
                <div className="frame-303">
                  <div className="default-circle-6" />

                  <p
                    className="text-wrapper-212"
                    style={{
                      flex: screenWidth < 393 ? "1" : undefined,
                      marginRight:
                        screenWidth >= 393 && screenWidth < 1440
                          ? "-762.00px"
                          : undefined,
                      width:
                        screenWidth >= 393 && screenWidth < 1440
                          ? "1071px"
                          : undefined,
                    }}
                  >
                    I have read and acknowledge the certification
                  </p>
                </div>
              </div>
            </div>

            <div className="CTA-4">
              <div className="frame-304">
                <div className="text-wrapper-213">Cancel</div>
              </div>

              <div className="frame-305">
                <div className="text-wrapper-214">Next</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className={`${screenWidth < 393 && "class-37"} ${screenWidth >= 393 && screenWidth < 1440 && "class-38"}`}
            lineClassName={`${screenWidth < 393 && "class-39"} ${screenWidth >= 393 && screenWidth < 1440 && "class-40"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-306">
          <div className="frame-307">
            <div className="frame-308">
              <div className="frame-309">
                <div className="frame-310">
                  <div className="frame-311">
                    <div className="text-wrapper-215">LOGO</div>
                  </div>
                </div>

                <div className="frame-312">
                  <div className="frame-313">
                    <img
                      className="img-17"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-19.svg"
                    />

                    <div className="text-wrapper-216">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-308">
                <div className="frame-308">
                  <div className="frame-314">
                    <div className="img-17">
                      <div className="vuesax-linear-gift-6">
                        <img
                          className="gift-8"
                          alt="Gift"
                          src="/img/gift-11.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-217">Products</div>
                  </div>

                  <div className="frame-314">
                    <img
                      className="img-17"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-11.svg"
                    />

                    <div className="text-wrapper-217">Collaborators</div>
                  </div>

                  <div className="frame-314">
                    <img
                      className="img-17"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-217">Checkout</div>
                  </div>

                  <div className="frame-314">
                    <img
                      className="img-17"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-217">Emails</div>
                  </div>

                  <div className="frame-314">
                    <img
                      className="img-17"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-11.svg"
                    />

                    <div className="text-wrapper-217">Workflows</div>
                  </div>

                  <div className="frame-314">
                    <img
                      className="img-17"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-22.svg"
                    />

                    <div className="text-wrapper-217">Sales</div>
                  </div>

                  <div className="frame-314">
                    <img
                      className="img-17"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-217">Analytics</div>
                  </div>

                  <div className="frame-314">
                    <img
                      className="img-17"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-23.svg"
                    />

                    <div className="text-wrapper-217">Payouts</div>
                  </div>

                  <div className="frame-314">
                    <img
                      className="img-17"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-11.svg"
                    />

                    <div className="text-wrapper-217">Library</div>
                  </div>
                </div>

                <div className="frame-314">
                  <img
                    className="img-17"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-11.svg"
                  />

                  <div className="text-wrapper-217">Settings</div>
                </div>

                <div className="frame-314">
                  <img
                    className="img-17"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-217">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-315">
            <div className="frame-316">
              <div className="frame-317">
                <div className="frame-318">
                  <div className="text-wrapper-218">Search</div>

                  <SearchNormal24
                    className="property-1-linear-8"
                    color="#232323"
                  />
                </div>
              </div>

              <div className="frame-319">
                <div className="text-wrapper-219">Login</div>
              </div>

              <div className="frame-320">
                <div className="text-wrapper-220">Sign Up</div>
              </div>
            </div>

            <div className="frame-321">
              <div className="frame-322">
                <div className="back-icon-button-7">
                  <div className="vuesax-outline-arrow-8" />
                </div>

                <div className="div-8">
                  <div className="text-wrapper-221">Payout Method</div>

                  <p className="text-wrapper-222">
                    Please enter your preferred payout method to receive
                    payments securely and efficiently.
                  </p>
                </div>
              </div>

              <div className="frame-323">
                <div className="input-47">
                  <div className="text-wrapper-209">Account type</div>

                  <div className="frame-324">
                    <div className="input-48">
                      <div className="frame-300">
                        <div className="default-circle-5" />

                        <div className="text-wrapper-223">Individual</div>
                      </div>
                    </div>

                    <div className="input-48">
                      <div className="frame-300">
                        <div className="default-circle-5" />

                        <div className="text-wrapper-223">
                          Registered Business
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-322">
                  <div className="input-49">
                    <div className="text-wrapper-209">First Name</div>

                    <div className="input-45">
                      <div className="text-wrapper-211">Dmitri Ivanov</div>
                    </div>
                  </div>

                  <div className="input-49">
                    <div className="text-wrapper-209">Last Name</div>

                    <div className="input-45">
                      <div className="text-wrapper-211">dmitri.ivanov</div>
                    </div>
                  </div>
                </div>

                <div className="frame-322">
                  <div className="input-49">
                    <div className="text-wrapper-209">Date of birth</div>

                    <div className="input-45">
                      <div className="text-wrapper-211">July 05, 1999</div>
                    </div>
                  </div>

                  <div className="input-49">
                    <div className="text-wrapper-209">Country</div>

                    <div className="input-45">
                      <div className="text-wrapper-211">
                        Select your country
                      </div>

                      <img
                        className="expand-more"
                        alt="Expand more"
                        src="/img/expand-more-6.svg"
                      />
                    </div>
                  </div>
                </div>

                <div className="frame-322">
                  <div className="input-49">
                    <label className="text-wrapper-209" htmlFor="input-2">
                      Address
                    </label>

                    <input
                      className="input-46"
                      id="input-2"
                      placeholder="dmitri.ivanov@gmail.com"
                      type="email"
                    />
                  </div>

                  <div className="input-49">
                    <div className="text-wrapper-209">City</div>

                    <div className="input-45">
                      <div className="text-wrapper-211">+1 (646) 555-1376</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="CTA-5">
                <div className="frame-325">
                  <div className="text-wrapper-213">Back</div>
                </div>

                <div className="frame-326">
                  <div className="text-wrapper-214">Done</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
