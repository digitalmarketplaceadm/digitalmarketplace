import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const SecurityPayout = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-payout"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        height:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "956px"
            : undefined,
        minHeight: screenWidth >= 1440 ? "1022px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-91"} ${screenWidth >= 393 && screenWidth < 1440 && "class-92"}`}
            className={`${screenWidth < 393 && "class-89"} ${screenWidth >= 393 && screenWidth < 1440 && "class-90"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-38.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-39.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-93"} ${screenWidth >= 393 && screenWidth < 1440 && "class-94"}`}
            property1="dark"
            wiFi="/img/wi-fi-38.svg"
          />
          <div className="frame-1042">
            <div className="back-icon-button-45">
              <div className="vuesax-outline-arrow-26" />
            </div>

            <div className="frame-1043">
              <div className="text-wrapper-525">Payout Method</div>
            </div>
          </div>

          <div
            className="frame-1044"
            style={{
              marginBottom: screenWidth < 393 ? "-21.00px" : undefined,
            }}
          >
            <div className="frame-1045">
              <div className="div-15">
                <div className="text-wrapper-526">Account type</div>

                <div className="input-66">
                  <div className="frame-1046">
                    <div className="default-circle-12" />

                    <div className="frame-1047">
                      <div className="group-150" />
                    </div>

                    <div className="text-wrapper-527">Bank Transfer</div>
                  </div>
                </div>

                <div className="input-66">
                  <div className="frame-1046">
                    <div className="default-circle-12" />

                    <div className="frame-1047">
                      <div className="paypal-svgrepo">
                        <div className="page-12" />
                      </div>
                    </div>

                    <div className="text-wrapper-527">Paypal</div>
                  </div>
                </div>
              </div>

              <div className="div-15">
                <div className="input-67">
                  <div className="text-wrapper-526">Country</div>

                  <div className="input-68">
                    <div className="text-wrapper-528">Select your country</div>

                    <img
                      className="expand-more-6"
                      alt="Expand more"
                      src={
                        screenWidth < 393
                          ? "/img/expand-more-7.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/expand-more-8-3.svg"
                            : undefined
                      }
                    />
                  </div>
                </div>

                <div className="input-67">
                  <div className="text-wrapper-526">Swift//BIC</div>

                  <div className="input-68">
                    <div className="text-wrapper-528">Dmitri Ivanov</div>
                  </div>
                </div>

                <div className="input-67">
                  <div className="text-wrapper-526">Bank Address</div>

                  <div className="input-68">
                    <div className="text-wrapper-528">dmitri.ivanov</div>
                  </div>
                </div>

                <div className="input-67">
                  <div className="text-wrapper-526">Bank CIty</div>

                  <div className="input-68">
                    <div className="text-wrapper-528">July 05, 1999</div>
                  </div>
                </div>

                <div className="input-67">
                  <div className="text-wrapper-526">Bank Province/State</div>

                  <div className="input-68">
                    <div className="text-wrapper-528">Select your country</div>
                  </div>
                </div>

                <div className="input-67">
                  <label className="text-wrapper-526" htmlFor="input-1">
                    Account Number
                  </label>

                  <input
                    className="input-69"
                    id="input-1"
                    placeholder="dmitri.ivanov@gmail.com"
                    type="email"
                  />
                </div>

                <div className="input-67">
                  <div className="text-wrapper-526">Name of Account Holder</div>

                  <div className="input-68">
                    <div className="text-wrapper-528">+1 (646) 555-1376</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-1048">
              <div className="div-16">
                <div className="frame-1049">
                  <div className="default-circle-13" />

                  <p
                    className="text-wrapper-529"
                    style={{
                      flex: screenWidth < 393 ? "1" : undefined,
                      marginRight:
                        screenWidth >= 393 && screenWidth < 1440
                          ? "-762.00px"
                          : undefined,
                      width:
                        screenWidth >= 393 && screenWidth < 1440
                          ? "1071px"
                          : undefined,
                    }}
                  >
                    I have read and acknowledge the certification
                  </p>
                </div>
              </div>
            </div>

            <div className="CTA-12">
              <div className="frame-1050">
                <div className="text-wrapper-530">Cancel</div>
              </div>

              <div className="frame-1051">
                <div className="text-wrapper-531">Next</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className={`${screenWidth < 393 && "class-95"} ${screenWidth >= 393 && screenWidth < 1440 && "class-96"}`}
            lineClassName={`${screenWidth < 393 && "class-97"} ${screenWidth >= 393 && screenWidth < 1440 && "class-98"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-1052">
          <div className="frame-1053">
            <div className="frame-1054">
              <div className="frame-1055">
                <div className="frame-1056">
                  <div className="frame-1057">
                    <div className="text-wrapper-532">LOGO</div>
                  </div>
                </div>

                <div className="frame-1058">
                  <div className="frame-1059">
                    <img
                      className="img-56"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-19.svg"
                    />

                    <div className="text-wrapper-533">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-1054">
                <div className="frame-1054">
                  <div className="frame-1060">
                    <div className="img-56">
                      <div className="vuesax-linear-gift-23">
                        <img
                          className="gift-33"
                          alt="Gift"
                          src="/img/gift-11.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-534">Products</div>
                  </div>

                  <div className="frame-1060">
                    <img
                      className="img-56"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-11.svg"
                    />

                    <div className="text-wrapper-534">Collaborators</div>
                  </div>

                  <div className="frame-1060">
                    <img
                      className="img-56"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-9-2.svg"
                    />

                    <div className="text-wrapper-534">Checkout</div>
                  </div>

                  <div className="frame-1060">
                    <img
                      className="img-56"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-534">Emails</div>
                  </div>

                  <div className="frame-1060">
                    <img
                      className="img-56"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-11.svg"
                    />

                    <div className="text-wrapper-534">Workflows</div>
                  </div>

                  <div className="frame-1060">
                    <img
                      className="img-56"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-22.svg"
                    />

                    <div className="text-wrapper-534">Sales</div>
                  </div>

                  <div className="frame-1060">
                    <img
                      className="img-56"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-534">Analytics</div>
                  </div>

                  <div className="frame-1060">
                    <img
                      className="img-56"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-23.svg"
                    />

                    <div className="text-wrapper-534">Payouts</div>
                  </div>

                  <div className="frame-1060">
                    <img
                      className="img-56"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-11.svg"
                    />

                    <div className="text-wrapper-534">Library</div>
                  </div>
                </div>

                <div className="frame-1060">
                  <img
                    className="img-56"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-11.svg"
                  />

                  <div className="text-wrapper-534">Settings</div>
                </div>

                <div className="frame-1060">
                  <img
                    className="img-56"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-9.svg"
                  />

                  <div className="text-wrapper-534">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-1061">
            <div className="frame-1062">
              <div className="frame-1063">
                <div className="frame-1064">
                  <div className="text-wrapper-535">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-1065">
                <div className="text-wrapper-536">Login</div>
              </div>

              <div className="frame-1066">
                <div className="text-wrapper-537">Sign Up</div>
              </div>
            </div>

            <div className="frame-1067">
              <div className="frame-1068">
                <div className="back-icon-button-45">
                  <div className="vuesax-outline-arrow-26" />
                </div>

                <div className="div-16">
                  <div className="text-wrapper-538">Payout Method</div>

                  <p className="text-wrapper-539">
                    Please enter your preferred payout method to receive
                    payments securely and efficiently.
                  </p>
                </div>
              </div>

              <div className="frame-1069">
                <div className="input-70">
                  <div className="text-wrapper-526">Account type</div>

                  <div className="frame-1070">
                    <div className="input-71">
                      <div className="frame-1046">
                        <div className="default-circle-12" />

                        <div className="text-wrapper-540">Individual</div>
                      </div>
                    </div>

                    <div className="input-71">
                      <div className="frame-1046">
                        <div className="default-circle-12" />

                        <div className="text-wrapper-540">
                          Registered Business
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-1068">
                  <div className="input-72">
                    <div className="text-wrapper-526">First Name</div>

                    <div className="input-68">
                      <div className="text-wrapper-528">Dmitri Ivanov</div>
                    </div>
                  </div>

                  <div className="input-72">
                    <div className="text-wrapper-526">Last Name</div>

                    <div className="input-68">
                      <div className="text-wrapper-528">dmitri.ivanov</div>
                    </div>
                  </div>
                </div>

                <div className="frame-1068">
                  <div className="input-72">
                    <div className="text-wrapper-526">Date of birth</div>

                    <div className="input-68">
                      <div className="text-wrapper-528">July 05, 1999</div>
                    </div>
                  </div>

                  <div className="input-72">
                    <div className="text-wrapper-526">Country</div>

                    <div className="input-68">
                      <div className="text-wrapper-528">
                        Select your country
                      </div>

                      <img
                        className="expand-more-6"
                        alt="Expand more"
                        src="/img/expand-more-6.svg"
                      />
                    </div>
                  </div>
                </div>

                <div className="frame-1068">
                  <div className="input-72">
                    <label className="text-wrapper-526" htmlFor="input-2">
                      Address
                    </label>

                    <input
                      className="input-69"
                      id="input-2"
                      placeholder="dmitri.ivanov@gmail.com"
                      type="email"
                    />
                  </div>

                  <div className="input-72">
                    <div className="text-wrapper-526">City</div>

                    <div className="input-68">
                      <div className="text-wrapper-528">+1 (646) 555-1376</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="CTA-13">
                <div className="frame-1071">
                  <div className="text-wrapper-530">Back</div>
                </div>

                <div className="frame-1072">
                  <div className="text-wrapper-531">Done</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
