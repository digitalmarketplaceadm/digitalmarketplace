import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal } from "../../icons/SearchNormal";
import "./style.css";

export const SecurityPayout = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-payout"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        height:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "956px"
            : undefined,
        minHeight: screenWidth >= 1440 ? "1022px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-3"} ${screenWidth >= 393 && screenWidth < 1440 && "class-4"}`}
            className={`${screenWidth < 393 && "class-5"} ${screenWidth >= 393 && screenWidth < 1440 && "class-6"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-18.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-19.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class"} ${screenWidth >= 393 && screenWidth < 1440 && "class-2"}`}
            property1="dark"
            wiFi="/img/wi-fi-18.svg"
          />
          <div className="frame">
            <div className="back-icon-button">
              <div className="vuesax-outline-arrow" />
            </div>

            <div className="div-wrapper">
              <div className="text-wrapper">Payout Method</div>
            </div>
          </div>

          <div
            className="div"
            style={{
              marginBottom: screenWidth < 393 ? "-21.00px" : undefined,
            }}
          >
            <div className="frame-2">
              <div className="div-2">
                <div className="text-wrapper-2">Account type</div>

                <div className="input">
                  <div className="frame-3">
                    <div className="default-circle" />

                    <div className="frame-4">
                      <div className="group" />
                    </div>

                    <div className="text-wrapper-3">Bank Transfer</div>
                  </div>
                </div>

                <div className="input">
                  <div className="frame-3">
                    <div className="default-circle" />

                    <div className="frame-4">
                      <div className="paypal-svgrepo">
                        <div className="page" />
                      </div>
                    </div>

                    <div className="text-wrapper-3">Paypal</div>
                  </div>
                </div>
              </div>

              <div className="div-2">
                <div className="input-2">
                  <div className="text-wrapper-2">Country</div>

                  <div className="input-3">
                    <div className="text-wrapper-4">Select your country</div>

                    <img
                      className="expand-more"
                      alt="Expand more"
                      src={
                        screenWidth < 393
                          ? "/img/expand-more-7.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/expand-more-8.svg"
                            : undefined
                      }
                    />
                  </div>
                </div>

                <div className="input-2">
                  <div className="text-wrapper-2">Swift//BIC</div>

                  <div className="input-3">
                    <div className="text-wrapper-4">Dmitri Ivanov</div>
                  </div>
                </div>

                <div className="input-2">
                  <div className="text-wrapper-2">Bank Address</div>

                  <div className="input-3">
                    <div className="text-wrapper-4">dmitri.ivanov</div>
                  </div>
                </div>

                <div className="input-2">
                  <div className="text-wrapper-2">Bank CIty</div>

                  <div className="input-3">
                    <div className="text-wrapper-4">July 05, 1999</div>
                  </div>
                </div>

                <div className="input-2">
                  <div className="text-wrapper-2">Bank Province/State</div>

                  <div className="input-3">
                    <div className="text-wrapper-4">Select your country</div>
                  </div>
                </div>

                <div className="input-2">
                  <label className="text-wrapper-2" htmlFor="input-1">
                    Account Number
                  </label>

                  <input
                    className="input-4"
                    id="input-1"
                    placeholder="dmitri.ivanov@gmail.com"
                    type="email"
                  />
                </div>

                <div className="input-2">
                  <div className="text-wrapper-2">Name of Account Holder</div>

                  <div className="input-3">
                    <div className="text-wrapper-4">+1 (646) 555-1376</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="input-wrapper">
              <div className="div-3">
                <div className="frame-5">
                  <div className="default-circle-2" />

                  <p
                    className="p"
                    style={{
                      flex: screenWidth < 393 ? "1" : undefined,
                      marginRight:
                        screenWidth >= 393 && screenWidth < 1440
                          ? "-762.00px"
                          : undefined,
                      width:
                        screenWidth >= 393 && screenWidth < 1440
                          ? "1071px"
                          : undefined,
                    }}
                  >
                    I have read and acknowledge the certification
                  </p>
                </div>
              </div>
            </div>

            <div className="CTA">
              <div className="frame-6">
                <div className="text-wrapper-5">Cancel</div>
              </div>

              <div className="frame-7">
                <div className="text-wrapper-6">Next</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className={`${screenWidth < 393 && "class-7"} ${screenWidth >= 393 && screenWidth < 1440 && "class-8"}`}
            lineClassName={`${screenWidth < 393 && "class-9"} ${screenWidth >= 393 && screenWidth < 1440 && "class-10"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-8">
          <div className="frame-wrapper">
            <div className="frame-9">
              <div className="frame-10">
                <div className="frame-11">
                  <div className="frame-12">
                    <div className="text-wrapper-7">LOGO</div>
                  </div>
                </div>

                <div className="frame-13">
                  <div className="frame-14">
                    <img
                      className="img"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-19.svg"
                    />

                    <div className="text-wrapper-8">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-9">
                <div className="frame-9">
                  <div className="frame-15">
                    <div className="img">
                      <div className="vuesax-linear-gift">
                        <img
                          className="gift"
                          alt="Gift"
                          src="/img/gift-11.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-9">Products</div>
                  </div>

                  <div className="frame-15">
                    <img
                      className="img"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-11.svg"
                    />

                    <div className="text-wrapper-9">Collaborators</div>
                  </div>

                  <div className="frame-15">
                    <img
                      className="img"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-9">Checkout</div>
                  </div>

                  <div className="frame-15">
                    <img
                      className="img"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-9">Emails</div>
                  </div>

                  <div className="frame-15">
                    <img
                      className="img"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-11.svg"
                    />

                    <div className="text-wrapper-9">Workflows</div>
                  </div>

                  <div className="frame-15">
                    <img
                      className="img"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-22.svg"
                    />

                    <div className="text-wrapper-9">Sales</div>
                  </div>

                  <div className="frame-15">
                    <img
                      className="img"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-9">Analytics</div>
                  </div>

                  <div className="frame-15">
                    <img
                      className="img"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-23.svg"
                    />

                    <div className="text-wrapper-9">Payouts</div>
                  </div>

                  <div className="frame-15">
                    <img
                      className="img"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-11.svg"
                    />

                    <div className="text-wrapper-9">Library</div>
                  </div>
                </div>

                <div className="frame-15">
                  <img
                    className="img"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-11.svg"
                  />

                  <div className="text-wrapper-9">Settings</div>
                </div>

                <div className="frame-15">
                  <img
                    className="img"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-9">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-16">
            <div className="frame-17">
              <div className="frame-18">
                <div className="frame-19">
                  <div className="text-wrapper-10">Search</div>

                  <SearchNormal className="search-normal" color="#232323" />
                </div>
              </div>

              <div className="frame-20">
                <div className="text-wrapper-11">Login</div>
              </div>

              <div className="frame-21">
                <div className="text-wrapper-12">Sign Up</div>
              </div>
            </div>

            <div className="frame-22">
              <div className="frame-23">
                <div className="back-icon-button">
                  <div className="vuesax-outline-arrow" />
                </div>

                <div className="div-3">
                  <div className="text-wrapper-13">Payout Method</div>

                  <p className="text-wrapper-14">
                    Please enter your preferred payout method to receive
                    payments securely and efficiently.
                  </p>
                </div>
              </div>

              <div className="frame-24">
                <div className="input-5">
                  <div className="text-wrapper-2">Account type</div>

                  <div className="frame-25">
                    <div className="input-6">
                      <div className="frame-3">
                        <div className="default-circle" />

                        <div className="text-wrapper-15">Individual</div>
                      </div>
                    </div>

                    <div className="input-6">
                      <div className="frame-3">
                        <div className="default-circle" />

                        <div className="text-wrapper-15">
                          Registered Business
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-23">
                  <div className="input-7">
                    <div className="text-wrapper-2">First Name</div>

                    <div className="input-3">
                      <div className="text-wrapper-4">Dmitri Ivanov</div>
                    </div>
                  </div>

                  <div className="input-7">
                    <div className="text-wrapper-2">Last Name</div>

                    <div className="input-3">
                      <div className="text-wrapper-4">dmitri.ivanov</div>
                    </div>
                  </div>
                </div>

                <div className="frame-23">
                  <div className="input-7">
                    <div className="text-wrapper-2">Date of birth</div>

                    <div className="input-3">
                      <div className="text-wrapper-4">July 05, 1999</div>
                    </div>
                  </div>

                  <div className="input-7">
                    <div className="text-wrapper-2">Country</div>

                    <div className="input-3">
                      <div className="text-wrapper-4">Select your country</div>

                      <img
                        className="expand-more"
                        alt="Expand more"
                        src="/img/expand-more-6.svg"
                      />
                    </div>
                  </div>
                </div>

                <div className="frame-23">
                  <div className="input-7">
                    <label className="text-wrapper-2" htmlFor="input-2">
                      Address
                    </label>

                    <input
                      className="input-4"
                      id="input-2"
                      placeholder="dmitri.ivanov@gmail.com"
                      type="email"
                    />
                  </div>

                  <div className="input-7">
                    <div className="text-wrapper-2">City</div>

                    <div className="input-3">
                      <div className="text-wrapper-4">+1 (646) 555-1376</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="CTA-2">
                <div className="frame-26">
                  <div className="text-wrapper-5">Back</div>
                </div>

                <div className="frame-27">
                  <div className="text-wrapper-6">Done</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
