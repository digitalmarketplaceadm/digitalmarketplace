import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const SecurityTrader = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-trader"
      style={{
        alignItems:
          screenWidth < 1200
            ? "center"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1200
            ? "#ffffff"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection: screenWidth < 1200 ? "column" : undefined,
        gap:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
        minHeight:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "1022px"
            : undefined,
        minWidth:
          screenWidth < 1200
            ? "320px"
            : screenWidth >= 1200 && screenWidth < 1440
              ? "1200px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
        width:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "100%"
            : undefined,
      }}
    >
      {screenWidth < 1200 && (
        <>
          <StatusBar
            batteryClassName="status-bar-114"
            className="status-bar-112"
            combinedShape="/img/combined-shape-38.svg"
            containerClassName="status-bar-113"
            property1="dark"
            wiFi="/img/wi-fi-38.svg"
          />
          <div className="frame-1004">
            <div className="back-icon-button-44">
              <div className="vuesax-outline-arrow-25" />
            </div>

            <div className="frame-1005">
              <div className="text-wrapper-501">Trader Status Declaration</div>
            </div>
          </div>

          <div className="frame-1006">
            <div className="frame-1007">
              <div className="div-14">
                <div className="frame-1008">
                  <p className="text-wrapper-502">Yes, I am a Trader</p>

                  <div className="default-circle-10" />
                </div>
              </div>

              <div className="frame-1009">
                <div className="text-wrapper-503">Select this if you:</div>

                <div className="frame-1009">
                  <div className="frame-1008">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-8.svg"
                    />

                    <p className="text-wrapper-504">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>

                  <div className="frame-1008">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-9.svg"
                    />

                    <p className="text-wrapper-504">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>

                  <div className="frame-1008">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-10.svg"
                    />

                    <p className="text-wrapper-504">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>

                  <div className="frame-1008">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-11.svg"
                    />

                    <p className="text-wrapper-504">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-1007">
              <div className="div-14">
                <div className="frame-1008">
                  <p className="text-wrapper-502">
                    No, I am&nbsp;&nbsp;not a Trader
                  </p>

                  <div className="default-circle-10" />
                </div>
              </div>

              <div className="frame-1009">
                <div className="text-wrapper-503">Select this if you:</div>

                <div className="frame-1009">
                  <div className="frame-1008">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-12.svg"
                    />

                    <p className="text-wrapper-504">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>

                  <div className="frame-1008">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-13.svg"
                    />

                    <p className="text-wrapper-504">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>

                  <div className="frame-1008">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-14.svg"
                    />

                    <p className="text-wrapper-504">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>

                  <div className="frame-1008">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-15.svg"
                    />

                    <p className="text-wrapper-504">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="div-14">
              <div className="frame-1010">
                <div className="default-circle-11" />

                <input
                  className="i-the-undersigned"
                  placeholder="I, the undersigned, hereby declare my status as a Trader under [specify the relevant tax laws or criteria in your jurisdiction, such as IRS guidelines for U.S. traders or local tax authority]. I acknowledge the following I am engaged in the business of buying and selling securities, commodities, or other financial instruments as a regular part of my business activities.My trading activities are substantial, frequent, and carried out with the intent of generating income from short-term price movements.&lt;br/&gt;&lt;br/&gt;I understand that as a trader, I am not considered an investor, and I may be subject to different tax treatments, including the reporting of gains and losses under Mark-to-Market rules (if applicable), and/or other tax regulations specific to traders."
                  type="number"
                />
              </div>
            </div>

            <div className="frame-1011">
              <div className="input-65">
                <div className="frame-1010">
                  <div className="check-svgrepo-com">
                    <div className="layer-5">
                      <img
                        className="icons-5"
                        alt="Icons"
                        src="/img/icons-q2-1.png"
                      />
                    </div>
                  </div>

                  <p className="by-confirming-your">
                    By Confirming your status you declare that
                    your&nbsp;&nbsp;selection accurately reflects your trader
                    status on Gumroad Market and understand how this affects the
                    visibility of your author information.
                  </p>
                </div>
              </div>
            </div>

            <div className="CTA-10">
              <div className="frame-1012">
                <div className="text-wrapper-505">Cancel</div>
              </div>

              <div className="frame-1013">
                <div className="text-wrapper-506">Next</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-44"
            lineClassName="home-indicator-45"
            property1="dark"
          />
        </>
      )}

      {((screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440) && (
        <div className="frame-1014">
          <div className="frame-1015">
            <div className="frame-1016">
              <div className="frame-1017">
                <div className="frame-1018">
                  <div className="frame-1019">
                    <div className="text-wrapper-507">LOGO</div>
                  </div>
                </div>

                <div className="frame-1020">
                  <div className="frame-1021">
                    <img
                      className="img-55"
                      alt="Home angle svgrepo"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/home-angle-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/home-angle-svgrepo-com-19.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-508">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-1016">
                <div className="frame-1016">
                  <div className="frame-1022">
                    <div className="img-55">
                      <div className="vuesax-linear-gift-22">
                        <img
                          className="gift-32"
                          alt="Gift"
                          src={
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "/img/gift-1.png"
                              : screenWidth >= 1440
                                ? "/img/gift-11.png"
                                : undefined
                          }
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-509">Products</div>
                  </div>

                  <div className="frame-1022">
                    <img
                      className="img-55"
                      alt="Users group two"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/users-group-two-rounded-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/users-group-two-rounded-svgrepo-com-11.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-509">Collaborators</div>
                  </div>

                  <div className="frame-1022">
                    <img
                      className="img-55"
                      alt="Cart svgrepo com"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/cart-svgrepo-com-1-2.svg"
                          : screenWidth >= 1440
                            ? "/img/cart-svgrepo-com-9-2.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-509">Checkout</div>
                  </div>

                  <div className="frame-1022">
                    <img
                      className="img-55"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-509">Emails</div>
                  </div>

                  <div className="frame-1022">
                    <img
                      className="img-55"
                      alt="Flow parallel"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/flow-parallel-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/flow-parallel-svgrepo-com-11.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-509">Workflows</div>
                  </div>

                  <div className="frame-1022">
                    <img
                      className="img-55"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-2.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-22.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-509">Sales</div>
                  </div>

                  <div className="frame-1022">
                    <img
                      className="img-55"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-509">Analytics</div>
                  </div>

                  <div className="frame-1022">
                    <img
                      className="img-55"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-2.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-23.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-509">Payouts</div>
                  </div>

                  <div className="frame-1022">
                    <img
                      className="img-55"
                      alt="Book bookmark"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/book-bookmark-minimalistic-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/book-bookmark-minimalistic-svgrepo-com-11.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-509">Library</div>
                  </div>
                </div>

                <div className="frame-1022">
                  <img
                    className="img-55"
                    alt="Settings svgrepo com"
                    src={
                      screenWidth >= 1200 && screenWidth < 1440
                        ? "/img/settings-svgrepo-com-1.svg"
                        : screenWidth >= 1440
                          ? "/img/settings-svgrepo-com-11.svg"
                          : undefined
                    }
                  />

                  <div className="text-wrapper-509">Settings</div>
                </div>

                <div className="frame-1022">
                  <img
                    className="img-55"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-9.svg"
                  />

                  <div className="text-wrapper-509">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-1023">
            <div className="frame-1024">
              <div className="frame-1025">
                <div className="frame-1026">
                  <div className="text-wrapper-510">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-1027">
                <div className="text-wrapper-511">Login</div>
              </div>

              <div className="frame-1028">
                <div className="text-wrapper-512">Sign Up</div>
              </div>
            </div>

            <div className="frame-1029">
              <div className="div-14">
                <div className="frame-1030">
                  <div className="frame-1031">
                    <div className="frame-1030">
                      <div className="back-icon-button-44">
                        <div className="vuesax-outline-arrow-25" />
                      </div>

                      <div className="text-wrapper-513">
                        Trader status declaration
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="frame-1032">
                <div className="frame-1033">
                  <div className="frame-1034">
                    <div className="div-14">
                      <div className="frame-1008">
                        <p className="text-wrapper-514">Yes, I am a Trader</p>

                        <div className="default-circle-10" />
                      </div>
                    </div>

                    <div className="div-14">
                      <div className="text-wrapper-515">
                        Select this if you:
                      </div>

                      <div
                        className="frame-1035"
                        style={{
                          alignSelf:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "stretch"
                              : undefined,
                          display:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "flex"
                              : screenWidth >= 1440
                                ? "inline-flex"
                                : undefined,
                          width:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "100%"
                              : undefined,
                        }}
                      >
                        <div className="frame-1008">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-16.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-516"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>

                        <div className="frame-1008">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-16.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-517"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>

                        <div className="frame-1008">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-16.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-518"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>

                        <div className="frame-1008">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-16.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-519"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-1036">
                    <div className="div-14">
                      <div className="frame-1008">
                        <p className="text-wrapper-514">
                          No, I am&nbsp;&nbsp;not a Trader
                        </p>

                        <div className="default-circle-10" />
                      </div>
                    </div>

                    <div className="div-14">
                      <div className="div-14">
                        <div className="frame-1037">
                          <div className="text-wrapper-520">
                            Select this if you:
                          </div>
                        </div>
                      </div>

                      <div
                        className="frame-1038"
                        style={{
                          alignSelf:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "stretch"
                              : undefined,
                          display:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "flex"
                              : screenWidth >= 1440
                                ? "inline-flex"
                                : undefined,
                          width:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "100%"
                              : undefined,
                        }}
                      >
                        <div className="frame-1008">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-20.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com-4.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-521"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>

                        <div className="frame-1008">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-20.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com-4.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-522"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>

                        <div className="frame-1008">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-20.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com-4.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-523"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>

                        <div className="frame-1008">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-20.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com-4.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-524"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="div-14">
                  <div className="frame-1010">
                    <div className="default-circle-11" />

                    <input
                      className="i-the-undersigned"
                      placeholder="I, the undersigned, hereby declare my status as a Trader under [specify the relevant tax laws or criteria in your jurisdiction, such as IRS guidelines for U.S. traders or local tax authority]. I acknowledge the following I am engaged in the business of buying and selling securities, commodities, or other financial instruments as a regular part of my business activities.My trading activities are substantial, frequent, and carried out with the intent of generating income from short-term price movements.&lt;br/&gt;&lt;br/&gt;I understand that as a trader, I am not considered an investor, and I may be subject to different tax treatments, including the reporting of gains and losses under Mark-to-Market rules (if applicable), and/or other tax regulations specific to traders."
                      type="number"
                    />
                  </div>
                </div>

                <div className="frame-1011">
                  <div className="input-65">
                    <div
                      className="frame-1039"
                      style={{
                        alignSelf:
                          screenWidth >= 1200 && screenWidth < 1440
                            ? "stretch"
                            : undefined,
                        display:
                          screenWidth >= 1200 && screenWidth < 1440
                            ? "flex"
                            : screenWidth >= 1440
                              ? "inline-flex"
                              : undefined,
                        marginRight:
                          screenWidth >= 1440 ? "-28.00px" : undefined,
                        width:
                          screenWidth >= 1200 && screenWidth < 1440
                            ? "100%"
                            : undefined,
                      }}
                    >
                      <div className="check-svgrepo-com">
                        <div className="layer-5">
                          <img
                            className="icons-5"
                            alt="Icons"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/icons-q2-2.png"
                                : screenWidth >= 1440
                                  ? "/img/icons-q2.png"
                                  : undefined
                            }
                          />
                        </div>
                      </div>

                      <p
                        className="by-confirming-your-2"
                        style={{
                          width:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "785px"
                              : screenWidth >= 1440
                                ? "1071px"
                                : undefined,
                        }}
                      >
                        By Confirming your status you declare that
                        your&nbsp;&nbsp;selection accurately reflects your
                        trader status on Gumroad Market and understand how this
                        affects the visibility of your author information.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="CTA-11">
                <div className="frame-1040">
                  <div className="text-wrapper-505">Back</div>
                </div>

                <div className="frame-1041">
                  <div className="text-wrapper-506">Done</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
