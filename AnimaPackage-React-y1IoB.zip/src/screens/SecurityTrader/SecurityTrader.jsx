import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal24 } from "../../icons/SearchNormal24";
import "./style.css";

export const SecurityTrader = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-trader"
      style={{
        alignItems:
          screenWidth < 1200
            ? "center"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1200
            ? "#ffffff"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection: screenWidth < 1200 ? "column" : undefined,
        gap:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
        minHeight:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "1022px"
            : undefined,
        minWidth:
          screenWidth < 1200
            ? "320px"
            : screenWidth >= 1200 && screenWidth < 1440
              ? "1200px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
        width:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "100%"
            : undefined,
      }}
    >
      {screenWidth < 1200 && (
        <>
          <StatusBar
            batteryClassName="status-bar-10"
            className="status-bar-8"
            combinedShape="/img/combined-shape-18.svg"
            containerClassName="status-bar-9"
            property1="dark"
            wiFi="/img/wi-fi-18.svg"
          />
          <div className="frame-259">
            <div className="back-icon-button-6">
              <div className="vuesax-outline-arrow-7" />
            </div>

            <div className="frame-260">
              <div className="text-wrapper-184">Trader Status Declaration</div>
            </div>
          </div>

          <div className="frame-261">
            <div className="frame-262">
              <div className="div-6">
                <div className="frame-263">
                  <p className="text-wrapper-185">Yes, I am a Trader</p>

                  <div className="default-circle-3" />
                </div>
              </div>

              <div className="frame-264">
                <div className="text-wrapper-186">Select this if you:</div>

                <div className="frame-264">
                  <div className="frame-263">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-8.svg"
                    />

                    <p className="text-wrapper-187">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>

                  <div className="frame-263">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-9.svg"
                    />

                    <p className="text-wrapper-187">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>

                  <div className="frame-263">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-10.svg"
                    />

                    <p className="text-wrapper-187">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>

                  <div className="frame-263">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-11.svg"
                    />

                    <p className="text-wrapper-187">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-262">
              <div className="div-6">
                <div className="frame-263">
                  <p className="text-wrapper-185">
                    No, I am&nbsp;&nbsp;not a Trader
                  </p>

                  <div className="default-circle-3" />
                </div>
              </div>

              <div className="frame-264">
                <div className="text-wrapper-186">Select this if you:</div>

                <div className="frame-264">
                  <div className="frame-263">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-12.svg"
                    />

                    <p className="text-wrapper-187">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>

                  <div className="frame-263">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-13.svg"
                    />

                    <p className="text-wrapper-187">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>

                  <div className="frame-263">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-14.svg"
                    />

                    <p className="text-wrapper-187">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>

                  <div className="frame-263">
                    <img
                      className="check-svgrepo-com"
                      alt="Check svgrepo com"
                      src="/img/check-svgrepo-com-15.svg"
                    />

                    <p className="text-wrapper-187">
                      Regularly create and sell digital assets as a business
                      activity
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="div-6">
              <div className="frame-265">
                <div className="default-circle-4" />

                <input
                  className="i-the-undersigned"
                  placeholder="I, the undersigned, hereby declare my status as a Trader under [specify the relevant tax laws or criteria in your jurisdiction, such as IRS guidelines for U.S. traders or local tax authority]. I acknowledge the following I am engaged in the business of buying and selling securities, commodities, or other financial instruments as a regular part of my business activities.My trading activities are substantial, frequent, and carried out with the intent of generating income from short-term price movements.&lt;br/&gt;&lt;br/&gt;I understand that as a trader, I am not considered an investor, and I may be subject to different tax treatments, including the reporting of gains and losses under Mark-to-Market rules (if applicable), and/or other tax regulations specific to traders."
                  type="number"
                />
              </div>
            </div>

            <div className="input-wrapper">
              <div className="input-42">
                <div className="frame-265">
                  <div className="check-svgrepo-com">
                    <div className="layer">
                      <img
                        className="icons"
                        alt="Icons"
                        src="/img/icons-q2-1.png"
                      />
                    </div>
                  </div>

                  <p className="by-confirming-your">
                    By Confirming your status you declare that
                    your&nbsp;&nbsp;selection accurately reflects your trader
                    status on Gumroad Market and understand how this affects the
                    visibility of your author information.
                  </p>
                </div>
              </div>
            </div>

            <div className="CTA-2">
              <div className="frame-266">
                <div className="text-wrapper-188">Cancel</div>
              </div>

              <div className="frame-267">
                <div className="text-wrapper-189">Next</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-7"
            lineClassName="home-indicator-8"
            property1="dark"
          />
        </>
      )}

      {((screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440) && (
        <div className="frame-268">
          <div className="frame-269">
            <div className="frame-270">
              <div className="frame-271">
                <div className="frame-272">
                  <div className="frame-273">
                    <div className="text-wrapper-190">LOGO</div>
                  </div>
                </div>

                <div className="frame-274">
                  <div className="frame-275">
                    <img
                      className="img-16"
                      alt="Home angle svgrepo"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/home-angle-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/home-angle-svgrepo-com-19.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-191">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-270">
                <div className="frame-270">
                  <div className="frame-276">
                    <div className="img-16">
                      <div className="vuesax-linear-gift-5">
                        <img
                          className="gift-7"
                          alt="Gift"
                          src={
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "/img/gift-1.png"
                              : screenWidth >= 1440
                                ? "/img/gift-11.png"
                                : undefined
                          }
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-192">Products</div>
                  </div>

                  <div className="frame-276">
                    <img
                      className="img-16"
                      alt="Users group two"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/users-group-two-rounded-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/users-group-two-rounded-svgrepo-com-11.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-192">Collaborators</div>
                  </div>

                  <div className="frame-276">
                    <img
                      className="img-16"
                      alt="Cart svgrepo com"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/cart-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/cart-svgrepo-com-4.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-192">Checkout</div>
                  </div>

                  <div className="frame-276">
                    <img
                      className="img-16"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-192">Emails</div>
                  </div>

                  <div className="frame-276">
                    <img
                      className="img-16"
                      alt="Flow parallel"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/flow-parallel-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/flow-parallel-svgrepo-com-11.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-192">Workflows</div>
                  </div>

                  <div className="frame-276">
                    <img
                      className="img-16"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-2.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-22.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-192">Sales</div>
                  </div>

                  <div className="frame-276">
                    <img
                      className="img-16"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-192">Analytics</div>
                  </div>

                  <div className="frame-276">
                    <img
                      className="img-16"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-2.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-23.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-192">Payouts</div>
                  </div>

                  <div className="frame-276">
                    <img
                      className="img-16"
                      alt="Book bookmark"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/book-bookmark-minimalistic-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/book-bookmark-minimalistic-svgrepo-com-11.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-192">Library</div>
                  </div>
                </div>

                <div className="frame-276">
                  <img
                    className="img-16"
                    alt="Settings svgrepo com"
                    src={
                      screenWidth >= 1200 && screenWidth < 1440
                        ? "/img/settings-svgrepo-com-1.svg"
                        : screenWidth >= 1440
                          ? "/img/settings-svgrepo-com-11.svg"
                          : undefined
                    }
                  />

                  <div className="text-wrapper-192">Settings</div>
                </div>

                <div className="frame-276">
                  <img
                    className="img-16"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-192">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-277">
            <div className="frame-278">
              <div className="frame-279">
                <div className="frame-280">
                  <div className="text-wrapper-193">Search</div>

                  <SearchNormal24
                    className="check-svgrepo-com"
                    color="#232323"
                  />
                </div>
              </div>

              <div className="frame-281">
                <div className="text-wrapper-194">Login</div>
              </div>

              <div className="frame-282">
                <div className="text-wrapper-195">Sign Up</div>
              </div>
            </div>

            <div className="frame-283">
              <div className="div-6">
                <div className="frame-284">
                  <div className="frame-285">
                    <div className="frame-284">
                      <div className="back-icon-button-6">
                        <div className="vuesax-outline-arrow-7" />
                      </div>

                      <div className="text-wrapper-196">
                        Trader status declaration
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="frame-286">
                <div className="frame-287">
                  <div className="frame-288">
                    <div className="div-6">
                      <div className="frame-263">
                        <p className="text-wrapper-197">Yes, I am a Trader</p>

                        <div className="default-circle-3" />
                      </div>
                    </div>

                    <div className="div-6">
                      <div className="text-wrapper-198">
                        Select this if you:
                      </div>

                      <div
                        className="frame-289"
                        style={{
                          alignSelf:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "stretch"
                              : undefined,
                          display:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "flex"
                              : screenWidth >= 1440
                                ? "inline-flex"
                                : undefined,
                          width:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "100%"
                              : undefined,
                        }}
                      >
                        <div className="frame-263">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-16.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-199"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>

                        <div className="frame-263">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-16.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-200"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>

                        <div className="frame-263">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-16.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-201"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>

                        <div className="frame-263">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-16.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-202"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-290">
                    <div className="div-6">
                      <div className="frame-263">
                        <p className="text-wrapper-197">
                          No, I am&nbsp;&nbsp;not a Trader
                        </p>

                        <div className="default-circle-3" />
                      </div>
                    </div>

                    <div className="div-6">
                      <div className="div-6">
                        <div className="frame-291">
                          <div className="text-wrapper-203">
                            Select this if you:
                          </div>
                        </div>
                      </div>

                      <div
                        className="frame-292"
                        style={{
                          alignSelf:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "stretch"
                              : undefined,
                          display:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "flex"
                              : screenWidth >= 1440
                                ? "inline-flex"
                                : undefined,
                          width:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "100%"
                              : undefined,
                        }}
                      >
                        <div className="frame-263">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-20.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com-4.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-204"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>

                        <div className="frame-263">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-20.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com-4.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-205"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>

                        <div className="frame-263">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-20.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com-4.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-206"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>

                        <div className="frame-263">
                          <img
                            className="check-svgrepo-com"
                            alt="Check svgrepo com"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/check-svgrepo-com-20.svg"
                                : screenWidth >= 1440
                                  ? "/img/check-svgrepo-com-4.svg"
                                  : undefined
                            }
                          />

                          <p
                            className="text-wrapper-207"
                            style={{
                              flex:
                                screenWidth >= 1200 && screenWidth < 1440
                                  ? "1"
                                  : undefined,
                              width:
                                screenWidth >= 1440 ? "fit-content" : undefined,
                            }}
                          >
                            Regularly create and sell digital assets as a
                            business activity
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="div-6">
                  <div className="frame-265">
                    <div className="default-circle-4" />

                    <input
                      className="i-the-undersigned"
                      placeholder="I, the undersigned, hereby declare my status as a Trader under [specify the relevant tax laws or criteria in your jurisdiction, such as IRS guidelines for U.S. traders or local tax authority]. I acknowledge the following I am engaged in the business of buying and selling securities, commodities, or other financial instruments as a regular part of my business activities.My trading activities are substantial, frequent, and carried out with the intent of generating income from short-term price movements.&lt;br/&gt;&lt;br/&gt;I understand that as a trader, I am not considered an investor, and I may be subject to different tax treatments, including the reporting of gains and losses under Mark-to-Market rules (if applicable), and/or other tax regulations specific to traders."
                      type="number"
                    />
                  </div>
                </div>

                <div className="input-wrapper">
                  <div className="input-42">
                    <div
                      className="frame-293"
                      style={{
                        alignSelf:
                          screenWidth >= 1200 && screenWidth < 1440
                            ? "stretch"
                            : undefined,
                        display:
                          screenWidth >= 1200 && screenWidth < 1440
                            ? "flex"
                            : screenWidth >= 1440
                              ? "inline-flex"
                              : undefined,
                        marginRight:
                          screenWidth >= 1440 ? "-28.00px" : undefined,
                        width:
                          screenWidth >= 1200 && screenWidth < 1440
                            ? "100%"
                            : undefined,
                      }}
                    >
                      <div className="check-svgrepo-com">
                        <div className="layer">
                          <img
                            className="icons"
                            alt="Icons"
                            src={
                              screenWidth >= 1200 && screenWidth < 1440
                                ? "/img/icons-q2-2.png"
                                : screenWidth >= 1440
                                  ? "/img/icons-q2.png"
                                  : undefined
                            }
                          />
                        </div>
                      </div>

                      <p
                        className="by-confirming-your-2"
                        style={{
                          width:
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "785px"
                              : screenWidth >= 1440
                                ? "1071px"
                                : undefined,
                        }}
                      >
                        By Confirming your status you declare that
                        your&nbsp;&nbsp;selection accurately reflects your
                        trader status on Gumroad Market and understand how this
                        affects the visibility of your author information.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="CTA-3">
                <div className="frame-294">
                  <div className="text-wrapper-188">Back</div>
                </div>

                <div className="frame-295">
                  <div className="text-wrapper-189">Done</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
