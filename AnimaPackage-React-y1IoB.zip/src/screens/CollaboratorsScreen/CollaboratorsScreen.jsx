import React from "react";
import { SearchNormal } from "../../components/SearchNormal";
import "./style.css";

export const CollaboratorsScreen = () => {
  return (
    <div className="collaborators-screen">
      <div className="frame-956">
        <div className="frame-957">
          <div className="frame-958">
            <div className="frame-959">
              <div className="frame-960">
                <div className="frame-961">
                  <div className="text-wrapper-476">LOGO</div>
                </div>
              </div>

              <div className="frame-962">
                <div className="frame-963">
                  <img
                    className="img-53"
                    alt="Home angle svgrepo"
                    src="/img/home-angle-svgrepo-com-10.svg"
                  />

                  <div className="text-wrapper-477">Home</div>
                </div>
              </div>
            </div>

            <div className="frame-958">
              <div className="frame-958">
                <div className="frame-964">
                  <div className="img-53">
                    <div className="vuesax-linear-gift-20">
                      <img
                        className="gift-30"
                        alt="Gift"
                        src="/img/gift-9.png"
                      />
                    </div>
                  </div>

                  <div className="text-wrapper-478">Products</div>
                </div>

                <div className="frame-964">
                  <img
                    className="img-53"
                    alt="Users group two"
                    src="/img/users-group-two-rounded-svgrepo-com-6-2.svg"
                  />

                  <div className="text-wrapper-478">Collaborators</div>
                </div>

                <div className="frame-964">
                  <img
                    className="img-53"
                    alt="Cart svgrepo com"
                    src="/img/cart-svgrepo-com-6-3.svg"
                  />

                  <div className="text-wrapper-478">Checkout</div>
                </div>

                <div className="frame-964">
                  <img
                    className="img-53"
                    alt="Email envelope"
                    src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                  />

                  <div className="text-wrapper-478">Emails</div>
                </div>

                <div className="frame-964">
                  <img
                    className="img-53"
                    alt="Flow parallel"
                    src="/img/flow-parallel-svgrepo-com-6-2.svg"
                  />

                  <div className="text-wrapper-478">Workflows</div>
                </div>

                <div className="frame-964">
                  <img
                    className="img-53"
                    alt="Money dollars"
                    src="/img/money-dollars-svgrepo-com-12-2.svg"
                  />

                  <div className="text-wrapper-478">Sales</div>
                </div>

                <div className="frame-964">
                  <img
                    className="img-53"
                    alt="Chart waterfall"
                    src="/img/chart-waterfall-svgrepo-com-9.svg"
                  />

                  <div className="text-wrapper-478">Analytics</div>
                </div>

                <div className="frame-964">
                  <img
                    className="img-53"
                    alt="Money dollars"
                    src="/img/money-dollars-svgrepo-com-12-2.svg"
                  />

                  <div className="text-wrapper-478">Payouts</div>
                </div>

                <div className="frame-964">
                  <img
                    className="img-53"
                    alt="Book bookmark"
                    src="/img/book-bookmark-minimalistic-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-478">Library</div>
                </div>
              </div>

              <div className="frame-964">
                <img
                  className="img-53"
                  alt="Settings svgrepo com"
                  src="/img/settings-svgrepo-com-6.svg"
                />

                <div className="text-wrapper-478">Settings</div>
              </div>

              <div className="frame-964">
                <img
                  className="img-53"
                  alt="Book open svgrepo"
                  src="/img/book-open-svgrepo-com-6.svg"
                />

                <div className="text-wrapper-478">Help</div>
              </div>
            </div>
          </div>
        </div>

        <div className="frame-965">
          <div className="frame-966">
            <div className="frame-967">
              <div className="frame-968">
                <div className="text-wrapper-479">Search</div>

                <SearchNormal property1="linear" />
              </div>
            </div>

            <div className="frame-969">
              <div className="text-wrapper-480">Login</div>
            </div>

            <div className="frame-970">
              <div className="text-wrapper-481">Sign Up</div>
            </div>
          </div>

          <div className="frame-971">
            <div className="frame-972">
              <div className="back-icon-button-41">
                <div className="vuesax-outline-arrow-23" />
              </div>

              <div className="frame-973">
                <div className="text-wrapper-482">Products</div>

                <div className="text-wrapper-483">9 Products</div>
              </div>
            </div>

            <div className="frame-974">
              <div className="frame-975">
                <div className="text-wrapper-484">Products</div>

                <img
                  className="vector-158"
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>

              <div className="frame-975">
                <div className="text-wrapper-485">Collaborators</div>

                <img
                  className="vector-159"
                  alt="Vector"
                  src="/img/vector-1-19-3.svg"
                />
              </div>

              <div className="frame-975">
                <div className="text-wrapper-484">Reviews</div>

                <img
                  className="vector-160"
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>
            </div>

            <div className="frame-976">
              <div className="group-147">
                <div className="back-icon-button-42">
                  <img
                    className="plus-large-svgrepo"
                    alt="Plus large svgrepo"
                    src="/img/plus-large-svgrepo-com-6.svg"
                  />
                </div>
              </div>

              <div className="frame-977">
                <div className="text-wrapper-486">Add Collaborators</div>

                <p className="text-wrapper-487">
                  Selling digital products is even better with a team! Invite
                  collaborators to help you manage, create, and sell your
                  landing pages, templates, or digital assets effortlessly.
                </p>
              </div>

              <div className="frame-969">
                <div className="text-wrapper-488">Add Collaborators</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
