import React from "react";
import { SearchNormal24 } from "../../icons/SearchNormal24";
import "./style.css";

export const CollaboratorsScreen = () => {
  return (
    <div className="collaborators-screen">
      <div className="frame-211">
        <div className="frame-212">
          <div className="frame-213">
            <div className="frame-214">
              <div className="frame-215">
                <div className="frame-216">
                  <div className="text-wrapper-159">LOGO</div>
                </div>
              </div>

              <div className="frame-217">
                <div className="frame-218">
                  <img
                    className="img-14"
                    alt="Home angle svgrepo"
                    src="/img/home-angle-svgrepo-com-10.svg"
                  />

                  <div className="text-wrapper-160">Home</div>
                </div>
              </div>
            </div>

            <div className="frame-213">
              <div className="frame-213">
                <div className="frame-219">
                  <div className="img-14">
                    <div className="vuesax-linear-gift-3">
                      <img className="gift-5" alt="Gift" src="/img/gift.png" />
                    </div>
                  </div>

                  <div className="text-wrapper-161">Products</div>
                </div>

                <div className="frame-219">
                  <img
                    className="img-14"
                    alt="Users group two"
                    src="/img/users-group-two-rounded-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-161">Collaborators</div>
                </div>

                <div className="frame-219">
                  <img
                    className="img-14"
                    alt="Cart svgrepo com"
                    src="/img/cart-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-161">Checkout</div>
                </div>

                <div className="frame-219">
                  <img
                    className="img-14"
                    alt="Email envelope"
                    src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-161">Emails</div>
                </div>

                <div className="frame-219">
                  <img
                    className="img-14"
                    alt="Flow parallel"
                    src="/img/flow-parallel-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-161">Workflows</div>
                </div>

                <div className="frame-219">
                  <img
                    className="img-14"
                    alt="Money dollars"
                    src="/img/money-dollars-svgrepo-com-12.svg"
                  />

                  <div className="text-wrapper-161">Sales</div>
                </div>

                <div className="frame-219">
                  <img
                    className="img-14"
                    alt="Chart waterfall"
                    src="/img/chart-waterfall-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-161">Analytics</div>
                </div>

                <div className="frame-219">
                  <img
                    className="img-14"
                    alt="Money dollars"
                    src="/img/money-dollars-svgrepo-com-12.svg"
                  />

                  <div className="text-wrapper-161">Payouts</div>
                </div>

                <div className="frame-219">
                  <img
                    className="img-14"
                    alt="Book bookmark"
                    src="/img/book-bookmark-minimalistic-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-161">Library</div>
                </div>
              </div>

              <div className="frame-219">
                <img
                  className="img-14"
                  alt="Settings svgrepo com"
                  src="/img/settings-svgrepo-com-6.svg"
                />

                <div className="text-wrapper-161">Settings</div>
              </div>

              <div className="frame-219">
                <img
                  className="img-14"
                  alt="Book open svgrepo"
                  src="/img/book-open-svgrepo-com-6.svg"
                />

                <div className="text-wrapper-161">Help</div>
              </div>
            </div>
          </div>
        </div>

        <div className="frame-220">
          <div className="frame-221">
            <div className="frame-222">
              <div className="frame-223">
                <div className="text-wrapper-162">Search</div>

                <SearchNormal24 className="search-normal-5" color="#232323" />
              </div>
            </div>

            <div className="frame-224">
              <div className="text-wrapper-163">Login</div>
            </div>

            <div className="frame-225">
              <div className="text-wrapper-164">Sign Up</div>
            </div>
          </div>

          <div className="frame-226">
            <div className="frame-227">
              <div className="back-icon-button-4">
                <div className="vuesax-outline-arrow-5" />
              </div>

              <div className="frame-228">
                <div className="text-wrapper-165">Products</div>

                <div className="text-wrapper-166">9 Products</div>
              </div>
            </div>

            <div className="frame-229">
              <div className="frame-230">
                <div className="text-wrapper-167">Products</div>

                <img
                  className="vector-16"
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>

              <div className="frame-230">
                <div className="text-wrapper-168">Collaborators</div>

                <img
                  className="vector-17"
                  alt="Vector"
                  src="/img/vector-1-19.svg"
                />
              </div>

              <div className="frame-230">
                <div className="text-wrapper-167">Reviews</div>

                <img
                  className="vector-18"
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>
            </div>

            <div className="frame-231">
              <div className="group">
                <div className="plus-large-svgrepo-wrapper">
                  <img
                    className="plus-large-svgrepo"
                    alt="Plus large svgrepo"
                    src="/img/plus-large-svgrepo-com-6.svg"
                  />
                </div>
              </div>

              <div className="frame-232">
                <div className="text-wrapper-169">Add Collaborators</div>

                <p className="text-wrapper-170">
                  Selling digital products is even better with a team! Invite
                  collaborators to help you manage, create, and sell your
                  landing pages, templates, or digital assets effortlessly.
                </p>
              </div>

              <div className="frame-224">
                <div className="text-wrapper-171">Add Collaborators</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
