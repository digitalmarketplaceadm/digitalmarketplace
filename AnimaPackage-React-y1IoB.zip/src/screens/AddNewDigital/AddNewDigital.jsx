import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal38 } from "../../icons/SearchNormal38";
import "./style.css";

export const AddNewDigital = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="add-new-digital"
      style={{
        alignItems:
          screenWidth < 1440
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1440
            ? "var(--variable-collection-white-duplicate)"
            : screenWidth >= 1440
              ? "var(--variable-collection-fill-duplicate)"
              : undefined,
        flexDirection: screenWidth < 1440 ? "column" : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "1236px" : undefined,
        minWidth:
          screenWidth < 1440
            ? "320px"
            : screenWidth >= 1440
              ? "1440px"
              : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {screenWidth < 1440 && (
        <>
          <StatusBar
            batteryClassName="status-bar-25"
            className="status-bar-22"
            combinedShape="/img/combined-shape-20.svg"
            containerClassName="status-bar-24"
            property1="dark"
            rectangleClassName="status-bar-26"
            timeClassName="status-bar-23"
            wiFi="/img/wi-fi-2.svg"
          />
          <div className="frame-167">
            <div className="back-icon-button-10">
              <div className="vuesax-outline-arrow-6" />
            </div>

            <div className="frame-168">
              <div className="text-wrapper-90">Add New Content</div>
            </div>
          </div>

          <div className="frame-169">
            <div className="frame-170">
              <div className="input-4">
                <div className="text-wrapper-91"> Photos</div>

                <div className="frame-171">
                  <img
                    className="group-12"
                    alt="Group"
                    src="/img/group-7-2x.png"
                  />
                </div>
              </div>
            </div>

            <div className="div-3">
              <div className="text-wrapper-92">Title</div>

              <div className="enter-your-title-wrapper">
                <div className="div-4">Enter your&nbsp;&nbsp;title</div>
              </div>
            </div>

            <div className="input-5">
              <div className="text-wrapper-92">Price</div>

              <div className="input-6">
                <div className="div-4">Enter price</div>
              </div>
            </div>

            <div className="div-3">
              <div className="text-wrapper-91">Cover</div>

              <div className="frame-171">
                <img
                  className="group-12"
                  alt="Group"
                  src="/img/group-7-2x.png"
                />
              </div>
            </div>

            <div className="frame-170">
              <div className="input-4">
                <div className="text-wrapper-92">Description</div>

                <div className="your-title-wrapper">
                  <div className="your-title">Your&nbsp;&nbsp;title</div>
                </div>
              </div>
            </div>

            <div className="frame-170">
              <div className="input-4">
                <div className="text-wrapper-92">Visibility</div>

                <div className="input-wrapper">
                  <div className="input-7">
                    <div className="frame-172">
                      <div className="default-circle" />

                      <p className="div-5">
                        <span className="span">Visible</span>

                        <span className="text-wrapper-93">
                          {" "}
                          - everyone can see this content
                        </span>
                      </p>
                    </div>
                  </div>
                </div>

                <div className="frame-173">
                  <div className="input-8">
                    <div className="frame-174">
                      <div className="default-circle" />

                      <p className="div-4">
                        <span className="span">Invisible</span>

                        <span className="text-wrapper-93">
                          {" "}
                          - Nobody except you can see this content
                        </span>
                      </p>
                    </div>
                  </div>
                </div>

                <div className="frame-173">
                  <div className="input-8">
                    <div className="frame-174">
                      <div className="default-circle" />

                      <p className="div-4">
                        <span className="span">Unlisted</span>

                        <span className="text-wrapper-93">
                          {" "}
                          -&nbsp;&nbsp;Only people who know the direct link to
                          this content can see it. Won’t be listed alongside
                          other content on your store
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="CTA">
              <div className="frame-175">
                <div className="text-wrapper-94">Cancel</div>
              </div>

              <div className="frame-176">
                <div className="text-wrapper-95">Add</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-11"
            lineClassName="home-indicator-12"
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-177">
          <div className="frame-178">
            <div className="frame-179">
              <div className="frame-180">
                <div className="frame-181">
                  <div className="frame-182">
                    <div className="text-wrapper-96">LOGO</div>
                  </div>
                </div>
              </div>

              <div className="frame-179">
                <div className="frame-183">
                  <div className="frame-184">
                    <div className="div-3">
                      <div className="frame-185">
                        <img
                          className="home-svgrepo-com-2"
                          alt="Home svgrepo com"
                          src="/img/home-svgrepo-com-4.svg"
                        />

                        <div className="text-wrapper-97">Home</div>
                      </div>

                      <div className="frame-185">
                        <img
                          className="img-12"
                          alt="Security safe"
                          src="/img/security-safe-svgrepo-com-2.svg"
                        />

                        <div className="text-wrapper-98">Security</div>
                      </div>

                      <div className="frame-185">
                        <div className="img-12">
                          <div className="vuesax-linear-gift-4">
                            <img
                              className="gift-7"
                              alt="Gift"
                              src="/img/gift-6.png"
                            />
                          </div>
                        </div>

                        <div className="text-wrapper-99">Products</div>
                      </div>

                      <div className="frame-185">
                        <img
                          className="img-12"
                          alt="Advertising svgrepo"
                          src="/img/advertising-svgrepo-com-2.svg"
                        />

                        <div className="text-wrapper-98">Marketing</div>
                      </div>

                      <div className="frame-185">
                        <img
                          className="img-12"
                          alt="Cart large svgrepo"
                          src="/img/cart-large-4-svgrepo-com-2.svg"
                        />

                        <div className="text-wrapper-98">Your Store</div>
                      </div>

                      <div className="frame-185">
                        <img
                          className="img-12"
                          alt="People svgrepo com"
                          src="/img/people-svgrepo-com-4.svg"
                        />

                        <div className="text-wrapper-98">Collaborators</div>
                      </div>

                      <div className="frame-185">
                        <div className="group-13" />

                        <div className="text-wrapper-98">Checkout</div>
                      </div>

                      <div className="frame-185">
                        <div className="img-12">
                          <div className="email-svgrepo-3">
                            <div className="page-4" />
                          </div>
                        </div>

                        <div className="text-wrapper-98">Emails</div>
                      </div>

                      <div className="frame-185">
                        <img
                          className="img-12"
                          alt="Flow parallel"
                          src="/img/flow-parallel-svgrepo-com-14.svg"
                        />

                        <div className="text-wrapper-98">Workflows</div>
                      </div>

                      <div className="frame-185">
                        <img
                          className="img-12"
                          alt="Coin svgrepo com"
                          src="/img/coin-svgrepo-com-9.svg"
                        />

                        <div className="text-wrapper-98">Sales</div>
                      </div>

                      <div className="frame-185">
                        <img
                          className="img-12"
                          alt="Graph svgrepo com"
                          src="/img/graph-svgrepo-com.svg"
                        />

                        <div className="text-wrapper-98">Analytics</div>
                      </div>

                      <div className="frame-185">
                        <img
                          className="img-12"
                          alt="Coin svgrepo com"
                          src="/img/coin-svgrepo-com-9.svg"
                        />

                        <div className="text-wrapper-98">Payouts</div>
                      </div>

                      <div className="frame-185">
                        <img
                          className="img-12"
                          alt="Book bookmark"
                          src="/img/book-bookmark-minimalistic-svgrepo-com-14.svg"
                        />

                        <div className="text-wrapper-98">Library</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-185">
                  <img
                    className="img-12"
                    alt="Setting svgrepo"
                    src="/img/setting-2-svgrepo-com-2.svg"
                  />

                  <div className="text-wrapper-98">Settings</div>
                </div>

                <div className="frame-185">
                  <img
                    className="img-12"
                    alt="Open book svgrepo"
                    src="/img/open-book-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-98">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-186">
            <div className="frame-187">
              <div className="frame-188">
                <div className="frame-189">
                  <div className="text-wrapper-100">Real Estate</div>

                  <SearchNormal38
                    className="search-normal-38"
                    color="#292929"
                  />
                </div>
              </div>

              <div className="back-icon-button-11">
                <div className="img-12">
                  <div className="vuesax-linear-3">
                    <div className="notification-3">
                      <img
                        className="group-14"
                        alt="Group"
                        src="/img/group-33845-6.png"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="back-icon-button-11">
                <img
                  className="img-12"
                  alt="Messenger fill"
                  src="/img/messenger-fill-svgrepo-com-2-3.svg"
                />
              </div>

              <div className="frame-190">
                <div className="frame-191">
                  <img
                    className="ellipse-6"
                    alt="Ellipse"
                    src="/img/ellipse-52.png"
                  />

                  <div className="frame-192">
                    <div className="text-wrapper-101">Lenny White</div>
                  </div>
                </div>

                <img
                  className="search-normal-38"
                  alt="Expand more"
                  src="/img/expand-more-2.svg"
                />
              </div>
            </div>

            <div className="frame-193">
              <div className="frame-170">
                <div className="back-icon-button-10">
                  <div className="vuesax-outline-arrow-6" />
                </div>

                <div className="frame-194">
                  <div className="text-wrapper-102">Add New Content</div>

                  <p className="text-wrapper-103">
                    To start selling, upload your product files (max 5GB).
                  </p>
                </div>
              </div>

              <div className="frame-195">
                <div className="frame-170">
                  <div className="input-4">
                    <div className="text-wrapper-91">Product Photos</div>

                    <div className="frame-196">
                      <img
                        className="group-15"
                        alt="Group"
                        src="/img/group-5.png"
                      />

                      <div className="frame-197">
                        <p className="upload-image">
                          <span className="text-wrapper-104">
                            Upload&nbsp;&nbsp;Image
                          </span>

                          <span className="text-wrapper-105"> (0/10)</span>
                        </p>

                        <p className="text-wrapper-106">
                          Drag and drop your file here, or click to browse.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-170">
                  <div className="input-9">
                    <div className="text-wrapper-92">Title</div>

                    <div className="input-10">
                      <div className="div-4">Enter your&nbsp;&nbsp;title</div>
                    </div>
                  </div>

                  <div className="input-9">
                    <div className="text-wrapper-92">Price</div>

                    <div className="input-10">
                      <div className="div-4">Enter price</div>
                    </div>
                  </div>
                </div>

                <div className="frame-170">
                  <div className="input-4">
                    <div className="text-wrapper-91">Cover</div>

                    <div className="frame-196">
                      <img
                        className="group-15"
                        alt="Group"
                        src="/img/group-5.png"
                      />

                      <div className="frame-197">
                        <p className="upload-image">
                          <span className="text-wrapper-104">
                            Upload&nbsp;&nbsp;Image
                          </span>

                          <span className="text-wrapper-105"> (0/10)</span>
                        </p>

                        <p className="text-wrapper-106">
                          Drag and drop your file here, or click to browse.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-170">
                  <div className="input-4">
                    <div className="text-wrapper-92">Description</div>

                    <div className="input-11">
                      <div className="your-title">Your&nbsp;&nbsp;title</div>
                    </div>
                  </div>
                </div>

                <div className="frame-170">
                  <div className="input-4">
                    <div className="text-wrapper-92">Visibility</div>

                    <div className="input-wrapper">
                      <div className="input-7">
                        <div className="frame-172">
                          <div className="default-circle" />

                          <p className="div-5">
                            <span className="span">Visible</span>

                            <span className="text-wrapper-93">
                              {" "}
                              - everyone can see this Content
                            </span>
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="input-wrapper">
                      <div className="input-7">
                        <div className="frame-172">
                          <div className="default-circle" />

                          <p className="div-5">
                            <span className="span">Invisible</span>

                            <span className="text-wrapper-93">
                              {" "}
                              - Nobody except you can see this Content
                            </span>
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="input-wrapper">
                      <div className="input-7">
                        <div className="frame-172">
                          <div className="default-circle" />

                          <p className="div-5">
                            <span className="span">Unlisted</span>

                            <span className="text-wrapper-93">
                              {" "}
                              -&nbsp;&nbsp;Only people who know the direct link
                              to this Content can see it. Won’t be listed
                              alongside other Content on your store
                            </span>
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="CTA-2">
                <div className="frame-198">
                  <div className="text-wrapper-94">Cancel</div>
                </div>

                <div className="frame-199">
                  <div className="text-wrapper-95">Add Product</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
