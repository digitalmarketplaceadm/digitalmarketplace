export { AddNewDigital } from "./AddNewDigital";
