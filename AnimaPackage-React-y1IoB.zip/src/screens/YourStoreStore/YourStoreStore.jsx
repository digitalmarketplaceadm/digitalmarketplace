import React from "react";
import { SearchNormal38 } from "../../icons/SearchNormal38";
import "./style.css";

export const YourStoreStore = () => {
  return (
    <div className="your-store-store">
      <div className="frame-390">
        <div className="frame-391">
          <div className="frame-392">
            <div className="frame-393">
              <div className="frame-394">
                <div className="frame-395">
                  <div className="text-wrapper-193">LOGO</div>
                </div>
              </div>
            </div>

            <div className="frame-392">
              <div className="frame-392">
                <div className="frame-396">
                  <div className="frame-397">
                    <img
                      className="home-svgrepo-com-5"
                      alt="Home svgrepo com"
                      src="/img/home-svgrepo-com-7-2.svg"
                    />

                    <div className="text-wrapper-194">Home</div>
                  </div>

                  <div className="frame-397">
                    <img
                      className="img-19"
                      alt="Security safe"
                      src="/img/security-safe-svgrepo-com-2.svg"
                    />

                    <div className="text-wrapper-195">Security</div>
                  </div>

                  <div className="frame-397">
                    <div className="gift-15">
                      <div className="vuesax-linear-gift-9">
                        <img
                          className="gift-16"
                          alt="Gift"
                          src="/img/gift-16.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-195">Products</div>
                  </div>

                  <div className="frame-397">
                    <img
                      className="img-19"
                      alt="Advertising svgrepo"
                      src="/img/advertising-svgrepo-com-2.svg"
                    />

                    <div className="text-wrapper-195">Marketing</div>
                  </div>

                  <div className="frame-397">
                    <img
                      className="img-19"
                      alt="Cart large svgrepo"
                      src="/img/cart-large-4-svgrepo-com-2.svg"
                    />

                    <div className="text-wrapper-195">Your Store</div>
                  </div>

                  <div className="frame-397">
                    <img
                      className="img-19"
                      alt="People svgrepo com"
                      src="/img/people-svgrepo-com-4.svg"
                    />

                    <div className="text-wrapper-195">Collaborators</div>
                  </div>

                  <div className="frame-397">
                    <div className="group-76" />

                    <div className="text-wrapper-195">Checkout</div>
                  </div>

                  <div className="frame-397">
                    <div className="img-19">
                      <div className="email-svgrepo-8">
                        <div className="page-9" />
                      </div>
                    </div>

                    <div className="text-wrapper-195">Emails</div>
                  </div>

                  <div className="frame-397">
                    <img
                      className="img-19"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-14.svg"
                    />

                    <div className="text-wrapper-195">Workflows</div>
                  </div>

                  <div className="frame-397">
                    <img
                      className="img-19"
                      alt="Coin svgrepo com"
                      src="/img/coin-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-195">Sales</div>
                  </div>

                  <div className="frame-397">
                    <img
                      className="img-19"
                      alt="Graph svgrepo com"
                      src="/img/graph-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-195">Analytics</div>
                  </div>

                  <div className="frame-397">
                    <img
                      className="img-19"
                      alt="Coin svgrepo com"
                      src="/img/coin-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-195">Payouts</div>
                  </div>

                  <div className="frame-397">
                    <img
                      className="img-19"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-14.svg"
                    />

                    <div className="text-wrapper-195">Library</div>
                  </div>
                </div>
              </div>

              <div className="frame-397">
                <img
                  className="img-19"
                  alt="Setting svgrepo"
                  src="/img/setting-2-svgrepo-com-2.svg"
                />

                <div className="text-wrapper-195">Settings</div>
              </div>

              <div className="frame-397">
                <img
                  className="img-19"
                  alt="Open book svgrepo"
                  src="/img/open-book-svgrepo-com-6.svg"
                />

                <div className="text-wrapper-195">Help</div>
              </div>
            </div>
          </div>
        </div>

        <div className="frame-398">
          <div className="frame-399">
            <div className="frame-400">
              <div className="frame-401">
                <div className="text-wrapper-196">Real Estate</div>

                <SearchNormal38
                  className="property-1-linear-instance"
                  color="#292929"
                />
              </div>
            </div>

            <div className="back-icon-button-26">
              <div className="img-19">
                <div className="vuesax-linear-8">
                  <div className="notification-8">
                    <img
                      className="group-77"
                      alt="Group"
                      src="/img/group-33845-6.png"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="back-icon-button-26">
              <img
                className="img-19"
                alt="Messenger fill"
                src="/img/messenger-fill-svgrepo-com-6.svg"
              />
            </div>

            <div className="frame-402">
              <div className="frame-403">
                <img
                  className="ellipse-17"
                  alt="Ellipse"
                  src="/img/ellipse-52-7.png"
                />

                <div className="frame-404">
                  <div className="text-wrapper-197">Lenny White</div>
                </div>
              </div>

              <img
                className="property-1-linear-instance"
                alt="Expand more"
                src="/img/expand-more-2-2.svg"
              />
            </div>
          </div>

          <div className="frame-405">
            <div className="frame-406">
              <div className="frame-407">
                <div className="frame-408">
                  <div className="frame-409">
                    <div className="text-wrapper-198">Messages</div>

                    <div className="frame-410">
                      <div className="group-78">
                        <div className="search-normal-9">
                          <div className="vuesax-linear-search-5">
                            <div className="search-normal-10">
                              <img
                                className="group-79"
                                alt="Group"
                                src="/img/group-33839-2x.png"
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="group-78">
                        <div className="vuesax-linear-add-5" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-407">
                  <div className="text-wrapper-199">Recent</div>

                  <div className="frame-411">
                    <div className="frame-412">
                      <div className="frame-413">
                        <img
                          className="ellipse-18"
                          alt="Ellipse"
                          src="/img/ellipse-52-6.png"
                        />

                        <div className="ellipse-19" />
                      </div>

                      <div className="text-wrapper-200">Ethan</div>
                    </div>

                    <div className="frame-412">
                      <div className="frame-413">
                        <img
                          className="ellipse-18"
                          alt="Ellipse"
                          src="/img/ellipse-52-7.png"
                        />
                      </div>

                      <div className="text-wrapper-200">Lenny</div>
                    </div>

                    <div className="frame-412">
                      <div className="frame-413">
                        <img
                          className="ellipse-18"
                          alt="Ellipse"
                          src="/img/ellipse-52-8.png"
                        />
                      </div>

                      <div className="text-wrapper-200">Lucas</div>
                    </div>

                    <div className="frame-412">
                      <div className="frame-413">
                        <img
                          className="ellipse-18"
                          alt="Ellipse"
                          src="/img/ellipse-1-3-2x.png"
                        />

                        <div className="ellipse-19" />
                      </div>

                      <div className="text-wrapper-200">Lorraine</div>
                    </div>

                    <div className="frame-412">
                      <div className="frame-413">
                        <img
                          className="ellipse-20"
                          alt="Ellipse"
                          src="/img/ellipse-52-9.png"
                        />

                        <div className="ellipse-19" />
                      </div>

                      <div className="text-wrapper-200">Precious</div>
                    </div>
                  </div>

                  <div className="frame-414">
                    <div className="frame-413">
                      <img
                        className="ellipse-21"
                        alt="Ellipse"
                        src="/img/ellipse-52-6.png"
                      />

                      <div className="ellipse-22" />
                    </div>

                    <div className="frame-415">
                      <div className="text-wrapper-201">Ethan Carter</div>

                      <div className="frame-416">
                        <p className="text-wrapper-196">
                          Hi, I like your landing page
                        </p>

                        <div className="text-wrapper-202">•</div>

                        <div className="text-wrapper-203">1:12pm</div>
                      </div>
                    </div>

                    <div className="ellipse-23" />
                  </div>

                  <div className="frame-417">
                    <div className="frame-413">
                      <img
                        className="ellipse-21"
                        alt="Ellipse"
                        src="/img/ellipse-52-7.png"
                      />
                    </div>

                    <div className="frame-415">
                      <div className="text-wrapper-199">Lenny White</div>

                      <div className="frame-416">
                        <p className="text-wrapper-204">
                          you: we can talk about that
                        </p>

                        <div className="text-wrapper-202">•</div>

                        <div className="text-wrapper-203">Wed</div>
                      </div>
                    </div>

                    <img
                      className="ellipse-24"
                      alt="Ellipse"
                      src="/img/ellipse-53.png"
                    />
                  </div>

                  <div className="frame-418">
                    <div className="frame-413">
                      <img
                        className="ellipse-21"
                        alt="Ellipse"
                        src="/img/ellipse-52-8.png"
                      />
                    </div>

                    <div className="frame-415">
                      <div className="text-wrapper-199">Lucas Park</div>

                      <div className="frame-416">
                        <div className="text-wrapper-204">hello</div>

                        <div className="text-wrapper-202">•</div>

                        <div className="text-wrapper-203">Wed</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-418">
                    <div className="frame-413">
                      <div className="frame-413">
                        <img
                          className="ellipse-21"
                          alt="Ellipse"
                          src="/img/ellipse-1-3-2x.png"
                        />

                        <div className="ellipse-22" />
                      </div>
                    </div>

                    <div className="frame-415">
                      <div className="text-wrapper-199">Lorraine Lim</div>

                      <div className="frame-416">
                        <p className="text-wrapper-204">
                          I’d like you to create a website
                        </p>

                        <div className="text-wrapper-202">•</div>

                        <div className="text-wrapper-203">Wed</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-418">
                    <div className="frame-413">
                      <img
                        className="ellipse-21"
                        alt="Ellipse"
                        src="/img/ellipse-52-9.png"
                      />

                      <div className="ellipse-22" />
                    </div>

                    <div className="frame-415">
                      <div className="text-wrapper-199">Precious Bennett</div>

                      <div className="frame-416">
                        <div className="text-wrapper-204">
                          I need b2b website
                        </div>

                        <div className="text-wrapper-202">•</div>

                        <div className="text-wrapper-203">Tue</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-418">
                    <div className="frame-413">
                      <img
                        className="ellipse-21"
                        alt="Ellipse"
                        src="/img/ellipse-1.png"
                      />

                      <div className="ellipse-22" />
                    </div>

                    <div className="frame-415">
                      <div className="text-wrapper-199">Caleb Monroe</div>

                      <div className="frame-416">
                        <div className="text-wrapper-204">I like it!</div>

                        <div className="text-wrapper-202">•</div>

                        <div className="text-wrapper-203">Tue</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-418">
                    <div className="frame-413">
                      <img
                        className="ellipse-21"
                        alt="Ellipse"
                        src="/img/ellipse-1-1-2x.png"
                      />

                      <div className="ellipse-22" />
                    </div>

                    <div className="frame-415">
                      <div className="text-wrapper-199">Aria Morgan</div>

                      <div className="frame-416">
                        <p className="text-wrapper-204">
                          perfect, this is what&nbsp;&nbsp;I want!
                        </p>

                        <div className="text-wrapper-202">•</div>

                        <div className="text-wrapper-203">Tue</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-418">
                    <div className="frame-413">
                      <img
                        className="ellipse-21"
                        alt="Ellipse"
                        src="/img/ellipse-1-2-2x.png"
                      />

                      <div className="ellipse-22" />
                    </div>

                    <div className="frame-415">
                      <div className="text-wrapper-199">Sienna Blake</div>

                      <div className="frame-416">
                        <div className="text-wrapper-204">Excellent!</div>

                        <div className="text-wrapper-202">•</div>

                        <div className="text-wrapper-203">Tue</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-417">
                    <div className="frame-413">
                      <img
                        className="ellipse-21"
                        alt="Ellipse"
                        src="/img/ellipse-52-2.png"
                      />

                      <div className="ellipse-22" />
                    </div>

                    <div className="frame-415">
                      <div className="text-wrapper-199">Noah Sinclair</div>

                      <div className="frame-416">
                        <p className="text-wrapper-204">
                          you: okay this is noted
                        </p>

                        <div className="text-wrapper-202">•</div>

                        <div className="text-wrapper-203">Tue</div>
                      </div>
                    </div>

                    <img
                      className="ellipse-24"
                      alt="Ellipse"
                      src="/img/ellipse-53-1.png"
                    />
                  </div>

                  <div className="frame-418">
                    <div className="frame-413">
                      <img
                        className="ellipse-21"
                        alt="Ellipse"
                        src="/img/ellipse-52-3.png"
                      />
                    </div>

                    <div className="frame-415">
                      <div className="text-wrapper-199">Leo Donovan</div>

                      <div className="frame-416">
                        <div className="text-wrapper-204">love it</div>

                        <div className="text-wrapper-202">•</div>

                        <div className="text-wrapper-203">Tue</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-417">
                    <div className="frame-413">
                      <img
                        className="ellipse-21"
                        alt="Ellipse"
                        src="/img/ellipse-52-4.png"
                      />

                      <div className="ellipse-19" />
                    </div>

                    <div className="frame-415">
                      <div className="text-wrapper-199">Sienna Blake</div>

                      <div className="frame-416">
                        <div className="text-wrapper-204">no</div>

                        <div className="text-wrapper-202">•</div>

                        <div className="text-wrapper-203">Tue</div>
                      </div>
                    </div>

                    <img
                      className="ellipse-24"
                      alt="Ellipse"
                      src="/img/ellipse-53-2.png"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-419">
              <div className="frame-420">
                <img
                  className="ellipse-21"
                  alt="Ellipse"
                  src="/img/ellipse-52-5.png"
                />

                <div className="frame-421">
                  <div className="text-wrapper-205">Alexander Johnson</div>

                  <div className="frame-422">
                    <div className="ellipse-25" />

                    <div className="text-wrapper-206">Online</div>
                  </div>
                </div>
              </div>

              <div className="image-24">
                <div className="frame-423">
                  <div className="text-wrapper-207">Yesterday</div>

                  <div className="frame-424">
                    <img
                      className="ellipse-21"
                      alt="Ellipse"
                      src="/img/ellipse-52-6.png"
                    />

                    <div className="frame-425">
                      <div className="frame-426">
                        <p className="text-wrapper-204">
                          I have a big project in mind.
                        </p>
                      </div>

                      <div className="text-wrapper-208">1:05pm</div>
                    </div>
                  </div>

                  <div className="frame-427">
                    <div className="frame-428">
                      <div className="text-wrapper-209">that sounds great!</div>
                    </div>

                    <div className="text-wrapper-210">1:02pm</div>
                  </div>

                  <div className="frame-427">
                    <div className="frame-428">
                      <div className="text-wrapper-209">that sounds great!</div>
                    </div>

                    <div className="frame-428">
                      <p className="text-wrapper-209">
                        let me know what’s in your mind
                      </p>
                    </div>

                    <div className="text-wrapper-210">1:02pm</div>
                  </div>

                  <div className="frame-424">
                    <img
                      className="ellipse-21"
                      alt="Ellipse"
                      src="/img/ellipse-52-6.png"
                    />

                    <div className="frame-425">
                      <div className="frame-426">
                        <p className="text-wrapper-204">
                          I’d like to have a booking website
                        </p>
                      </div>

                      <div className="frame-429">
                        <div className="text-wrapper-204">
                          similar to AirBnB
                        </div>
                      </div>

                      <div className="text-wrapper-211">1:05pm</div>
                    </div>
                  </div>

                  <div className="frame-430">
                    <div className="frame-427">
                      <div className="frame-431">
                        <p className="text-wrapper-209">
                          great! just send me the whole documents for this
                          website
                        </p>
                      </div>
                    </div>

                    <div className="text-wrapper-210">1:02pm</div>
                  </div>

                  <div className="text-wrapper-207">Today</div>

                  <div className="frame-424">
                    <img
                      className="ellipse-21"
                      alt="Ellipse"
                      src="/img/ellipse-52-6.png"
                    />

                    <div className="frame-425">
                      <div className="frame-426">
                        <p className="text-wrapper-204">
                          I jut sent to your email , let me know if you received
                          it
                        </p>
                      </div>

                      <div className="text-wrapper-208">6:01am</div>
                    </div>
                  </div>

                  <div className="frame-427">
                    <div className="frame-427">
                      <div className="frame-428">
                        <div className="text-wrapper-209">Received!</div>
                      </div>
                    </div>

                    <div className="text-wrapper-210">1:02pm</div>
                  </div>

                  <div className="frame-424">
                    <img
                      className="ellipse-21"
                      alt="Ellipse"
                      src="/img/ellipse-52-6.png"
                    />

                    <div className="frame-425">
                      <div className="frame-426">
                        <p className="text-wrapper-204">
                          let me know if you have questions!
                        </p>
                      </div>

                      <div className="text-wrapper-211">9:01am</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="frame-432">
                <div className="frame-433">
                  <img
                    className="group-wrapper-3"
                    alt="Plus svgrepo com"
                    src="/img/plus-svgrepo-com.svg"
                  />

                  <div className="group-wrapper-3">
                    <img
                      className="group-80"
                      alt="Group"
                      src="/img/group-1272630336.png"
                    />
                  </div>

                  <div className="group-wrapper-3">
                    <img
                      className="group-81"
                      alt="Group"
                      src="/img/group-1272630337-1.png"
                    />
                  </div>

                  <div className="microphone-svgrepo-2">
                    <img
                      className="group-82"
                      alt="Group"
                      src="/img/group-289574.png"
                    />
                  </div>

                  <div className="frame-434">
                    <div className="text-wrapper-212">Hi I saw som.</div>

                    <img
                      className="vector-53"
                      alt="Vector"
                      src="/img/vector-92.svg"
                    />
                  </div>

                  <div className="group-83">
                    <img
                      className="vector-54"
                      alt="Vector"
                      src="/img/vector-93.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
