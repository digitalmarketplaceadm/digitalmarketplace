import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal38 } from "../../icons/SearchNormal38";
import "./style.css";

export const ChannelReviews = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="channel-reviews"
      style={{
        alignItems:
          screenWidth < 1440
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1440
            ? "var(--variable-collection-white-duplicate)"
            : screenWidth >= 1440
              ? "var(--variable-collection-fill-duplicate)"
              : undefined,
        flexDirection: screenWidth < 1440 ? "column" : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "100vh" : undefined,
        minWidth:
          screenWidth < 1440
            ? "320px"
            : screenWidth >= 1440
              ? "1440px"
              : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
      }}
    >
      {screenWidth < 1440 && (
        <>
          <StatusBar
            actionClassName="status-bar-16"
            batteryClassName="status-bar-20"
            className="status-bar-17"
            combinedShape="/img/combined-shape-20.svg"
            containerClassName="status-bar-19"
            property1="dark"
            rectangleClassName="status-bar-21"
            timeClassName="status-bar-18"
            wiFi="/img/wi-fi-2.svg"
          />
          <div className="frame-69">
            <div className="back-icon-button-5">
              <div className="vuesax-outline-arrow-3" />
            </div>

            <div className="frame-70">
              <div className="text-wrapper-38">Content</div>
            </div>
          </div>

          <div className="frame-71">
            <div className="frame-72">
              <div className="frame-73">
                <div className="text-wrapper-39">Channel</div>

                <img
                  className="vector-10"
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>

              <div className="frame-73">
                <div className="text-wrapper-40">Reviews</div>

                <img
                  className="vector-11"
                  alt="Vector"
                  src="/img/vector-1-35-3.svg"
                />
              </div>
            </div>

            <div className="user-opinion">
              <div className="opinion-content">
                <div className="frame-74">
                  <div className="frame-75">
                    <img
                      className="image-7"
                      alt="Image"
                      src="/img/image-20-2x.png"
                    />

                    <div className="user-name">Aiden Harris</div>
                  </div>

                  <div className="date-of-adding">April 2, 2025</div>
                </div>

                <div className="frame-76">
                  <img
                    className="image-7"
                    alt="Image"
                    src="/img/image-21.png"
                  />

                  <div className="text-wrapper-41">
                    Real Estate Landing Page
                  </div>
                </div>

                <div className="review">
                  <div className="opinion-stars">
                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-16.svg"
                    />

                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-17-2.svg"
                    />

                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-18.svg"
                    />

                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-19-2.svg"
                    />

                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-20.svg"
                    />
                  </div>

                  <div className="average-review-value">
                    <div className="average-review-value-2">5.0</div>
                  </div>
                </div>

                <p className="p">
                  I recently used this Real Estate Landing Page template for my
                  property listings, and I couldn&#39;t be more impressed! The
                  design is sleek, modern, and highly professional, making it
                  easy for potential buyers to navigate and find the information
                  they need quickly.
                </p>
              </div>

              <div className="add-comment-and">
                <div className="likes">
                  <div className="text-button">
                    <img
                      className="img-6"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-2.svg"
                    />

                    <button className="button">114</button>
                  </div>

                  <div className="text-button">
                    <img
                      className="img-6"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-1-2.svg"
                    />

                    <button className="button">5</button>
                  </div>
                </div>
              </div>

              <div className="frame-77">
                <img
                  className="image-7"
                  alt="Image"
                  src="/img/image-25-2x.png"
                />

                <div className="frame-78">
                  <div className="frame-79">
                    <div className="text-wrapper-42">Reply</div>

                    <img
                      className="img-6"
                      alt="Send svgrepo com"
                      src="/img/send-svgrepo-com-3.svg"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="user-opinion">
              <div className="opinion-content">
                <div className="frame-80">
                  <div className="frame-81">
                    <div className="frame-82">
                      <img
                        className="image-7"
                        alt="Image"
                        src="/img/image-20-2x.png"
                      />

                      <div className="user-name">Samantha Evans</div>
                    </div>

                    <div className="average-review-value-wrapper">
                      <div className="average-review-value">
                        <div className="average-review-value-2">5.0</div>
                      </div>
                    </div>
                  </div>

                  <div className="date-of-adding-2">April 2, 2025</div>
                </div>

                <div className="frame-76">
                  <img
                    className="img-6"
                    alt="Image"
                    src="/img/image-22-2x.png"
                  />

                  <div className="text-wrapper-41">
                    Business Pro Landing Page
                  </div>
                </div>

                <div className="review">
                  <div className="opinion-stars">
                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-21.svg"
                    />

                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-22-2.svg"
                    />

                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-23.svg"
                    />

                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-24.svg"
                    />

                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-25.svg"
                    />
                  </div>

                  <div className="average-review-value">
                    <div className="average-review-value-2">5.0</div>
                  </div>
                </div>

                <p className="p">
                  The Business Pro Landing Page has completely transformed the
                  way I present my business online. It’s sleek, professional,
                  and most importantly, highly effective at converting visitors
                  into leads. This page is perfect for startups and businesses
                  looking to make a strong first impression!
                </p>
              </div>

              <div className="add-comment-and">
                <div className="likes">
                  <div className="text-button">
                    <img
                      className="img-6"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-2.svg"
                    />

                    <button className="button">114</button>
                  </div>

                  <div className="text-button">
                    <img
                      className="img-6"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-1-2.svg"
                    />

                    <button className="button">5</button>
                  </div>
                </div>
              </div>

              <div className="frame-77">
                <img
                  className="image-7"
                  alt="Image"
                  src="/img/image-25-2x.png"
                />

                <div className="frame-78">
                  <div className="frame-79">
                    <div className="text-wrapper-42">Reply</div>

                    <img
                      className="img-6"
                      alt="Send svgrepo com"
                      src="/img/send-svgrepo-com-4-2.svg"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="user-opinion">
              <div className="opinion-content">
                <div className="frame-80">
                  <div className="frame-81">
                    <div className="frame-83">
                      <img
                        className="image-7"
                        alt="Image"
                        src="/img/image-20-2x.png"
                      />

                      <div className="user-name">Ella Cooper</div>
                    </div>
                  </div>

                  <div className="date-of-adding-2">April 2, 2025</div>
                </div>

                <div className="frame-76">
                  <img
                    className="image-7"
                    alt="Image"
                    src="/img/image-23.png"
                  />

                  <div className="text-wrapper-41">SaaS Starter Page</div>
                </div>

                <div className="review-2">
                  <div className="opinion-stars">
                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-26.svg"
                    />

                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-27-2.svg"
                    />

                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-28.svg"
                    />

                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-29.svg"
                    />

                    <img
                      className="img-5"
                      alt="Star outline"
                      src="/img/star-outline-30-2.svg"
                    />
                  </div>

                  <div className="average-review-value">
                    <div className="average-review-value-3">4.0</div>
                  </div>
                </div>

                <p className="p">
                  The SaaS Starter Page is exactly what I needed to showcase my
                  software product in a clean, professional, and high-converting
                  way. From the layout to the functionality, everything is
                  designed to attract users and drive sign-ups!
                </p>
              </div>

              <div className="add-comment-and">
                <div className="likes">
                  <div className="text-button">
                    <img
                      className="img-6"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-2.svg"
                    />

                    <button className="button">114</button>
                  </div>

                  <div className="text-button">
                    <img
                      className="img-6"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-1-2.svg"
                    />

                    <button className="button">5</button>
                  </div>
                </div>
              </div>

              <div className="frame-77">
                <img
                  className="image-7"
                  alt="Image"
                  src="/img/image-25-2x.png"
                />

                <div className="frame-78">
                  <div className="frame-79">
                    <div className="text-wrapper-42">Reply</div>

                    <img
                      className="img-6"
                      alt="Send svgrepo com"
                      src="/img/send-svgrepo-com-5.svg"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="BNB-wrapper">
            <div className="BNB-2">
              <div className="navigation-menu-2">
                <img
                  className="img-6"
                  alt="Home svgrepo com"
                  src="/img/home-svgrepo-com-7.svg"
                />

                <div className="text-wrapper-43">Home</div>
              </div>

              <div className="navigation-menu-2">
                <SearchNormal property1="linear" />
                <div className="text-wrapper-44">Search</div>
              </div>

              <div className="navigation-menu-2">
                <div className="group-8" />

                <div className="text-wrapper-45">Cart</div>
              </div>

              <div className="navigation-menu-2">
                <div className="ellipse-wrapper">
                  <div className="ellipse-3" />
                </div>

                <div className="text-wrapper-46">Help</div>
              </div>

              <div className="navigation-menu-2">
                <img
                  className="image-7"
                  alt="Image"
                  src="/img/image-6-2x.png"
                />

                <div className="text-wrapper-47">Profile</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-7"
            lineClassName="home-indicator-8"
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-84">
          <div className="frame-85">
            <div className="frame-86">
              <div className="frame-87">
                <div className="frame-88">
                  <div className="frame-89">
                    <div className="text-wrapper-48">LOGO</div>
                  </div>
                </div>
              </div>

              <div className="frame-86">
                <div className="frame-90">
                  <div className="frame-91">
                    <div className="frame-92">
                      <div className="frame-93">
                        <img
                          className="img-6"
                          alt="Home svgrepo com"
                          src="/img/home-svgrepo-com-4.svg"
                        />

                        <div className="text-wrapper-49">Home</div>
                      </div>

                      <div className="frame-93">
                        <img
                          className="img-7"
                          alt="Security safe"
                          src="/img/security-safe-svgrepo-com-2.svg"
                        />

                        <div className="text-wrapper-50">Security</div>
                      </div>

                      <div className="frame-93">
                        <div className="img-7">
                          <div className="img-wrapper">
                            <img
                              className="gift-4"
                              alt="Gift"
                              src="/img/gift-6.png"
                            />
                          </div>
                        </div>

                        <div className="text-wrapper-51">Products</div>
                      </div>

                      <div className="frame-93">
                        <img
                          className="img-7"
                          alt="Advertising svgrepo"
                          src="/img/advertising-svgrepo-com-2.svg"
                        />

                        <div className="text-wrapper-50">Marketing</div>
                      </div>

                      <div className="frame-93">
                        <img
                          className="img-7"
                          alt="Cart large svgrepo"
                          src="/img/cart-large-4-svgrepo-com-2.svg"
                        />

                        <div className="text-wrapper-50">Your Store</div>
                      </div>

                      <div className="frame-93">
                        <img
                          className="img-7"
                          alt="People svgrepo com"
                          src="/img/people-svgrepo-com-4.svg"
                        />

                        <div className="text-wrapper-50">Collaborators</div>
                      </div>

                      <div className="frame-93">
                        <div className="group-9" />

                        <div className="text-wrapper-50">Checkout</div>
                      </div>

                      <div className="frame-93">
                        <div className="img-7">
                          <div className="email-svgrepo-2">
                            <div className="page-3" />
                          </div>
                        </div>

                        <div className="text-wrapper-50">Emails</div>
                      </div>

                      <div className="frame-93">
                        <img
                          className="img-7"
                          alt="Flow parallel"
                          src="/img/flow-parallel-svgrepo-com-14.svg"
                        />

                        <div className="text-wrapper-50">Workflows</div>
                      </div>

                      <div className="frame-93">
                        <img
                          className="img-7"
                          alt="Coin svgrepo com"
                          src="/img/coin-svgrepo-com-9.svg"
                        />

                        <div className="text-wrapper-50">Sales</div>
                      </div>

                      <div className="frame-93">
                        <img
                          className="img-7"
                          alt="Graph svgrepo com"
                          src="/img/graph-svgrepo-com.svg"
                        />

                        <div className="text-wrapper-50">Analytics</div>
                      </div>

                      <div className="frame-93">
                        <img
                          className="img-7"
                          alt="Coin svgrepo com"
                          src="/img/coin-svgrepo-com-9.svg"
                        />

                        <div className="text-wrapper-50">Payouts</div>
                      </div>

                      <div className="frame-93">
                        <img
                          className="img-7"
                          alt="Book bookmark"
                          src="/img/book-bookmark-minimalistic-svgrepo-com-14.svg"
                        />

                        <div className="text-wrapper-50">Library</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-93">
                  <img
                    className="img-7"
                    alt="Setting svgrepo"
                    src="/img/setting-2-svgrepo-com-2.svg"
                  />

                  <div className="text-wrapper-50">Settings</div>
                </div>

                <div className="frame-93">
                  <img
                    className="img-7"
                    alt="Open book svgrepo"
                    src="/img/open-book-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-50">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-94">
            <div className="frame-95">
              <div className="frame-96">
                <div className="frame-97">
                  <div className="text-wrapper-52">Real Estate</div>

                  <SearchNormal38 className="img-5" color="#292929" />
                </div>
              </div>

              <div className="back-icon-button-6">
                <div className="img-7">
                  <div className="vuesax-linear-2">
                    <div className="notification-2">
                      <img
                        className="group-10"
                        alt="Group"
                        src="/img/group-33845-6.png"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="back-icon-button-6">
                <img
                  className="img-7"
                  alt="Messenger fill"
                  src="/img/messenger-fill-svgrepo-com-4-2.svg"
                />
              </div>

              <div className="frame-98">
                <div className="frame-99">
                  <img
                    className="ellipse-4"
                    alt="Ellipse"
                    src="/img/ellipse-52.png"
                  />

                  <div className="frame-100">
                    <div className="text-wrapper-53">Lenny White</div>
                  </div>
                </div>

                <img
                  className="img-5"
                  alt="Expand more"
                  src="/img/expand-more-4-2.svg"
                />
              </div>
            </div>

            <div className="frame-101">
              <div className="frame-102">
                <div className="back-icon-button-5">
                  <div className="vuesax-outline-arrow-3" />
                </div>

                <div className="frame-103">
                  <div className="text-wrapper-54">Channel</div>

                  <div className="text-wrapper-55">9 Products</div>
                </div>
              </div>

              <div className="frame-72">
                <div className="frame-73">
                  <div className="text-wrapper-39">Content</div>

                  <img
                    className="vector-12"
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-73">
                  <div className="text-wrapper-40">Reviews</div>

                  <img
                    className="vector-11"
                    alt="Vector"
                    src="/img/vector-1-33.svg"
                  />
                </div>
              </div>

              <div className="user-opinion-2">
                <div className="opinion-content">
                  <div className="frame-80">
                    <div className="frame-81">
                      <div className="frame-83">
                        <img
                          className="image-8"
                          alt="Image"
                          src="/img/image-15.png"
                        />

                        <div className="user-name">Aiden Harris</div>
                      </div>

                      <div className="review-2">
                        <div className="opinion-stars">
                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-1.svg"
                          />

                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-2.svg"
                          />

                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-3-2.svg"
                          />

                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-4-2.svg"
                          />

                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-5-2.svg"
                          />
                        </div>

                        <div className="average-review-value">
                          <div className="average-review-value-2">5.0</div>
                        </div>
                      </div>
                    </div>

                    <div className="date-of-adding-3">April 2, 2025</div>
                  </div>

                  <div className="frame-76">
                    <img
                      className="image-8"
                      alt="Image"
                      src="/img/image-16-2x.png"
                    />

                    <div className="text-wrapper-41">
                      Real Estate Landing Page
                    </div>
                  </div>

                  <p className="p">
                    I recently used this Real Estate Landing Page template for
                    my property listings, and I couldn&#39;t be more impressed!
                    The design is sleek, modern, and highly professional, making
                    it easy for potential buyers to navigate and find the
                    information they need quickly.
                  </p>
                </div>

                <div className="add-comment-and">
                  <div className="likes">
                    <div className="text-button">
                      <img
                        className="img-6"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com-2.svg"
                      />

                      <button className="button">114</button>
                    </div>

                    <div className="text-button">
                      <img
                        className="img-6"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com-1-2.svg"
                      />

                      <button className="button">5</button>
                    </div>
                  </div>
                </div>

                <div className="frame-77">
                  <img
                    className="image-8"
                    alt="Image"
                    src="/img/image-19-2x.png"
                  />

                  <div className="frame-104">
                    <div className="frame-79">
                      <div className="text-wrapper-42">Reply</div>

                      <img
                        className="img-6"
                        alt="Send svgrepo com"
                        src="/img/send-svgrepo-com-7.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="user-opinion-2">
                <div className="opinion-content">
                  <div className="frame-80">
                    <div className="frame-81">
                      <div className="frame-83">
                        <img
                          className="image-8"
                          alt="Image"
                          src="/img/image-15.png"
                        />

                        <div className="user-name">Samantha Evans</div>
                      </div>

                      <div className="review-2">
                        <div className="opinion-stars">
                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-6-2.svg"
                          />

                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-7-2.svg"
                          />

                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-8.svg"
                          />

                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-9.svg"
                          />

                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-10.svg"
                          />
                        </div>

                        <div className="average-review-value">
                          <div className="average-review-value-2">5.0</div>
                        </div>
                      </div>
                    </div>

                    <div className="date-of-adding-3">April 2, 2025</div>
                  </div>

                  <div className="frame-76">
                    <img
                      className="image-9"
                      alt="Image"
                      src="/img/image-17.png"
                    />

                    <div className="text-wrapper-41">
                      Business Pro Landing Page
                    </div>
                  </div>

                  <p className="p">
                    The Business Pro Landing Page has completely transformed the
                    way I present my business online. It’s sleek, professional,
                    and most importantly, highly effective at converting
                    visitors into leads. This page is perfect for startups and
                    businesses looking to make a strong first impression!
                  </p>
                </div>

                <div className="add-comment-and">
                  <div className="likes">
                    <div className="text-button">
                      <img
                        className="img-6"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com-2.svg"
                      />

                      <button className="button">114</button>
                    </div>

                    <div className="text-button">
                      <img
                        className="img-6"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com-1-2.svg"
                      />

                      <button className="button">5</button>
                    </div>
                  </div>
                </div>

                <div className="frame-77">
                  <img
                    className="image-8"
                    alt="Image"
                    src="/img/image-19-2x.png"
                  />

                  <div className="frame-104">
                    <div className="frame-79">
                      <div className="text-wrapper-42">Reply</div>

                      <img
                        className="img-6"
                        alt="Send svgrepo com"
                        src="/img/send-svgrepo-com-1.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="user-opinion-3">
                <div className="opinion-content">
                  <div className="frame-80">
                    <div className="frame-81">
                      <div className="frame-83">
                        <img
                          className="image-8"
                          alt="Image"
                          src="/img/image-15.png"
                        />

                        <div className="user-name">Ella Cooper</div>
                      </div>

                      <div className="review-2">
                        <div className="opinion-stars">
                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-11.svg"
                          />

                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-12-2.svg"
                          />

                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-13.svg"
                          />

                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-14.svg"
                          />

                          <img
                            className="img-5"
                            alt="Star outline"
                            src="/img/star-outline-15-2.svg"
                          />
                        </div>

                        <div className="average-review-value">
                          <div className="average-review-value-3">4.0</div>
                        </div>
                      </div>
                    </div>

                    <div className="date-of-adding-3">April 2, 2025</div>
                  </div>

                  <div className="frame-76">
                    <img
                      className="image-8"
                      alt="Image"
                      src="/img/image-18.png"
                    />

                    <div className="text-wrapper-41">SaaS Starter Page</div>
                  </div>

                  <p className="p">
                    The SaaS Starter Page is exactly what I needed to showcase
                    my software product in a clean, professional, and
                    high-converting way. From the layout to the functionality,
                    everything is designed to attract users and drive sign-ups!
                  </p>
                </div>

                <div className="add-comment-and">
                  <div className="likes">
                    <div className="text-button">
                      <img
                        className="img-6"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com-2.svg"
                      />

                      <button className="button">114</button>
                    </div>

                    <div className="text-button">
                      <img
                        className="img-6"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com-1-2.svg"
                      />

                      <button className="button">5</button>
                    </div>
                  </div>
                </div>

                <div className="frame-77">
                  <img
                    className="image-8"
                    alt="Image"
                    src="/img/image-19-2x.png"
                  />

                  <div className="frame-104">
                    <div className="frame-79">
                      <div className="text-wrapper-42">Reply</div>

                      <img
                        className="img-6"
                        alt="Send svgrepo com"
                        src="/img/send-svgrepo-com-2.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
