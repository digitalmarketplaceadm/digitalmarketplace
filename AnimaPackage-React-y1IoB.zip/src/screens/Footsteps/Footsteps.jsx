import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal38 } from "../../icons/SearchNormal38";
import "./style.css";

export const Footsteps = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="footsteps"
      style={{
        alignItems:
          screenWidth < 1440
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1440
            ? "var(--variable-collection-white-duplicate)"
            : screenWidth >= 1440
              ? "var(--variable-collection-fill-duplicate)"
              : undefined,
        flexDirection: screenWidth < 1440 ? "column" : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight:
          screenWidth < 1440
            ? "100vh"
            : screenWidth >= 1440
              ? "1023px"
              : undefined,
        minWidth:
          screenWidth < 1440
            ? "393px"
            : screenWidth >= 1440
              ? "1440px"
              : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {screenWidth < 1440 && (
        <>
          <StatusBar
            actionClassName="status-bar-34"
            batteryClassName="status-bar-37"
            className="status-bar-33"
            combinedShape="/img/combined-shape-2.svg"
            containerClassName="status-bar-36"
            property1="dark"
            rectangleClassName="status-bar-38"
            timeClassName="status-bar-35"
            wiFi="/img/wi-fi-2.svg"
          />
          <div className="frame-230">
            <div className="back-icon-button-14">
              <div className="vuesax-outline-arrow-8" />
            </div>

            <div className="frame-231">
              <div className="text-wrapper-117">Footstep</div>
            </div>

            <div className="group-22">
              <div className="vuesax-linear-search-wrapper">
                <div className="vuesax-linear-search">
                  <div className="search-normal-2">
                    <img
                      className="group-23"
                      alt="Group"
                      src="/img/group-33839-2x.png"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="group-22">
              <div className="footprint-svgrepo" />
            </div>
          </div>

          <div className="frame-232">
            <div className="frame-233">
              <div className="element-solutions-card-4">
                <div className="frame-234">
                  <div className="frame-235">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-2-2x.png"
                    />
                  </div>
                </div>

                <div className="description-2">$29.99</div>

                <div className="frame-235">
                  <div className="frame-236">
                    <div className="title-4">Gardening</div>
                  </div>
                </div>

                <div className="text-wrapper-118">Friday 2:30 pm</div>
              </div>

              <div className="element-solutions-card-4">
                <div className="frame-234">
                  <div className="frame-235">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-2-2x.png"
                    />
                  </div>
                </div>

                <div className="description-2">$29.99</div>

                <div className="frame-235">
                  <div className="frame-236">
                    <div className="title-4">Music</div>
                  </div>
                </div>

                <div className="text-wrapper-118">Friday 2:30 pm</div>
              </div>

              <div className="element-solutions-card-4">
                <div className="frame-234">
                  <div className="frame-235">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-2-2x.png"
                    />
                  </div>
                </div>

                <div className="description-2">$29.99</div>

                <div className="frame-235">
                  <div className="frame-236">
                    <div className="title-4">Music</div>
                  </div>
                </div>

                <div className="text-wrapper-118">Friday 2:30 pm</div>
              </div>
            </div>

            <div className="frame-233">
              <div className="element-solutions-card-4">
                <div className="frame-234">
                  <div className="frame-235">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-2-2x.png"
                    />
                  </div>
                </div>

                <div className="description-2">$29.99</div>

                <div className="frame-235">
                  <div className="frame-236">
                    <div className="title-4">Gardening</div>
                  </div>
                </div>

                <div className="text-wrapper-118">12 May 2:30 pm</div>
              </div>

              <div className="element-solutions-card-4">
                <div className="frame-234">
                  <div className="frame-235">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-2-2x.png"
                    />
                  </div>
                </div>

                <div className="description-2">$29.99</div>

                <div className="frame-235">
                  <div className="frame-236">
                    <div className="title-4">Music</div>
                  </div>
                </div>

                <div className="text-wrapper-118">12 May 2:30 pm</div>
              </div>

              <div className="element-solutions-card-4">
                <div className="frame-234">
                  <div className="frame-235">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-2-2x.png"
                    />
                  </div>
                </div>

                <div className="description-2">$29.99</div>

                <div className="frame-235">
                  <div className="frame-236">
                    <div className="title-4">Music</div>
                  </div>
                </div>

                <div className="text-wrapper-118">12 May 2:30 pm</div>
              </div>
            </div>

            <div className="frame-233">
              <div className="element-solutions-card-4">
                <div className="frame-234">
                  <div className="frame-235">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-2-2x.png"
                    />
                  </div>
                </div>

                <div className="description-2">$29.99</div>

                <div className="frame-235">
                  <div className="frame-236">
                    <div className="title-4">Gardening</div>
                  </div>
                </div>

                <div className="text-wrapper-118">12 May 2:30 pm</div>
              </div>

              <div className="element-solutions-card-4">
                <div className="frame-234">
                  <div className="frame-235">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-2-2x.png"
                    />
                  </div>
                </div>

                <div className="description-2">$29.99</div>

                <div className="frame-235">
                  <div className="frame-236">
                    <div className="title-4">Music</div>
                  </div>
                </div>

                <div className="text-wrapper-118">12 May 2:30 pm</div>
              </div>

              <div className="element-solutions-card-4">
                <div className="frame-234">
                  <div className="frame-235">
                    <img
                      className="image-17"
                      alt="Image"
                      src="/img/image-2-2x.png"
                    />
                  </div>
                </div>

                <div className="description-2">$29.99</div>

                <div className="frame-235">
                  <div className="frame-236">
                    <div className="title-4">Music</div>
                  </div>
                </div>

                <div className="text-wrapper-118">12 May 2:30 pm</div>
              </div>
            </div>
          </div>

          <div className="frame-237">
            <div className="BNB-5">
              <div className="navigation-menu-6">
                <img
                  className="home-svgrepo-com-4"
                  alt="Home svgrepo com"
                  src="/img/home-svgrepo-com-5.svg"
                />

                <div className="text-wrapper-119">Home</div>
              </div>

              <div className="navigation-menu-6">
                <div className="group-24" />

                <div className="text-wrapper-120">Search</div>
              </div>

              <div className="navigation-menu-6">
                <div className="group-25" />

                <div className="text-wrapper-121">Cart</div>
              </div>

              <div className="navigation-menu-6">
                <div className="home-svgrepo-com-4">
                  <div className="frame-238">
                    <div className="headset-svgrepo-com-2">
                      <div className="overlap-group-3">
                        <img
                          className="vector-24"
                          alt="Vector"
                          src="/img/vector.svg"
                        />

                        <img
                          className="vector-25"
                          alt="Vector"
                          src="/img/vector-1.svg"
                        />

                        <img
                          className="vector-26"
                          alt="Vector"
                          src="/img/vector-2-2.svg"
                        />

                        <img
                          className="vector-27"
                          alt="Vector"
                          src="/img/vector-3.svg"
                        />

                        <img
                          className="vector-28"
                          alt="Vector"
                          src="/img/vector-4.svg"
                        />

                        <img
                          className="vector-29"
                          alt="Vector"
                          src="/img/vector-5.svg"
                        />

                        <img
                          className="group-26"
                          alt="Group"
                          src="/img/group-2.png"
                        />

                        <img
                          className="group-27"
                          alt="Group"
                          src="/img/group-1.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-wrapper-119">Help</div>
              </div>

              <div className="navigation-menu-6">
                <img className="image-18" alt="Image" src="/img/image-14.png" />

                <div className="text-wrapper-119">Profile</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-15"
            lineClassName="home-indicator-16"
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-239">
          <div className="frame-240">
            <div className="frame-241">
              <div className="frame-242">
                <div className="frame-243">
                  <div className="frame-244">
                    <div className="text-wrapper-122">LOGO</div>
                  </div>
                </div>
              </div>

              <div className="frame-241">
                <div className="frame-241">
                  <div className="frame-245">
                    <div className="frame-246">
                      <img
                        className="home-svgrepo-com-4"
                        alt="Home svgrepo com"
                        src="/img/home-svgrepo-com-6.svg"
                      />

                      <div className="text-wrapper-123">Home</div>
                    </div>

                    <div className="frame-246">
                      <img
                        className="img-14"
                        alt="Security safe"
                        src="/img/security-safe-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-124">Security</div>
                    </div>

                    <div className="frame-246">
                      <div className="gift-9">
                        <div className="vuesax-linear-gift-6">
                          <img
                            className="gift-10"
                            alt="Gift"
                            src="/img/gift-16.png"
                          />
                        </div>
                      </div>

                      <div className="text-wrapper-124">Products</div>
                    </div>

                    <div className="frame-246">
                      <img
                        className="img-14"
                        alt="Advertising svgrepo"
                        src="/img/advertising-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-124">Marketing</div>
                    </div>

                    <div className="frame-246">
                      <img
                        className="img-14"
                        alt="Cart large svgrepo"
                        src="/img/cart-large-4-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-124">Your Store</div>
                    </div>

                    <div className="frame-246">
                      <img
                        className="img-14"
                        alt="People svgrepo com"
                        src="/img/people-svgrepo-com-4.svg"
                      />

                      <div className="text-wrapper-124">Collaborators</div>
                    </div>

                    <div className="frame-246">
                      <div className="group-28" />

                      <div className="text-wrapper-124">Checkout</div>
                    </div>

                    <div className="frame-246">
                      <div className="img-14">
                        <div className="email-svgrepo-5">
                          <div className="page-6" />
                        </div>
                      </div>

                      <div className="text-wrapper-124">Emails</div>
                    </div>

                    <div className="frame-246">
                      <img
                        className="img-14"
                        alt="Flow parallel"
                        src="/img/flow-parallel-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-124">Workflows</div>
                    </div>

                    <div className="frame-246">
                      <img
                        className="img-14"
                        alt="Coin svgrepo com"
                        src="/img/coin-svgrepo-com-9.svg"
                      />

                      <div className="text-wrapper-124">Sales</div>
                    </div>

                    <div className="frame-246">
                      <img
                        className="img-14"
                        alt="Graph svgrepo com"
                        src="/img/graph-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-124">Analytics</div>
                    </div>

                    <div className="frame-246">
                      <img
                        className="img-14"
                        alt="Coin svgrepo com"
                        src="/img/coin-svgrepo-com-9.svg"
                      />

                      <div className="text-wrapper-124">Payouts</div>
                    </div>

                    <div className="frame-246">
                      <img
                        className="img-14"
                        alt="Book bookmark"
                        src="/img/book-bookmark-minimalistic-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-124">Library</div>
                    </div>
                  </div>
                </div>

                <div className="frame-246">
                  <img
                    className="img-14"
                    alt="Setting svgrepo"
                    src="/img/setting-2-svgrepo-com-2.svg"
                  />

                  <div className="text-wrapper-124">Settings</div>
                </div>

                <div className="frame-246">
                  <img
                    className="img-14"
                    alt="Open book svgrepo"
                    src="/img/open-book-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-124">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-247">
            <div className="frame-248">
              <div className="frame-249">
                <div className="frame-250">
                  <div className="text-wrapper-125">Real Estate</div>

                  <SearchNormal38
                    className="property-1-linear"
                    color="#292929"
                  />
                </div>
              </div>

              <div className="back-icon-button-15">
                <div className="img-14">
                  <div className="vuesax-linear-5">
                    <div className="notification-5">
                      <img
                        className="group-29"
                        alt="Group"
                        src="/img/group-33845-6.png"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="back-icon-button-15">
                <img
                  className="img-14"
                  alt="Messenger fill"
                  src="/img/messenger-fill-svgrepo-com-4.svg"
                />
              </div>

              <div className="frame-251">
                <div className="frame-252">
                  <img
                    className="ellipse-8"
                    alt="Ellipse"
                    src="/img/ellipse-52.png"
                  />

                  <div className="frame-253">
                    <div className="text-wrapper-126">Lenny White</div>
                  </div>
                </div>

                <img
                  className="property-1-linear"
                  alt="Expand more"
                  src="/img/expand-more-4.svg"
                />
              </div>
            </div>

            <div className="frame-254">
              <div className="frame-255">
                <div className="frame-256">
                  <div className="back-icon-button-14">
                    <div className="vuesax-outline-arrow-8" />
                  </div>

                  <div className="frame-231">
                    <div className="frame-257">
                      <div className="text-wrapper-127">Footstep</div>

                      <div className="frame-258">
                        <div className="group-22">
                          <div className="vuesax-linear-add-2" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-233">
                  <div className="element-solutions-card-4">
                    <img
                      className="image-19"
                      alt="Image"
                      src="/img/image-1-2x.png"
                    />

                    <div className="frame-235">
                      <div className="frame-236">
                        <div className="element-service-wrapper">
                          <div className="description-wrapper">
                            <div className="description-3">$29.99</div>
                          </div>
                        </div>

                        <div className="title-5">Gardening</div>

                        <div className="text-wrapper-128">Friday 2:30 pm</div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-4">
                    <img
                      className="image-19"
                      alt="Image"
                      src="/img/image-1-2x.png"
                    />

                    <div className="frame-235">
                      <div className="frame-236">
                        <div className="element-service-wrapper">
                          <div className="description-wrapper">
                            <div className="description-3">$29.99</div>
                          </div>
                        </div>

                        <div className="title-5">Music</div>

                        <div className="text-wrapper-128">Friday 2:30 pm</div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-4">
                    <img
                      className="image-19"
                      alt="Image"
                      src="/img/image-1-2x.png"
                    />

                    <div className="frame-235">
                      <div className="frame-236">
                        <div className="element-service-wrapper">
                          <div className="description-wrapper">
                            <div className="description-3">$29.99</div>
                          </div>
                        </div>

                        <div className="title-5">Gardening</div>

                        <div className="text-wrapper-128">Friday 2:30 pm</div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-4">
                    <img
                      className="image-19"
                      alt="Image"
                      src="/img/image-1-2x.png"
                    />

                    <div className="frame-235">
                      <div className="frame-236">
                        <div className="element-service-wrapper">
                          <div className="description-wrapper">
                            <div className="description-3">$29.99</div>
                          </div>
                        </div>

                        <div className="title-5">Gardening</div>

                        <div className="text-wrapper-128">Friday 2:30 pm</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-233">
                  <div className="element-solutions-card-4">
                    <img
                      className="image-19"
                      alt="Image"
                      src="/img/image-1-2x.png"
                    />

                    <div className="frame-235">
                      <div className="frame-236">
                        <div className="element-service-wrapper">
                          <div className="description-wrapper">
                            <div className="description-3">$29.99</div>
                          </div>
                        </div>

                        <div className="title-5">Gardening</div>

                        <div className="text-wrapper-128">Friday 2:30 pm</div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-4">
                    <img
                      className="image-19"
                      alt="Image"
                      src="/img/image-1-2x.png"
                    />

                    <div className="frame-235">
                      <div className="frame-236">
                        <div className="element-service-wrapper">
                          <div className="description-wrapper">
                            <div className="description-3">$29.99</div>
                          </div>
                        </div>

                        <div className="title-5">Gardening</div>

                        <div className="text-wrapper-128">Friday 2:30 pm</div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-4">
                    <img
                      className="image-19"
                      alt="Image"
                      src="/img/image-1-2x.png"
                    />

                    <div className="frame-235">
                      <div className="frame-236">
                        <div className="element-service-wrapper">
                          <div className="description-wrapper">
                            <div className="description-3">$29.99</div>
                          </div>
                        </div>

                        <div className="title-5">Gardening</div>

                        <div className="text-wrapper-128">Friday 2:30 pm</div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-4">
                    <img
                      className="image-19"
                      alt="Image"
                      src="/img/image-1-2x.png"
                    />

                    <div className="frame-235">
                      <div className="frame-236">
                        <div className="element-service-wrapper">
                          <div className="description-wrapper">
                            <div className="description-3">$29.99</div>
                          </div>
                        </div>

                        <div className="title-5">Gardening</div>

                        <div className="text-wrapper-128">Friday 2:30 pm</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
