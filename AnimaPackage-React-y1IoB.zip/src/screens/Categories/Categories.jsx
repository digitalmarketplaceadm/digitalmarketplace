import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal } from "../../icons/SearchNormal";
import "./style.css";

export const Categories = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="categories"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "1024px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-37"} ${screenWidth >= 393 && screenWidth < 1440 && "class-38"}`}
            className={`${screenWidth < 393 && "class-39"} ${screenWidth >= 393 && screenWidth < 1440 && "class-40"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-14.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-15.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-35"} ${screenWidth >= 393 && screenWidth < 1440 && "class-36"}`}
            property1="dark"
            rectangleClassName="status-bar-instance"
            timeClassName="status-bar-2"
            wiFi="/img/wi-fi-14.svg"
          />
          <div className="frame-119">
            <div className="back-icon-button-4">
              <div className="vuesax-outline-arrow-5" />
            </div>

            <div
              className="text-wrapper-66"
              style={{
                flex: screenWidth < 393 ? "1" : undefined,
                width:
                  screenWidth >= 393 && screenWidth < 1440
                    ? "321px"
                    : undefined,
              }}
            >
              Categories
            </div>
          </div>

          <div className="frame-120">
            <div className="frame-121">
              <div className="frame-122">
                <div className="frame-123">
                  <img
                    className="img-5"
                    alt="Cube svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/cube-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/cube-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-124">
                  <div className="text-wrapper-67">3D</div>
                </div>
              </div>

              <div className="frame-122">
                <div className="frame-123">
                  <img
                    className="img-5"
                    alt="Roblox svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/roblox-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/roblox-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">Roblox</div>
                </div>
              </div>

              <div className="frame-122">
                <div className="frame-123">
                  <div className="img-5">
                    <img
                      className="group-2"
                      alt="Group"
                      src={
                        screenWidth < 393
                          ? "/img/group-12.png"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/group-15.png"
                            : undefined
                      }
                    />
                  </div>
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">Crafts</div>
                </div>
              </div>
            </div>

            <div className="frame-126">
              <div className="frame-122">
                <div className="frame-123">
                  <img
                    className="img-5"
                    alt="Music note svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/music-note-4-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/music-note-4-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-124">
                  <div className="text-wrapper-68">
                    Music &amp; Sound Design
                  </div>
                </div>
              </div>

              <div className="frame-122">
                <div className="frame-123">
                  <div className="img-5">
                    <div className="overlap-group">
                      <img
                        className="group-3"
                        alt="Group"
                        src={
                          screenWidth < 393
                            ? "/img/group-13.png"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/group-16.png"
                              : undefined
                        }
                      />

                      <img
                        className="vector"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-44.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-55.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-2"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-45.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-56.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-3"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-46.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-57.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-4"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-47.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-58.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-5"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-48.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-59.svg"
                              : undefined
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">Design</div>
                </div>
              </div>

              <div className="frame-122">
                <div className="frame-123">
                  <img
                    className="img-5"
                    alt="Check square svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/check-square-svgrepo-com-10.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/check-square-svgrepo-com-11.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">Drawing &amp; Painting</div>
                </div>
              </div>
            </div>

            <div className="frame-126">
              <div className="frame-122">
                <div className="frame-127">
                  <img
                    className="img-6"
                    alt="Book svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/book-svgrepo-com-4.png"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/book-svgrepo-com-5.png"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-124">
                  <div className="text-wrapper-67">Fiction Book</div>
                </div>
              </div>

              <div className="frame-122">
                <div className="frame-127">
                  <img
                    className="img-6"
                    alt="Gym svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/gym-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/gym-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">Fitness &amp; Health</div>
                </div>
              </div>

              <div className="frame-122">
                <div className="frame-127">
                  <img
                    className="img-6"
                    alt="Camera svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/camera-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/camera-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">Photography</div>
                </div>
              </div>
            </div>

            <div className="frame-126">
              <div className="frame-122">
                <div className="frame-127">
                  <img
                    className="img-6"
                    alt="Pen square svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/pen-square-svgrepo-com-10.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/pen-square-svgrepo-com-11.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-124">
                  <div className="text-wrapper-68">
                    Writing &amp; Publishing
                  </div>
                </div>
              </div>

              <div className="frame-122">
                <div className="frame-127">
                  <img
                    className="img-6"
                    alt="Suitcase svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/suitcase-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/suitcase-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">Business &amp; Money</div>
                </div>
              </div>

              <div className="frame-122">
                <div className="frame-127">
                  <img
                    className="img-6"
                    alt="Film svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/film-02-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/film-02-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">Films</div>
                </div>
              </div>
            </div>

            <div className="frame-121">
              <div className="frame-122">
                <div className="frame-127">
                  <img
                    className="img-6"
                    alt="Book saved svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/book-saved-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/book-saved-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">
                    Comics &amp; Graphics...
                  </div>
                </div>
              </div>

              <div className="frame-128">
                <div className="frame-127">
                  <img
                    className="img-6"
                    alt="Mic svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/mic-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/mic-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">Audio</div>
                </div>
              </div>

              <div className="frame-128">
                <div className="frame-127">
                  <img
                    className="img-6"
                    alt="Music note svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/music-note-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/music-note-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-124">
                  <div className="text-wrapper-68">Recorded Music</div>
                </div>
              </div>
            </div>

            <div className="frame-121">
              <div className="frame-128">
                <div className="frame-127">
                  <img
                    className="img-6"
                    alt="Book svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/book-1-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/book-1-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">Education</div>
                </div>
              </div>

              <div className="frame-128">
                <div className="frame-127">
                  <div className="img-6">
                    <div className="overlap-group-2">
                      <img
                        className="group-4"
                        alt="Group"
                        src={
                          screenWidth < 393
                            ? "/img/group-14.png"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/group-17.png"
                              : undefined
                        }
                      />

                      <img
                        className="vector-6"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-49.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-60.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-7"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-50.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-61.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-8"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-51.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-62.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-9"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-52.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-63.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-10"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-53.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-64.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-11"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-54.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-65.svg"
                              : undefined
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">Gaming</div>
                </div>
              </div>

              <div className="frame-122">
                <div className="frame-127">
                  <img
                    className="img-6"
                    alt="Code circle svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/code-circle-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/code-circle-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-125">
                  <div className="text-wrapper-68">Software Develop...</div>
                </div>
              </div>
            </div>
          </div>

          <div
            className="BNB-wrapper"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB">
              {screenWidth < 393 && (
                <div className="frame-129">
                  <div className="navigation-menu-home">
                    <div className="navigation-menu-home-2">
                      <img
                        className="img-7"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-1.svg"
                      />

                      <div className="text-wrapper-69">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu">
                    <SearchNormal className="img-8" color="#535353" />
                    <div className="text-wrapper-70">Search</div>
                  </div>

                  <div className="navigation-menu">
                    <img
                      className="img-8"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-71">Cart</div>
                  </div>

                  <div className="navigation-menu">
                    <img
                      className="img-8"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-5.svg"
                    />

                    <div className="text-wrapper-72">Help</div>
                  </div>

                  <div className="navigation-menu">
                    <img className="image" alt="Image" src="/img/image.png" />

                    <div className="text-wrapper-73">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1440 && (
                <>
                  <div className="navigation-menu-home">
                    <div className="navigation-menu-home-2">
                      <img
                        className="img-7"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-11.svg"
                      />

                      <div className="text-wrapper-69">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-2">
                    <SearchNormal className="img-7" color="#535353" />
                  </div>

                  <div className="navigation-menu-2">
                    <img
                      className="img-7"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-1.svg"
                    />
                  </div>

                  <div className="navigation-menu-2">
                    <div className="ellipse-wrapper">
                      <div className="ellipse" />
                    </div>
                  </div>

                  <div className="navigation-menu-2">
                    <img className="image-2" alt="Image" src="/img/image.png" />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-3"
            lineClassName={`${screenWidth < 393 && "class-41"} ${screenWidth >= 393 && screenWidth < 1440 && "class-42"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-130">
          <div className="frame-131">
            <div className="frame-132">
              <div className="frame-133">
                <div className="frame-134">
                  <div className="frame-135">
                    <div className="text-wrapper-74">LOGO</div>
                  </div>
                </div>

                <div className="frame-136">
                  <div className="frame-137">
                    <img
                      className="img-9"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-75">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-132">
                <div className="frame-132">
                  <div className="frame-138">
                    <div className="img-9">
                      <div className="vuesax-linear-gift-3">
                        <img
                          className="gift-5"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-76">Products</div>
                  </div>

                  <div className="frame-138">
                    <img
                      className="img-9"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-76">Collaborators</div>
                  </div>

                  <div className="frame-138">
                    <img
                      className="img-9"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-76">Checkout</div>
                  </div>

                  <div className="frame-138">
                    <img
                      className="img-9"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-76">Emails</div>
                  </div>

                  <div className="frame-138">
                    <img
                      className="img-9"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-76">Workflows</div>
                  </div>

                  <div className="frame-138">
                    <img
                      className="img-9"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-76">Sales</div>
                  </div>

                  <div className="frame-138">
                    <img
                      className="img-9"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-76">Analytics</div>
                  </div>

                  <div className="frame-138">
                    <img
                      className="img-9"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-76">Payouts</div>
                  </div>

                  <div className="frame-138">
                    <img
                      className="img-9"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-76">Library</div>
                  </div>
                </div>

                <div className="frame-138">
                  <img
                    className="img-9"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-76">Settings</div>
                </div>

                <div className="frame-138">
                  <img
                    className="img-9"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-76">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-139">
            <div className="frame-140">
              <div className="frame-141">
                <div className="frame-142">
                  <div className="text-wrapper-77">Search</div>

                  <SearchNormal className="search-normal-1" color="#232323" />
                </div>
              </div>

              <div className="frame-143">
                <div className="text-wrapper-78">Login</div>
              </div>

              <div className="frame-144">
                <div className="text-wrapper-79">Sign Up</div>
              </div>
            </div>

            <div className="frame-145">
              <div className="frame-121">
                <div className="back-icon-button-4">
                  <div className="vuesax-outline-arrow-5" />
                </div>

                <div className="text-wrapper-80">Categories</div>
              </div>

              <div className="frame-146">
                <div className="frame-147">
                  <div className="frame-148">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Cube svgrepo com"
                        src="/img/cube-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-124">
                      <div className="text-wrapper-81">3D</div>
                    </div>
                  </div>

                  <div className="frame-148">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Roblox svgrepo com"
                        src="/img/roblox-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-125">
                      <div className="text-wrapper-82">Roblox</div>
                    </div>
                  </div>

                  <div className="frame-148">
                    <div className="frame-149">
                      <div className="img-10">
                        <img
                          className="group-5"
                          alt="Group"
                          src="/img/group-9.png"
                        />
                      </div>
                    </div>

                    <div className="frame-125">
                      <div className="text-wrapper-82">Crafts</div>
                    </div>
                  </div>

                  <div className="frame-148">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Music note svgrepo"
                        src="/img/music-note-4-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-124">
                      <div className="text-wrapper-81">
                        Music &amp; Sound Design
                      </div>
                    </div>
                  </div>

                  <div className="frame-148">
                    <div className="frame-149">
                      <div className="img-10">
                        <div className="overlap-group-3">
                          <img
                            className="group-6"
                            alt="Group"
                            src="/img/group-10.png"
                          />

                          <img
                            className="vector-12"
                            alt="Vector"
                            src="/img/vector-33.svg"
                          />

                          <img
                            className="vector-13"
                            alt="Vector"
                            src="/img/vector-34.svg"
                          />

                          <img
                            className="vector-14"
                            alt="Vector"
                            src="/img/vector-35.svg"
                          />

                          <img
                            className="vector-15"
                            alt="Vector"
                            src="/img/vector-36.svg"
                          />

                          <img
                            className="vector-16"
                            alt="Vector"
                            src="/img/vector-37.svg"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="frame-125">
                      <div className="text-wrapper-82">Design</div>
                    </div>
                  </div>
                </div>

                <div className="frame-147">
                  <div className="frame-148">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Check square svgrepo"
                        src="/img/check-square-svgrepo-com-9.svg"
                      />
                    </div>

                    <div className="frame-125">
                      <div className="text-wrapper-82">
                        Drawing &amp; Painting
                      </div>
                    </div>
                  </div>

                  <div className="frame-148">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Book svgrepo com"
                        src="/img/book-svgrepo-com-3.png"
                      />
                    </div>

                    <div className="frame-124">
                      <div className="text-wrapper-81">Fiction Book</div>
                    </div>
                  </div>

                  <div className="frame-148">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Gym svgrepo com"
                        src="/img/gym-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-125">
                      <div className="fitness-health">Fitness &amp; Health</div>
                    </div>
                  </div>

                  <div className="frame-148">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Camera svgrepo com"
                        src="/img/camera-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-125">
                      <div className="text-wrapper-82">Photography</div>
                    </div>
                  </div>

                  <div className="frame-148">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Pen square svgrepo"
                        src="/img/pen-square-svgrepo-com-9.svg"
                      />
                    </div>

                    <div className="frame-124">
                      <div className="writing-publishing">
                        Writing &amp; Publishing
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-147">
                  <div className="frame-148">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Suitcase svgrepo com"
                        src="/img/suitcase-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-125">
                      <div className="text-wrapper-82">
                        Business &amp; Money
                      </div>
                    </div>
                  </div>

                  <div className="frame-148">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Film svgrepo com"
                        src="/img/film-02-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-125">
                      <div className="text-wrapper-82">FIlms</div>
                    </div>
                  </div>

                  <div className="frame-148">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Book saved svgrepo"
                        src="/img/book-saved-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-125">
                      <div className="text-wrapper-82">
                        Comics &amp; Graphics...
                      </div>
                    </div>
                  </div>

                  <div className="frame-150">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Mic svgrepo com"
                        src="/img/mic-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-125">
                      <div className="text-wrapper-82">Audio</div>
                    </div>
                  </div>

                  <div className="frame-150">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Music note svgrepo"
                        src="/img/music-note-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-124">
                      <div className="text-wrapper-81">Recorded Music</div>
                    </div>
                  </div>
                </div>

                <div className="frame-151">
                  <div className="frame-152">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Book svgrepo com"
                        src="/img/book-1-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-125">
                      <div className="text-wrapper-82">Education</div>
                    </div>
                  </div>

                  <div className="frame-152">
                    <div className="frame-149">
                      <div className="img-10">
                        <div className="overlap-group-4">
                          <img
                            className="group-7"
                            alt="Group"
                            src="/img/group-11.png"
                          />

                          <img
                            className="vector-17"
                            alt="Vector"
                            src="/img/vector-38.svg"
                          />

                          <img
                            className="vector-18"
                            alt="Vector"
                            src="/img/vector-39.svg"
                          />

                          <img
                            className="vector-19"
                            alt="Vector"
                            src="/img/vector-40.svg"
                          />

                          <img
                            className="vector-20"
                            alt="Vector"
                            src="/img/vector-41.svg"
                          />

                          <img
                            className="vector-21"
                            alt="Vector"
                            src="/img/vector-42.svg"
                          />

                          <img
                            className="vector-22"
                            alt="Vector"
                            src="/img/vector-43.svg"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="frame-125">
                      <div className="text-wrapper-82">Gaming</div>
                    </div>
                  </div>

                  <div className="frame-153">
                    <div className="frame-149">
                      <img
                        className="img-10"
                        alt="Code circle svgrepo"
                        src="/img/code-circle-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-125">
                      <div className="text-wrapper-82">Software Develop...</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
