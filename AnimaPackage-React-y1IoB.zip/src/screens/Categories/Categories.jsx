import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const Categories = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="categories"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 393
            ? "var(--variable-collection-white-duplicate)"
            : screenWidth >= 393 && screenWidth < 1440
              ? "#ffffff"
              : screenWidth >= 1440
                ? "var(--variable-collection-fill-duplicate)"
                : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "1148px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {screenWidth < 393 && (
        <StatusBar
          actionClassName="status-bar-84"
          batteryClassName="status-bar-87"
          className="status-bar-83"
          combinedShape="/img/combined-shape-22.svg"
          containerClassName="status-bar-86"
          property1="dark"
          rectangleClassName="status-bar-88"
          timeClassName="status-bar-85"
          wiFi="/img/wi-fi-22.svg"
        />
      )}

      {screenWidth >= 393 && screenWidth < 1440 && (
        <StatusBar
          batteryClassName="status-bar-92"
          className="status-bar-89"
          combinedShape="/img/combined-shape-23.svg"
          containerClassName="status-bar-91"
          property1="dark"
          rectangleClassName="status-bar-93"
          timeClassName="status-bar-90"
          wiFi="/img/wi-fi-23-2.svg"
        />
      )}

      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <div className="frame-489">
            <div
              className="back-icon-button-31"
              style={{
                backgroundColor:
                  screenWidth < 393
                    ? "var(--variable-collection-fill-duplicate)"
                    : screenWidth >= 393 && screenWidth < 1440
                      ? "#f5f6f8"
                      : undefined,
              }}
            >
              <div className="vuesax-outline-arrow-15" />
            </div>

            <div
              className="text-wrapper-243"
              style={{
                color:
                  screenWidth < 393
                    ? "var(--variable-collection-black-duplicate)"
                    : screenWidth >= 393 && screenWidth < 1440
                      ? "var(--variable-collection-primary-black)"
                      : undefined,
                marginRight: screenWidth < 393 ? "-73.00px" : undefined,
              }}
            >
              Categories
            </div>
          </div>

          <div
            className="frame-490"
            style={{
              backgroundColor:
                screenWidth < 393
                  ? "var(--variable-collection-white-duplicate)"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "#ffffff"
                    : undefined,
            }}
          >
            {screenWidth < 393 && (
              <div className="frame-491">
                <div className="frame-492">
                  <div className="frame-493">
                    <div className="frame-494">
                      <div className="group-105" />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-244">Health</div>
                    </div>
                  </div>

                  <div className="frame-496">
                    <div className="frame-494">
                      <img
                        className="group-106"
                        alt="Group"
                        src="/img/group-1272630326-3.png"
                      />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-244">Fitness</div>
                    </div>
                  </div>

                  <div className="frame-496">
                    <div className="frame-494">
                      <div className="group-107" />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-244">Cooking</div>
                    </div>
                  </div>
                </div>

                <div className="frame-497">
                  <div className="frame-496">
                    <div className="frame-498">
                      <div className="group-108" />
                    </div>

                    <div className="frame-499">
                      <div className="text-wrapper-244">
                        Beauty &amp; Fashion
                      </div>
                    </div>
                  </div>

                  <div className="frame-493">
                    <div className="frame-498">
                      <div className="group-109" />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-244">Music</div>
                    </div>
                  </div>

                  <div className="frame-496">
                    <div className="frame-498">
                      <img
                        className="img-27"
                        alt="Computer svgrepo com"
                        src="/img/computer-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-244">
                        Information Technology
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-500">
                  <div className="frame-500">
                    <div className="frame-501">
                      <div className="group-110" />

                      <div className="text-wrapper-245">Language</div>
                    </div>

                    <div className="frame-501">
                      <div className="img-28">
                        <img
                          className="group-111"
                          alt="Group"
                          src="/img/group-28.png"
                        />
                      </div>

                      <div className="text-wrapper-245">Psychology</div>
                    </div>

                    <div className="frame-501">
                      <div className="group-112" />

                      <div className="text-wrapper-245">Business</div>
                    </div>

                    <div className="frame-501">
                      <div className="group-113" />

                      <div className="text-wrapper-245">Travel</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Pencil svgrepo com"
                        src="/img/pencil-svgrepo-com-3.svg"
                      />

                      <div className="text-wrapper-245">Writing</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Car svgrepo com"
                        src="/img/car-svgrepo-com-3.svg"
                      />

                      <div className="text-wrapper-245">Car</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Pet svgrepo com"
                        src="/img/pet-svgrepo-com-3.svg"
                      />

                      <div className="text-wrapper-245">Pets</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Garden svgrepo com"
                        src="/img/garden-svgrepo-com-3.svg"
                      />

                      <div className="text-wrapper-245">Gardening</div>
                    </div>

                    <div className="frame-501">
                      <div className="img-28">
                        <div className="layer">
                          <div className="icons">
                            <div className="overlap-group-11">
                              <img
                                className="img-29"
                                alt="Vector"
                                src="/img/vector-48.svg"
                              />

                              <img
                                className="img-29"
                                alt="Group"
                                src="/img/group-30.png"
                              />
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="text-wrapper-245">Arts &amp; Crafts</div>
                    </div>

                    <div className="frame-501">
                      <div className="icons-wrapper">
                        <div className="q-icons" />
                      </div>

                      <div className="text-wrapper-245">Sports</div>
                    </div>

                    <div className="frame-501">
                      <div className="img-28">
                        <img
                          className="group-114"
                          alt="Group"
                          src="/img/group-29.png"
                        />
                      </div>

                      <div className="text-wrapper-245">Dance</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Dot menu more"
                        src="/img/dot-menu-more-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-245">See All</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {screenWidth >= 393 && screenWidth < 1440 && (
              <>
                <div className="frame-492">
                  <div className="frame-493">
                    <div className="frame-502">
                      <div className="group-115" />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-246">Health</div>
                    </div>
                  </div>

                  <div className="frame-496">
                    <div className="frame-503">
                      <img
                        className="group-106"
                        alt="Group"
                        src="/img/group-1272630326-4.png"
                      />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">Fitness</div>
                    </div>
                  </div>

                  <div className="frame-496">
                    <div className="frame-503">
                      <div className="group-116" />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">Cooking</div>
                    </div>
                  </div>
                </div>

                <div className="frame-497">
                  <div className="frame-496">
                    <div className="frame-504">
                      <div className="group-117" />
                    </div>

                    <div className="frame-499">
                      <div className="text-wrapper-247">
                        Beauty &amp; Fashion
                      </div>
                    </div>
                  </div>

                  <div className="frame-493">
                    <div className="frame-505">
                      <div className="group-118" />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">Music</div>
                    </div>
                  </div>

                  <div className="frame-496">
                    <div className="frame-504">
                      <img
                        className="img-27"
                        alt="Computer svgrepo com"
                        src="/img/computer-svgrepo-com-4.svg"
                      />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">
                        Information Technology
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-497">
                  <div className="frame-496">
                    <div className="frame-506">
                      <div className="group-119" />
                    </div>

                    <div className="frame-499">
                      <div className="text-wrapper-248">Language</div>
                    </div>
                  </div>

                  <div className="frame-496">
                    <div className="frame-506">
                      <div className="img-30">
                        <img
                          className="group-120"
                          alt="Group"
                          src="/img/group-32.png"
                        />
                      </div>
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">Psychology</div>
                    </div>
                  </div>

                  <div className="frame-496">
                    <div className="frame-506">
                      <div className="group-121" />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">Business</div>
                    </div>
                  </div>
                </div>

                <div className="frame-497">
                  <div className="frame-496">
                    <div className="frame-506">
                      <div className="group-122" />
                    </div>

                    <div className="frame-499">
                      <div className="text-wrapper-247">Travel</div>
                    </div>
                  </div>

                  <div className="frame-496">
                    <div className="frame-506">
                      <img
                        className="img-30"
                        alt="Pencil svgrepo com"
                        src="/img/pencil-svgrepo-com-4.svg"
                      />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">Writing</div>
                    </div>
                  </div>

                  <div className="frame-496">
                    <div className="frame-506">
                      <img
                        className="img-30"
                        alt="Car svgrepo com"
                        src="/img/car-svgrepo-com-4.svg"
                      />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">Car</div>
                    </div>
                  </div>
                </div>

                <div className="frame-492">
                  <div className="frame-496">
                    <div className="frame-504">
                      <img
                        className="img-27"
                        alt="Pet svgrepo com"
                        src="/img/pet-svgrepo-com-4.svg"
                      />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">Pets</div>
                    </div>
                  </div>

                  <div className="frame-493">
                    <div className="frame-506">
                      <img
                        className="img-30"
                        alt="Garden svgrepo com"
                        src="/img/garden-svgrepo-com-4.svg"
                      />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">Gardening</div>
                    </div>
                  </div>

                  <div className="frame-493">
                    <div className="frame-506">
                      <div className="img-30">
                        <div className="layer-2">
                          <div className="icons-q">
                            <div className="overlap-group-12">
                              <img
                                className="vector-79"
                                alt="Vector"
                                src="/img/vector-49.svg"
                              />

                              <img
                                className="group-123"
                                alt="Group"
                                src="/img/group-34.png"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="frame-499">
                      <div className="text-wrapper-247">Arts &amp; Crafts</div>
                    </div>
                  </div>
                </div>

                <div className="frame-492">
                  <div className="frame-493">
                    <div className="frame-506">
                      <div className="img-30">
                        <div className="layer-2">
                          <div className="icons-2" />
                        </div>
                      </div>
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">Sports</div>
                    </div>
                  </div>

                  <div className="frame-493">
                    <div className="frame-506">
                      <div className="img-30">
                        <img
                          className="group-124"
                          alt="Group"
                          src="/img/group-33.png"
                        />
                      </div>
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">Dance</div>
                    </div>
                  </div>

                  <div className="frame-496">
                    <div className="frame-506">
                      <img
                        className="img-30"
                        alt="Dot menu more"
                        src="/img/dot-menu-more-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-495">
                      <div className="text-wrapper-247">See All</div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </>
      )}

      {screenWidth >= 393 && screenWidth < 1440 && (
        <div className="frame-507">
          <div className="BNB-11">
            <div className="navigation-menu-home-wrapper">
              <div className="navigation-menu-home-3">
                <img
                  className="img-31"
                  alt="Home angle svgrepo"
                  src="/img/home-angle-svgrepo-com-15.svg"
                />

                <div className="text-wrapper-249">Home</div>
              </div>
            </div>

            <div className="navigation-menu-12">
              <SearchNormal property1="linear" />
            </div>

            <div className="navigation-menu-12">
              <img
                className="img-31"
                alt="Cart large"
                src="/img/cart-large-minimalistic-svgrepo-com-8.svg"
              />
            </div>

            <div className="navigation-menu-12">
              <div className="frame-508">
                <div className="ellipse-27" />
              </div>
            </div>

            <div className="navigation-menu-12">
              <img className="image-29" alt="Image" src="/img/image-4-2.png" />
            </div>
          </div>
        </div>
      )}

      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <HomeIndicator
          className={`${screenWidth < 393 && "class-35"} ${screenWidth >= 393 && screenWidth < 1440 && "class-36"}`}
          lineClassName={`${screenWidth < 393 && "class-37"} ${screenWidth >= 393 && screenWidth < 1440 && "class-38"}`}
          property1="dark"
        />
      )}

      {screenWidth >= 1440 && (
        <div className="frame-509">
          <div className="frame-510">
            <div className="frame-511">
              <div className="frame-512">
                <div className="frame-513">
                  <div className="frame-514">
                    <div className="text-wrapper-250">LOGO</div>
                  </div>
                </div>
              </div>

              <div className="frame-511">
                <div className="frame-511">
                  <div className="frame-500">
                    <div className="frame-501">
                      <img
                        className="img-31"
                        alt="Home svgrepo com"
                        src="/img/home-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-251">Home</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Security safe"
                        src="/img/security-safe-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-245">Security</div>
                    </div>

                    <div className="frame-501">
                      <div className="gift-21">
                        <div className="vuesax-linear-gift-12">
                          <img
                            className="gift-22"
                            alt="Gift"
                            src="/img/gift-6-2.png"
                          />
                        </div>
                      </div>

                      <div className="text-wrapper-245">Products</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Advertising svgrepo"
                        src="/img/advertising-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-245">Marketing</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Cart large svgrepo"
                        src="/img/cart-large-4-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-245">Your Store</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="People svgrepo com"
                        src="/img/people-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-245">Collaborators</div>
                    </div>

                    <div className="frame-501">
                      <div className="group-125" />

                      <div className="text-wrapper-245">Checkout</div>
                    </div>

                    <div className="frame-501">
                      <div className="img-28">
                        <div className="email-svgrepo-10">
                          <div className="page-11" />
                        </div>
                      </div>

                      <div className="text-wrapper-245">Emails</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Flow parallel"
                        src="/img/flow-parallel-svgrepo-com-6-3.svg"
                      />

                      <div className="text-wrapper-245">Workflows</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Coin svgrepo com"
                        src="/img/coin-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-245">Sales</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Graph svgrepo com"
                        src="/img/graph-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-245">Analytics</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Coin svgrepo com"
                        src="/img/coin-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-245">Payouts</div>
                    </div>

                    <div className="frame-501">
                      <img
                        className="img-28"
                        alt="Book bookmark"
                        src="/img/book-bookmark-minimalistic-svgrepo-com-6-3.svg"
                      />

                      <div className="text-wrapper-245">Library</div>
                    </div>
                  </div>
                </div>

                <div className="frame-501">
                  <img
                    className="img-28"
                    alt="Setting svgrepo"
                    src="/img/setting-2-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-245">Settings</div>
                </div>

                <div className="frame-501">
                  <img
                    className="img-28"
                    alt="Open book svgrepo"
                    src="/img/open-book-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-245">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-515">
            <div className="frame-516">
              <div className="frame-517">
                <div className="frame-518">
                  <div className="text-wrapper-252">Real Estate</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="back-icon-button-32">
                <div className="img-28">
                  <div className="vuesax-linear-13">
                    <div className="notification-15">
                      <img
                        className="group-126"
                        alt="Group"
                        src="/img/group-33845.png"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="back-icon-button-32">
                <img
                  className="img-28"
                  alt="Messenger fill"
                  src="/img/messenger-fill-svgrepo-com-7.svg"
                />
              </div>

              <div className="frame-519">
                <div className="frame-520">
                  <img
                    className="ellipse-28"
                    alt="Ellipse"
                    src="/img/ellipse-52.png"
                  />

                  <div className="frame-521">
                    <div className="text-wrapper-253">Lenny White</div>
                  </div>
                </div>

                <img
                  className="expand-more-2"
                  alt="Expand more"
                  src="/img/expand-more-15.svg"
                />
              </div>
            </div>

            <div className="frame-522">
              <div className="frame-492">
                <div className="back-icon-button-33">
                  <div className="vuesax-outline-arrow-15" />
                </div>

                <div className="text-wrapper-254">Categories</div>
              </div>

              <div className="frame-523">
                <div className="frame-524">
                  <div className="frame-525">
                    <div className="frame-496">
                      <div className="frame-526">
                        <div className="group-127" />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Health</div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-526">
                        <img
                          className="group-128"
                          alt="Group"
                          src="/img/group-1272630326-2.png"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Fitness</div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-526">
                        <div className="group-129" />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Cooking</div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-527">
                        <div className="group-130" />
                      </div>

                      <div className="frame-499">
                        <div className="text-wrapper-255">
                          Beauty &amp; Fashion
                        </div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-527">
                        <div className="group-131" />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Music</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-525">
                    <div className="frame-496">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="Computer svgrepo com"
                          src="/img/computer-svgrepo-com-2.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">
                          Information Technology
                        </div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-527">
                        <div className="group-132" />
                      </div>

                      <div className="frame-499">
                        <div className="text-wrapper-256">Language</div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-527">
                        <div className="img-32">
                          <img
                            className="group-133"
                            alt="Group"
                            src="/img/group-22.png"
                          />
                        </div>
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Psychology</div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-527">
                        <div className="group-134" />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Business</div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-527">
                        <div className="group-135" />
                      </div>

                      <div className="frame-499">
                        <div className="text-wrapper-255">Travel</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-525">
                    <div className="frame-496">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="Pencil svgrepo com"
                          src="/img/pencil-svgrepo-com-2.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Writing</div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="Car svgrepo com"
                          src="/img/car-svgrepo-com-2.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Car</div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="Pet svgrepo com"
                          src="/img/pet-svgrepo-com-2.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Pets</div>
                      </div>
                    </div>

                    <div className="frame-493">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="Garden svgrepo com"
                          src="/img/garden-svgrepo-com-2.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Gardening</div>
                      </div>
                    </div>

                    <div className="frame-493">
                      <div className="frame-527">
                        <div className="img-32">
                          <div className="icons-q-wrapper">
                            <div className="icons-3">
                              <div className="overlap-group-13">
                                <img
                                  className="vector-80"
                                  alt="Vector"
                                  src="/img/vector-46.svg"
                                />

                                <img
                                  className="group-136"
                                  alt="Group"
                                  src="/img/group-23.png"
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="frame-499">
                        <div className="text-wrapper-255">
                          Arts &amp; Crafts
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-525">
                    <div className="frame-493">
                      <div className="frame-527">
                        <div className="img-33">
                          <div className="layer-2">
                            <div className="icons-4" />
                          </div>
                        </div>
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Sports</div>
                      </div>
                    </div>

                    <div className="frame-493">
                      <div className="frame-527">
                        <div className="img-33">
                          <img
                            className="group-124"
                            alt="Group"
                            src="/img/group-20.png"
                          />
                        </div>
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Dance</div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-527">
                        <img
                          className="img-33"
                          alt="Book minimalistic"
                          src="/img/book-minimalistic-svgrepo-com.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Academic</div>
                      </div>
                    </div>

                    <div className="frame-493">
                      <div className="frame-527">
                        <img
                          className="img-33"
                          alt="Photography svgrepo"
                          src="/img/photography-svgrepo-com.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">
                          Photography &amp; Video
                        </div>
                      </div>
                    </div>

                    <div className="frame-493">
                      <div className="frame-527">
                        <img
                          className="img-33"
                          alt="Heart svgrepo com"
                          src="/img/heart-svgrepo-com.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Dating</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-525">
                    <div className="frame-493">
                      <div className="frame-527">
                        <div className="img-32">
                          <img
                            className="group-137"
                            alt="Group"
                            src="/img/group-24.png"
                          />

                          <img
                            className="vector-81"
                            alt="Vector"
                            src="/img/vector-47.svg"
                          />
                        </div>
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Kids</div>
                      </div>
                    </div>

                    <div className="frame-493">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="Social share svgrepo"
                          src="/img/social-share-svgrepo-com.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Social</div>
                      </div>
                    </div>

                    <div className="frame-493">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="Home svgrepo com"
                          src="/img/home-1-svgrepo-com.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Home design</div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="Shopping bag svgrepo"
                          src="/img/shopping-bag-svgrepo-com.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Shopping</div>
                      </div>
                    </div>

                    <div className="frame-493">
                      <div className="frame-527">
                        <div className="img-32">
                          <img
                            className="layer-3"
                            alt="Layer"
                            src="/img/layer-2.png"
                          />
                        </div>
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Outdoor</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-525">
                    <div className="frame-493">
                      <div className="frame-527">
                        <div className="img-32">
                          <img
                            className="group-138"
                            alt="Group"
                            src="/img/group-21.png"
                          />

                          <img
                            className="group-139"
                            alt="Group"
                            src="/img/group-25.png"
                          />
                        </div>
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Cleaning</div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-527">
                        <div className="img-32">
                          <img
                            className="layer-4"
                            alt="Layer"
                            src="/img/layer-1.png"
                          />
                        </div>
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Repair</div>
                      </div>
                    </div>

                    <div className="frame-493">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="Building svgrepo com"
                          src="/img/building-svgrepo-com.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Building</div>
                      </div>
                    </div>

                    <div className="frame-493">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="Open book svgrepo"
                          src="/img/open-book-svgrepo-com-1.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Reading</div>
                      </div>
                    </div>

                    <div className="frame-496">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="Math finance svgrepo"
                          src="/img/math-finance-svgrepo-com.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Math</div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-525">
                    <div className="frame-528">
                      <div className="frame-527">
                        <div className="img-32">
                          <img
                            className="group-140"
                            alt="Group"
                            src="/img/group-26.png"
                          />
                        </div>
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Science</div>
                      </div>
                    </div>

                    <div className="frame-528">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="History svgrepo com"
                          src="/img/history-svgrepo-com.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">History</div>
                      </div>
                    </div>

                    <div className="frame-529">
                      <div className="frame-527">
                        <img
                          className="img-32"
                          alt="Film svgrepo com"
                          src="/img/film-svgrepo-com.svg"
                        />
                      </div>

                      <div className="frame-495">
                        <div className="text-wrapper-255">Film</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
