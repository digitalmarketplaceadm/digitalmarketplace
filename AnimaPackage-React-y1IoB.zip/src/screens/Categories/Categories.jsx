import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal24 } from "../../icons/SearchNormal24";
import "./style.css";

export const Categories = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="categories"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "1024px" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-65"} ${screenWidth >= 393 && screenWidth < 1440 && "class-66"}`}
            className={`${screenWidth < 393 && "class-67"} ${screenWidth >= 393 && screenWidth < 1440 && "class-68"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-14.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-15.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-69"} ${screenWidth >= 393 && screenWidth < 1440 && "class-70"}`}
            property1="dark"
            rectangleClassName="status-bar-11"
            timeClassName="status-bar-12"
            wiFi="/img/wi-fi-14.svg"
          />
          <div className="frame-418">
            <div className="back-icon-button-11">
              <div className="vuesax-outline-arrow-12" />
            </div>

            <div
              className="text-wrapper-275"
              style={{
                flex: screenWidth < 393 ? "1" : undefined,
                width:
                  screenWidth >= 393 && screenWidth < 1440
                    ? "321px"
                    : undefined,
              }}
            >
              Categories
            </div>
          </div>

          <div className="frame-419">
            <div className="frame-420">
              <div className="frame-421">
                <div className="frame-422">
                  <img
                    className="img-21"
                    alt="Cube svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/cube-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/cube-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-423">
                  <div className="text-wrapper-276">3D</div>
                </div>
              </div>

              <div className="frame-421">
                <div className="frame-422">
                  <img
                    className="img-21"
                    alt="Roblox svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/roblox-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/roblox-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">Roblox</div>
                </div>
              </div>

              <div className="frame-421">
                <div className="frame-422">
                  <div className="img-21">
                    <img
                      className="group-5"
                      alt="Group"
                      src={
                        screenWidth < 393
                          ? "/img/group-12.png"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/group-15.png"
                            : undefined
                      }
                    />
                  </div>
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">Crafts</div>
                </div>
              </div>
            </div>

            <div className="frame-425">
              <div className="frame-421">
                <div className="frame-422">
                  <img
                    className="img-21"
                    alt="Music note svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/music-note-4-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/music-note-4-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-423">
                  <div className="text-wrapper-277">
                    Music &amp; Sound Design
                  </div>
                </div>
              </div>

              <div className="frame-421">
                <div className="frame-422">
                  <div className="img-21">
                    <div className="overlap-group-2">
                      <img
                        className="group-6"
                        alt="Group"
                        src={
                          screenWidth < 393
                            ? "/img/group-13.png"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/group-16.png"
                              : undefined
                        }
                      />

                      <img
                        className="vector-19"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-44.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-55.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-20"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-45.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-56.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-21"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-46.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-57.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-22"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-47.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-58.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-23"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-48.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-59.svg"
                              : undefined
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">Design</div>
                </div>
              </div>

              <div className="frame-421">
                <div className="frame-422">
                  <img
                    className="img-21"
                    alt="Check square svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/check-square-svgrepo-com-10.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/check-square-svgrepo-com-11.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">Drawing &amp; Painting</div>
                </div>
              </div>
            </div>

            <div className="frame-425">
              <div className="frame-421">
                <div className="frame-426">
                  <img
                    className="img-22"
                    alt="Book svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/book-svgrepo-com-4.png"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/book-svgrepo-com-5.png"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-423">
                  <div className="text-wrapper-276">Fiction Book</div>
                </div>
              </div>

              <div className="frame-421">
                <div className="frame-426">
                  <img
                    className="img-22"
                    alt="Gym svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/gym-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/gym-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">Fitness &amp; Health</div>
                </div>
              </div>

              <div className="frame-421">
                <div className="frame-426">
                  <img
                    className="img-22"
                    alt="Camera svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/camera-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/camera-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">Photography</div>
                </div>
              </div>
            </div>

            <div className="frame-425">
              <div className="frame-421">
                <div className="frame-426">
                  <img
                    className="img-22"
                    alt="Pen square svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/pen-square-svgrepo-com-10.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/pen-square-svgrepo-com-11.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-423">
                  <div className="text-wrapper-277">
                    Writing &amp; Publishing
                  </div>
                </div>
              </div>

              <div className="frame-421">
                <div className="frame-426">
                  <img
                    className="img-22"
                    alt="Suitcase svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/suitcase-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/suitcase-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">Business &amp; Money</div>
                </div>
              </div>

              <div className="frame-421">
                <div className="frame-426">
                  <img
                    className="img-22"
                    alt="Film svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/film-02-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/film-02-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">Films</div>
                </div>
              </div>
            </div>

            <div className="frame-420">
              <div className="frame-421">
                <div className="frame-426">
                  <img
                    className="img-22"
                    alt="Book saved svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/book-saved-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/book-saved-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">
                    Comics &amp; Graphics...
                  </div>
                </div>
              </div>

              <div className="frame-427">
                <div className="frame-426">
                  <img
                    className="img-22"
                    alt="Mic svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/mic-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/mic-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">Audio</div>
                </div>
              </div>

              <div className="frame-427">
                <div className="frame-426">
                  <img
                    className="img-22"
                    alt="Music note svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/music-note-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/music-note-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-423">
                  <div className="text-wrapper-277">Recorded Music</div>
                </div>
              </div>
            </div>

            <div className="frame-420">
              <div className="frame-427">
                <div className="frame-426">
                  <img
                    className="img-22"
                    alt="Book svgrepo com"
                    src={
                      screenWidth < 393
                        ? "/img/book-1-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/book-1-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">Education</div>
                </div>
              </div>

              <div className="frame-427">
                <div className="frame-426">
                  <div className="img-22">
                    <div className="overlap-group-3">
                      <img
                        className="group-7"
                        alt="Group"
                        src={
                          screenWidth < 393
                            ? "/img/group-14.png"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/group-17.png"
                              : undefined
                        }
                      />

                      <img
                        className="vector-24"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-49.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-60.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-25"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-50.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-61.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-26"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-51.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-62.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-27"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-52.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-63.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-28"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-53.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-64.svg"
                              : undefined
                        }
                      />

                      <img
                        className="vector-29"
                        alt="Vector"
                        src={
                          screenWidth < 393
                            ? "/img/vector-54.svg"
                            : screenWidth >= 393 && screenWidth < 1440
                              ? "/img/vector-65.svg"
                              : undefined
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">Gaming</div>
                </div>
              </div>

              <div className="frame-421">
                <div className="frame-426">
                  <img
                    className="img-22"
                    alt="Code circle svgrepo"
                    src={
                      screenWidth < 393
                        ? "/img/code-circle-svgrepo-com-4.svg"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "/img/code-circle-svgrepo-com-5.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-424">
                  <div className="text-wrapper-277">Software Develop...</div>
                </div>
              </div>
            </div>
          </div>

          <div
            className="frame-428"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-5">
              {screenWidth < 393 && (
                <div className="frame-429">
                  <div className="navigation-menu-home-8">
                    <div className="navigation-menu-home-9">
                      <img
                        className="img-23"
                        alt="Home angle svgrepo"
                        src="/img/image.svg"
                      />

                      <div className="text-wrapper-278">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-9">
                    <SearchNormal24 className="img-24" color="#535353" />
                    <div className="text-wrapper-279">Search</div>
                  </div>

                  <div className="navigation-menu-9">
                    <img
                      className="img-24"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-280">Cart</div>
                  </div>

                  <div className="navigation-menu-9">
                    <img
                      className="img-24"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-5-2.svg"
                    />

                    <div className="text-wrapper-281">Help</div>
                  </div>

                  <div className="navigation-menu-9">
                    <img
                      className="image-23"
                      alt="Image"
                      src="/img/image.png"
                    />

                    <div className="text-wrapper-282">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1440 && (
                <>
                  <div className="navigation-menu-home-8">
                    <div className="navigation-menu-home-9">
                      <img
                        className="img-23"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-11.svg"
                      />

                      <div className="text-wrapper-278">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-10">
                    <SearchNormal24 className="img-23" color="#535353" />
                  </div>

                  <div className="navigation-menu-10">
                    <img
                      className="img-23"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-1.svg"
                    />
                  </div>

                  <div className="navigation-menu-10">
                    <div className="frame-430">
                      <div className="ellipse-5" />
                    </div>
                  </div>

                  <div className="navigation-menu-10">
                    <img
                      className="image-24"
                      alt="Image"
                      src="/img/image.png"
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-12"
            lineClassName={`${screenWidth < 393 && "class-71"} ${screenWidth >= 393 && screenWidth < 1440 && "class-72"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-431">
          <div className="frame-432">
            <div className="frame-433">
              <div className="frame-434">
                <div className="frame-435">
                  <div className="frame-436">
                    <div className="text-wrapper-283">LOGO</div>
                  </div>
                </div>

                <div className="frame-437">
                  <div className="frame-438">
                    <img
                      className="img-25"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-284">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-433">
                <div className="frame-433">
                  <div className="frame-439">
                    <div className="img-25">
                      <div className="vuesax-linear-gift-10">
                        <img
                          className="gift-12"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-285">Products</div>
                  </div>

                  <div className="frame-439">
                    <img
                      className="img-25"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-285">Collaborators</div>
                  </div>

                  <div className="frame-439">
                    <img
                      className="img-25"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-285">Checkout</div>
                  </div>

                  <div className="frame-439">
                    <img
                      className="img-25"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-285">Emails</div>
                  </div>

                  <div className="frame-439">
                    <img
                      className="img-25"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-285">Workflows</div>
                  </div>

                  <div className="frame-439">
                    <img
                      className="img-25"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-285">Sales</div>
                  </div>

                  <div className="frame-439">
                    <img
                      className="img-25"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-285">Analytics</div>
                  </div>

                  <div className="frame-439">
                    <img
                      className="img-25"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-285">Payouts</div>
                  </div>

                  <div className="frame-439">
                    <img
                      className="img-25"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-285">Library</div>
                  </div>
                </div>

                <div className="frame-439">
                  <img
                    className="img-25"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-285">Settings</div>
                </div>

                <div className="frame-439">
                  <img
                    className="img-25"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com.svg"
                  />

                  <div className="text-wrapper-285">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-440">
            <div className="frame-441">
              <div className="frame-442">
                <div className="frame-443">
                  <div className="text-wrapper-286">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-444">
                <div className="text-wrapper-287">Login</div>
              </div>

              <div className="frame-445">
                <div className="text-wrapper-288">Sign Up</div>
              </div>
            </div>

            <div className="frame-446">
              <div className="frame-420">
                <div className="back-icon-button-11">
                  <div className="vuesax-outline-arrow-12" />
                </div>

                <div className="text-wrapper-289">Categories</div>
              </div>

              <div className="frame-447">
                <div className="frame-448">
                  <div className="frame-449">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Cube svgrepo com"
                        src="/img/cube-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-423">
                      <div className="text-wrapper-290">3D</div>
                    </div>
                  </div>

                  <div className="frame-449">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Roblox svgrepo com"
                        src="/img/roblox-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-424">
                      <div className="text-wrapper-291">Roblox</div>
                    </div>
                  </div>

                  <div className="frame-449">
                    <div className="frame-450">
                      <div className="img-26">
                        <img
                          className="group-8"
                          alt="Group"
                          src="/img/group-9.png"
                        />
                      </div>
                    </div>

                    <div className="frame-424">
                      <div className="text-wrapper-291">Crafts</div>
                    </div>
                  </div>

                  <div className="frame-449">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Music note svgrepo"
                        src="/img/music-note-4-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-423">
                      <div className="text-wrapper-290">
                        Music &amp; Sound Design
                      </div>
                    </div>
                  </div>

                  <div className="frame-449">
                    <div className="frame-450">
                      <div className="img-26">
                        <div className="overlap-group-4">
                          <img
                            className="group-9"
                            alt="Group"
                            src="/img/group-10.png"
                          />

                          <img
                            className="vector-30"
                            alt="Vector"
                            src="/img/vector-33.svg"
                          />

                          <img
                            className="vector-31"
                            alt="Vector"
                            src="/img/vector-34.svg"
                          />

                          <img
                            className="vector-32"
                            alt="Vector"
                            src="/img/vector-35.svg"
                          />

                          <img
                            className="vector-33"
                            alt="Vector"
                            src="/img/vector-36.svg"
                          />

                          <img
                            className="vector-34"
                            alt="Vector"
                            src="/img/vector-37.svg"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="frame-424">
                      <div className="text-wrapper-291">Design</div>
                    </div>
                  </div>
                </div>

                <div className="frame-448">
                  <div className="frame-449">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Check square svgrepo"
                        src="/img/check-square-svgrepo-com-9.svg"
                      />
                    </div>

                    <div className="frame-424">
                      <div className="text-wrapper-291">
                        Drawing &amp; Painting
                      </div>
                    </div>
                  </div>

                  <div className="frame-449">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Book svgrepo com"
                        src="/img/book-svgrepo-com-3.png"
                      />
                    </div>

                    <div className="frame-423">
                      <div className="text-wrapper-290">Fiction Book</div>
                    </div>
                  </div>

                  <div className="frame-449">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Gym svgrepo com"
                        src="/img/gym-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-424">
                      <div className="fitness-health">Fitness &amp; Health</div>
                    </div>
                  </div>

                  <div className="frame-449">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Camera svgrepo com"
                        src="/img/camera-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-424">
                      <div className="text-wrapper-291">Photography</div>
                    </div>
                  </div>

                  <div className="frame-449">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Pen square svgrepo"
                        src="/img/pen-square-svgrepo-com-9.svg"
                      />
                    </div>

                    <div className="frame-423">
                      <div className="writing-publishing">
                        Writing &amp; Publishing
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-448">
                  <div className="frame-449">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Suitcase svgrepo com"
                        src="/img/suitcase-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-424">
                      <div className="text-wrapper-291">
                        Business &amp; Money
                      </div>
                    </div>
                  </div>

                  <div className="frame-449">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Film svgrepo com"
                        src="/img/film-02-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-424">
                      <div className="text-wrapper-291">FIlms</div>
                    </div>
                  </div>

                  <div className="frame-449">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Book saved svgrepo"
                        src="/img/book-saved-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-424">
                      <div className="text-wrapper-291">
                        Comics &amp; Graphics...
                      </div>
                    </div>
                  </div>

                  <div className="frame-451">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Mic svgrepo com"
                        src="/img/mic-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-424">
                      <div className="text-wrapper-291">Audio</div>
                    </div>
                  </div>

                  <div className="frame-451">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Music note svgrepo"
                        src="/img/music-note-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-423">
                      <div className="text-wrapper-290">Recorded Music</div>
                    </div>
                  </div>
                </div>

                <div className="frame-452">
                  <div className="frame-453">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Book svgrepo com"
                        src="/img/book-1-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-424">
                      <div className="text-wrapper-291">Education</div>
                    </div>
                  </div>

                  <div className="frame-453">
                    <div className="frame-450">
                      <div className="img-26">
                        <div className="overlap-group-5">
                          <img
                            className="group-10"
                            alt="Group"
                            src="/img/group-11.png"
                          />

                          <img
                            className="vector-35"
                            alt="Vector"
                            src="/img/vector-38.svg"
                          />

                          <img
                            className="vector-36"
                            alt="Vector"
                            src="/img/vector-39.svg"
                          />

                          <img
                            className="vector-37"
                            alt="Vector"
                            src="/img/vector-40.svg"
                          />

                          <img
                            className="vector-38"
                            alt="Vector"
                            src="/img/vector-41.svg"
                          />

                          <img
                            className="vector-39"
                            alt="Vector"
                            src="/img/vector-42.svg"
                          />

                          <img
                            className="vector-40"
                            alt="Vector"
                            src="/img/vector-43.svg"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="frame-424">
                      <div className="text-wrapper-291">Gaming</div>
                    </div>
                  </div>

                  <div className="frame-454">
                    <div className="frame-450">
                      <img
                        className="img-26"
                        alt="Code circle svgrepo"
                        src="/img/code-circle-svgrepo-com-3.svg"
                      />
                    </div>

                    <div className="frame-424">
                      <div className="text-wrapper-291">
                        Software Develop...
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
