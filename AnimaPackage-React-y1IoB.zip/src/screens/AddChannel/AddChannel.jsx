import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal38 } from "../../icons/SearchNormal38";
import "./style.css";

export const AddChannel = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="add-channel"
      style={{
        alignItems:
          screenWidth < 1440
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1440
            ? "var(--variable-collection-white-duplicate)"
            : screenWidth >= 1440
              ? "var(--variable-collection-fill-duplicate)"
              : undefined,
        flexDirection: screenWidth < 1440 ? "column" : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minWidth:
          screenWidth < 1440
            ? "320px"
            : screenWidth >= 1440
              ? "1440px"
              : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
      }}
    >
      {screenWidth < 1440 && (
        <>
          <StatusBar
            batteryClassName="status-bar-14"
            className="status-bar-11"
            combinedShape="/img/combined-shape-20.svg"
            containerClassName="status-bar-13"
            property1="dark"
            rectangleClassName="status-bar-15"
            timeClassName="status-bar-12"
            wiFi="/img/wi-fi-2.svg"
          />
          <div className="frame-40">
            <div className="back-icon-button-3">
              <div className="vuesax-outline-arrow-2" />
            </div>

            <div className="frame-41">
              <div className="text-wrapper-25">Channel</div>
            </div>
          </div>

          <div className="frame-42">
            <div className="frame-43">
              <div className="frame-44">
                <div className="text-wrapper-26">Channel</div>

                <img
                  className="vector-7"
                  alt="Vector"
                  src="/img/vector-1-38.svg"
                />
              </div>

              <div className="frame-44">
                <div className="text-wrapper-27">Reviews</div>

                <img
                  className="vector-8"
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>
            </div>

            <div className="frame-45">
              <div className="back-icon-button-wrapper">
                <div className="plus-large-svgrepo-wrapper">
                  <img
                    className="img-3"
                    alt="Plus large svgrepo"
                    src="/img/plus-large-svgrepo-com-12.svg"
                  />
                </div>
              </div>

              <div className="frame-46">
                <div className="text-wrapper-28">Add Content</div>

                <p className="turn-your-creativity">
                  Turn your creativity into profit by adding and selling
                  your&nbsp;&nbsp;content effortlessly.
                </p>
              </div>

              <div className="frame-47">
                <div className="text-wrapper-29">Add Content</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-5"
            lineClassName="home-indicator-6"
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-48">
          <div className="frame-49">
            <div className="frame-50">
              <div className="frame-51">
                <div className="frame-52">
                  <div className="frame-53">
                    <div className="text-wrapper-30">LOGO</div>
                  </div>
                </div>
              </div>

              <div className="frame-50">
                <div className="frame-54">
                  <div className="frame-55">
                    <div className="frame-56">
                      <div className="frame-57">
                        <img
                          className="img-3"
                          alt="Home svgrepo com"
                          src="/img/home-svgrepo-com-4.svg"
                        />

                        <div className="text-wrapper-31">Home</div>
                      </div>

                      <div className="frame-57">
                        <img
                          className="img-4"
                          alt="Security safe"
                          src="/img/security-safe-svgrepo-com-2.svg"
                        />

                        <div className="text-wrapper-32">Security</div>
                      </div>

                      <div className="frame-57">
                        <div className="img-4">
                          <div className="gift-wrapper">
                            <img
                              className="gift-3"
                              alt="Gift"
                              src="/img/gift-6.png"
                            />
                          </div>
                        </div>

                        <div className="text-wrapper-33">Products</div>
                      </div>

                      <div className="frame-57">
                        <img
                          className="img-4"
                          alt="Advertising svgrepo"
                          src="/img/advertising-svgrepo-com-2.svg"
                        />

                        <div className="text-wrapper-32">Marketing</div>
                      </div>

                      <div className="frame-57">
                        <img
                          className="img-4"
                          alt="Cart large svgrepo"
                          src="/img/cart-large-4-svgrepo-com-2.svg"
                        />

                        <div className="text-wrapper-32">Your Store</div>
                      </div>

                      <div className="frame-57">
                        <img
                          className="img-4"
                          alt="People svgrepo com"
                          src="/img/people-svgrepo-com-4.svg"
                        />

                        <div className="text-wrapper-32">Collaborators</div>
                      </div>

                      <div className="frame-57">
                        <div className="group-6" />

                        <div className="text-wrapper-32">Checkout</div>
                      </div>

                      <div className="frame-57">
                        <div className="img-4">
                          <div className="page-wrapper">
                            <div className="page-2" />
                          </div>
                        </div>

                        <div className="text-wrapper-32">Emails</div>
                      </div>

                      <div className="frame-57">
                        <img
                          className="img-4"
                          alt="Flow parallel"
                          src="/img/flow-parallel-svgrepo-com-14.svg"
                        />

                        <div className="text-wrapper-32">Workflows</div>
                      </div>

                      <div className="frame-57">
                        <img
                          className="img-4"
                          alt="Coin svgrepo com"
                          src="/img/coin-svgrepo-com-9.svg"
                        />

                        <div className="text-wrapper-32">Sales</div>
                      </div>

                      <div className="frame-57">
                        <img
                          className="img-4"
                          alt="Graph svgrepo com"
                          src="/img/graph-svgrepo-com.svg"
                        />

                        <div className="text-wrapper-32">Analytics</div>
                      </div>

                      <div className="frame-57">
                        <img
                          className="img-4"
                          alt="Coin svgrepo com"
                          src="/img/coin-svgrepo-com-9.svg"
                        />

                        <div className="text-wrapper-32">Payouts</div>
                      </div>

                      <div className="frame-57">
                        <img
                          className="img-4"
                          alt="Book bookmark"
                          src="/img/book-bookmark-minimalistic-svgrepo-com-14.svg"
                        />

                        <div className="text-wrapper-32">Library</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-57">
                  <img
                    className="img-4"
                    alt="Setting svgrepo"
                    src="/img/setting-2-svgrepo-com-2.svg"
                  />

                  <div className="text-wrapper-32">Settings</div>
                </div>

                <div className="frame-57">
                  <img
                    className="img-4"
                    alt="Open book svgrepo"
                    src="/img/open-book-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-32">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-58">
            <div className="frame-59">
              <div className="frame-60">
                <div className="frame-61">
                  <div className="text-wrapper-34">Real Estate</div>

                  <SearchNormal38 className="expand-more" color="#292929" />
                </div>
              </div>

              <div className="back-icon-button-4">
                <div className="img-4">
                  <div className="notification-wrapper">
                    <div className="group-wrapper">
                      <img
                        className="group-7"
                        alt="Group"
                        src="/img/group-33845-6.png"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="back-icon-button-4">
                <img
                  className="img-4"
                  alt="Messenger fill"
                  src="/img/messenger-fill-svgrepo-com-5-3.svg"
                />
              </div>

              <div className="frame-62">
                <div className="frame-63">
                  <img
                    className="ellipse-2"
                    alt="Ellipse"
                    src="/img/ellipse-52.png"
                  />

                  <div className="frame-64">
                    <div className="text-wrapper-35">Lenny White</div>
                  </div>
                </div>

                <img
                  className="expand-more"
                  alt="Expand more"
                  src="/img/expand-more-5-4.svg"
                />
              </div>
            </div>

            <div className="frame-65">
              <div className="frame-66">
                <div className="back-icon-button-3">
                  <div className="vuesax-outline-arrow-2" />
                </div>

                <div className="frame-67">
                  <div className="text-wrapper-36">Channel</div>

                  <div className="text-wrapper-37">9 Products</div>
                </div>
              </div>

              <div className="frame-43">
                <div className="frame-44">
                  <div className="text-wrapper-26">Channel</div>

                  <img
                    className="vector-7"
                    alt="Vector"
                    src="/img/vector-1-36.svg"
                  />
                </div>

                <div className="frame-44">
                  <div className="text-wrapper-27">Reviews</div>

                  <img
                    className="vector-9"
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>
              </div>

              <div className="frame-68">
                <div className="back-icon-button-wrapper">
                  <div className="plus-large-svgrepo-wrapper">
                    <img
                      className="img-3"
                      alt="Plus large svgrepo"
                      src="/img/plus-large-svgrepo-com-6.svg"
                    />
                  </div>
                </div>

                <div className="frame-46">
                  <div className="text-wrapper-28">Add Content</div>

                  <p className="turn-your-creativity">
                    Turn your creativity into profit by adding and selling
                    your&nbsp;&nbsp;Content effortlessly.
                  </p>
                </div>

                <div className="frame-47">
                  <div className="text-wrapper-29">Add Content</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
