import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const Reviews = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="reviews"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "100vh" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-83"} ${screenWidth >= 393 && screenWidth < 1440 && "class-84"}`}
            className={`${screenWidth < 393 && "class-81"} ${screenWidth >= 393 && screenWidth < 1440 && "class-82"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-20-2.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-21.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-85"} ${screenWidth >= 393 && screenWidth < 1440 && "class-86"}`}
            property1="dark"
            wiFi="/img/wi-fi-20.svg"
          />
          <div className="frame-916">
            <div className="back-icon-button-40">
              <div className="vuesax-outline-arrow-22" />
            </div>

            <div className="frame-917">
              <div className="text-wrapper-457">Products</div>

              <div className="text-wrapper-458">9 Products</div>
            </div>
          </div>

          <div className="frame-918">
            <div className="frame-919">
              <div className="frame-920">
                <div className="div-13">Products</div>

                <img
                  className="vector-153"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-62258.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44796.00px"
                          : undefined,
                  }}
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>

              <div className="frame-920">
                <div className="div-13">Collaborators</div>

                <img
                  className="vector-154"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-62336.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44874.00px"
                          : undefined,
                  }}
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>

              <div className="frame-920">
                <div className="text-wrapper-459">Reviews</div>

                <img
                  className="vector-155"
                  alt="Vector"
                  src={
                    screenWidth < 393
                      ? "/img/vector-1-32.svg"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "/img/vector-1-35.svg"
                        : undefined
                  }
                />
              </div>
            </div>

            <div className="user-opinion-4">
              <div className="opinion-content-2">
                <div className="frame-921">
                  <div className="frame-922">
                    <img
                      className="image-53"
                      alt="Image"
                      src="/img/image-5-3.png"
                    />

                    <div className="user-name-2">Aiden Harris</div>
                  </div>

                  <div className="date-of-adding-4">April 2, 2025</div>
                </div>

                <div className="frame-923">
                  <img
                    className="image-53"
                    alt="Image"
                    src="/img/image-11.png"
                  />

                  <div className="text-wrapper-460">
                    Real Estate Landing Page
                  </div>
                </div>

                <div className="review-3">
                  <div className="opinion-stars-2">
                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-17.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-32.svg"
                            : undefined
                      }
                    />

                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-18-2.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-33.svg"
                            : undefined
                      }
                    />

                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-19.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-34.svg"
                            : undefined
                      }
                    />

                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-20-2.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-35.svg"
                            : undefined
                      }
                    />

                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-21-2.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-36.svg"
                            : undefined
                      }
                    />
                  </div>

                  <div className="average-review-value-4">
                    <div className="average-review-value-5">5.0</div>
                  </div>
                </div>

                <p className="opinion-content-3">
                  I recently used this Real Estate Landing Page template for my
                  property listings, and I couldn&#39;t be more impressed! The
                  design is sleek, modern, and highly professional, making it
                  easy for potential buyers to navigate and find the information
                  they need quickly.
                </p>
              </div>

              <div className="likes-wrapper">
                <div className="likes-2">
                  <div className="text-button-2">
                    <img
                      className="img-50"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-6.svg"
                    />

                    <button className="button-2">114</button>
                  </div>

                  <div className="text-button-2">
                    <img
                      className="img-50"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-7.svg"
                    />

                    <button className="button-2">5</button>
                  </div>
                </div>
              </div>

              <div className="frame-924">
                <img
                  className="image-53"
                  alt="Image"
                  src="/img/image-7-2.png"
                />

                <div className="frame-925">
                  <div className="frame-926">
                    <div className="text-wrapper-461">Reply</div>

                    <img
                      className="img-50"
                      alt="Send svgrepo com"
                      src={
                        screenWidth < 393
                          ? "/img/send-svgrepo-com-3-2.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/send-svgrepo-com-6.svg"
                            : undefined
                      }
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="user-opinion-4">
              <div className="opinion-content-2">
                <div className="frame-927">
                  <div className="frame-928">
                    <div
                      className="frame-929"
                      style={{
                        marginRight: screenWidth < 393 ? "-15.00px" : undefined,
                      }}
                    >
                      <img
                        className="image-53"
                        alt="Image"
                        src="/img/image-5-3.png"
                      />

                      <div className="user-name-2">Samantha Evans</div>
                    </div>

                    <div
                      className="review-4"
                      style={{
                        marginRight: screenWidth < 393 ? "-51.00px" : undefined,
                      }}
                    >
                      <div className="average-review-value-4">
                        <div className="average-review-value-5">5.0</div>
                      </div>
                    </div>
                  </div>

                  <div className="date-of-adding-5">April 2, 2025</div>
                </div>

                <div className="frame-923">
                  <img className="img-50" alt="Image" src="/img/image-12.png" />

                  <div className="text-wrapper-460">
                    Business Pro Landing Page
                  </div>
                </div>

                <div className="review-3">
                  <div className="opinion-stars-2">
                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-22.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-37.svg"
                            : undefined
                      }
                    />

                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-23-2.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-38.svg"
                            : undefined
                      }
                    />

                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-24-2.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-39.svg"
                            : undefined
                      }
                    />

                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-25-2.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-40.svg"
                            : undefined
                      }
                    />

                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/image.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-41.svg"
                            : undefined
                      }
                    />
                  </div>

                  <div className="average-review-value-4">
                    <div className="average-review-value-5">5.0</div>
                  </div>
                </div>

                <p className="opinion-content-3">
                  The Business Pro Landing Page has completely transformed the
                  way I present my business online. It’s sleek, professional,
                  and most importantly, highly effective at converting visitors
                  into leads. This page is perfect for startups and businesses
                  looking to make a strong first impression!
                </p>
              </div>

              <div className="likes-wrapper">
                <div className="likes-2">
                  <div className="text-button-2">
                    <img
                      className="img-50"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-6.svg"
                    />

                    <button className="button-2">114</button>
                  </div>

                  <div className="text-button-2">
                    <img
                      className="img-50"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-7.svg"
                    />

                    <button className="button-2">5</button>
                  </div>
                </div>
              </div>

              <div className="frame-924">
                <img
                  className="image-53"
                  alt="Image"
                  src="/img/image-7-2.png"
                />

                <div className="frame-925">
                  <div className="frame-926">
                    <div className="text-wrapper-461">Reply</div>

                    <img
                      className="img-50"
                      alt="Send svgrepo com"
                      src={
                        screenWidth < 393
                          ? "/img/send-svgrepo-com-4.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/send-svgrepo-com-7-2.svg"
                            : undefined
                      }
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="user-opinion-4">
              <div className="opinion-content-2">
                <div className="frame-927">
                  <div className="frame-928">
                    <div className="frame-930">
                      <img
                        className="image-53"
                        alt="Image"
                        src="/img/image-5-3.png"
                      />

                      <div className="user-name-2">Ella Cooper</div>
                    </div>
                  </div>

                  <div className="date-of-adding-5">April 2, 2025</div>
                </div>

                <div className="frame-923">
                  <img
                    className="image-53"
                    alt="Image"
                    src="/img/image-13.png"
                  />

                  <div className="text-wrapper-460">SaaS Starter Page</div>
                </div>

                <div className="review-5">
                  <div className="opinion-stars-2">
                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-27.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-42.svg"
                            : undefined
                      }
                    />

                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-28-2.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-43.svg"
                            : undefined
                      }
                    />

                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-29-2.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-44.svg"
                            : undefined
                      }
                    />

                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-30.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-45.svg"
                            : undefined
                      }
                    />

                    <img
                      className="star-outline"
                      alt="Star outline"
                      src={
                        screenWidth < 393
                          ? "/img/star-outline-31.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/star-outline-46.svg"
                            : undefined
                      }
                    />
                  </div>

                  <div className="average-review-value-4">
                    <div className="average-review-value-6">4.0</div>
                  </div>
                </div>

                <p className="opinion-content-3">
                  The SaaS Starter Page is exactly what I needed to showcase my
                  software product in a clean, professional, and high-converting
                  way. From the layout to the functionality, everything is
                  designed to attract users and drive sign-ups!
                </p>
              </div>

              <div className="likes-wrapper">
                <div className="likes-2">
                  <div className="text-button-2">
                    <img
                      className="img-50"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-6.svg"
                    />

                    <button className="button-2">114</button>
                  </div>

                  <div className="text-button-2">
                    <img
                      className="img-50"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-7.svg"
                    />

                    <button className="button-2">5</button>
                  </div>
                </div>
              </div>

              <div className="frame-924">
                <img
                  className="image-53"
                  alt="Image"
                  src="/img/image-7-2.png"
                />

                <div className="frame-925">
                  <div className="frame-926">
                    <div className="text-wrapper-461">Reply</div>

                    <img
                      className="img-50"
                      alt="Send svgrepo com"
                      src={
                        screenWidth < 393
                          ? "/img/send-svgrepo-com-5-2.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/send-svgrepo-com-8.svg"
                            : undefined
                      }
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            className="frame-931"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-18">
              {screenWidth < 393 && (
                <div className="frame-932">
                  <div className="navigation-menu-home-16">
                    <div className="navigation-menu-home-17">
                      <img
                        className="img-50"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-462">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-24">
                    <SearchNormal property1="linear" />
                    <div className="text-wrapper-463">Search</div>
                  </div>

                  <div className="navigation-menu-24">
                    <img
                      className="img-51"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-464">Cart</div>
                  </div>

                  <div className="navigation-menu-24">
                    <img
                      className="img-51"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-3.svg"
                    />

                    <div className="text-wrapper-465">Help</div>
                  </div>

                  <div className="navigation-menu-24">
                    <img
                      className="image-54"
                      alt="Image"
                      src="/img/image-6.png"
                    />

                    <div className="text-wrapper-466">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1440 && (
                <>
                  <div className="navigation-menu-home-16">
                    <div className="navigation-menu-home-17">
                      <img
                        className="img-50"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-15.svg"
                      />

                      <div className="text-wrapper-462">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-25">
                    <SearchNormal property1="linear" />
                  </div>

                  <div className="navigation-menu-25">
                    <img
                      className="img-50"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-7.svg"
                    />
                  </div>

                  <div className="navigation-menu-25">
                    <div className="frame-933">
                      <div className="ellipse-38" />
                    </div>
                  </div>

                  <div className="navigation-menu-25">
                    <img
                      className="image-53"
                      alt="Image"
                      src="/img/image-6.png"
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-41"
            lineClassName={`${screenWidth < 393 && "class-87"} ${screenWidth >= 393 && screenWidth < 1440 && "class-88"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-934">
          <div className="frame-935">
            <div className="frame-936">
              <div className="frame-937">
                <div className="frame-938">
                  <div className="frame-939">
                    <div className="text-wrapper-467">LOGO</div>
                  </div>
                </div>

                <div className="frame-940">
                  <div className="frame-941">
                    <img
                      className="img-52"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-10.svg"
                    />

                    <div className="text-wrapper-468">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-936">
                <div className="frame-936">
                  <div className="frame-942">
                    <div className="img-52">
                      <div className="vuesax-linear-gift-19">
                        <img
                          className="gift-29"
                          alt="Gift"
                          src="/img/gift-9.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-469">Products</div>
                  </div>

                  <div className="frame-942">
                    <img
                      className="img-52"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-6-2.svg"
                    />

                    <div className="text-wrapper-469">Collaborators</div>
                  </div>

                  <div className="frame-942">
                    <img
                      className="img-52"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-6-3.svg"
                    />

                    <div className="text-wrapper-469">Checkout</div>
                  </div>

                  <div className="frame-942">
                    <img
                      className="img-52"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-469">Emails</div>
                  </div>

                  <div className="frame-942">
                    <img
                      className="img-52"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-6-2.svg"
                    />

                    <div className="text-wrapper-469">Workflows</div>
                  </div>

                  <div className="frame-942">
                    <img
                      className="img-52"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12-2.svg"
                    />

                    <div className="text-wrapper-469">Sales</div>
                  </div>

                  <div className="frame-942">
                    <img
                      className="img-52"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-469">Analytics</div>
                  </div>

                  <div className="frame-942">
                    <img
                      className="img-52"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12-2.svg"
                    />

                    <div className="text-wrapper-469">Payouts</div>
                  </div>

                  <div className="frame-942">
                    <img
                      className="img-52"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-469">Library</div>
                  </div>
                </div>

                <div className="frame-942">
                  <img
                    className="img-52"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-469">Settings</div>
                </div>

                <div className="frame-942">
                  <img
                    className="img-52"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-469">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-943">
            <div className="frame-944">
              <div className="frame-945">
                <div className="frame-946">
                  <div className="text-wrapper-470">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-947">
                <div className="text-wrapper-471">Login</div>
              </div>

              <div className="frame-948">
                <div className="text-wrapper-472">Sign Up</div>
              </div>
            </div>

            <div className="frame-949">
              <div className="frame-950">
                <div className="back-icon-button-40">
                  <div className="vuesax-outline-arrow-22" />
                </div>

                <div className="frame-951">
                  <div className="text-wrapper-473">Products</div>

                  <div className="text-wrapper-458">9 Products</div>
                </div>
              </div>

              <div className="frame-919">
                <div className="frame-920">
                  <div className="div-13">Products</div>

                  <img
                    className="vector-156"
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-920">
                  <p className="div-13">
                    <span className="text-wrapper-474">Collaborators</span>

                    <span className="text-wrapper-475">&nbsp;</span>
                  </p>

                  <img
                    className="vector-157"
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-920">
                  <div className="text-wrapper-459">Reviews</div>

                  <img
                    className="vector-155"
                    alt="Vector"
                    src="/img/vector-1-29.svg"
                  />
                </div>
              </div>

              <div className="user-opinion-5">
                <div className="opinion-content-2">
                  <div className="frame-927">
                    <div className="frame-928">
                      <div className="frame-952">
                        <img
                          className="image-55"
                          alt="Image"
                          src="/img/image-3.png"
                        />

                        <div className="user-name-2">Aiden Harris</div>
                      </div>

                      <div className="review-6">
                        <div className="opinion-stars-2">
                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-1-2.svg"
                          />

                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-2-2.svg"
                          />

                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-3.svg"
                          />

                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-4.svg"
                          />

                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-5.svg"
                          />
                        </div>

                        <div className="average-review-value-4">
                          <div className="average-review-value-5">5.0</div>
                        </div>
                      </div>
                    </div>

                    <div className="date-of-adding-6">April 2, 2025</div>
                  </div>

                  <div className="frame-923">
                    <img
                      className="image-55"
                      alt="Image"
                      src="/img/image-8-2x.png"
                    />

                    <div className="text-wrapper-460">
                      Real Estate Landing Page
                    </div>
                  </div>

                  <p className="opinion-content-3">
                    I recently used this Real Estate Landing Page template for
                    my property listings, and I couldn&#39;t be more impressed!
                    The design is sleek, modern, and highly professional, making
                    it easy for potential buyers to navigate and find the
                    information they need quickly.
                  </p>
                </div>

                <div className="likes-wrapper">
                  <div className="likes-2">
                    <div className="text-button-2">
                      <img
                        className="img-50"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com.svg"
                      />

                      <button className="button-2">114</button>
                    </div>

                    <div className="text-button-2">
                      <img
                        className="img-50"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com-1.svg"
                      />

                      <button className="button-2">5</button>
                    </div>
                  </div>
                </div>

                <div className="frame-924">
                  <img
                    className="image-55"
                    alt="Image"
                    src="/img/image-4-3.png"
                  />

                  <div className="frame-953">
                    <div className="frame-926">
                      <div className="text-wrapper-461">Reply</div>

                      <img
                        className="img-50"
                        alt="Send svgrepo com"
                        src="/img/send-svgrepo-com.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="user-opinion-5">
                <div className="opinion-content-2">
                  <div className="frame-927">
                    <div className="frame-928">
                      <div className="frame-954">
                        <img
                          className="image-55"
                          alt="Image"
                          src="/img/image-3.png"
                        />

                        <div className="user-name-2">Samantha Evans</div>
                      </div>

                      <div className="review-7">
                        <div className="opinion-stars-2">
                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-6.svg"
                          />

                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-7.svg"
                          />

                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-8-2.svg"
                          />

                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-9-2.svg"
                          />

                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-10-2.svg"
                          />
                        </div>

                        <div className="average-review-value-4">
                          <div className="average-review-value-5">5.0</div>
                        </div>
                      </div>
                    </div>

                    <div className="date-of-adding-6">April 2, 2025</div>
                  </div>

                  <div className="frame-923">
                    <img
                      className="image-56"
                      alt="Image"
                      src="/img/image-9-2x.png"
                    />

                    <div className="text-wrapper-460">
                      Business Pro Landing Page
                    </div>
                  </div>

                  <p className="opinion-content-3">
                    The Business Pro Landing Page has completely transformed the
                    way I present my business online. It’s sleek, professional,
                    and most importantly, highly effective at converting
                    visitors into leads. This page is perfect for startups and
                    businesses looking to make a strong first impression!
                  </p>
                </div>

                <div className="likes-wrapper">
                  <div className="likes-2">
                    <div className="text-button-2">
                      <img
                        className="img-50"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com.svg"
                      />

                      <button className="button-2">114</button>
                    </div>

                    <div className="text-button-2">
                      <img
                        className="img-50"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com-1.svg"
                      />

                      <button className="button-2">5</button>
                    </div>
                  </div>
                </div>

                <div className="frame-924">
                  <img
                    className="image-55"
                    alt="Image"
                    src="/img/image-4-3.png"
                  />

                  <div className="frame-953">
                    <div className="frame-926">
                      <div className="text-wrapper-461">Reply</div>

                      <img
                        className="img-50"
                        alt="Send svgrepo com"
                        src="/img/send-svgrepo-com-1-2.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="user-opinion-6">
                <div className="opinion-content-2">
                  <div className="frame-927">
                    <div className="frame-928">
                      <div className="frame-955">
                        <img
                          className="image-55"
                          alt="Image"
                          src="/img/image-3.png"
                        />

                        <div className="user-name-2">Ella Cooper</div>
                      </div>

                      <div className="review-8">
                        <div className="opinion-stars-2">
                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-11-2.svg"
                          />

                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-12.svg"
                          />

                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-13-2.svg"
                          />

                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-14-2.svg"
                          />

                          <img
                            className="star-outline"
                            alt="Star outline"
                            src="/img/star-outline-15.svg"
                          />
                        </div>

                        <div className="average-review-value-4">
                          <div className="average-review-value-6">4.0</div>
                        </div>
                      </div>
                    </div>

                    <div className="date-of-adding-6">April 2, 2025</div>
                  </div>

                  <div className="frame-923">
                    <img
                      className="image-55"
                      alt="Image"
                      src="/img/image-10-2.png"
                    />

                    <div className="text-wrapper-460">SaaS Starter Page</div>
                  </div>

                  <p className="opinion-content-3">
                    The SaaS Starter Page is exactly what I needed to showcase
                    my software product in a clean, professional, and
                    high-converting way. From the layout to the functionality,
                    everything is designed to attract users and drive sign-ups!
                  </p>
                </div>

                <div className="likes-wrapper">
                  <div className="likes-2">
                    <div className="text-button-2">
                      <img
                        className="img-50"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com.svg"
                      />

                      <button className="button-2">114</button>
                    </div>

                    <div className="text-button-2">
                      <img
                        className="img-50"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com-1.svg"
                      />

                      <button className="button-2">5</button>
                    </div>
                  </div>
                </div>

                <div className="frame-924">
                  <img
                    className="image-55"
                    alt="Image"
                    src="/img/image-4-3.png"
                  />

                  <div className="frame-953">
                    <div className="frame-926">
                      <div className="text-wrapper-461">Reply</div>

                      <img
                        className="img-50"
                        alt="Send svgrepo com"
                        src="/img/send-svgrepo-com-2-2.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
