import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal24 } from "../../icons/SearchNormal24";
import { StarOutline11 } from "../../icons/StarOutline11";
import { StarOutline15 } from "../../icons/StarOutline15";
import { StarOutline41 } from "../../icons/StarOutline41";
import "./style.css";

export const Reviews = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="reviews"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "100vh" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-23"} ${screenWidth >= 393 && screenWidth < 1440 && "class-24"}`}
            className={`${screenWidth < 393 && "class-25"} ${screenWidth >= 393 && screenWidth < 1440 && "class-26"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-20.svg"
                : screenWidth >= 393 && screenWidth < 1440
                  ? "/img/combined-shape-21.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-27"} ${screenWidth >= 393 && screenWidth < 1440 && "class-28"}`}
            property1="dark"
            wiFi="/img/wi-fi-20.svg"
          />
          <div className="frame-171">
            <div className="back-icon-button-3">
              <div className="vuesax-outline-arrow-4" />
            </div>

            <div className="frame-172">
              <div className="text-wrapper-141">Products</div>

              <div className="text-wrapper-142">9 Products</div>
            </div>
          </div>

          <div className="frame-173">
            <div className="frame-174">
              <div className="frame-175">
                <div className="div-5">Products</div>

                <img
                  className="vector-11"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-62258.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44796.00px"
                          : undefined,
                  }}
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>

              <div className="frame-175">
                <div className="div-5">Collaborators</div>

                <img
                  className="vector-12"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-62336.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44874.00px"
                          : undefined,
                  }}
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>

              <div className="frame-175">
                <div className="text-wrapper-143">Reviews</div>

                <img
                  className="vector-13"
                  alt="Vector"
                  src={
                    screenWidth < 393
                      ? "/img/vector-1-32.svg"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "/img/vector-1-35.svg"
                        : undefined
                  }
                />
              </div>
            </div>

            <div className="user-opinion">
              <div className="opinion-content">
                <div className="frame-176">
                  <div className="frame-177">
                    <img
                      className="image-19"
                      alt="Image"
                      src="/img/image-5.png"
                    />

                    <div className="user-name">Aiden Harris</div>
                  </div>

                  <div className="date-of-adding">April 2, 2025</div>
                </div>

                <div className="frame-178">
                  <img
                    className="image-19"
                    alt="Image"
                    src="/img/image-11.png"
                  />

                  <div className="text-wrapper-144">
                    Real Estate Landing Page
                  </div>
                </div>

                <div className="review">
                  <div className="opinion-stars">
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6273)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2565)"
                            : undefined
                      }
                    />
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6274)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2566)"
                            : undefined
                      }
                    />
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6275)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2567)"
                            : undefined
                      }
                    />
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6276)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2568)"
                            : undefined
                      }
                    />
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6277)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2569)"
                            : undefined
                      }
                    />
                  </div>

                  <div className="average-review-value">
                    <div className="average-review-value-2">5.0</div>
                  </div>
                </div>

                <p className="opinion-content-2">
                  I recently used this Real Estate Landing Page template for my
                  property listings, and I couldn&#39;t be more impressed! The
                  design is sleek, modern, and highly professional, making it
                  easy for potential buyers to navigate and find the information
                  they need quickly.
                </p>
              </div>

              <div className="add-comment-and">
                <div className="likes">
                  <div className="text-button">
                    <img
                      className="img-11"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-6.svg"
                    />

                    <button className="button-2">114</button>
                  </div>

                  <div className="text-button">
                    <img
                      className="img-11"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-7.svg"
                    />

                    <button className="button-2">5</button>
                  </div>
                </div>
              </div>

              <div className="frame-179">
                <img className="image-19" alt="Image" src="/img/image-7.png" />

                <div className="frame-180">
                  <div className="frame-181">
                    <div className="text-wrapper-145">Reply</div>

                    <img
                      className="img-11"
                      alt="Send svgrepo com"
                      src={
                        screenWidth < 393
                          ? "/img/send-svgrepo-com-3.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/send-svgrepo-com-6.svg"
                            : undefined
                      }
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="user-opinion">
              <div className="opinion-content">
                <div className="frame-182">
                  <div className="frame-183">
                    <div
                      className="frame-184"
                      style={{
                        marginRight: screenWidth < 393 ? "-15.00px" : undefined,
                      }}
                    >
                      <img
                        className="image-19"
                        alt="Image"
                        src="/img/image-5.png"
                      />

                      <div className="user-name">Samantha Evans</div>
                    </div>

                    <div
                      className="average-review-value-wrapper"
                      style={{
                        marginRight: screenWidth < 393 ? "-51.00px" : undefined,
                      }}
                    >
                      <div className="average-review-value">
                        <div className="average-review-value-2">5.0</div>
                      </div>
                    </div>
                  </div>

                  <div className="date-of-adding-2">April 2, 2025</div>
                </div>

                <div className="frame-178">
                  <img className="img-11" alt="Image" src="/img/image-12.png" />

                  <div className="text-wrapper-144">
                    Business Pro Landing Page
                  </div>
                </div>

                <div className="review">
                  <div className="opinion-stars">
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6324)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2616)"
                            : undefined
                      }
                    />
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6325)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2617)"
                            : undefined
                      }
                    />
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6326)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2618)"
                            : undefined
                      }
                    />
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6327)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2619)"
                            : undefined
                      }
                    />
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6328)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2620)"
                            : undefined
                      }
                    />
                  </div>

                  <div className="average-review-value">
                    <div className="average-review-value-2">5.0</div>
                  </div>
                </div>

                <p className="opinion-content-2">
                  The Business Pro Landing Page has completely transformed the
                  way I present my business online. It’s sleek, professional,
                  and most importantly, highly effective at converting visitors
                  into leads. This page is perfect for startups and businesses
                  looking to make a strong first impression!
                </p>
              </div>

              <div className="add-comment-and">
                <div className="likes">
                  <div className="text-button">
                    <img
                      className="img-11"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-6.svg"
                    />

                    <button className="button-2">114</button>
                  </div>

                  <div className="text-button">
                    <img
                      className="img-11"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-7.svg"
                    />

                    <button className="button-2">5</button>
                  </div>
                </div>
              </div>

              <div className="frame-179">
                <img className="image-19" alt="Image" src="/img/image-7.png" />

                <div className="frame-180">
                  <div className="frame-181">
                    <div className="text-wrapper-145">Reply</div>

                    <img
                      className="img-11"
                      alt="Send svgrepo com"
                      src={
                        screenWidth < 393
                          ? "/img/send-svgrepo-com-4.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/send-svgrepo-com-7.svg"
                            : undefined
                      }
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="user-opinion">
              <div className="opinion-content">
                <div className="frame-182">
                  <div className="frame-183">
                    <div className="frame-185">
                      <img
                        className="image-19"
                        alt="Image"
                        src="/img/image-5.png"
                      />

                      <div className="user-name">Ella Cooper</div>
                    </div>
                  </div>

                  <div className="date-of-adding-2">April 2, 2025</div>
                </div>

                <div className="frame-178">
                  <img
                    className="image-19"
                    alt="Image"
                    src="/img/image-13.png"
                  />

                  <div className="text-wrapper-144">SaaS Starter Page</div>
                </div>

                <div className="review-2">
                  <div className="opinion-stars">
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6372)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2664)"
                            : undefined
                      }
                    />
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6373)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2665)"
                            : undefined
                      }
                    />
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6374)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2666)"
                            : undefined
                      }
                    />
                    <StarOutline41
                      className="instance-node-2"
                      color={
                        screenWidth < 393
                          ? "url(#paint0_linear_398_6375)"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "url(#paint0_linear_64_2667)"
                            : undefined
                      }
                    />
                    <StarOutline15 className="instance-node-2" />
                  </div>

                  <div className="average-review-value">
                    <div className="average-review-value-3">4.0</div>
                  </div>
                </div>

                <p className="opinion-content-2">
                  The SaaS Starter Page is exactly what I needed to showcase my
                  software product in a clean, professional, and high-converting
                  way. From the layout to the functionality, everything is
                  designed to attract users and drive sign-ups!
                </p>
              </div>

              <div className="add-comment-and">
                <div className="likes">
                  <div className="text-button">
                    <img
                      className="img-11"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-6.svg"
                    />

                    <button className="button-2">114</button>
                  </div>

                  <div className="text-button">
                    <img
                      className="img-11"
                      alt="Like svgrepo com"
                      src="/img/like-svgrepo-com-7.svg"
                    />

                    <button className="button-2">5</button>
                  </div>
                </div>
              </div>

              <div className="frame-179">
                <img className="image-19" alt="Image" src="/img/image-7.png" />

                <div className="frame-180">
                  <div className="frame-181">
                    <div className="text-wrapper-145">Reply</div>

                    <img
                      className="img-11"
                      alt="Send svgrepo com"
                      src={
                        screenWidth < 393
                          ? "/img/send-svgrepo-com-5.svg"
                          : screenWidth >= 393 && screenWidth < 1440
                            ? "/img/send-svgrepo-com-8.svg"
                            : undefined
                      }
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div
            className="frame-186"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-4">
              {screenWidth < 393 && (
                <div className="frame-187">
                  <div className="navigation-menu-home-6">
                    <div className="navigation-menu-home-7">
                      <img
                        className="img-11"
                        alt="Home angle svgrepo"
                        src="/img/image.svg"
                      />

                      <div className="text-wrapper-146">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-7">
                    <SearchNormal24 className="img-12" color="#535353" />
                    <div className="text-wrapper-147">Search</div>
                  </div>

                  <div className="navigation-menu-7">
                    <img
                      className="img-12"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-148">Cart</div>
                  </div>

                  <div className="navigation-menu-7">
                    <img
                      className="img-12"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-3.svg"
                    />

                    <div className="text-wrapper-149">Help</div>
                  </div>

                  <div className="navigation-menu-7">
                    <img
                      className="image-20"
                      alt="Image"
                      src="/img/image.png"
                    />

                    <div className="text-wrapper-150">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1440 && (
                <>
                  <div className="navigation-menu-home-6">
                    <div className="navigation-menu-home-7">
                      <img
                        className="img-11"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-11.svg"
                      />

                      <div className="text-wrapper-146">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-8">
                    <SearchNormal24 className="img-11" color="#535353" />
                  </div>

                  <div className="navigation-menu-8">
                    <img
                      className="img-11"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-7.svg"
                    />
                  </div>

                  <div className="navigation-menu-8">
                    <div className="frame-188">
                      <div className="ellipse-4" />
                    </div>
                  </div>

                  <div className="navigation-menu-8">
                    <img
                      className="image-19"
                      alt="Image"
                      src="/img/image.png"
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-4"
            lineClassName={`${screenWidth < 393 && "class-29"} ${screenWidth >= 393 && screenWidth < 1440 && "class-30"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-189">
          <div className="frame-190">
            <div className="frame-191">
              <div className="frame-192">
                <div className="frame-193">
                  <div className="frame-194">
                    <div className="text-wrapper-151">LOGO</div>
                  </div>
                </div>

                <div className="frame-195">
                  <div className="frame-196">
                    <img
                      className="img-13"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-10.svg"
                    />

                    <div className="text-wrapper-152">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-191">
                <div className="frame-191">
                  <div className="frame-197">
                    <div className="img-13">
                      <div className="vuesax-linear-gift-2">
                        <img
                          className="gift-4"
                          alt="Gift"
                          src="/img/gift.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-153">Products</div>
                  </div>

                  <div className="frame-197">
                    <img
                      className="img-13"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-153">Collaborators</div>
                  </div>

                  <div className="frame-197">
                    <img
                      className="img-13"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-153">Checkout</div>
                  </div>

                  <div className="frame-197">
                    <img
                      className="img-13"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-153">Emails</div>
                  </div>

                  <div className="frame-197">
                    <img
                      className="img-13"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-153">Workflows</div>
                  </div>

                  <div className="frame-197">
                    <img
                      className="img-13"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-153">Sales</div>
                  </div>

                  <div className="frame-197">
                    <img
                      className="img-13"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-153">Analytics</div>
                  </div>

                  <div className="frame-197">
                    <img
                      className="img-13"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-153">Payouts</div>
                  </div>

                  <div className="frame-197">
                    <img
                      className="img-13"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-153">Library</div>
                  </div>
                </div>

                <div className="frame-197">
                  <img
                    className="img-13"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-153">Settings</div>
                </div>

                <div className="frame-197">
                  <img
                    className="img-13"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-153">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-198">
            <div className="frame-199">
              <div className="frame-200">
                <div className="frame-201">
                  <div className="text-wrapper-154">Search</div>

                  <SearchNormal24 className="instance-node-2" color="#232323" />
                </div>
              </div>

              <div className="frame-202">
                <div className="text-wrapper-155">Login</div>
              </div>

              <div className="frame-203">
                <div className="text-wrapper-156">Sign Up</div>
              </div>
            </div>

            <div className="frame-204">
              <div className="frame-205">
                <div className="back-icon-button-3">
                  <div className="vuesax-outline-arrow-4" />
                </div>

                <div className="frame-206">
                  <div className="text-wrapper-157">Products</div>

                  <div className="text-wrapper-142">9 Products</div>
                </div>
              </div>

              <div className="frame-174">
                <div className="frame-175">
                  <div className="div-5">Products</div>

                  <img
                    className="vector-14"
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-175">
                  <p className="div-5">
                    <span className="span">Collaborators</span>

                    <span className="text-wrapper-158">&nbsp;</span>
                  </p>

                  <img
                    className="vector-15"
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-175">
                  <div className="text-wrapper-143">Reviews</div>

                  <img
                    className="vector-13"
                    alt="Vector"
                    src="/img/vector-1-29.svg"
                  />
                </div>
              </div>

              <div className="user-opinion-2">
                <div className="opinion-content">
                  <div className="frame-182">
                    <div className="frame-183">
                      <div className="frame-207">
                        <img
                          className="image-21"
                          alt="Image"
                          src="/img/image-3.png"
                        />

                        <div className="user-name">Aiden Harris</div>
                      </div>

                      <div className="review-3">
                        <div className="opinion-stars">
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4095)"
                          />
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4096)"
                          />
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4097)"
                          />
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4098)"
                          />
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4099)"
                          />
                        </div>

                        <div className="average-review-value">
                          <div className="average-review-value-2">5.0</div>
                        </div>
                      </div>
                    </div>

                    <div className="date-of-adding-3">April 2, 2025</div>
                  </div>

                  <div className="frame-178">
                    <img
                      className="image-21"
                      alt="Image"
                      src="/img/image-8.png"
                    />

                    <div className="text-wrapper-144">
                      Real Estate Landing Page
                    </div>
                  </div>

                  <p className="opinion-content-2">
                    I recently used this Real Estate Landing Page template for
                    my property listings, and I couldn&#39;t be more impressed!
                    The design is sleek, modern, and highly professional, making
                    it easy for potential buyers to navigate and find the
                    information they need quickly.
                  </p>
                </div>

                <div className="add-comment-and">
                  <div className="likes">
                    <div className="text-button">
                      <img
                        className="img-11"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com.svg"
                      />

                      <button className="button-2">114</button>
                    </div>

                    <div className="text-button">
                      <img
                        className="img-11"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com-1.svg"
                      />

                      <button className="button-2">5</button>
                    </div>
                  </div>
                </div>

                <div className="frame-179">
                  <img
                    className="image-21"
                    alt="Image"
                    src="/img/image-4.png"
                  />

                  <div className="frame-208">
                    <div className="frame-181">
                      <div className="text-wrapper-145">Reply</div>

                      <img
                        className="img-11"
                        alt="Send svgrepo com"
                        src="/img/send-svgrepo-com.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="user-opinion-2">
                <div className="opinion-content">
                  <div className="frame-182">
                    <div className="frame-183">
                      <div className="frame-209">
                        <img
                          className="image-21"
                          alt="Image"
                          src="/img/image-3.png"
                        />

                        <div className="user-name">Samantha Evans</div>
                      </div>

                      <div className="review-4">
                        <div className="opinion-stars">
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4143)"
                          />
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4144)"
                          />
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4145)"
                          />
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4146)"
                          />
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4147)"
                          />
                        </div>

                        <div className="average-review-value">
                          <div className="average-review-value-2">5.0</div>
                        </div>
                      </div>
                    </div>

                    <div className="date-of-adding-3">April 2, 2025</div>
                  </div>

                  <div className="frame-178">
                    <img
                      className="image-22"
                      alt="Image"
                      src="/img/image-9.png"
                    />

                    <div className="text-wrapper-144">
                      Business Pro Landing Page
                    </div>
                  </div>

                  <p className="opinion-content-2">
                    The Business Pro Landing Page has completely transformed the
                    way I present my business online. It’s sleek, professional,
                    and most importantly, highly effective at converting
                    visitors into leads. This page is perfect for startups and
                    businesses looking to make a strong first impression!
                  </p>
                </div>

                <div className="add-comment-and">
                  <div className="likes">
                    <div className="text-button">
                      <img
                        className="img-11"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com.svg"
                      />

                      <button className="button-2">114</button>
                    </div>

                    <div className="text-button">
                      <img
                        className="img-11"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com-1.svg"
                      />

                      <button className="button-2">5</button>
                    </div>
                  </div>
                </div>

                <div className="frame-179">
                  <img
                    className="image-21"
                    alt="Image"
                    src="/img/image-4.png"
                  />

                  <div className="frame-208">
                    <div className="frame-181">
                      <div className="text-wrapper-145">Reply</div>

                      <img
                        className="img-11"
                        alt="Send svgrepo com"
                        src="/img/send-svgrepo-com-1.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="user-opinion-3">
                <div className="opinion-content">
                  <div className="frame-182">
                    <div className="frame-183">
                      <div className="frame-210">
                        <img
                          className="image-21"
                          alt="Image"
                          src="/img/image-3.png"
                        />

                        <div className="user-name">Ella Cooper</div>
                      </div>

                      <div className="review-5">
                        <div className="opinion-stars">
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4191)"
                          />
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4192)"
                          />
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4193)"
                          />
                          <StarOutline11
                            className="instance-node-2"
                            color="url(#paint0_linear_51_4194)"
                          />
                          <StarOutline15 className="instance-node-2" />
                        </div>

                        <div className="average-review-value">
                          <div className="average-review-value-3">4.0</div>
                        </div>
                      </div>
                    </div>

                    <div className="date-of-adding-3">April 2, 2025</div>
                  </div>

                  <div className="frame-178">
                    <img
                      className="image-21"
                      alt="Image"
                      src="/img/image-10.png"
                    />

                    <div className="text-wrapper-144">SaaS Starter Page</div>
                  </div>

                  <p className="opinion-content-2">
                    The SaaS Starter Page is exactly what I needed to showcase
                    my software product in a clean, professional, and
                    high-converting way. From the layout to the functionality,
                    everything is designed to attract users and drive sign-ups!
                  </p>
                </div>

                <div className="add-comment-and">
                  <div className="likes">
                    <div className="text-button">
                      <img
                        className="img-11"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com.svg"
                      />

                      <button className="button-2">114</button>
                    </div>

                    <div className="text-button">
                      <img
                        className="img-11"
                        alt="Like svgrepo com"
                        src="/img/like-svgrepo-com-1.svg"
                      />

                      <button className="button-2">5</button>
                    </div>
                  </div>
                </div>

                <div className="frame-179">
                  <img
                    className="image-21"
                    alt="Image"
                    src="/img/image-4.png"
                  />

                  <div className="frame-208">
                    <div className="frame-181">
                      <div className="text-wrapper-145">Reply</div>

                      <img
                        className="img-11"
                        alt="Send svgrepo com"
                        src="/img/send-svgrepo-com-2.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
