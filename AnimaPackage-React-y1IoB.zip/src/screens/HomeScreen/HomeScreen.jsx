import React from "react";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const HomeScreen = () => {
  return (
    <div className="home-screen">
      <StatusBar
        batteryClassName="status-bar-81"
        className="status-bar-78"
        combinedShape="/img/combined-shape-26.svg"
        containerClassName="status-bar-80"
        property1="dark"
        rectangleClassName="status-bar-82"
        timeClassName="status-bar-79"
        wiFi="/img/wi-fi-22.svg"
      />
      <div className="frame-479">
        <div className="back-icon-button-30">
          <div className="messenger-fill">
            <div className="notification-13">
              <div className="vuesax-linear-12">
                <div className="notification-14">
                  <img
                    className="group-100"
                    alt="Group"
                    src="/img/group-33845-1.png"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="back-icon-button-30">
          <img
            className="messenger-fill"
            alt="Messenger fill"
            src="/img/messenger-fill-svgrepo-com-1-2.svg"
          />
        </div>
      </div>

      <div className="frame-480">
        <div className="frame-481">
          <div className="text-wrapper-237">Welcome to Gumroad!</div>
        </div>

        <div className="frame-482">
          <div className="frame-483">
            <div className="text-wrapper-238">Search</div>

            <SearchNormal property1="linear" />
          </div>
        </div>

        <div className="frame-484">
          <div className="frame-485">
            <div className="frame-486">
              <img
                className="img-26"
                alt="Category svgrepo com"
                src="/img/category-svgrepo-com.svg"
              />
            </div>

            <div className="text-wrapper-239">Categories</div>
          </div>

          <div className="frame-485">
            <div className="frame-486">
              <img
                className="img-26"
                alt="Pencil svgrepo com"
                src="/img/pencil-svgrepo-com-5.svg"
              />
            </div>

            <div className="text-wrapper-239">Publish</div>
          </div>

          <div className="frame-485">
            <div className="frame-486">
              <div className="img-26">
                <img
                  className="group-101"
                  alt="Group"
                  src="/img/group-36.png"
                />
              </div>
            </div>

            <div className="text-wrapper-239">Answer</div>
          </div>
        </div>
      </div>

      <div className="frame-487">
        <div className="BNB-10">
          <div className="navigation-menu-11">
            <img
              className="home-svgrepo-com-8"
              alt="Home svgrepo com"
              src="/img/home-svgrepo-com-1-3.svg"
            />

            <div className="text-wrapper-240">Home</div>
          </div>

          <div className="navigation-menu-11">
            <SearchNormal property1="linear" />
            <div className="text-wrapper-241">Search</div>
          </div>

          <div className="navigation-menu-11">
            <div className="group-102" />

            <div className="text-wrapper-242">Cart</div>
          </div>

          <div className="navigation-menu-11">
            <div className="home-svgrepo-com-8">
              <div className="frame-488">
                <div className="headset-svgrepo-com-7">
                  <div className="overlap-group-10">
                    <img
                      className="vector-73"
                      alt="Vector"
                      src="/img/vector-50.svg"
                    />

                    <img
                      className="vector-74"
                      alt="Vector"
                      src="/img/vector-51.svg"
                    />

                    <img
                      className="vector-75"
                      alt="Vector"
                      src="/img/vector-52.svg"
                    />

                    <img
                      className="vector-76"
                      alt="Vector"
                      src="/img/vector-53.svg"
                    />

                    <img
                      className="vector-77"
                      alt="Vector"
                      src="/img/vector-54.svg"
                    />

                    <img
                      className="vector-78"
                      alt="Vector"
                      src="/img/vector-55.svg"
                    />

                    <img
                      className="group-103"
                      alt="Group"
                      src="/img/group-37.png"
                    />

                    <img
                      className="group-104"
                      alt="Group"
                      src="/img/group-38.png"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="text-wrapper-242">Help</div>
          </div>

          <div className="navigation-menu-11">
            <img className="image-28" alt="Image" src="/img/image-5-2x.png" />

            <div className="text-wrapper-242">Profile</div>
          </div>
        </div>
      </div>

      <HomeIndicator
        className="home-indicator-31"
        lineClassName="home-indicator-32"
        property1="dark"
      />
    </div>
  );
};
