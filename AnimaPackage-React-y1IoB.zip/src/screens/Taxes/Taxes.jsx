import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const Taxes = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="taxes"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393
            ? "center"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393
            ? "#ffffff"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393
            ? "column"
            : undefined,
        gap:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1200
              ? "393px"
              : screenWidth >= 1200 && screenWidth < 1440
                ? "1200px"
                : screenWidth >= 1440
                  ? "1440px"
                  : undefined,
        padding:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
      }}
    >
      {((screenWidth >= 393 && screenWidth < 1200) || screenWidth < 393) && (
        <>
          <StatusBar
            batteryClassName={`${screenWidth < 393 && "class-49"} ${screenWidth >= 393 && screenWidth < 1200 && "class-50"}`}
            className={`${screenWidth < 393 && "class-47"} ${screenWidth >= 393 && screenWidth < 1200 && "class-48"}`}
            combinedShape={
              screenWidth < 393
                ? "/img/combined-shape-31.svg"
                : screenWidth >= 393 && screenWidth < 1200
                  ? "/img/combined-shape-32.svg"
                  : undefined
            }
            containerClassName={`${screenWidth < 393 && "class-51"} ${screenWidth >= 393 && screenWidth < 1200 && "class-52"}`}
            property1="dark"
            rectangleClassName="status-bar-97"
            timeClassName="status-bar-96"
            wiFi="/img/wi-fi-31.svg"
          />
          <div className="frame-578">
            <div className="back-icon-button-35">
              <div className="vuesax-outline-arrow-17" />
            </div>

            <div className="frame-579">
              <div className="text-wrapper-283">Account settings</div>

              <p className="text-wrapper-284">
                Edit your account details here such as payment details, name,
                download limits etc.
              </p>
            </div>
          </div>

          <div className="frame-580">
            <div className="div-10">
              <div className="frame-581">
                <div className="frame-582">
                  <div className="text-wrapper-285">Store</div>

                  <img
                    className="vector-98"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28133.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10671.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-583">
                  <div className="text-wrapper-285">Payment Details</div>

                  <img
                    className="vector-99"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28186.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10724.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-584">
                  <div className="text-wrapper-285">Billing &amp; Invoices</div>

                  <img
                    className="vector-100"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28309.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-10847.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-585"
                  style={{
                    marginRight: screenWidth < 393 ? "-52.00px" : undefined,
                  }}
                >
                  <div className="text-wrapper-286">Taxes</div>

                  <img
                    className="vector-101"
                    style={{
                      height:
                        screenWidth < 393
                          ? "1px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "1.5px"
                            : undefined,
                      marginLeft:
                        screenWidth < 393
                          ? "-28435.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-0.75px"
                            : undefined,
                      marginRight:
                        screenWidth >= 393 && screenWidth < 1200
                          ? "-0.75px"
                          : undefined,
                      marginTop: screenWidth < 393 ? "-62718.00px" : undefined,
                    }}
                    alt="Vector"
                    src={
                      screenWidth < 393
                        ? "/img/vector-1-18.png"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "/img/vector-1-101.svg"
                          : undefined
                    }
                  />
                </div>

                <div
                  className="frame-586"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-128.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-55.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-285">Shipping</div>

                  <img
                    className="vector-102"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28489.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-11027.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-587"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-259.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-186.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-285">Advance settings</div>

                  <img
                    className="vector-103"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28565.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-11103.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-588"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-369.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-296.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-285">Login settings</div>

                  <img
                    className="vector-104"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28696.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-11234.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div
                  className="frame-589"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-462.00px"
                        : screenWidth >= 393 && screenWidth < 1200
                          ? "-389.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-285">Developers</div>

                  <img
                    className="vector-105"
                    style={{
                      marginLeft:
                        screenWidth < 393
                          ? "-28806.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-11344.00px"
                            : undefined,
                      marginTop:
                        screenWidth < 393
                          ? "-62718.00px"
                          : screenWidth >= 393 && screenWidth < 1200
                            ? "-62700.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>
              </div>
            </div>

            <div
              className="input-25"
              style={{
                alignSelf: screenWidth < 393 ? "stretch" : undefined,
                width:
                  screenWidth < 393
                    ? "100%"
                    : screenWidth >= 393 && screenWidth < 1200
                      ? "361px"
                      : undefined,
              }}
            >
              <div className="text-wrapper-287">Store Address</div>

              <div className="frame-590">
                <img
                  className="vector-106"
                  alt="Vector"
                  src="/img/vector-2.svg"
                />

                <div className="text-wrapper-288">Add Store address</div>
              </div>
            </div>

            <div
              className="input-26"
              style={{
                alignSelf: screenWidth < 393 ? "stretch" : undefined,
                width:
                  screenWidth < 393
                    ? "100%"
                    : screenWidth >= 393 && screenWidth < 1200
                      ? "361px"
                      : undefined,
              }}
            >
              <div className="text-wrapper-287">Tax Rates</div>

              <div className="frame-590">
                <img
                  className="vector-106"
                  alt="Vector"
                  src="/img/vector-2.svg"
                />

                <div className="text-wrapper-288">Add Tax Rate</div>
              </div>
            </div>

            <div className="div-10">
              <div className="text-wrapper-287">Tax Settings</div>

              <div className="frame-591">
                <div className="frame-592">
                  <div className="default-circle-7" />

                  <p className="text-wrapper-289">
                    Let Gumroad handle digital products EU VAT automatically for
                    you
                  </p>
                </div>
              </div>

              <div className="frame-591">
                <div className="frame-592">
                  <div className="default-circle-7" />

                  <p className="text-wrapper-289">
                    Let Gumroad handle digital products UK VAT automatically for
                    you
                  </p>
                </div>
              </div>

              <div className="frame-591">
                <div className="frame-592">
                  <div className="default-circle-7" />

                  <p className="text-wrapper-290">
                    Charge taxes on shipping rates
                  </p>
                </div>
              </div>

              <div className="frame-591">
                <div className="frame-592">
                  <div className="default-circle-7" />

                  <p className="text-wrapper-290">
                    Redeem EU VAT company numbers
                  </p>
                </div>
              </div>
            </div>

            <div
              className="input-27"
              style={{
                alignSelf: screenWidth < 393 ? "stretch" : undefined,
                width:
                  screenWidth < 393
                    ? "100%"
                    : screenWidth >= 393 && screenWidth < 1200
                      ? "361px"
                      : undefined,
              }}
            >
              <p className="text-wrapper-287">
                If sales tax (VAT) is required for a transaction choose a flow
                below
              </p>

              <div className="input-28">
                <p className="text-wrapper-291">
                  Add sales tax on top of product price
                </p>
              </div>
            </div>

            <div className="CTA-6">
              <div
                className="frame-593"
                style={{
                  flex: screenWidth < 393 ? "1" : undefined,
                  flexGrow: screenWidth < 393 ? "1" : undefined,
                  width:
                    screenWidth >= 393 && screenWidth < 1200
                      ? "172.5px"
                      : undefined,
                }}
              >
                <div className="text-wrapper-292">Cancel</div>
              </div>

              <div
                className="frame-594"
                style={{
                  flex: screenWidth < 393 ? "1" : undefined,
                  flexGrow: screenWidth < 393 ? "1" : undefined,
                  width:
                    screenWidth >= 393 && screenWidth < 1200
                      ? "172.5px"
                      : undefined,
                }}
              >
                <div className="text-wrapper-288">Save</div>
              </div>
            </div>
          </div>

          <div
            className="frame-595"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1200
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-13">
              {screenWidth < 393 && (
                <div className="frame-596">
                  <div className="navigation-menu-home-6">
                    <div className="navigation-menu-home-7">
                      <img
                        className="img-37"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-293">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-15">
                    <SearchNormal property1="linear" />
                    <div className="text-wrapper-294">Search</div>
                  </div>

                  <div className="navigation-menu-15">
                    <img
                      className="img-38"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-295">Cart</div>
                  </div>

                  <div className="navigation-menu-15">
                    <img
                      className="img-38"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-7.svg"
                    />

                    <div className="text-wrapper-296">Help</div>
                  </div>

                  <div className="navigation-menu-15">
                    <img
                      className="image-32"
                      alt="Image"
                      src="/img/image-6.png"
                    />

                    <div className="text-wrapper-297">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1200 && (
                <>
                  <div className="navigation-menu-home-6">
                    <div className="navigation-menu-home-7">
                      <div className="frame-597" />

                      <div className="text-wrapper-293">Profile</div>
                    </div>
                  </div>

                  <div className="navigation-menu-16">
                    <SearchNormal property1="linear" />
                  </div>

                  <div className="navigation-menu-16">
                    <img
                      className="img-37"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-9.svg"
                    />
                  </div>

                  <div className="navigation-menu-16">
                    <div className="frame-598">
                      <div className="ellipse-30" />
                    </div>
                  </div>

                  <div className="navigation-menu-16">
                    <img
                      className="image-33"
                      alt="Image"
                      src="/img/image-6.png"
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-34"
            lineClassName={`${screenWidth < 393 && "class-53"} ${screenWidth >= 393 && screenWidth < 1200 && "class-54"}`}
            property1="dark"
          />
        </>
      )}

      {((screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440) && (
        <div className="frame-599">
          <div className="frame-600">
            <div className="frame-601">
              <div className="frame-602">
                <div className="frame-603">
                  <div className="frame-604">
                    <div className="text-wrapper-298">LOGO</div>
                  </div>
                </div>

                <div className="div-10">
                  <div className="frame-605">
                    <img
                      className="img-39"
                      alt="Home angle svgrepo"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/home-angle-svgrepo-com-15-2.svg"
                          : screenWidth >= 1440
                            ? "/img/home-angle-svgrepo-com-14-2.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-299">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-601">
                <div className="frame-601">
                  <div className="frame-606">
                    <div className="img-39">
                      <div className="vuesax-linear-gift-14">
                        <img
                          className="gift-24"
                          alt="Gift"
                          src={
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "/img/gift-7.png"
                              : screenWidth >= 1440
                                ? "/img/gift-6-2x.png"
                                : undefined
                          }
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-300">Products</div>
                  </div>

                  <div className="frame-606">
                    <img
                      className="img-39"
                      alt="Users group two"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/users-group-two-rounded-svgrepo-com-7.svg"
                          : screenWidth >= 1440
                            ? "/img/users-group-two-rounded-svgrepo-com-6.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-300">Collaborators</div>
                  </div>

                  <div className="frame-606">
                    <img
                      className="img-39"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-6-2.svg"
                    />

                    <div className="text-wrapper-300">Checkout</div>
                  </div>

                  <div className="frame-606">
                    <img
                      className="img-39"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-300">Emails</div>
                  </div>

                  <div className="frame-606">
                    <img
                      className="img-39"
                      alt="Flow parallel"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/flow-parallel-svgrepo-com-7-2.svg"
                          : screenWidth >= 1440
                            ? "/img/flow-parallel-svgrepo-com-6.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-300">Workflows</div>
                  </div>

                  <div className="frame-606">
                    <img
                      className="img-39"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-14.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-12.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-300">Sales</div>
                  </div>

                  <div className="frame-606">
                    <img
                      className="img-39"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-300">Analytics</div>
                  </div>

                  <div className="frame-606">
                    <img
                      className="img-39"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-14.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-12.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-300">Payouts</div>
                  </div>

                  <div className="frame-606">
                    <img
                      className="img-39"
                      alt="Book bookmark"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/book-bookmark-minimalistic-svgrepo-com-7.svg"
                          : screenWidth >= 1440
                            ? "/img/book-bookmark-minimalistic-svgrepo-com-6-2.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-300">Library</div>
                  </div>
                </div>

                <div className="frame-606">
                  <img
                    className="img-39"
                    alt="Settings svgrepo com"
                    src={
                      screenWidth >= 1200 && screenWidth < 1440
                        ? "/img/settings-svgrepo-com-7.svg"
                        : screenWidth >= 1440
                          ? "/img/settings-svgrepo-com-6-2.svg"
                          : undefined
                    }
                  />

                  <div className="text-wrapper-300">Settings</div>
                </div>

                <div className="frame-606">
                  <img
                    className="img-39"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-6-2.svg"
                  />

                  <div className="text-wrapper-300">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-607">
            <div className="frame-608">
              <div className="frame-609">
                <div className="frame-610">
                  <div className="text-wrapper-301">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-611">
                <div className="text-wrapper-288">Login</div>
              </div>

              <div className="frame-612">
                <div className="text-wrapper-302">Sign Up</div>
              </div>
            </div>

            <div className="frame-613">
              <div className="frame-592">
                <div className="back-icon-button-35">
                  <div className="vuesax-outline-arrow-17" />
                </div>

                <div className="frame-579">
                  <div className="text-wrapper-303">Account settings</div>

                  <p className="text-wrapper-304">
                    Edit your account details here such as payment details,
                    name, download limits etc.
                  </p>
                </div>
              </div>

              <div className="frame-581">
                <div className="frame-614">
                  <div className="text-wrapper-305">Store</div>

                  <img
                    className="vector-107"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-47490.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-11886.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-615">
                  <div className="text-wrapper-305">Payment Details</div>

                  <img
                    className="vector-108"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-47548.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-11828.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-616">
                  <div className="text-wrapper-305">Billing &amp; Invoices</div>

                  <img
                    className="vector-109"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-47687.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-11689.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-617">
                  <div className="text-wrapper-306">Taxes</div>

                  <img
                    className="vector-110"
                    alt="Vector"
                    src={
                      screenWidth >= 1200 && screenWidth < 1440
                        ? "/img/vector-1-109.svg"
                        : screenWidth >= 1440
                          ? "/img/vector-1-85.svg"
                          : undefined
                    }
                  />
                </div>

                <div className="frame-618">
                  <div className="text-wrapper-305">Shipping</div>

                  <img
                    className="vector-111"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-47887.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-11489.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-619">
                  <div className="text-wrapper-305">Advance settings</div>

                  <img
                    className="vector-112"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-47971.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-11405.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-620">
                  <div className="text-wrapper-305">Login settings</div>

                  <img
                    className="vector-113"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-48119.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-11257.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>

                <div className="frame-621">
                  <div className="text-wrapper-305">Developers</div>

                  <img
                    className="vector-114"
                    style={{
                      marginLeft:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-48243.00px"
                          : undefined,
                      marginRight:
                        screenWidth >= 1440 ? "-11133.00px" : undefined,
                      marginTop:
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "-67965.00px"
                          : screenWidth >= 1440
                            ? "-69130.00px"
                            : undefined,
                    }}
                    alt="Vector"
                    src="/img/vector-1-18.png"
                  />
                </div>
              </div>

              <div className="frame-622">
                <div className="frame-581">
                  <div className="input-29">
                    <div className="text-wrapper-307">Store Address</div>

                    <div className="frame-623">
                      <img
                        className="vector-106"
                        alt="Vector"
                        src="/img/vector-2.svg"
                      />

                      <div className="text-wrapper-288">Add Store address</div>
                    </div>
                  </div>
                </div>

                <div className="frame-581">
                  <div className="input-30">
                    <div className="text-wrapper-307">Tax Rates</div>

                    <div className="frame-623">
                      <img
                        className="vector-106"
                        alt="Vector"
                        src="/img/vector-2.svg"
                      />

                      <div className="text-wrapper-288">Add Tax Rate</div>
                    </div>
                  </div>
                </div>

                <div className="frame-581">
                  <div className="input-31">
                    <div className="text-wrapper-307">Tax Settings</div>

                    <div className="frame-591">
                      <div className="frame-592">
                        <div className="default-circle-7" />

                        <p className="text-wrapper-308">
                          Let Gumroad handle digital products EU VAT
                          automatically for you
                        </p>
                      </div>
                    </div>

                    <div className="frame-591">
                      <div className="frame-592">
                        <div className="default-circle-7" />

                        <p className="text-wrapper-308">
                          Let Gumroad handle digital products UK VAT
                          automatically for you
                        </p>
                      </div>
                    </div>

                    <div className="frame-591">
                      <div className="frame-592">
                        <div className="default-circle-7" />

                        <p className="text-wrapper-308">
                          Charge taxes on shipping rates
                        </p>
                      </div>
                    </div>

                    <div className="frame-591">
                      <div className="frame-592">
                        <div className="default-circle-7" />

                        <p className="text-wrapper-308">
                          Redeem EU VAT company numbers
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-624">
                  <div className="input-32">
                    <p className="text-wrapper-307">
                      If sales tax (VAT) is required for a transaction choose a
                      flow below
                    </p>

                    <div className="input-28">
                      <p className="text-wrapper-291">
                        Add sales tax on top of product price
                      </p>

                      <img
                        className="expand-more-4"
                        alt="Expand more"
                        src={
                          screenWidth >= 1200 && screenWidth < 1440
                            ? "/img/expand-more-3-3.svg"
                            : screenWidth >= 1440
                              ? "/img/expand-more-2-4.svg"
                              : undefined
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="CTA-6">
                  <div className="frame-625">
                    <div className="text-wrapper-292">Cancel</div>
                  </div>

                  <div className="frame-626">
                    <div className="text-wrapper-288">Save</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
