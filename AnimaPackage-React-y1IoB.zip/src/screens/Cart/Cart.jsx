import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal38 } from "../../icons/SearchNormal38";
import "./style.css";

export const Cart = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="cart"
      style={{
        alignItems:
          screenWidth < 1440
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1440
            ? "var(--variable-collection-white-duplicate)"
            : screenWidth >= 1440
              ? "var(--variable-collection-fill)"
              : undefined,
        flexDirection: screenWidth < 1440 ? "column" : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight:
          screenWidth < 1440
            ? "100vh"
            : screenWidth >= 1440
              ? "1023px"
              : undefined,
        minWidth:
          screenWidth < 1440
            ? "393px"
            : screenWidth >= 1440
              ? "1440px"
              : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {screenWidth < 1440 && (
        <>
          <StatusBar
            actionClassName="status-bar-40"
            batteryClassName="status-bar-43"
            className="status-bar-39"
            combinedShape="/img/combined-shape-2.svg"
            containerClassName="status-bar-42"
            property1="dark"
            rectangleClassName="status-bar-44"
            timeClassName="status-bar-41"
            wiFi="/img/wi-fi-2.svg"
          />
          <div className="frame-259">
            <div className="back-icon-button-16">
              <div className="vuesax-outline-arrow-9" />
            </div>

            <div className="frame-260">
              <p className="div-6">
                <span className="text-wrapper-129">Cart </span>

                <span className="text-wrapper-130">(9)</span>
              </p>
            </div>
          </div>

          <div className="frame-261">
            <div className="input-12">
              <div className="frame-262">
                <div className="default-circle-2" />

                <img
                  className="img-15"
                  alt="Cart large svgrepo"
                  src="/img/cart-large-4-svgrepo-com-2.svg"
                />

                <div className="text-wrapper-131">John Doe</div>
              </div>

              <div className="frame-263">
                <div className="frame-264">
                  <div className="default-circle-2" />

                  <img
                    className="image-20"
                    alt="Image"
                    src="/img/image-24.png"
                  />

                  <div className="frame-265">
                    <div className="frame-266">
                      <div className="title-6">Real Estate Landing...</div>

                      <div className="frame-267">
                        <div className="text-2">
                          <div className="element-service-2">
                            <div className="description-4">$29.99</div>
                          </div>
                        </div>

                        <div className="input-13">
                          <div className="selected-quantity">1</div>

                          <img
                            className="img-16"
                            alt="Expand more"
                            src="/img/expand-more-5-3.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="input-12">
              <div className="frame-262">
                <div className="default-circle-2" />

                <img
                  className="img-15"
                  alt="Cart large svgrepo"
                  src="/img/cart-large-4-svgrepo-com-2.svg"
                />

                <div className="text-wrapper-131">John Doe</div>
              </div>

              <div className="frame-263">
                <div className="frame-264">
                  <div className="default-circle-2" />

                  <img
                    className="image-20"
                    alt="Image"
                    src="/img/image-24.png"
                  />

                  <div className="frame-265">
                    <div className="frame-266">
                      <div className="title-6">Real Estate Landing...</div>

                      <div className="frame-267">
                        <div className="text-2">
                          <div className="element-service-2">
                            <div className="description-4">$29.99</div>
                          </div>
                        </div>

                        <div className="input-13">
                          <div className="selected-quantity">1</div>

                          <img
                            className="img-16"
                            alt="Expand more"
                            src="/img/expand-more-6-3.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="input-14">
              <div className="frame-262">
                <div className="default-circle-2" />

                <img
                  className="img-15"
                  alt="Cart large svgrepo"
                  src="/img/cart-large-4-svgrepo-com-2.svg"
                />

                <div className="text-wrapper-131">John Doe</div>
              </div>

              <div className="frame-268">
                <div className="frame-264">
                  <div className="default-circle-2" />

                  <img
                    className="image-20"
                    alt="Image"
                    src="/img/image-24.png"
                  />

                  <div className="frame-265">
                    <div className="frame-266">
                      <div className="title-6">Real Estate Landing...</div>

                      <div className="frame-267">
                        <div className="text-2">
                          <div className="element-service-2">
                            <div className="description-4">$29.99</div>
                          </div>
                        </div>

                        <div className="input-13">
                          <div className="selected-quantity">1</div>

                          <img
                            className="img-16"
                            alt="Expand more"
                            src="/img/expand-more-7-2.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="frame-269">
                <div className="frame-264">
                  <div className="default-circle-2" />

                  <img
                    className="image-20"
                    alt="Image"
                    src="/img/image-24.png"
                  />

                  <div className="frame-265">
                    <div className="frame-266">
                      <div className="title-6">Real Estate Landing...</div>

                      <div className="frame-267">
                        <div className="text-2">
                          <div className="element-service-2">
                            <div className="description-4">$29.99</div>
                          </div>
                        </div>

                        <div className="input-13">
                          <div className="selected-quantity">1</div>

                          <img
                            className="img-16"
                            alt="Expand more"
                            src="/img/expand-more-8.svg"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="CTA-3">
              <div className="description-5">Total: $29.99</div>

              <div className="frame-270">
                <div className="text-wrapper-132">Check Out</div>
              </div>
            </div>
          </div>

          <div className="frame-271">
            <div className="BNB-6">
              <div className="navigation-menu-7">
                <img
                  className="img-16"
                  alt="Home svgrepo com"
                  src="/img/home-svgrepo-com-5.svg"
                />

                <div className="text-wrapper-133">Home</div>
              </div>

              <div className="navigation-menu-7">
                <div className="group-30" />

                <div className="text-wrapper-134">Search</div>
              </div>

              <div className="navigation-menu-7">
                <div className="group-31" />

                <div className="text-wrapper-135">Cart</div>
              </div>

              <div className="navigation-menu-7">
                <div className="img-16">
                  <div className="frame-272">
                    <div className="headset-svgrepo-com-3">
                      <div className="overlap-group-4">
                        <img
                          className="vector-30"
                          alt="Vector"
                          src="/img/vector.svg"
                        />

                        <img
                          className="vector-31"
                          alt="Vector"
                          src="/img/vector-1.svg"
                        />

                        <img
                          className="vector-32"
                          alt="Vector"
                          src="/img/vector-2-2.svg"
                        />

                        <img
                          className="vector-33"
                          alt="Vector"
                          src="/img/vector-3.svg"
                        />

                        <img
                          className="vector-34"
                          alt="Vector"
                          src="/img/vector-4.svg"
                        />

                        <img
                          className="vector-35"
                          alt="Vector"
                          src="/img/vector-5.svg"
                        />

                        <img
                          className="group-32"
                          alt="Group"
                          src="/img/group-2.png"
                        />

                        <img
                          className="group-33"
                          alt="Group"
                          src="/img/group-1.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-wrapper-133">Help</div>
              </div>

              <div className="navigation-menu-7">
                <img className="image-21" alt="Image" src="/img/image-14.png" />

                <div className="text-wrapper-133">Profile</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-17"
            lineClassName="home-indicator-18"
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-273">
          <div className="frame-274">
            <div className="frame-275">
              <div className="frame-276">
                <div className="frame-277">
                  <div className="frame-278">
                    <div className="text-wrapper-136">LOGO</div>
                  </div>
                </div>
              </div>

              <div className="frame-275">
                <div className="frame-275">
                  <div className="frame-279">
                    <div className="frame-280">
                      <img
                        className="img-16"
                        alt="Home svgrepo com"
                        src="/img/home-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-137">Home</div>
                    </div>

                    <div className="frame-280">
                      <img
                        className="img-15"
                        alt="Security safe"
                        src="/img/security-safe-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-138">Security</div>
                    </div>

                    <div className="frame-280">
                      <div className="gift-11">
                        <div className="vuesax-linear-gift-7">
                          <img
                            className="gift-12"
                            alt="Gift"
                            src="/img/gift-16.png"
                          />
                        </div>
                      </div>

                      <div className="text-wrapper-138">Products</div>
                    </div>

                    <div className="frame-280">
                      <img
                        className="img-15"
                        alt="Advertising svgrepo"
                        src="/img/advertising-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-138">Marketing</div>
                    </div>

                    <div className="frame-280">
                      <img
                        className="img-15"
                        alt="Cart large svgrepo"
                        src="/img/cart-large-4-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-138">Your Store</div>
                    </div>

                    <div className="frame-280">
                      <img
                        className="img-15"
                        alt="People svgrepo com"
                        src="/img/people-svgrepo-com-4.svg"
                      />

                      <div className="text-wrapper-138">Collaborators</div>
                    </div>

                    <div className="frame-280">
                      <div className="group-34" />

                      <div className="text-wrapper-138">Checkout</div>
                    </div>

                    <div className="frame-280">
                      <div className="img-15">
                        <div className="email-svgrepo-6">
                          <div className="page-7" />
                        </div>
                      </div>

                      <div className="text-wrapper-138">Emails</div>
                    </div>

                    <div className="frame-280">
                      <img
                        className="img-15"
                        alt="Flow parallel"
                        src="/img/flow-parallel-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-138">Workflows</div>
                    </div>

                    <div className="frame-280">
                      <img
                        className="img-15"
                        alt="Coin svgrepo com"
                        src="/img/coin-svgrepo-com-9.svg"
                      />

                      <div className="text-wrapper-138">Sales</div>
                    </div>

                    <div className="frame-280">
                      <img
                        className="img-15"
                        alt="Graph svgrepo com"
                        src="/img/graph-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-138">Analytics</div>
                    </div>

                    <div className="frame-280">
                      <img
                        className="img-15"
                        alt="Coin svgrepo com"
                        src="/img/coin-svgrepo-com-9.svg"
                      />

                      <div className="text-wrapper-138">Payouts</div>
                    </div>

                    <div className="frame-280">
                      <img
                        className="img-15"
                        alt="Book bookmark"
                        src="/img/book-bookmark-minimalistic-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-138">Library</div>
                    </div>
                  </div>
                </div>

                <div className="frame-280">
                  <img
                    className="img-15"
                    alt="Setting svgrepo"
                    src="/img/setting-2-svgrepo-com-2.svg"
                  />

                  <div className="text-wrapper-138">Settings</div>
                </div>

                <div className="frame-280">
                  <img
                    className="img-15"
                    alt="Open book svgrepo"
                    src="/img/open-book-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-138">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-281">
            <div className="frame-282">
              <div className="frame-283">
                <div className="frame-284">
                  <div className="text-wrapper-139">Real Estate</div>

                  <SearchNormal38
                    className="search-normal-38-instance"
                    color="#292929"
                  />
                </div>
              </div>

              <div className="back-icon-button-17">
                <div className="img-15">
                  <div className="vuesax-linear-6">
                    <div className="notification-6">
                      <img
                        className="group-35"
                        alt="Group"
                        src="/img/group-33845-6.png"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="back-icon-button-17">
                <img
                  className="img-15"
                  alt="Messenger fill"
                  src="/img/messenger-fill-svgrepo-com.svg"
                />
              </div>

              <div className="frame-285">
                <div className="frame-286">
                  <img
                    className="ellipse-9"
                    alt="Ellipse"
                    src="/img/ellipse-52.png"
                  />

                  <div className="frame-287">
                    <div className="text-wrapper-140">Lenny White</div>
                  </div>
                </div>

                <img
                  className="search-normal-38-instance"
                  alt="Expand more"
                  src="/img/expand-more-16.svg"
                />
              </div>
            </div>

            <div className="frame-288">
              <div className="frame-289">
                <div className="frame-290">
                  <div className="back-icon-button-18">
                    <div className="vuesax-outline-arrow-9" />
                  </div>

                  <div className="frame-260">
                    <div className="frame-291">
                      <p className="div-7">
                        <span className="text-wrapper-141">Cart </span>

                        <span className="text-wrapper-142">(9)</span>
                      </p>

                      <div className="frame-292">
                        <div className="group-36">
                          <div className="vuesax-linear-add-3" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="input-12">
                  <div className="frame-293">
                    <div className="default-circle-3" />

                    <img
                      className="img-15"
                      alt="Cart large svgrepo"
                      src="/img/cart-large-4-svgrepo-com-2.svg"
                    />

                    <div className="text-wrapper-143">John Doe</div>
                  </div>

                  <div className="frame-294">
                    <div className="frame-264">
                      <div className="default-circle-3" />

                      <img
                        className="image-20"
                        alt="Image"
                        src="/img/image-24.png"
                      />

                      <div className="frame-265">
                        <div className="frame-266">
                          <div className="title-7">Real Estate Landing...</div>

                          <div className="frame-267">
                            <div className="text-2">
                              <div className="element-service-2">
                                <div className="description-4">$29.99</div>
                              </div>
                            </div>

                            <div className="input-15">
                              <div className="selected-quantity-2">1</div>

                              <img
                                className="img-16"
                                alt="Expand more"
                                src="/img/expand-more-1.svg"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="input-12">
                  <div className="frame-293">
                    <div className="default-circle-3" />

                    <img
                      className="img-15"
                      alt="Cart large svgrepo"
                      src="/img/cart-large-4-svgrepo-com-2.svg"
                    />

                    <div className="text-wrapper-143">John Doe</div>
                  </div>

                  <div className="frame-294">
                    <div className="frame-264">
                      <div className="default-circle-3" />

                      <img
                        className="image-20"
                        alt="Image"
                        src="/img/image-24.png"
                      />

                      <div className="frame-265">
                        <div className="frame-266">
                          <div className="title-7">Real Estate Landing...</div>

                          <div className="frame-267">
                            <div className="text-2">
                              <div className="element-service-2">
                                <div className="description-4">$29.99</div>
                              </div>
                            </div>

                            <div className="input-15">
                              <div className="selected-quantity-2">1</div>

                              <img
                                className="img-16"
                                alt="Expand more"
                                src="/img/expand-more-2-3.svg"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="input-14">
                  <div className="frame-293">
                    <div className="default-circle-3" />

                    <img
                      className="img-15"
                      alt="Cart large svgrepo"
                      src="/img/cart-large-4-svgrepo-com-2.svg"
                    />

                    <div className="text-wrapper-143">John Doe</div>
                  </div>

                  <div className="frame-295">
                    <div className="frame-264">
                      <div className="default-circle-3" />

                      <img
                        className="image-20"
                        alt="Image"
                        src="/img/image-24.png"
                      />

                      <div className="frame-265">
                        <div className="frame-266">
                          <div className="title-7">Real Estate Landing...</div>

                          <div className="frame-267">
                            <div className="text-2">
                              <div className="element-service-2">
                                <div className="description-4">$29.99</div>
                              </div>
                            </div>

                            <div className="input-15">
                              <div className="selected-quantity-2">1</div>

                              <img
                                className="img-16"
                                alt="Expand more"
                                src="/img/expand-more-3.svg"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-296">
                    <div className="frame-264">
                      <div className="default-circle-3" />

                      <img
                        className="image-20"
                        alt="Image"
                        src="/img/image-24.png"
                      />

                      <div className="frame-265">
                        <div className="frame-266">
                          <div className="title-7">Real Estate Landing...</div>

                          <div className="frame-267">
                            <div className="text-2">
                              <div className="element-service-2">
                                <div className="description-4">$29.99</div>
                              </div>
                            </div>

                            <div className="input-15">
                              <div className="selected-quantity-2">1</div>

                              <img
                                className="img-16"
                                alt="Expand more"
                                src="/img/expand-more-4-5.svg"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="CTA-3">
                  <div className="description-5">Total: $29.99</div>

                  <div className="frame-297">
                    <div className="text-wrapper-144">Check Out</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
