import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal38 } from "../../icons/SearchNormal38";
import "./style.css";

export const SavedExperts = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="saved-experts"
      style={{
        alignItems:
          screenWidth < 1440
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1440
            ? "var(--variable-collection-white-duplicate)"
            : screenWidth >= 1440
              ? "var(--variable-collection-fill-duplicate)"
              : undefined,
        flexDirection: screenWidth < 1440 ? "column" : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight:
          screenWidth < 1440
            ? "100vh"
            : screenWidth >= 1440
              ? "1023px"
              : undefined,
        minWidth:
          screenWidth < 1440
            ? "393px"
            : screenWidth >= 1440
              ? "1440px"
              : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {screenWidth < 1440 && (
        <>
          <StatusBar
            actionClassName="status-bar-28"
            batteryClassName="status-bar-31"
            className="status-bar-27"
            combinedShape="/img/combined-shape-2.svg"
            containerClassName="status-bar-30"
            property1="dark"
            rectangleClassName="status-bar-32"
            timeClassName="status-bar-29"
            wiFi="/img/wi-fi-2.svg"
          />
          <div className="frame-200">
            <div className="back-icon-button-12">
              <div className="vuesax-outline-arrow-7" />
            </div>

            <div className="frame-201">
              <div className="text-wrapper-107">Saved Experts</div>
            </div>
          </div>

          <div className="frame-202">
            <div className="frame-203">
              <div className="element-solutions-card-3">
                <div className="frame-204">
                  <div className="frame-205">
                    <img
                      className="image-12"
                      alt="Image"
                      src="/img/image-11-2x.png"
                    />

                    <img
                      className="image-13"
                      alt="Image"
                      src="/img/image-4-2x.png"
                    />
                  </div>

                  <div className="frame-205">
                    <img
                      className="image-12"
                      alt="Image"
                      src="/img/image-5-2.png"
                    />

                    <img
                      className="image-12"
                      alt="Image"
                      src="/img/image-7-2x.png"
                    />
                  </div>
                </div>

                <div className="frame-205">
                  <div className="title-wrapper">
                    <div className="title-3">Gardening</div>
                  </div>
                </div>
              </div>

              <div className="element-solutions-card-3">
                <div className="frame-204">
                  <div className="frame-205">
                    <img
                      className="image-12"
                      alt="Image"
                      src="/img/image-11-2x.png"
                    />

                    <img
                      className="image-13"
                      alt="Image"
                      src="/img/image-4-2x.png"
                    />
                  </div>

                  <div className="frame-205">
                    <img
                      className="image-12"
                      alt="Image"
                      src="/img/image-5-2.png"
                    />

                    <img
                      className="image-12"
                      alt="Image"
                      src="/img/image-7-2x.png"
                    />
                  </div>
                </div>

                <div className="frame-205">
                  <div className="title-wrapper">
                    <div className="title-3">Music</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-203">
              <div className="element-solutions-card-3">
                <div className="frame-204">
                  <div className="frame-205">
                    <img
                      className="image-12"
                      alt="Image"
                      src="/img/image-11-2x.png"
                    />

                    <img
                      className="image-13"
                      alt="Image"
                      src="/img/image-4-2x.png"
                    />
                  </div>

                  <div className="frame-205">
                    <img
                      className="image-12"
                      alt="Image"
                      src="/img/image-5-2.png"
                    />

                    <img
                      className="image-12"
                      alt="Image"
                      src="/img/image-7-2x.png"
                    />
                  </div>
                </div>

                <div className="frame-205">
                  <div className="title-wrapper">
                    <div className="title-3">Writing</div>
                  </div>
                </div>
              </div>

              <div className="element-solutions-card-3">
                <div className="frame-204">
                  <div className="frame-205">
                    <img
                      className="image-12"
                      alt="Image"
                      src="/img/image-11-2x.png"
                    />

                    <img
                      className="image-13"
                      alt="Image"
                      src="/img/image-4-2x.png"
                    />
                  </div>

                  <div className="frame-205">
                    <img
                      className="image-12"
                      alt="Image"
                      src="/img/image-5-2.png"
                    />

                    <img
                      className="image-12"
                      alt="Image"
                      src="/img/image-7-2x.png"
                    />
                  </div>
                </div>

                <div className="frame-205">
                  <div className="title-wrapper">
                    <div className="title-3">Music</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-206">
            <div className="BNB-4">
              <div className="navigation-menu-5">
                <img
                  className="home-svgrepo-com-3"
                  alt="Home svgrepo com"
                  src="/img/home-svgrepo-com-5.svg"
                />

                <div className="text-wrapper-108">Home</div>
              </div>

              <div className="navigation-menu-5">
                <div className="group-16" />

                <div className="text-wrapper-109">Search</div>
              </div>

              <div className="navigation-menu-5">
                <div className="group-17" />

                <div className="text-wrapper-110">Cart</div>
              </div>

              <div className="navigation-menu-5">
                <div className="home-svgrepo-com-3">
                  <div className="frame-207">
                    <div className="overlap-group-wrapper">
                      <div className="overlap-group-2">
                        <img
                          className="vector-18"
                          alt="Vector"
                          src="/img/vector.svg"
                        />

                        <img
                          className="vector-19"
                          alt="Vector"
                          src="/img/vector-1.svg"
                        />

                        <img
                          className="vector-20"
                          alt="Vector"
                          src="/img/vector-2-2.svg"
                        />

                        <img
                          className="vector-21"
                          alt="Vector"
                          src="/img/vector-3.svg"
                        />

                        <img
                          className="vector-22"
                          alt="Vector"
                          src="/img/vector-4.svg"
                        />

                        <img
                          className="vector-23"
                          alt="Vector"
                          src="/img/vector-5.svg"
                        />

                        <img
                          className="group-18"
                          alt="Group"
                          src="/img/group-2.png"
                        />

                        <img
                          className="group-19"
                          alt="Group"
                          src="/img/group-1.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-wrapper-108">Help</div>
              </div>

              <div className="navigation-menu-5">
                <img className="image-14" alt="Image" src="/img/image-14.png" />

                <div className="text-wrapper-108">Profile</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-13"
            lineClassName="home-indicator-14"
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-208">
          <div className="frame-209">
            <div className="frame-210">
              <div className="frame-211">
                <div className="frame-212">
                  <div className="frame-213">
                    <div className="text-wrapper-111">LOGO</div>
                  </div>
                </div>
              </div>

              <div className="frame-210">
                <div className="frame-210">
                  <div className="frame-214">
                    <div className="frame-215">
                      <img
                        className="home-svgrepo-com-3"
                        alt="Home svgrepo com"
                        src="/img/home-svgrepo-com-2-3.svg"
                      />

                      <div className="text-wrapper-112">Home</div>
                    </div>

                    <div className="frame-215">
                      <img
                        className="img-13"
                        alt="Security safe"
                        src="/img/security-safe-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-113">Security</div>
                    </div>

                    <div className="frame-215">
                      <div className="vuesax-linear-gift-wrapper">
                        <div className="vuesax-linear-gift-5">
                          <img
                            className="gift-8"
                            alt="Gift"
                            src="/img/gift-16.png"
                          />
                        </div>
                      </div>

                      <div className="text-wrapper-113">Products</div>
                    </div>

                    <div className="frame-215">
                      <img
                        className="img-13"
                        alt="Advertising svgrepo"
                        src="/img/advertising-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-113">Marketing</div>
                    </div>

                    <div className="frame-215">
                      <img
                        className="img-13"
                        alt="Cart large svgrepo"
                        src="/img/cart-large-4-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-113">Your Store</div>
                    </div>

                    <div className="frame-215">
                      <img
                        className="img-13"
                        alt="People svgrepo com"
                        src="/img/people-svgrepo-com-4.svg"
                      />

                      <div className="text-wrapper-113">Collaborators</div>
                    </div>

                    <div className="frame-215">
                      <div className="group-20" />

                      <div className="text-wrapper-113">Checkout</div>
                    </div>

                    <div className="frame-215">
                      <div className="img-13">
                        <div className="email-svgrepo-4">
                          <div className="page-5" />
                        </div>
                      </div>

                      <div className="text-wrapper-113">Emails</div>
                    </div>

                    <div className="frame-215">
                      <img
                        className="img-13"
                        alt="Flow parallel"
                        src="/img/flow-parallel-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-113">Workflows</div>
                    </div>

                    <div className="frame-215">
                      <img
                        className="img-13"
                        alt="Coin svgrepo com"
                        src="/img/coin-svgrepo-com-9.svg"
                      />

                      <div className="text-wrapper-113">Sales</div>
                    </div>

                    <div className="frame-215">
                      <img
                        className="img-13"
                        alt="Graph svgrepo com"
                        src="/img/graph-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-113">Analytics</div>
                    </div>

                    <div className="frame-215">
                      <img
                        className="img-13"
                        alt="Coin svgrepo com"
                        src="/img/coin-svgrepo-com-9.svg"
                      />

                      <div className="text-wrapper-113">Payouts</div>
                    </div>

                    <div className="frame-215">
                      <img
                        className="img-13"
                        alt="Book bookmark"
                        src="/img/book-bookmark-minimalistic-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-113">Library</div>
                    </div>
                  </div>
                </div>

                <div className="frame-215">
                  <img
                    className="img-13"
                    alt="Setting svgrepo"
                    src="/img/setting-2-svgrepo-com-2.svg"
                  />

                  <div className="text-wrapper-113">Settings</div>
                </div>

                <div className="frame-215">
                  <img
                    className="img-13"
                    alt="Open book svgrepo"
                    src="/img/open-book-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-113">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-216">
            <div className="frame-217">
              <div className="frame-218">
                <div className="frame-219">
                  <div className="text-wrapper-114">Real Estate</div>

                  <SearchNormal38 className="search-normal-1" color="#292929" />
                </div>
              </div>

              <div className="back-icon-button-13">
                <div className="img-13">
                  <div className="vuesax-linear-4">
                    <div className="notification-4">
                      <img
                        className="group-21"
                        alt="Group"
                        src="/img/group-33845-6.png"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="back-icon-button-13">
                <img
                  className="img-13"
                  alt="Messenger fill"
                  src="/img/messenger-fill-svgrepo-com-1.svg"
                />
              </div>

              <div className="frame-220">
                <div className="frame-221">
                  <img
                    className="ellipse-7"
                    alt="Ellipse"
                    src="/img/ellipse-52.png"
                  />

                  <div className="frame-222">
                    <div className="text-wrapper-115">Lenny White</div>
                  </div>
                </div>

                <img
                  className="search-normal-1"
                  alt="Expand more"
                  src="/img/expand-more-1-2.svg"
                />
              </div>
            </div>

            <div className="frame-223">
              <div className="frame-224">
                <div className="frame-225">
                  <div className="back-icon-button-12">
                    <div className="vuesax-outline-arrow-7" />
                  </div>

                  <div className="frame-201">
                    <div className="frame-226">
                      <div className="text-wrapper-116">Saved Expert</div>

                      <div className="frame-227">
                        <div className="vuesax-linear-add-wrapper">
                          <div className="vuesax-linear-add" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-203">
                  <div className="element-solutions-card-3">
                    <div className="frame-228">
                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-8-2.png"
                        />

                        <img
                          className="image-16"
                          alt="Image"
                          src="/img/image-9.png"
                        />
                      </div>

                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-10-2x.png"
                        />

                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-3-2x.png"
                        />
                      </div>
                    </div>

                    <div className="frame-205">
                      <div className="title-wrapper">
                        <div className="title-3">Gardening</div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-3">
                    <div className="frame-228">
                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-8-2.png"
                        />

                        <img
                          className="image-16"
                          alt="Image"
                          src="/img/image-9.png"
                        />
                      </div>

                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-10-2x.png"
                        />

                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-3-2x.png"
                        />
                      </div>
                    </div>

                    <div className="frame-205">
                      <div className="title-wrapper">
                        <div className="title-3">Music</div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-3">
                    <div className="frame-228">
                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-8-2.png"
                        />

                        <img
                          className="image-16"
                          alt="Image"
                          src="/img/image-9.png"
                        />
                      </div>

                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-10-2x.png"
                        />

                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-3-2x.png"
                        />
                      </div>
                    </div>

                    <div className="frame-205">
                      <div className="title-wrapper">
                        <div className="title-3">Writing</div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-3">
                    <div className="frame-228">
                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-8-2.png"
                        />

                        <img
                          className="image-16"
                          alt="Image"
                          src="/img/image-9.png"
                        />
                      </div>

                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-10-2x.png"
                        />

                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-3-2x.png"
                        />
                      </div>
                    </div>

                    <div className="frame-205">
                      <div className="title-wrapper">
                        <div className="title-3">Gardening</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-203">
                  <div className="element-solutions-card-3">
                    <div className="frame-228">
                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-8-2.png"
                        />

                        <img
                          className="image-16"
                          alt="Image"
                          src="/img/image-9.png"
                        />
                      </div>

                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-10-2x.png"
                        />

                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-3-2x.png"
                        />
                      </div>
                    </div>

                    <div className="frame-205">
                      <div className="title-wrapper">
                        <div className="title-3">Gardening</div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-3">
                    <div className="frame-228">
                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-8-2.png"
                        />

                        <img
                          className="image-16"
                          alt="Image"
                          src="/img/image-9.png"
                        />
                      </div>

                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-10-2x.png"
                        />

                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-3-2x.png"
                        />
                      </div>
                    </div>

                    <div className="frame-205">
                      <div className="title-wrapper">
                        <div className="title-3">Music</div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-3">
                    <div className="frame-228">
                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-8-2.png"
                        />

                        <img
                          className="image-16"
                          alt="Image"
                          src="/img/image-9.png"
                        />
                      </div>

                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-10-2x.png"
                        />

                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-3-2x.png"
                        />
                      </div>
                    </div>

                    <div className="frame-205">
                      <div className="title-wrapper">
                        <div className="title-3">Writing</div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-3">
                    <div className="frame-228">
                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-8-2.png"
                        />

                        <img
                          className="image-16"
                          alt="Image"
                          src="/img/image-9.png"
                        />
                      </div>

                      <div className="frame-229">
                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-10-2x.png"
                        />

                        <img
                          className="image-15"
                          alt="Image"
                          src="/img/image-3-2x.png"
                        />
                      </div>
                    </div>

                    <div className="frame-205">
                      <div className="title-wrapper">
                        <div className="title-3">Gardening</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
