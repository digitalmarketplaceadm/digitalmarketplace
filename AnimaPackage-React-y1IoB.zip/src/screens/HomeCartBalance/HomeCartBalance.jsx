import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal1 } from "../../icons/SearchNormal1";
import { SearchNormal38 } from "../../icons/SearchNormal38";
import "./style.css";

export const HomeCartBalance = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="home-cart-balance"
      style={{
        alignItems:
          screenWidth < 1440
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1440
            ? "var(--variable-collection-white-duplicate)"
            : screenWidth >= 1440
              ? "var(--variable-collection-fill-duplicate)"
              : undefined,
        flexDirection: screenWidth < 1440 ? "column" : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight:
          screenWidth < 1440
            ? "100vh"
            : screenWidth >= 1440
              ? "1023px"
              : undefined,
        minWidth:
          screenWidth < 1440
            ? "393px"
            : screenWidth >= 1440
              ? "1440px"
              : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
        width: screenWidth >= 1440 ? "100%" : undefined,
      }}
    >
      {screenWidth < 1440 && (
        <>
          <StatusBar
            actionClassName="status-bar-46"
            batteryClassName="status-bar-49"
            className="status-bar-45"
            combinedShape="/img/combined-shape-2.svg"
            containerClassName="status-bar-48"
            property1="dark"
            rectangleClassName="status-bar-50"
            timeClassName="status-bar-47"
            wiFi="/img/wi-fi-2.svg"
          />
          <div className="frame-298">
            <div className="back-icon-button-19">
              <div className="vuesax-outline-arrow-10" />
            </div>

            <div className="frame-299">
              <div className="text-wrapper-145">My Balance</div>
            </div>
          </div>

          <div className="frame-300">
            <div className="background" />

            <div className="frame-301">
              <div className="frame-302">
                <div className="text-wrapper-146">Total Balance</div>
              </div>

              <div className="frame-303">
                <div className="text-wrapper-147">$12,650.00</div>

                <div className="group-37" />
              </div>
            </div>

            <div className="frame-304">
              <div className="frame-305">
                <div className="back-icon-button-20">
                  <img
                    className="img-17"
                    alt="Atm svgrepo com"
                    src="/img/atm-14-svgrepo-com-1.svg"
                  />
                </div>

                <div className="text-wrapper-148">Withdraw</div>
              </div>

              <div className="frame-305">
                <div className="back-icon-button-20">
                  <img
                    className="img-17"
                    alt="Paper plane svgrepo"
                    src="/img/paper-plane-svgrepo-com-1.svg"
                  />
                </div>

                <div className="text-wrapper-148">Transfer</div>
              </div>

              <div className="frame-305">
                <div className="back-icon-button-20">
                  <img
                    className="img-17"
                    alt="Top up balance"
                    src="/img/top-up-balance-svgrepo-com-1.svg"
                  />
                </div>

                <div className="text-wrapper-148">Top Up</div>
              </div>

              <div className="frame-305">
                <div className="back-icon-button-20">
                  <img
                    className="img-17"
                    alt="Money deposit money"
                    src="/img/money-deposit-money-deposit-account-svgrepo-com-1.svg"
                  />
                </div>

                <div className="text-wrapper-148">Deposit</div>
              </div>
            </div>

            <div className="frame-306">
              <div className="text-wrapper-149">Transaction</div>

              <div className="text-wrapper-150">View All</div>
            </div>

            <div className="frame-307">
              <div className="frame-308">
                <div className="back-icon-button-20">
                  <div className="group-38" />
                </div>
              </div>

              <div className="frame-309">
                <div className="frame-310">
                  <div className="text-wrapper-151">Online Shopping</div>

                  <div className="text-wrapper-152">1 May 9:23</div>
                </div>

                <div className="frame-311">
                  <div className="text-wrapper-153">+$120.00</div>

                  <div className="frame-312">
                    <div className="text-wrapper-154">Success</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-307">
              <div className="frame-308">
                <div className="back-icon-button-20">
                  <div className="group-38" />
                </div>
              </div>

              <div className="frame-309">
                <div className="frame-310">
                  <div className="text-wrapper-151">Online Shopping</div>

                  <div className="text-wrapper-152">1 May 9:23</div>
                </div>

                <div className="frame-311">
                  <div className="text-wrapper-153">+$120.00</div>

                  <div className="frame-312">
                    <div className="text-wrapper-154">Success</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-307">
              <div className="frame-308">
                <div className="back-icon-button-20">
                  <div className="group-38" />
                </div>
              </div>

              <div className="frame-309">
                <div className="frame-310">
                  <div className="text-wrapper-151">Online Shopping</div>

                  <div className="text-wrapper-152">1 May 9:23</div>
                </div>

                <div className="frame-311">
                  <div className="text-wrapper-153">+$120.00</div>

                  <div className="frame-312">
                    <div className="text-wrapper-154">Success</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-307">
              <div className="frame-308">
                <div className="back-icon-button-20">
                  <div className="group-38" />
                </div>
              </div>

              <div className="frame-309">
                <div className="frame-310">
                  <div className="text-wrapper-151">Online Shopping</div>

                  <div className="text-wrapper-152">1 May 9:23</div>
                </div>

                <div className="frame-311">
                  <div className="text-wrapper-153">+$120.00</div>

                  <div className="frame-312">
                    <div className="text-wrapper-154">Success</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-307">
              <div className="frame-308">
                <div className="back-icon-button-20">
                  <div className="group-38" />
                </div>
              </div>

              <div className="frame-309">
                <div className="frame-310">
                  <div className="text-wrapper-151">Online Shopping</div>

                  <div className="text-wrapper-152">1 May 9:23</div>
                </div>

                <div className="frame-311">
                  <div className="text-wrapper-153">+$120.00</div>

                  <div className="frame-312">
                    <div className="text-wrapper-154">Success</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-313">
              <div className="frame-308">
                <div className="back-icon-button-20">
                  <div className="group-38" />
                </div>
              </div>

              <div className="frame-309">
                <div className="frame-310">
                  <div className="text-wrapper-151">Online Shopping</div>

                  <div className="text-wrapper-152">1 May 9:23</div>
                </div>

                <div className="frame-311">
                  <div className="text-wrapper-153">+$120.00</div>

                  <div className="frame-312">
                    <div className="text-wrapper-154">Success</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-314">
            <div className="BNB-7">
              <div className="navigation-menu-8">
                <img
                  className="img-17"
                  alt="Home svgrepo com"
                  src="/img/home-svgrepo-com-1.svg"
                />

                <div className="text-wrapper-155">Home</div>
              </div>

              <div className="navigation-menu-8">
                <SearchNormal1 className="img-17" />
                <div className="text-wrapper-156">Search</div>
              </div>

              <div className="navigation-menu-8">
                <div className="group-39" />

                <div className="text-wrapper-157">Cart</div>
              </div>

              <div className="navigation-menu-8">
                <div className="img-17">
                  <div className="frame-315">
                    <div className="headset-svgrepo-com-4">
                      <div className="overlap-group-5">
                        <img
                          className="vector-36"
                          alt="Vector"
                          src="/img/vector.svg"
                        />

                        <img
                          className="vector-37"
                          alt="Vector"
                          src="/img/vector-1.svg"
                        />

                        <img
                          className="vector-38"
                          alt="Vector"
                          src="/img/vector-2-2.svg"
                        />

                        <img
                          className="vector-39"
                          alt="Vector"
                          src="/img/vector-3.svg"
                        />

                        <img
                          className="vector-40"
                          alt="Vector"
                          src="/img/vector-4.svg"
                        />

                        <img
                          className="vector-41"
                          alt="Vector"
                          src="/img/vector-5.svg"
                        />

                        <img
                          className="group-40"
                          alt="Group"
                          src="/img/group-2.png"
                        />

                        <img
                          className="group-41"
                          alt="Group"
                          src="/img/group-1.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-wrapper-157">Help</div>
              </div>

              <div className="navigation-menu-8">
                <img className="image-22" alt="Image" src="/img/image-14.png" />

                <div className="text-wrapper-157">Profile</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-19"
            lineClassName="home-indicator-20"
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-316">
          <div className="frame-317">
            <div className="frame-318">
              <div className="frame-319">
                <div className="frame-320">
                  <div className="frame-321">
                    <div className="text-wrapper-158">LOGO</div>
                  </div>
                </div>
              </div>

              <div className="frame-318">
                <div className="frame-318">
                  <div className="frame-322">
                    <div className="frame-323">
                      <img
                        className="img-17"
                        alt="Home svgrepo com"
                        src="/img/home-svgrepo-com-8.svg"
                      />

                      <div className="text-wrapper-159">Home</div>
                    </div>

                    <div className="frame-323">
                      <img
                        className="img-18"
                        alt="Security safe"
                        src="/img/security-safe-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-160">Security</div>
                    </div>

                    <div className="frame-323">
                      <div className="gift-13">
                        <div className="vuesax-linear-gift-8">
                          <img
                            className="gift-14"
                            alt="Gift"
                            src="/img/gift-16.png"
                          />
                        </div>
                      </div>

                      <div className="text-wrapper-160">Products</div>
                    </div>

                    <div className="frame-323">
                      <img
                        className="img-18"
                        alt="Advertising svgrepo"
                        src="/img/advertising-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-160">Marketing</div>
                    </div>

                    <div className="frame-323">
                      <img
                        className="img-18"
                        alt="Cart large svgrepo"
                        src="/img/cart-large-4-svgrepo-com-2.svg"
                      />

                      <div className="text-wrapper-160">Your Store</div>
                    </div>

                    <div className="frame-323">
                      <img
                        className="img-18"
                        alt="People svgrepo com"
                        src="/img/people-svgrepo-com-4.svg"
                      />

                      <div className="text-wrapper-160">Collaborators</div>
                    </div>

                    <div className="frame-323">
                      <div className="group-42" />

                      <div className="text-wrapper-160">Checkout</div>
                    </div>

                    <div className="frame-323">
                      <div className="img-18">
                        <div className="email-svgrepo-7">
                          <div className="page-8" />
                        </div>
                      </div>

                      <div className="text-wrapper-160">Emails</div>
                    </div>

                    <div className="frame-323">
                      <img
                        className="img-18"
                        alt="Flow parallel"
                        src="/img/flow-parallel-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-160">Workflows</div>
                    </div>

                    <div className="frame-323">
                      <img
                        className="img-18"
                        alt="Coin svgrepo com"
                        src="/img/coin-svgrepo-com-9.svg"
                      />

                      <div className="text-wrapper-160">Sales</div>
                    </div>

                    <div className="frame-323">
                      <img
                        className="img-18"
                        alt="Graph svgrepo com"
                        src="/img/graph-svgrepo-com.svg"
                      />

                      <div className="text-wrapper-160">Analytics</div>
                    </div>

                    <div className="frame-323">
                      <img
                        className="img-18"
                        alt="Coin svgrepo com"
                        src="/img/coin-svgrepo-com-9.svg"
                      />

                      <div className="text-wrapper-160">Payouts</div>
                    </div>

                    <div className="frame-323">
                      <img
                        className="img-18"
                        alt="Book bookmark"
                        src="/img/book-bookmark-minimalistic-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-160">Library</div>
                    </div>
                  </div>
                </div>

                <div className="frame-323">
                  <img
                    className="img-18"
                    alt="Setting svgrepo"
                    src="/img/setting-2-svgrepo-com-2.svg"
                  />

                  <div className="text-wrapper-160">Settings</div>
                </div>

                <div className="frame-323">
                  <img
                    className="img-18"
                    alt="Open book svgrepo"
                    src="/img/open-book-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-160">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-324">
            <div className="frame-325">
              <div className="frame-326">
                <div className="frame-327">
                  <div className="text-wrapper-161">Real Estate</div>

                  <SearchNormal38
                    className="search-normal-1-instance"
                    color="#292929"
                  />
                </div>
              </div>

              <div className="back-icon-button-21">
                <div className="img-18">
                  <div className="vuesax-linear-7">
                    <div className="notification-7">
                      <img
                        className="group-43"
                        alt="Group"
                        src="/img/group-33845-6.png"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="back-icon-button-21">
                <img
                  className="img-18"
                  alt="Messenger fill"
                  src="/img/messenger-fill-svgrepo-com-5.svg"
                />
              </div>

              <div className="frame-328">
                <div className="frame-329">
                  <img
                    className="ellipse-10"
                    alt="Ellipse"
                    src="/img/ellipse-52.png"
                  />

                  <div className="frame-330">
                    <div className="text-wrapper-162">Lenny White</div>
                  </div>
                </div>

                <img
                  className="search-normal-1-instance"
                  alt="Expand more"
                  src="/img/expand-more-13.svg"
                />
              </div>
            </div>

            <div className="frame-331">
              <div className="frame-332">
                <div className="frame-333">
                  <div className="back-icon-button-19">
                    <div className="vuesax-outline-arrow-10" />
                  </div>

                  <div className="frame-299">
                    <div className="frame-306">
                      <p className="cart-2">
                        <span className="text-wrapper-163">Cart </span>

                        <span className="text-wrapper-164">(9)</span>
                      </p>

                      <div className="frame-334">
                        <div className="group-44">
                          <div className="vuesax-linear-add-4" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-335">
                  <div className="background-2" />

                  <div className="frame-301">
                    <div className="frame-302">
                      <div className="text-wrapper-146">Total Balance</div>
                    </div>

                    <div className="frame-303">
                      <div className="text-wrapper-147">$12,650.00</div>

                      <div className="group-37" />
                    </div>
                  </div>

                  <div className="frame-304">
                    <div className="frame-305">
                      <div className="back-icon-button-20">
                        <img
                          className="img-17"
                          alt="Atm svgrepo com"
                          src="/img/atm-14-svgrepo-com.svg"
                        />
                      </div>

                      <div className="text-wrapper-148">Withdraw</div>
                    </div>

                    <div className="frame-305">
                      <div className="back-icon-button-20">
                        <img
                          className="img-17"
                          alt="Paper plane svgrepo"
                          src="/img/paper-plane-svgrepo-com.svg"
                        />
                      </div>

                      <div className="text-wrapper-148">Transfer</div>
                    </div>

                    <div className="frame-305">
                      <div className="back-icon-button-20">
                        <img
                          className="img-17"
                          alt="Top up balance"
                          src="/img/top-up-balance-svgrepo-com.svg"
                        />
                      </div>

                      <div className="text-wrapper-148">Top Up</div>
                    </div>

                    <div className="frame-305">
                      <div className="back-icon-button-20">
                        <img
                          className="img-17"
                          alt="Money deposit money"
                          src="/img/money-deposit-money-deposit-account-svgrepo-com.svg"
                        />
                      </div>

                      <div className="text-wrapper-148">Deposit</div>
                    </div>
                  </div>

                  <div className="frame-306">
                    <div className="text-wrapper-149">Transaction</div>

                    <div className="text-wrapper-150">View All</div>
                  </div>

                  <div className="frame-307">
                    <div className="frame-308">
                      <div className="back-icon-button-20">
                        <div className="group-38" />
                      </div>
                    </div>

                    <div className="frame-309">
                      <div className="frame-310">
                        <div className="text-wrapper-151">Online Shopping</div>

                        <div className="text-wrapper-152">1 May 9:23</div>
                      </div>

                      <div className="frame-311">
                        <div className="text-wrapper-153">+$120.00</div>

                        <div className="frame-312">
                          <div className="text-wrapper-154">Success</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-307">
                    <div className="frame-308">
                      <div className="back-icon-button-20">
                        <div className="group-38" />
                      </div>
                    </div>

                    <div className="frame-309">
                      <div className="frame-310">
                        <div className="text-wrapper-151">Online Shopping</div>

                        <div className="text-wrapper-152">1 May 9:23</div>
                      </div>

                      <div className="frame-311">
                        <div className="text-wrapper-153">+$120.00</div>

                        <div className="frame-312">
                          <div className="text-wrapper-154">Success</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-307">
                    <div className="frame-308">
                      <div className="back-icon-button-20">
                        <div className="group-38" />
                      </div>
                    </div>

                    <div className="frame-309">
                      <div className="frame-310">
                        <div className="text-wrapper-151">Online Shopping</div>

                        <div className="text-wrapper-152">1 May 9:23</div>
                      </div>

                      <div className="frame-311">
                        <div className="text-wrapper-153">+$120.00</div>

                        <div className="frame-312">
                          <div className="text-wrapper-154">Success</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-307">
                    <div className="frame-308">
                      <div className="back-icon-button-20">
                        <div className="group-38" />
                      </div>
                    </div>

                    <div className="frame-309">
                      <div className="frame-310">
                        <div className="text-wrapper-151">Online Shopping</div>

                        <div className="text-wrapper-152">1 May 9:23</div>
                      </div>

                      <div className="frame-311">
                        <div className="text-wrapper-153">+$120.00</div>

                        <div className="frame-312">
                          <div className="text-wrapper-154">Success</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-307">
                    <div className="frame-308">
                      <div className="back-icon-button-20">
                        <div className="group-38" />
                      </div>
                    </div>

                    <div className="frame-309">
                      <div className="frame-310">
                        <div className="text-wrapper-151">Online Shopping</div>

                        <div className="text-wrapper-152">1 May 9:23</div>
                      </div>

                      <div className="frame-311">
                        <div className="text-wrapper-153">+$120.00</div>

                        <div className="frame-312">
                          <div className="text-wrapper-154">Success</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="frame-307">
                    <div className="frame-308">
                      <div className="back-icon-button-20">
                        <div className="group-38" />
                      </div>
                    </div>

                    <div className="frame-309">
                      <div className="frame-310">
                        <div className="text-wrapper-151">Online Shopping</div>

                        <div className="text-wrapper-152">1 May 9:23</div>
                      </div>

                      <div className="frame-311">
                        <div className="text-wrapper-153">+$120.00</div>

                        <div className="frame-312">
                          <div className="text-wrapper-154">Success</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="CTA-4">
                  <div className="frame-336">
                    <div className="text-wrapper-165">Cancel</div>
                  </div>

                  <div className="frame-337">
                    <div className="text-wrapper-166">Add</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
