import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal24 } from "../../icons/SearchNormal24";
import "./style.css";

export const SecurityIdCheck = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-ID-check"
      style={{
        alignItems:
          screenWidth < 1200
            ? "center"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1200
            ? "#ffffff"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection: screenWidth < 1200 ? "column" : undefined,
        gap:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
        minHeight:
          screenWidth < 1200
            ? "100vh"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "1022px"
              : undefined,
        minWidth:
          screenWidth < 1200
            ? "393px"
            : screenWidth >= 1200 && screenWidth < 1440
              ? "1200px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
        width:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "100%"
            : undefined,
      }}
    >
      {screenWidth < 1200 && (
        <>
          <StatusBar
            batteryClassName="status-bar-7"
            className="status-bar-5"
            combinedShape="/img/combined-shape-19.svg"
            containerClassName="status-bar-6"
            property1="dark"
            wiFi="/img/wi-fi-18.svg"
          />
          <div className="frame-233">
            <div className="back-icon-button-5">
              <div className="vuesax-outline-arrow-6" />
            </div>

            <div className="frame-234">
              <div className="text-wrapper-172">ID Check</div>
            </div>
          </div>

          <div className="frame-235">
            <div className="frame-236">
              <img className="group-2" alt="Group" src="/img/group-1.png" />

              <p className="upload-product-image">
                <span className="text-wrapper-173">Upload Product Image</span>

                <span className="text-wrapper-174"> (0/10)</span>
              </p>

              <div className="frame-237">
                <div className="text-wrapper-175">Upload</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-5"
            lineClassName="home-indicator-6"
            property1="dark"
          />
        </>
      )}

      {((screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440) && (
        <div className="frame-238">
          <div className="frame-239">
            <div className="frame-240">
              <div className="frame-241">
                <div className="frame-242">
                  <div className="frame-243">
                    <div className="text-wrapper-176">LOGO</div>
                  </div>
                </div>

                <div className="frame-244">
                  <div className="frame-245">
                    <img
                      className="img-15"
                      alt="Home angle svgrepo"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/home-angle-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/home-angle-svgrepo-com-19.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-177">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-240">
                <div className="frame-240">
                  <div className="frame-246">
                    <div className="img-15">
                      <div className="vuesax-linear-gift-4">
                        <img
                          className="gift-6"
                          alt="Gift"
                          src={
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "/img/gift-1.png"
                              : screenWidth >= 1440
                                ? "/img/gift-11.png"
                                : undefined
                          }
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-178">Products</div>
                  </div>

                  <div className="frame-246">
                    <img
                      className="img-15"
                      alt="Users group two"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/users-group-two-rounded-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/users-group-two-rounded-svgrepo-com-11.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-178">Collaborators</div>
                  </div>

                  <div className="frame-246">
                    <img
                      className="img-15"
                      alt="Cart svgrepo com"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/cart-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/cart-svgrepo-com-4.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-178">Checkout</div>
                  </div>

                  <div className="frame-246">
                    <img
                      className="img-15"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-178">Emails</div>
                  </div>

                  <div className="frame-246">
                    <img
                      className="img-15"
                      alt="Flow parallel"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/flow-parallel-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/flow-parallel-svgrepo-com-11.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-178">Workflows</div>
                  </div>

                  <div className="frame-246">
                    <img
                      className="img-15"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-2.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-22.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-178">Sales</div>
                  </div>

                  <div className="frame-246">
                    <img
                      className="img-15"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-178">Analytics</div>
                  </div>

                  <div className="frame-246">
                    <img
                      className="img-15"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-2.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-23.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-178">Payouts</div>
                  </div>

                  <div className="frame-246">
                    <img
                      className="img-15"
                      alt="Book bookmark"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/book-bookmark-minimalistic-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/book-bookmark-minimalistic-svgrepo-com-11.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-178">Library</div>
                  </div>
                </div>

                <div className="frame-246">
                  <img
                    className="img-15"
                    alt="Settings svgrepo com"
                    src={
                      screenWidth >= 1200 && screenWidth < 1440
                        ? "/img/settings-svgrepo-com-1.svg"
                        : screenWidth >= 1440
                          ? "/img/settings-svgrepo-com-11.svg"
                          : undefined
                    }
                  />

                  <div className="text-wrapper-178">Settings</div>
                </div>

                <div className="frame-246">
                  <img
                    className="img-15"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-4.svg"
                  />

                  <div className="text-wrapper-178">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-247">
            <div className="frame-248">
              <div className="frame-249">
                <div className="frame-250">
                  <div className="text-wrapper-179">Search</div>

                  <SearchNormal24
                    className="search-normal-10"
                    color="#232323"
                  />
                </div>
              </div>

              <div className="frame-251">
                <div className="text-wrapper-180">Login</div>
              </div>

              <div className="frame-252">
                <div className="text-wrapper-181">Sign Up</div>
              </div>
            </div>

            <div className="frame-253">
              <div className="frame-254">
                <div className="frame-255">
                  <div className="frame-256">
                    <div className="frame-255">
                      <div className="back-icon-button-5">
                        <div className="vuesax-outline-arrow-6" />
                      </div>

                      <div className="text-wrapper-182">ID Check</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="frame-257">
                <img className="group-3" alt="Group" src="/img/group.png" />

                <div className="frame-258">
                  <p className="upload-product-image-2">
                    <span className="text-wrapper-173">
                      Upload Product Image
                    </span>

                    <span className="text-wrapper-174"> (0/10)</span>
                  </p>

                  <p className="text-wrapper-183">
                    Drag and drop your file here, or click to browse.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
