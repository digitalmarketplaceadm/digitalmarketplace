import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const SecurityIdCheck = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="security-ID-check"
      style={{
        alignItems:
          screenWidth < 1200
            ? "center"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1200
            ? "#ffffff"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection: screenWidth < 1200 ? "column" : undefined,
        gap:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
        minHeight:
          screenWidth < 1200
            ? "100vh"
            : (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
              ? "1022px"
              : undefined,
        minWidth:
          screenWidth < 1200
            ? "393px"
            : screenWidth >= 1200 && screenWidth < 1440
              ? "1200px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        padding:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "16px"
            : undefined,
        width:
          (screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440
            ? "100%"
            : undefined,
      }}
    >
      {screenWidth < 1200 && (
        <>
          <StatusBar
            batteryClassName="status-bar-111"
            className="status-bar-109"
            combinedShape="/img/combined-shape-39.svg"
            containerClassName="status-bar-110"
            property1="dark"
            wiFi="/img/wi-fi-38.svg"
          />
          <div className="frame-978">
            <div className="back-icon-button-43">
              <div className="vuesax-outline-arrow-24" />
            </div>

            <div className="frame-979">
              <div className="text-wrapper-489">ID Check</div>
            </div>
          </div>

          <div className="frame-980">
            <div className="frame-981">
              <img
                className="group-148"
                alt="Group"
                src="/img/group-1-2x.png"
              />

              <p className="upload-product-image">
                <span className="text-wrapper-490">Upload Product Image</span>

                <span className="text-wrapper-491"> (0/10)</span>
              </p>

              <div className="frame-982">
                <div className="text-wrapper-492">Upload</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-42"
            lineClassName="home-indicator-43"
            property1="dark"
          />
        </>
      )}

      {((screenWidth >= 1200 && screenWidth < 1440) || screenWidth >= 1440) && (
        <div className="frame-983">
          <div className="frame-984">
            <div className="frame-985">
              <div className="frame-986">
                <div className="frame-987">
                  <div className="frame-988">
                    <div className="text-wrapper-493">LOGO</div>
                  </div>
                </div>

                <div className="frame-989">
                  <div className="frame-990">
                    <img
                      className="img-54"
                      alt="Home angle svgrepo"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/home-angle-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/home-angle-svgrepo-com-19.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-494">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-985">
                <div className="frame-985">
                  <div className="frame-991">
                    <div className="img-54">
                      <div className="vuesax-linear-gift-21">
                        <img
                          className="gift-31"
                          alt="Gift"
                          src={
                            screenWidth >= 1200 && screenWidth < 1440
                              ? "/img/gift-1.png"
                              : screenWidth >= 1440
                                ? "/img/gift-11.png"
                                : undefined
                          }
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-495">Products</div>
                  </div>

                  <div className="frame-991">
                    <img
                      className="img-54"
                      alt="Users group two"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/users-group-two-rounded-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/users-group-two-rounded-svgrepo-com-11.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-495">Collaborators</div>
                  </div>

                  <div className="frame-991">
                    <img
                      className="img-54"
                      alt="Cart svgrepo com"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/cart-svgrepo-com-1-2.svg"
                          : screenWidth >= 1440
                            ? "/img/cart-svgrepo-com-9-2.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-495">Checkout</div>
                  </div>

                  <div className="frame-991">
                    <img
                      className="img-54"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-495">Emails</div>
                  </div>

                  <div className="frame-991">
                    <img
                      className="img-54"
                      alt="Flow parallel"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/flow-parallel-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/flow-parallel-svgrepo-com-11.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-495">Workflows</div>
                  </div>

                  <div className="frame-991">
                    <img
                      className="img-54"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-2.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-22.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-495">Sales</div>
                  </div>

                  <div className="frame-991">
                    <img
                      className="img-54"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-495">Analytics</div>
                  </div>

                  <div className="frame-991">
                    <img
                      className="img-54"
                      alt="Money dollars"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/money-dollars-svgrepo-com-2.svg"
                          : screenWidth >= 1440
                            ? "/img/money-dollars-svgrepo-com-23.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-495">Payouts</div>
                  </div>

                  <div className="frame-991">
                    <img
                      className="img-54"
                      alt="Book bookmark"
                      src={
                        screenWidth >= 1200 && screenWidth < 1440
                          ? "/img/book-bookmark-minimalistic-svgrepo-com-1.svg"
                          : screenWidth >= 1440
                            ? "/img/book-bookmark-minimalistic-svgrepo-com-11.svg"
                            : undefined
                      }
                    />

                    <div className="text-wrapper-495">Library</div>
                  </div>
                </div>

                <div className="frame-991">
                  <img
                    className="img-54"
                    alt="Settings svgrepo com"
                    src={
                      screenWidth >= 1200 && screenWidth < 1440
                        ? "/img/settings-svgrepo-com-1.svg"
                        : screenWidth >= 1440
                          ? "/img/settings-svgrepo-com-11.svg"
                          : undefined
                    }
                  />

                  <div className="text-wrapper-495">Settings</div>
                </div>

                <div className="frame-991">
                  <img
                    className="img-54"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-9.svg"
                  />

                  <div className="text-wrapper-495">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-992">
            <div className="frame-993">
              <div className="frame-994">
                <div className="frame-995">
                  <div className="text-wrapper-496">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-996">
                <div className="text-wrapper-497">Login</div>
              </div>

              <div className="frame-997">
                <div className="text-wrapper-498">Sign Up</div>
              </div>
            </div>

            <div className="frame-998">
              <div className="frame-999">
                <div className="frame-1000">
                  <div className="frame-1001">
                    <div className="frame-1000">
                      <div className="back-icon-button-43">
                        <div className="vuesax-outline-arrow-24" />
                      </div>

                      <div className="text-wrapper-499">ID Check</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="frame-1002">
                <img className="group-149" alt="Group" src="/img/group.png" />

                <div className="frame-1003">
                  <p className="upload-product-image-2">
                    <span className="text-wrapper-490">
                      Upload Product Image
                    </span>

                    <span className="text-wrapper-491"> (0/10)</span>
                  </p>

                  <p className="text-wrapper-500">
                    Drag and drop your file here, or click to browse.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
