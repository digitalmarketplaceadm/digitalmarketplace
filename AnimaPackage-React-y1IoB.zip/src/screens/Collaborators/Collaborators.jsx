import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { SearchNormal } from "../../components/SearchNormal";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const Collaborators = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="collaborators"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "100vh" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        overflow: screenWidth < 393 ? "hidden" : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
      }}
    >
      {screenWidth < 393 && (
        <div className="status-bar-105">
          <div className="time-wrapper">
            <div className="time-2">9:41</div>
          </div>

          <div className="container-2">
            <div className="battery-2">
              <div className="overlap-group-15">
                <img
                  className="rectangle-8"
                  alt="Rectangle"
                  src="/img/rectangle-32-2.svg"
                />

                <div className="rectangle-9" />
              </div>
            </div>

            <img
              className="combined-shape-2"
              alt="Combined shape"
              src="/img/combined-shape-32-2.svg"
            />

            <img className="wi-fi-2" alt="Wi fi" src="/img/wi-fi-32.svg" />
          </div>
        </div>
      )}

      {screenWidth >= 393 && screenWidth < 1440 && (
        <StatusBar
          batteryClassName="status-bar-108"
          className="status-bar-106"
          combinedShape="/img/combined-shape-21.svg"
          containerClassName="status-bar-107"
          property1="dark"
          wiFi="/img/wi-fi-20.svg"
        />
      )}

      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <div className="frame-793">
            <div className="back-icon-button-38">
              <div className="vuesax-outline-arrow-20" />
            </div>

            <div className="frame-794">
              <div className="text-wrapper-386">Products</div>

              <div className="text-wrapper-387">9 Products</div>
            </div>
          </div>

          <div className="frame-795">
            <div className="frame-796">
              <div className="frame-797">
                <div className="text-wrapper-388">Products</div>

                <img
                  className="vector-148"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61825.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44363.00px"
                          : undefined,
                  }}
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>

              <div className="frame-797">
                <div className="text-wrapper-389">Collaborators</div>

                <img
                  className="vector-149"
                  alt="Vector"
                  src={
                    screenWidth < 393
                      ? "/img/vector-1-49.svg"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "/img/vector-1-52.svg"
                        : undefined
                  }
                />
              </div>

              <div className="frame-797">
                <div className="text-wrapper-388">Reviews</div>

                <img
                  className="vector-150"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-62013.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44551.00px"
                          : undefined,
                  }}
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>
            </div>

            <div className="frame-798">
              <div className="div-12">
                <div className="text-wrapper-390">Product Name</div>

                <div className="text-wrapper-391">Product Name</div>

                <div
                  className="text-wrapper-392"
                  style={{
                    marginRight: screenWidth < 393 ? "-48.00px" : undefined,
                  }}
                >
                  Discount
                </div>

                <div
                  className="text-wrapper-393"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-98.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-25.00px"
                          : undefined,
                  }}
                >
                  Edit
                </div>

                <div
                  className="three-dots-svgrepo"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-12">
                <div className="frame-799">
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-73.png"
                  />

                  <div className="text-wrapper-394">Alice Thompson</div>
                </div>

                <div
                  className="frame-800"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-42.png"
                  />

                  <div className="text-wrapper-395">
                    Real Estate Landing Page
                  </div>
                </div>

                <div
                  className="input-42"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-396">50</div>

                  <div className="text-wrapper-397">%</div>
                </div>

                <div
                  className="frame-801"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-464.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-391.00px"
                          : undefined,
                  }}
                >
                  <div className="switch">
                    <div className="switch-2" />
                  </div>

                  <div className="text-wrapper-398">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-2"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-12">
                <div className="frame-799">
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-75.png"
                  />

                  <div className="text-wrapper-394">David Lee</div>
                </div>

                <div
                  className="frame-802"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img
                    className="image-42"
                    alt="Image"
                    src="/img/image-43.png"
                  />

                  <div className="text-wrapper-395">
                    Business Pro Landing Page
                  </div>
                </div>

                <div
                  className="input-43"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-396">50</div>

                  <div className="text-wrapper-397">%</div>
                </div>

                <div
                  className="frame-803"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-464.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-391.00px"
                          : undefined,
                  }}
                >
                  <div className="switch-wrapper">
                    <div className="switch-3" />
                  </div>

                  <div className="text-wrapper-398">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-3"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-12">
                <div className="frame-799">
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-77.png"
                  />

                  <div className="text-wrapper-394">Michael Brown</div>
                </div>

                <div
                  className="frame-804"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-44.png"
                  />

                  <div className="text-wrapper-399">SaaS Starter Page</div>
                </div>

                <div
                  className="input-44"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-396">50</div>

                  <div className="text-wrapper-397">%</div>
                </div>

                <div
                  className="frame-805"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-277.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-204.00px"
                          : undefined,
                  }}
                >
                  <div className="switch-4">
                    <div className="switch-2" />
                  </div>

                  <div className="text-wrapper-400">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-4"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-12">
                <div className="frame-799">
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-78.png"
                  />

                  <div className="text-wrapper-394">Ethan Taylor</div>
                </div>

                <div
                  className="frame-806"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-45.png"
                  />

                  <div className="text-wrapper-395">
                    Event Promo Landing Page
                  </div>
                </div>

                <div
                  className="input-45"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-396">50</div>

                  <div className="text-wrapper-397">%</div>
                </div>

                <div
                  className="frame-807"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-277.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-204.00px"
                          : undefined,
                  }}
                >
                  <div className="switch-4">
                    <div className="switch-2" />
                  </div>

                  <div className="text-wrapper-400">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-5"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-12">
                <div className="frame-799">
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-79.png"
                  />

                  <div className="text-wrapper-394">Benjamin Harris</div>
                </div>

                <div
                  className="frame-808"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-46.png"
                  />

                  <div className="text-wrapper-395">Tech Conference Page</div>
                </div>

                <div
                  className="input-46"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-396">50</div>

                  <div className="text-wrapper-397">%</div>
                </div>

                <div
                  className="frame-809"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-277.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-204.00px"
                          : undefined,
                  }}
                >
                  <div className="switch-5">
                    <div className="switch-3" />
                  </div>

                  <div className="text-wrapper-400">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-6"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-12">
                <div className="frame-799">
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-80.png"
                  />

                  <div className="text-wrapper-394">Henry Carter</div>
                </div>

                <div
                  className="frame-810"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-47.png"
                  />

                  <div className="text-wrapper-399">Creative Portfolio</div>
                </div>

                <div
                  className="input-47"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-396">50</div>

                  <div className="text-wrapper-397">%</div>
                </div>

                <div
                  className="frame-811"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-277.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-204.00px"
                          : undefined,
                  }}
                >
                  <div className="switch-5">
                    <div className="switch-3" />
                  </div>

                  <div className="text-wrapper-400">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-7"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-12">
                <div className="frame-799">
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-82.png"
                  />

                  <div className="text-wrapper-394">Lily Lewis</div>
                </div>

                <div
                  className="frame-812"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-48.png"
                  />

                  <div className="text-wrapper-395">Webinar Funnel Page</div>
                </div>

                <div
                  className="input-48"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-396">50</div>

                  <div className="text-wrapper-397">%</div>
                </div>

                <div
                  className="frame-813"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-277.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-204.00px"
                          : undefined,
                  }}
                >
                  <div className="switch-4">
                    <div className="switch-2" />
                  </div>

                  <div className="text-wrapper-400">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-8"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-12">
                <div className="frame-799">
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-84.png"
                  />

                  <div className="text-wrapper-394">Grace Walker</div>
                </div>

                <div
                  className="frame-814"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-156.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-83.00px"
                          : undefined,
                  }}
                >
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-44.png"
                  />

                  <div className="text-wrapper-394">SaaS Starter Page</div>
                </div>

                <div
                  className="input-49"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-260.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-187.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-396">50</div>

                  <div className="text-wrapper-397">%</div>
                </div>

                <div
                  className="frame-815"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-285.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-212.00px"
                          : undefined,
                  }}
                >
                  <div className="switch-5">
                    <div className="switch-3" />
                  </div>

                  <div className="text-wrapper-400">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-9"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-12">
                <div className="frame-799">
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-85.png"
                  />

                  <div className="text-wrapper-394">Christopher Adams</div>
                </div>

                <div
                  className="frame-816"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-156.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-83.00px"
                          : undefined,
                  }}
                >
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-86.png"
                  />

                  <div className="text-wrapper-394">Minimal Portfolio</div>
                </div>

                <div
                  className="input-50"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-260.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-187.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-396">50</div>

                  <div className="text-wrapper-397">%</div>
                </div>

                <div
                  className="frame-817"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-285.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-212.00px"
                          : undefined,
                  }}
                >
                  <div className="switch-4">
                    <div className="switch-2" />
                  </div>

                  <div className="text-wrapper-400">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-10"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-12">
                <div className="frame-799">
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-87.png"
                  />

                  <div className="text-wrapper-394">Nathan Nelson</div>
                </div>

                <div
                  className="frame-818"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-156.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-83.00px"
                          : undefined,
                  }}
                >
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-45.png"
                  />

                  <div className="text-wrapper-395">
                    Event Promo Landing Page
                  </div>
                </div>

                <div
                  className="input-51"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-260.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-187.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-396">50</div>

                  <div className="text-wrapper-397">%</div>
                </div>

                <div
                  className="frame-819"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-285.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-212.00px"
                          : undefined,
                  }}
                >
                  <div className="switch-5">
                    <div className="switch-3" />
                  </div>

                  <div className="text-wrapper-400">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-11"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-12">
                <div className="frame-799">
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-88.png"
                  />

                  <div className="text-wrapper-394">Landon Robinson</div>
                </div>

                <div
                  className="frame-820"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-156.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-83.00px"
                          : undefined,
                  }}
                >
                  <img
                    className="image-41"
                    alt="Image"
                    src="/img/image-46.png"
                  />

                  <div className="text-wrapper-395">Tech Conference Page</div>
                </div>

                <div
                  className="input-52"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-260.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-187.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-396">50</div>

                  <div className="text-wrapper-397">%</div>
                </div>

                <div
                  className="frame-821"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-285.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-212.00px"
                          : undefined,
                  }}
                >
                  <div className="switch-5">
                    <div className="switch-3" />
                  </div>

                  <div className="text-wrapper-400">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-12"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>
            </div>
          </div>

          <div
            className="frame-822"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB-16">
              {screenWidth < 393 && (
                <div className="frame-823">
                  <div className="navigation-menu-home-12">
                    <div className="navigation-menu-home-13">
                      <img
                        className="img-44"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-14.svg"
                      />

                      <div className="text-wrapper-401">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-20">
                    <SearchNormal property1="linear" />
                    <div className="text-wrapper-402">Search</div>
                  </div>

                  <div className="navigation-menu-20">
                    <img
                      className="img-45"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-403">Cart</div>
                  </div>

                  <div className="navigation-menu-20">
                    <img
                      className="img-45"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-6-2.svg"
                    />

                    <div className="text-wrapper-404">Help</div>
                  </div>

                  <div className="navigation-menu-20">
                    <img
                      className="image-43"
                      alt="Image"
                      src="/img/image-6.png"
                    />

                    <div className="text-wrapper-405">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1440 && (
                <>
                  <div className="navigation-menu-home-12">
                    <div className="navigation-menu-home-13">
                      <img
                        className="img-44"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-15.svg"
                      />

                      <div className="text-wrapper-401">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-21">
                    <SearchNormal property1="linear" />
                  </div>

                  <div className="navigation-menu-21">
                    <img
                      className="img-44"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-7.svg"
                    />
                  </div>

                  <div className="navigation-menu-21">
                    <div className="frame-824">
                      <div className="ellipse-36" />
                    </div>
                  </div>

                  <div className="navigation-menu-21">
                    <img
                      className="image-44"
                      alt="Image"
                      src="/img/image-6.png"
                    />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-39"
            lineClassName={`${screenWidth < 393 && "class-71"} ${screenWidth >= 393 && screenWidth < 1440 && "class-72"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-825">
          <div className="frame-826">
            <div className="frame-827">
              <div className="frame-828">
                <div className="frame-829">
                  <div className="frame-830">
                    <div className="text-wrapper-406">LOGO</div>
                  </div>
                </div>

                <div className="frame-831">
                  <div className="frame-832">
                    <img
                      className="img-46"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-10.svg"
                    />

                    <div className="text-wrapper-407">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-827">
                <div className="frame-827">
                  <div className="frame-833">
                    <div className="img-46">
                      <div className="vuesax-linear-gift-17">
                        <img
                          className="gift-27"
                          alt="Gift"
                          src="/img/gift-9.png"
                        />
                      </div>
                    </div>

                    <div className="text-wrapper-408">Products</div>
                  </div>

                  <div className="frame-833">
                    <img
                      className="img-46"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-6-2.svg"
                    />

                    <div className="text-wrapper-408">Collaborators</div>
                  </div>

                  <div className="frame-833">
                    <img
                      className="img-46"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-6-3.svg"
                    />

                    <div className="text-wrapper-408">Checkout</div>
                  </div>

                  <div className="frame-833">
                    <img
                      className="img-46"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-408">Emails</div>
                  </div>

                  <div className="frame-833">
                    <img
                      className="img-46"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-6-2.svg"
                    />

                    <div className="text-wrapper-408">Workflows</div>
                  </div>

                  <div className="frame-833">
                    <img
                      className="img-46"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12-2.svg"
                    />

                    <div className="text-wrapper-408">Sales</div>
                  </div>

                  <div className="frame-833">
                    <img
                      className="img-46"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com-9.svg"
                    />

                    <div className="text-wrapper-408">Analytics</div>
                  </div>

                  <div className="frame-833">
                    <img
                      className="img-46"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12-2.svg"
                    />

                    <div className="text-wrapper-408">Payouts</div>
                  </div>

                  <div className="frame-833">
                    <img
                      className="img-46"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-408">Library</div>
                  </div>
                </div>

                <div className="frame-833">
                  <img
                    className="img-46"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-408">Settings</div>
                </div>

                <div className="frame-833">
                  <img
                    className="img-46"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-408">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-834">
            <div className="frame-835">
              <div className="frame-836">
                <div className="frame-837">
                  <div className="text-wrapper-409">Search</div>

                  <SearchNormal property1="linear" />
                </div>
              </div>

              <div className="frame-838">
                <div className="text-wrapper-410">Login</div>
              </div>

              <div className="frame-839">
                <div className="text-wrapper-411">Sign Up</div>
              </div>
            </div>

            <div className="frame-840">
              <div className="frame-841">
                <div className="back-icon-button-38">
                  <div className="vuesax-outline-arrow-20" />
                </div>

                <div className="frame-842">
                  <div className="text-wrapper-412">Products</div>

                  <div className="text-wrapper-387">9 Products</div>
                </div>
              </div>

              <div className="frame-843">
                <div className="frame-796">
                  <div className="frame-797">
                    <div className="text-wrapper-388">Products</div>

                    <img
                      className="vector-151"
                      alt="Vector"
                      src="/img/vector-1-18.png"
                    />
                  </div>

                  <div className="frame-797">
                    <div className="text-wrapper-389">Collaborators</div>

                    <img
                      className="vector-149"
                      alt="Vector"
                      src="/img/vector-1-46.svg"
                    />
                  </div>

                  <div className="frame-797">
                    <div className="text-wrapper-388">Reviews</div>

                    <img
                      className="vector-152"
                      alt="Vector"
                      src="/img/vector-1-18.png"
                    />
                  </div>
                </div>

                <div className="frame-844">
                  <div className="frame-845">
                    <div className="frame-837">
                      <div className="text-wrapper-409">Search</div>

                      <img
                        className="search-normal-11"
                        alt="Search normal"
                        src="/img/search-normal-23.svg"
                      />
                    </div>
                  </div>

                  <div className="frame-846">
                    <div className="default-circle-8" />

                    <div className="text-wrapper-413">Select all Product</div>
                  </div>
                </div>

                <div className="frame-847">
                  <div className="div-12">
                    <div className="text-wrapper-414">Product Name</div>

                    <div className="text-wrapper-414">Product Name</div>

                    <div className="text-wrapper-415">Discount</div>

                    <div className="text-wrapper-415">Edit</div>

                    <div className="three-dots-svgrepo-13" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-50.png"
                      />

                      <div className="text-wrapper-394">Alice Thompson</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-8-2x.png"
                      />

                      <div className="text-wrapper-394">
                        Real Estate Landing Page
                      </div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-849">
                      <div className="switch">
                        <div className="switch-2" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-52.png"
                      />

                      <div className="text-wrapper-394">David Lee</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-46"
                        alt="Image"
                        src="/img/image-9-2x.png"
                      />

                      <div className="text-wrapper-394">
                        Business Pro Landing Page
                      </div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-850">
                      <div className="switch-wrapper">
                        <div className="switch-3" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-54.png"
                      />

                      <div className="text-wrapper-394">Michael Brown</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-10-2.png"
                      />

                      <div className="text-wrapper-394">SaaS Starter Page</div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-851">
                      <div className="switch">
                        <div className="switch-2" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-55.png"
                      />

                      <div className="text-wrapper-394">Daniel Clark</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-71.png"
                      />

                      <div className="text-wrapper-394">Minimal Portfolio</div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-852">
                      <div className="switch-wrapper">
                        <div className="switch-3" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-56.png"
                      />

                      <div className="text-wrapper-394">Ethan Taylor</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-57.png"
                      />

                      <div className="text-wrapper-394">Startup One-Pager</div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-853">
                      <div className="switch">
                        <div className="switch-2" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-58.png"
                      />

                      <div className="text-wrapper-394">Benjamin Harris</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-72.png"
                      />

                      <div className="text-wrapper-394">
                        Event Promo Landing Page
                      </div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-854">
                      <div className="switch-wrapper">
                        <div className="switch-3" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-59.png"
                      />

                      <div className="text-wrapper-394">Henry Carter</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-68.png"
                      />

                      <div className="text-wrapper-394">
                        Tech Conference Page
                      </div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-855">
                      <div className="switch-wrapper">
                        <div className="switch-3" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-60.png"
                      />

                      <div className="text-wrapper-394">William Young</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-61.png"
                      />

                      <div className="text-wrapper-394">Creative Portfolio</div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-856">
                      <div className="switch">
                        <div className="switch-2" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-62.png"
                      />

                      <div className="text-wrapper-394">Lily Lewis</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-69.png"
                      />

                      <div className="text-wrapper-394">
                        Webinar Funnel Page
                      </div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-857">
                      <div className="switch-wrapper">
                        <div className="switch-3" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-63.png"
                      />

                      <div className="text-wrapper-394">Grace Walker</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-10-2.png"
                      />

                      <div className="text-wrapper-394">SaaS Starter Page</div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-858">
                      <div className="switch">
                        <div className="switch-2" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-64.png"
                      />

                      <div className="text-wrapper-394">Christopher Adams</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-71.png"
                      />

                      <div className="text-wrapper-394">Minimal Portfolio</div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-859">
                      <div className="switch-wrapper">
                        <div className="switch-3" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-65.png"
                      />

                      <div className="text-wrapper-394">Nathan Nelson</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-72.png"
                      />

                      <div className="text-wrapper-394">
                        Event Promo Landing Page
                      </div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-860">
                      <div className="switch-wrapper">
                        <div className="switch-3" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-66.png"
                      />

                      <div className="text-wrapper-394">Landon Robinson</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-68.png"
                      />

                      <div className="text-wrapper-394">
                        Tech Conference Page
                      </div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-861">
                      <div className="switch-wrapper">
                        <div className="switch-3" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-12">
                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-67.png"
                      />

                      <div className="text-wrapper-394">Leo Carter</div>
                    </div>

                    <div className="frame-848">
                      <img
                        className="image-45"
                        alt="Image"
                        src="/img/image-69.png"
                      />

                      <div className="text-wrapper-394">
                        Webinar Funnel Page
                      </div>
                    </div>

                    <div className="input-53">
                      <div className="text-wrapper-396">50</div>

                      <div className="text-wrapper-397">%</div>
                    </div>

                    <div className="frame-862">
                      <div className="switch-wrapper">
                        <div className="switch-3" />
                      </div>

                      <div className="text-wrapper-398">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
