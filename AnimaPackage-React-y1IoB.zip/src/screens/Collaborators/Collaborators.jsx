import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { Switch } from "../../components/Switch";
import { SearchNormal24 } from "../../icons/SearchNormal24";
import "./style.css";

export const Collaborators = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="collaborators"
      style={{
        alignItems:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "#ffffff"
            : screenWidth >= 1440
              ? "#f5f6f8"
              : undefined,
        flexDirection:
          (screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393
            ? "column"
            : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "100vh" : undefined,
        minWidth:
          screenWidth < 393
            ? "320px"
            : screenWidth >= 393 && screenWidth < 1440
              ? "393px"
              : screenWidth >= 1440
                ? "1440px"
                : undefined,
        overflow: screenWidth < 393 ? "hidden" : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
      }}
    >
      {screenWidth < 393 && (
        <div className="status-bar-2">
          <div className="time-wrapper">
            <div className="time-2">9:41</div>
          </div>

          <div className="container-2">
            <div className="overlap-group-wrapper">
              <div className="overlap-group">
                <img
                  className="img"
                  alt="Rectangle"
                  src="/img/rectangle-32.svg"
                />

                <div className="rectangle-2" />
              </div>
            </div>

            <img
              className="combined-shape-2"
              alt="Combined shape"
              src="/img/combined-shape-32.svg"
            />

            <img className="wi-fi-2" alt="Wi fi" src="/img/wi-fi-32.svg" />
          </div>
        </div>
      )}

      {screenWidth >= 393 && screenWidth < 1440 && (
        <StatusBar
          batteryClassName="status-bar-4"
          className="status-bar-instance"
          combinedShape="/img/combined-shape-21.svg"
          containerClassName="status-bar-3"
          property1="dark"
          wiFi="/img/wi-fi-20.svg"
        />
      )}

      {((screenWidth >= 393 && screenWidth < 1440) || screenWidth < 393) && (
        <>
          <div className="frame">
            <div className="back-icon-button">
              <div className="vuesax-outline-arrow" />
            </div>

            <div className="frame-2">
              <div className="text-wrapper-2">Products</div>

              <div className="text-wrapper-3">9 Products</div>
            </div>
          </div>

          <div className="frame-3">
            <div className="frame-4">
              <div className="frame-5">
                <div className="text-wrapper-4">Products</div>

                <img
                  className="vector"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61825.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44363.00px"
                          : undefined,
                  }}
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>

              <div className="frame-5">
                <div className="text-wrapper-5">Collaborators</div>

                <img
                  className="vector-2"
                  alt="Vector"
                  src={
                    screenWidth < 393
                      ? "/img/vector-1-49.svg"
                      : screenWidth >= 393 && screenWidth < 1440
                        ? "/img/vector-1-52.svg"
                        : undefined
                  }
                />
              </div>

              <div className="frame-5">
                <div className="text-wrapper-4">Reviews</div>

                <img
                  className="vector-3"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-62013.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44551.00px"
                          : undefined,
                  }}
                  alt="Vector"
                  src="/img/vector-1-18.png"
                />
              </div>
            </div>

            <div className="frame-6">
              <div className="div-3">
                <div className="text-wrapper-6">Product Name</div>

                <div className="text-wrapper-7">Product Name</div>

                <div
                  className="text-wrapper-8"
                  style={{
                    marginRight: screenWidth < 393 ? "-48.00px" : undefined,
                  }}
                >
                  Discount
                </div>

                <div
                  className="text-wrapper-9"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-98.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-25.00px"
                          : undefined,
                  }}
                >
                  Edit
                </div>

                <div
                  className="three-dots-svgrepo"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-3">
                <div className="frame-7">
                  <img className="image" alt="Image" src="/img/image-73.png" />

                  <div className="text-wrapper-10">Alice Thompson</div>
                </div>

                <div
                  className="frame-8"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img className="image" alt="Image" src="/img/image-17.png" />

                  <div className="text-wrapper-11">
                    Real Estate Landing Page
                  </div>
                </div>

                <div
                  className="input"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-12">50</div>

                  <div className="text-wrapper-13">%</div>
                </div>

                <div
                  className="frame-9"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-464.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-391.00px"
                          : undefined,
                  }}
                >
                  <Switch
                    className="switch-instance"
                    copy={false}
                    size="medium"
                    status="off"
                    title={false}
                  />
                  <div className="text-wrapper-14">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-2"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-3">
                <div className="frame-7">
                  <img className="image" alt="Image" src="/img/image-75.png" />

                  <div className="text-wrapper-10">David Lee</div>
                </div>

                <div
                  className="frame-10"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img
                    className="image-2"
                    alt="Image"
                    src="/img/image-18.png"
                  />

                  <div className="text-wrapper-11">
                    Business Pro Landing Page
                  </div>
                </div>

                <div
                  className="input-2"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-12">50</div>

                  <div className="text-wrapper-13">%</div>
                </div>

                <div
                  className="frame-11"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-464.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-391.00px"
                          : undefined,
                  }}
                >
                  <Switch
                    className="switch-2"
                    copy={false}
                    size="medium"
                    status="on"
                    title={false}
                  />
                  <div className="text-wrapper-14">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-3"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-3">
                <div className="frame-7">
                  <img className="image" alt="Image" src="/img/image-77.png" />

                  <div className="text-wrapper-10">Michael Brown</div>
                </div>

                <div
                  className="frame-12"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img className="image" alt="Image" src="/img/image-44.png" />

                  <div className="text-wrapper-15">SaaS Starter Page</div>
                </div>

                <div
                  className="input-3"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-12">50</div>

                  <div className="text-wrapper-13">%</div>
                </div>

                <div
                  className="frame-13"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-277.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-204.00px"
                          : undefined,
                  }}
                >
                  <Switch
                    className="switch-3"
                    copy={false}
                    size="medium"
                    status="off"
                    title={false}
                  />
                  <div className="text-wrapper-16">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-4"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-3">
                <div className="frame-7">
                  <img className="image" alt="Image" src="/img/image-78.png" />

                  <div className="text-wrapper-10">Ethan Taylor</div>
                </div>

                <div
                  className="frame-14"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img className="image" alt="Image" src="/img/image-29.png" />

                  <div className="text-wrapper-11">
                    Event Promo Landing Page
                  </div>
                </div>

                <div
                  className="input-4"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-12">50</div>

                  <div className="text-wrapper-13">%</div>
                </div>

                <div
                  className="frame-15"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-277.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-204.00px"
                          : undefined,
                  }}
                >
                  <Switch
                    className="switch-3"
                    copy={false}
                    size="medium"
                    status="off"
                    title={false}
                  />
                  <div className="text-wrapper-16">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-5"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-3">
                <div className="frame-7">
                  <img className="image" alt="Image" src="/img/image-79.png" />

                  <div className="text-wrapper-10">Benjamin Harris</div>
                </div>

                <div
                  className="frame-16"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img className="image" alt="Image" src="/img/image-30.png" />

                  <div className="text-wrapper-11">Tech Conference Page</div>
                </div>

                <div
                  className="input-5"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-12">50</div>

                  <div className="text-wrapper-13">%</div>
                </div>

                <div
                  className="frame-17"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-277.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-204.00px"
                          : undefined,
                  }}
                >
                  <Switch
                    className="switch-4"
                    copy={false}
                    size="medium"
                    status="on"
                    title={false}
                  />
                  <div className="text-wrapper-16">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-6"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-3">
                <div className="frame-7">
                  <img className="image" alt="Image" src="/img/image-80.png" />

                  <div className="text-wrapper-10">Henry Carter</div>
                </div>

                <div
                  className="frame-18"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img className="image" alt="Image" src="/img/image-47.png" />

                  <div className="text-wrapper-15">Creative Portfolio</div>
                </div>

                <div
                  className="input-6"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-12">50</div>

                  <div className="text-wrapper-13">%</div>
                </div>

                <div
                  className="frame-19"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-277.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-204.00px"
                          : undefined,
                  }}
                >
                  <Switch
                    className="switch-4"
                    copy={false}
                    size="medium"
                    status="on"
                    title={false}
                  />
                  <div className="text-wrapper-16">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-7"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-3">
                <div className="frame-7">
                  <img className="image" alt="Image" src="/img/image-82.png" />

                  <div className="text-wrapper-10">Lily Lewis</div>
                </div>

                <div
                  className="frame-20"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-148.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-75.00px"
                          : undefined,
                  }}
                >
                  <img className="image" alt="Image" src="/img/image-32.png" />

                  <div className="text-wrapper-11">Webinar Funnel Page</div>
                </div>

                <div
                  className="input-7"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-252.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-179.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-12">50</div>

                  <div className="text-wrapper-13">%</div>
                </div>

                <div
                  className="frame-21"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-277.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-204.00px"
                          : undefined,
                  }}
                >
                  <Switch
                    className="switch-3"
                    copy={false}
                    size="medium"
                    status="off"
                    title={false}
                  />
                  <div className="text-wrapper-16">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-8"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-3">
                <div className="frame-7">
                  <img className="image" alt="Image" src="/img/image-84.png" />

                  <div className="text-wrapper-10">Grace Walker</div>
                </div>

                <div
                  className="frame-22"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-156.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-83.00px"
                          : undefined,
                  }}
                >
                  <img className="image" alt="Image" src="/img/image-44.png" />

                  <div className="text-wrapper-10">SaaS Starter Page</div>
                </div>

                <div
                  className="input-8"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-260.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-187.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-12">50</div>

                  <div className="text-wrapper-13">%</div>
                </div>

                <div
                  className="frame-23"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-285.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-212.00px"
                          : undefined,
                  }}
                >
                  <Switch
                    className="switch-4"
                    copy={false}
                    size="medium"
                    status="on"
                    title={false}
                  />
                  <div className="text-wrapper-16">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-9"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-3">
                <div className="frame-7">
                  <img className="image" alt="Image" src="/img/image-85.png" />

                  <div className="text-wrapper-10">Christopher Adams</div>
                </div>

                <div
                  className="frame-24"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-156.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-83.00px"
                          : undefined,
                  }}
                >
                  <img className="image" alt="Image" src="/img/image-86.png" />

                  <div className="text-wrapper-10">Minimal Portfolio</div>
                </div>

                <div
                  className="input-9"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-260.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-187.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-12">50</div>

                  <div className="text-wrapper-13">%</div>
                </div>

                <div
                  className="frame-25"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-285.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-212.00px"
                          : undefined,
                  }}
                >
                  <Switch
                    className="switch-3"
                    copy={false}
                    size="medium"
                    status="off"
                    title={false}
                  />
                  <div className="text-wrapper-16">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-10"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-3">
                <div className="frame-7">
                  <img className="image" alt="Image" src="/img/image-87.png" />

                  <div className="text-wrapper-10">Nathan Nelson</div>
                </div>

                <div
                  className="frame-26"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-156.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-83.00px"
                          : undefined,
                  }}
                >
                  <img className="image" alt="Image" src="/img/image-29.png" />

                  <div className="text-wrapper-11">
                    Event Promo Landing Page
                  </div>
                </div>

                <div
                  className="input-10"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-260.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-187.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-12">50</div>

                  <div className="text-wrapper-13">%</div>
                </div>

                <div
                  className="frame-27"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-285.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-212.00px"
                          : undefined,
                  }}
                >
                  <Switch
                    className="switch-4"
                    copy={false}
                    size="medium"
                    status="on"
                    title={false}
                  />
                  <div className="text-wrapper-16">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-11"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>

              <div className="div-3">
                <div className="frame-7">
                  <img className="image" alt="Image" src="/img/image-88.png" />

                  <div className="text-wrapper-10">Landon Robinson</div>
                </div>

                <div
                  className="frame-28"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-156.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-83.00px"
                          : undefined,
                  }}
                >
                  <img className="image" alt="Image" src="/img/image-30.png" />

                  <div className="text-wrapper-11">Tech Conference Page</div>
                </div>

                <div
                  className="input-11"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-260.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-187.00px"
                          : undefined,
                  }}
                >
                  <div className="text-wrapper-12">50</div>

                  <div className="text-wrapper-13">%</div>
                </div>

                <div
                  className="frame-29"
                  style={{
                    marginRight:
                      screenWidth < 393
                        ? "-285.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-212.00px"
                          : undefined,
                  }}
                >
                  <Switch
                    className="switch-4"
                    copy={false}
                    size="medium"
                    status="on"
                    title={false}
                  />
                  <div className="text-wrapper-16">Show as co-creator</div>
                </div>

                <div
                  className="three-dots-svgrepo-12"
                  style={{
                    marginLeft:
                      screenWidth < 393
                        ? "-61813.00px"
                        : screenWidth >= 393 && screenWidth < 1440
                          ? "-44351.00px"
                          : undefined,
                  }}
                />
              </div>
            </div>
          </div>

          <div
            className="BNB-wrapper"
            style={{
              padding:
                screenWidth < 393
                  ? "8px"
                  : screenWidth >= 393 && screenWidth < 1440
                    ? "8px 16px"
                    : undefined,
            }}
          >
            <div className="BNB">
              {screenWidth < 393 && (
                <div className="frame-30">
                  <div className="navigation-menu-home">
                    <div className="navigation-menu-home-2">
                      <img
                        className="img-2"
                        alt="Home angle svgrepo"
                        src="/img/image.svg"
                      />

                      <div className="text-wrapper-17">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu">
                    <SearchNormal24 className="img-3" color="#535353" />
                    <div className="text-wrapper-18">Search</div>
                  </div>

                  <div className="navigation-menu">
                    <img
                      className="img-3"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-19">Cart</div>
                  </div>

                  <div className="navigation-menu">
                    <img
                      className="img-3"
                      alt="Headphone alt"
                      src="/img/headphone-alt-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-20">Help</div>
                  </div>

                  <div className="navigation-menu">
                    <img className="image-3" alt="Image" src="/img/image.png" />

                    <div className="text-wrapper-21">Profile</div>
                  </div>
                </div>
              )}

              {screenWidth >= 393 && screenWidth < 1440 && (
                <>
                  <div className="navigation-menu-home">
                    <div className="navigation-menu-home-2">
                      <img
                        className="img-2"
                        alt="Home angle svgrepo"
                        src="/img/home-angle-svgrepo-com-11.svg"
                      />

                      <div className="text-wrapper-17">Home</div>
                    </div>
                  </div>

                  <div className="navigation-menu-2">
                    <SearchNormal24 className="img-2" color="#535353" />
                  </div>

                  <div className="navigation-menu-2">
                    <img
                      className="img-2"
                      alt="Cart large"
                      src="/img/cart-large-minimalistic-svgrepo-com-7.svg"
                    />
                  </div>

                  <div className="navigation-menu-2">
                    <div className="ellipse-wrapper">
                      <div className="ellipse" />
                    </div>
                  </div>

                  <div className="navigation-menu-2">
                    <img className="image-4" alt="Image" src="/img/image.png" />
                  </div>
                </>
              )}
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-instance"
            lineClassName={`${screenWidth < 393 && "class"} ${screenWidth >= 393 && screenWidth < 1440 && "class-2"}`}
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-31">
          <div className="frame-wrapper">
            <div className="frame-32">
              <div className="frame-33">
                <div className="div-wrapper">
                  <div className="frame-34">
                    <div className="text-wrapper-22">LOGO</div>
                  </div>
                </div>

                <div className="frame-35">
                  <div className="frame-36">
                    <img
                      className="img-4"
                      alt="Home angle svgrepo"
                      src="/img/home-angle-svgrepo-com-10.svg"
                    />

                    <div className="text-wrapper-23">Home</div>
                  </div>
                </div>
              </div>

              <div className="frame-32">
                <div className="frame-32">
                  <div className="frame-37">
                    <div className="img-4">
                      <div className="vuesax-linear-gift">
                        <img className="gift" alt="Gift" src="/img/gift.png" />
                      </div>
                    </div>

                    <div className="text-wrapper-24">Products</div>
                  </div>

                  <div className="frame-37">
                    <img
                      className="img-4"
                      alt="Users group two"
                      src="/img/users-group-two-rounded-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-24">Collaborators</div>
                  </div>

                  <div className="frame-37">
                    <img
                      className="img-4"
                      alt="Cart svgrepo com"
                      src="/img/cart-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-24">Checkout</div>
                  </div>

                  <div className="frame-37">
                    <img
                      className="img-4"
                      alt="Email envelope"
                      src="/img/email-envelope-letter-mail-message-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-24">Emails</div>
                  </div>

                  <div className="frame-37">
                    <img
                      className="img-4"
                      alt="Flow parallel"
                      src="/img/flow-parallel-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-24">Workflows</div>
                  </div>

                  <div className="frame-37">
                    <img
                      className="img-4"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-24">Sales</div>
                  </div>

                  <div className="frame-37">
                    <img
                      className="img-4"
                      alt="Chart waterfall"
                      src="/img/chart-waterfall-svgrepo-com.svg"
                    />

                    <div className="text-wrapper-24">Analytics</div>
                  </div>

                  <div className="frame-37">
                    <img
                      className="img-4"
                      alt="Money dollars"
                      src="/img/money-dollars-svgrepo-com-12.svg"
                    />

                    <div className="text-wrapper-24">Payouts</div>
                  </div>

                  <div className="frame-37">
                    <img
                      className="img-4"
                      alt="Book bookmark"
                      src="/img/book-bookmark-minimalistic-svgrepo-com-6.svg"
                    />

                    <div className="text-wrapper-24">Library</div>
                  </div>
                </div>

                <div className="frame-37">
                  <img
                    className="img-4"
                    alt="Settings svgrepo com"
                    src="/img/settings-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-24">Settings</div>
                </div>

                <div className="frame-37">
                  <img
                    className="img-4"
                    alt="Book open svgrepo"
                    src="/img/book-open-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-24">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-38">
            <div className="frame-39">
              <div className="frame-40">
                <div className="frame-41">
                  <div className="text-wrapper-25">Search</div>

                  <SearchNormal24 className="search-normal" color="#232323" />
                </div>
              </div>

              <div className="frame-42">
                <div className="text-wrapper-26">Login</div>
              </div>

              <div className="frame-43">
                <div className="text-wrapper-27">Sign Up</div>
              </div>
            </div>

            <div className="frame-44">
              <div className="frame-45">
                <div className="back-icon-button">
                  <div className="vuesax-outline-arrow" />
                </div>

                <div className="frame-46">
                  <div className="text-wrapper-28">Products</div>

                  <div className="text-wrapper-3">9 Products</div>
                </div>
              </div>

              <div className="frame-47">
                <div className="frame-4">
                  <div className="frame-5">
                    <div className="text-wrapper-4">Products</div>

                    <img
                      className="vector-4"
                      alt="Vector"
                      src="/img/vector-1-18.png"
                    />
                  </div>

                  <div className="frame-5">
                    <div className="text-wrapper-5">Collaborators</div>

                    <img
                      className="vector-2"
                      alt="Vector"
                      src="/img/vector-1-46.svg"
                    />
                  </div>

                  <div className="frame-5">
                    <div className="text-wrapper-4">Reviews</div>

                    <img
                      className="vector-5"
                      alt="Vector"
                      src="/img/vector-1-18.png"
                    />
                  </div>
                </div>

                <div className="frame-48">
                  <div className="frame-49">
                    <div className="frame-41">
                      <div className="text-wrapper-25">Search</div>

                      <SearchNormal24
                        className="search-normal"
                        color="#232323"
                      />
                    </div>
                  </div>

                  <div className="frame-50">
                    <div className="default-circle" />

                    <div className="text-wrapper-29">Select all Product</div>
                  </div>
                </div>

                <div className="frame-51">
                  <div className="div-3">
                    <div className="text-wrapper-30">Product Name</div>

                    <div className="text-wrapper-30">Product Name</div>

                    <div className="text-wrapper-31">Discount</div>

                    <div className="text-wrapper-31">Edit</div>

                    <div className="three-dots-svgrepo-13" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-50.png"
                      />

                      <div className="text-wrapper-10">Alice Thompson</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-8.png"
                      />

                      <div className="text-wrapper-10">
                        Real Estate Landing Page
                      </div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-53">
                      <Switch
                        className="switch-instance"
                        copy={false}
                        size="medium"
                        status="off"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-52.png"
                      />

                      <div className="text-wrapper-10">David Lee</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-6"
                        alt="Image"
                        src="/img/image-9.png"
                      />

                      <div className="text-wrapper-10">
                        Business Pro Landing Page
                      </div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-54">
                      <Switch
                        className="switch-2"
                        copy={false}
                        size="medium"
                        status="on"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-54.png"
                      />

                      <div className="text-wrapper-10">Michael Brown</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-10.png"
                      />

                      <div className="text-wrapper-10">SaaS Starter Page</div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-55">
                      <Switch
                        className="switch-instance"
                        copy={false}
                        size="medium"
                        status="off"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-55.png"
                      />

                      <div className="text-wrapper-10">Daniel Clark</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-71.png"
                      />

                      <div className="text-wrapper-10">Minimal Portfolio</div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-56">
                      <Switch
                        className="switch-2"
                        copy={false}
                        size="medium"
                        status="on"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-56.png"
                      />

                      <div className="text-wrapper-10">Ethan Taylor</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-57.png"
                      />

                      <div className="text-wrapper-10">Startup One-Pager</div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-57">
                      <Switch
                        className="switch-instance"
                        copy={false}
                        size="medium"
                        status="off"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-58.png"
                      />

                      <div className="text-wrapper-10">Benjamin Harris</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-72.png"
                      />

                      <div className="text-wrapper-10">
                        Event Promo Landing Page
                      </div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-58">
                      <Switch
                        className="switch-2"
                        copy={false}
                        size="medium"
                        status="on"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-59.png"
                      />

                      <div className="text-wrapper-10">Henry Carter</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-68.png"
                      />

                      <div className="text-wrapper-10">
                        Tech Conference Page
                      </div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-59">
                      <Switch
                        className="switch-2"
                        copy={false}
                        size="medium"
                        status="on"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-60.png"
                      />

                      <div className="text-wrapper-10">William Young</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-61.png"
                      />

                      <div className="text-wrapper-10">Creative Portfolio</div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-60">
                      <Switch
                        className="switch-instance"
                        copy={false}
                        size="medium"
                        status="off"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-62.png"
                      />

                      <div className="text-wrapper-10">Lily Lewis</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-69.png"
                      />

                      <div className="text-wrapper-10">Webinar Funnel Page</div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-61">
                      <Switch
                        className="switch-2"
                        copy={false}
                        size="medium"
                        status="on"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-63.png"
                      />

                      <div className="text-wrapper-10">Grace Walker</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-10.png"
                      />

                      <div className="text-wrapper-10">SaaS Starter Page</div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-62">
                      <Switch
                        className="switch-instance"
                        copy={false}
                        size="medium"
                        status="off"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-64.png"
                      />

                      <div className="text-wrapper-10">Christopher Adams</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-71.png"
                      />

                      <div className="text-wrapper-10">Minimal Portfolio</div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-63">
                      <Switch
                        className="switch-2"
                        copy={false}
                        size="medium"
                        status="on"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-65.png"
                      />

                      <div className="text-wrapper-10">Nathan Nelson</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-72.png"
                      />

                      <div className="text-wrapper-10">
                        Event Promo Landing Page
                      </div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-64">
                      <Switch
                        className="switch-2"
                        copy={false}
                        size="medium"
                        status="on"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-66.png"
                      />

                      <div className="text-wrapper-10">Landon Robinson</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-68.png"
                      />

                      <div className="text-wrapper-10">
                        Tech Conference Page
                      </div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-65">
                      <Switch
                        className="switch-2"
                        copy={false}
                        size="medium"
                        status="on"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>

                  <div className="div-3">
                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-67.png"
                      />

                      <div className="text-wrapper-10">Leo Carter</div>
                    </div>

                    <div className="frame-52">
                      <img
                        className="image-5"
                        alt="Image"
                        src="/img/image-69.png"
                      />

                      <div className="text-wrapper-10">Webinar Funnel Page</div>
                    </div>

                    <div className="input-12">
                      <div className="text-wrapper-12">50</div>

                      <div className="text-wrapper-13">%</div>
                    </div>

                    <div className="frame-66">
                      <Switch
                        className="switch-2"
                        copy={false}
                        size="medium"
                        status="on"
                        title={false}
                      />
                      <div className="text-wrapper-14">Show as co-creator</div>
                    </div>

                    <div className="three-dots-svgrepo-14" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
