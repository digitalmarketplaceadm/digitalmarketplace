import React from "react";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const NotificationRead = () => {
  return (
    <div className="notification-read">
      <StatusBar
        actionClassName="status-bar-51"
        batteryClassName="status-bar-54"
        className="design-component-instance-node"
        combinedShape="/img/combined-shape-5.svg"
        containerClassName="status-bar-53"
        property1="dark"
        rectangleClassName="status-bar-55"
        timeClassName="status-bar-52"
        wiFi="/img/wi-fi-5.svg"
      />
      <div className="frame-338">
        <div className="back-icon-button-22">
          <div className="vuesax-outline-arrow-11" />
        </div>

        <div className="frame-339">
          <div className="text-wrapper-167">Notification</div>
        </div>

        <div className="search-normal-wrapper">
          <div className="search-normal-3">
            <div className="vuesax-linear-search-2">
              <div className="search-normal-4">
                <img
                  className="group-45"
                  alt="Group"
                  src="/img/group-33839.png"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="frame-340">
        <div className="frame-341">
          <div className="frame-342">
            <div className="text-wrapper-168">All</div>

            <img
              className="vector-42"
              alt="Vector"
              src="/img/vector-1-18.png"
            />
          </div>

          <div className="frame-342">
            <div className="text-wrapper-168">Unread</div>

            <img
              className="vector-43"
              alt="Vector"
              src="/img/vector-1-18.png"
            />
          </div>

          <div className="frame-342">
            <div className="text-wrapper-169">Read</div>

            <img
              className="vector-44"
              alt="Vector"
              src="/img/vector-6762-8.svg"
            />
          </div>
        </div>

        <div className="frame-341">
          <div className="frame-343">
            <div className="frame-344">
              <div className="group-46">
                <div className="frame-345">
                  <div className="ellipse-11" />

                  <div className="group-47" />
                </div>
              </div>

              <div className="frame-346">
                <div className="frame-347">
                  <div className="text-wrapper-170">Lorraine Lim</div>

                  <div className="commented-lorem-wrapper">
                    <div className="commented-lorem">
                      Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                    </div>
                  </div>
                </div>

                <div className="text-wrapper-171">Friday 2:30 pm</div>
              </div>
            </div>
          </div>
        </div>

        <div className="frame-341">
          <div className="frame-343">
            <div className="frame-344">
              <div className="group-46">
                <div className="frame-345">
                  <div className="ellipse-11" />

                  <div className="group-48" />
                </div>
              </div>

              <div className="frame-346">
                <div className="frame-347">
                  <div className="text-wrapper-170">Aira Morgan</div>

                  <div className="commented-lorem-wrapper">
                    <div className="commented-lorem">
                      Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                    </div>
                  </div>
                </div>

                <div className="text-wrapper-171">Friday 2:30 pm</div>
              </div>
            </div>
          </div>
        </div>

        <div className="frame-341">
          <div className="frame-348">
            <div className="frame-343">
              <div className="frame-344">
                <div className="group-46">
                  <div className="frame-345">
                    <div className="ellipse-11" />

                    <div className="group-49" />
                  </div>
                </div>

                <div className="frame-346">
                  <div className="frame-347">
                    <div className="text-wrapper-170">Sienna Blake</div>

                    <div className="commented-lorem-wrapper">
                      <div className="commented-lorem">
                        Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                      </div>
                    </div>
                  </div>

                  <div className="text-wrapper-171">Friday 2:30 pm</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="frame-341">
          <div className="frame-348">
            <div className="frame-343">
              <div className="frame-344">
                <div className="group-46">
                  <div className="frame-345">
                    <div className="ellipse-11" />

                    <div className="group-50" />
                  </div>
                </div>

                <div className="frame-346">
                  <div className="frame-347">
                    <div className="text-wrapper-170">Noah Sinclair</div>

                    <div className="commented-lorem-wrapper">
                      <div className="commented-lorem">
                        Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                      </div>
                    </div>
                  </div>

                  <div className="text-wrapper-171">Friday 2:30 pm</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="frame-341">
          <div className="frame-348">
            <div className="frame-343">
              <div className="frame-344">
                <div className="group-46">
                  <div className="frame-345">
                    <div className="ellipse-11" />

                    <div className="group-51" />
                  </div>
                </div>

                <div className="frame-346">
                  <div className="frame-347">
                    <div className="text-wrapper-170">Leo Donovan</div>

                    <div className="commented-lorem-wrapper">
                      <div className="commented-lorem">
                        Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                      </div>
                    </div>
                  </div>

                  <div className="text-wrapper-171">Friday 2:30 pm</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="frame-341">
          <div className="frame-348">
            <div className="frame-343">
              <div className="frame-344">
                <div className="group-46">
                  <div className="frame-345">
                    <div className="ellipse-11" />

                    <div className="group-52" />
                  </div>
                </div>

                <div className="frame-346">
                  <div className="frame-347">
                    <div className="text-wrapper-170">Caleb Monroe</div>

                    <div className="commented-lorem-wrapper">
                      <div className="commented-lorem">
                        Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                      </div>
                    </div>
                  </div>

                  <div className="text-wrapper-171">Friday 2:30 pm</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <HomeIndicator
        className="home-indicator-21"
        lineClassName="home-indicator-22"
        property1="dark"
      />
    </div>
  );
};
