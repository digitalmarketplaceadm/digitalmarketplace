import React from "react";
import { useWindowWidth } from "../../breakpoints";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import { SearchNormal1 } from "../../icons/SearchNormal1";
import { SearchNormal38 } from "../../icons/SearchNormal38";
import "./style.css";

export const MyChannel = () => {
  const screenWidth = useWindowWidth();

  return (
    <div
      className="my-channel"
      style={{
        alignItems:
          screenWidth < 1440
            ? "center"
            : screenWidth >= 1440
              ? "flex-start"
              : undefined,
        backgroundColor:
          screenWidth < 1440
            ? "var(--variable-collection-white-duplicate)"
            : screenWidth >= 1440
              ? "var(--variable-collection-fill)"
              : undefined,
        flexDirection: screenWidth < 1440 ? "column" : undefined,
        gap: screenWidth >= 1440 ? "16px" : undefined,
        minHeight: screenWidth >= 1440 ? "100vh" : undefined,
        minWidth:
          screenWidth < 1440
            ? "393px"
            : screenWidth >= 1440
              ? "1440px"
              : undefined,
        padding: screenWidth >= 1440 ? "16px" : undefined,
      }}
    >
      {screenWidth < 1440 && (
        <>
          <StatusBar
            batteryClassName="status-bar-4"
            className="status-bar-instance"
            combinedShape="/img/combined-shape-5-2.svg"
            containerClassName="status-bar-3"
            property1="dark"
            rectangleClassName="status-bar-5"
            timeClassName="status-bar-2"
            wiFi="/img/wi-fi-31.svg"
          />
          <div className="frame">
            <div className="back-icon-button">
              <div className="vuesax-outline-arrow" />
            </div>

            <div className="text-wrapper">My Channel</div>
          </div>

          <div className="div-wrapper">
            <div className="frame-wrapper">
              <div className="div">
                <div className="text-wrapper-2">Search</div>

                <SearchNormal38 className="search-normal" color="#292929" />
              </div>
            </div>
          </div>

          <div className="frame-2">
            <div className="div-2">
              <div className="element-solutions-card">
                <img className="image" alt="Image" src="/img/image-6-2.png" />

                <div className="frame-3">
                  <div className="frame-4">
                    <div className="title">Real Estate Landing...</div>

                    <div className="text">
                      <div className="element-service">
                        <div className="description">$29.99</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="element-solutions-card">
                <img className="img" alt="Image" src="/img/image-7.png" />

                <div className="frame-5">
                  <div className="title">Business Pro Landing...</div>

                  <div className="text">
                    <div className="element-service">
                      <div className="description">$50</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="div-2">
              <div className="element-solutions-card">
                <img className="image" alt="Image" src="/img/image-8.png" />

                <div className="frame-3">
                  <div className="frame-4">
                    <div className="title">SaaS Starter Page</div>

                    <div className="text">
                      <div className="element-service">
                        <div className="description">$50</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="element-solutions-card">
                <img className="image" alt="Image" src="/img/image-9-2.png" />

                <div className="frame-5">
                  <div className="title">Minimal Portfolio</div>

                  <div className="text">
                    <div className="element-service">
                      <div className="description">$1.99</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="div-2">
              <div className="element-solutions-card">
                <img className="image" alt="Image" src="/img/image.png" />

                <div className="frame-3">
                  <div className="frame-4">
                    <div className="title">Startup One-Pager</div>

                    <div className="text">
                      <div className="element-service">
                        <div className="description">$50</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="element-solutions-card">
                <img className="image" alt="Image" src="/img/image-11-2.png" />

                <div className="frame-5">
                  <div className="title">Event Promo Landing...</div>

                  <div className="text">
                    <div className="element-service">
                      <div className="description">$50</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="div-wrapper">
            <div className="BNB">
              <div className="navigation-menu">
                <img
                  className="home-svgrepo-com"
                  alt="Home svgrepo com"
                  src="/img/home-svgrepo-com-1-2.svg"
                />

                <div className="text-wrapper-3">Home</div>
              </div>

              <div className="navigation-menu">
                <SearchNormal1 className="home-svgrepo-com" />
                <div className="text-wrapper-4">Search</div>
              </div>

              <div className="navigation-menu">
                <div className="group" />

                <div className="text-wrapper-5">Cart</div>
              </div>

              <div className="navigation-menu">
                <div className="home-svgrepo-com">
                  <div className="headset-svgrepo-com-wrapper">
                    <div className="headset-svgrepo-com">
                      <div className="overlap-group">
                        <img
                          className="vector"
                          alt="Vector"
                          src="/img/vector.svg"
                        />

                        <img
                          className="vector-2"
                          alt="Vector"
                          src="/img/vector-1.svg"
                        />

                        <img
                          className="vector-3"
                          alt="Vector"
                          src="/img/vector-2-2.svg"
                        />

                        <img
                          className="vector-4"
                          alt="Vector"
                          src="/img/vector-3.svg"
                        />

                        <img
                          className="vector-5"
                          alt="Vector"
                          src="/img/vector-4.svg"
                        />

                        <img
                          className="vector-6"
                          alt="Vector"
                          src="/img/vector-5.svg"
                        />

                        <img
                          className="group-2"
                          alt="Group"
                          src="/img/group-2.png"
                        />

                        <img
                          className="group-3"
                          alt="Group"
                          src="/img/group-1.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-wrapper-5">Help</div>
              </div>

              <div className="navigation-menu">
                <img className="image-2" alt="Image" src="/img/image-14.png" />

                <div className="text-wrapper-5">Profile</div>
              </div>
            </div>
          </div>

          <HomeIndicator
            className="home-indicator-instance"
            lineClassName="home-indicator-2"
            property1="dark"
          />
        </>
      )}

      {screenWidth >= 1440 && (
        <div className="frame-6">
          <div className="frame-7">
            <div className="frame-8">
              <div className="frame-9">
                <div className="frame-10">
                  <div className="frame-11">
                    <div className="text-wrapper-6">LOGO</div>
                  </div>
                </div>
              </div>

              <div className="frame-8">
                <div className="frame-12">
                  <div className="frame-13">
                    <div className="frame-14">
                      <div className="frame-15">
                        <img
                          className="home-svgrepo-com"
                          alt="Home svgrepo com"
                          src="/img/home-svgrepo-com-4.svg"
                        />

                        <div className="text-wrapper-7">Home</div>
                      </div>

                      <div className="frame-15">
                        <img
                          className="img-2"
                          alt="Security safe"
                          src="/img/security-safe-svgrepo-com-2.svg"
                        />

                        <div className="text-wrapper-8">Security</div>
                      </div>

                      <div className="frame-15">
                        <div className="gift">
                          <div className="vuesax-linear-gift">
                            <img
                              className="gift-2"
                              alt="Gift"
                              src="/img/gift-16.png"
                            />
                          </div>
                        </div>

                        <div className="text-wrapper-8">Products</div>
                      </div>

                      <div className="frame-15">
                        <img
                          className="img-2"
                          alt="Advertising svgrepo"
                          src="/img/advertising-svgrepo-com-2.svg"
                        />

                        <div className="text-wrapper-8">Marketing</div>
                      </div>

                      <div className="frame-15">
                        <img
                          className="img-2"
                          alt="Cart large svgrepo"
                          src="/img/cart-large-4-svgrepo-com.svg"
                        />

                        <div className="text-wrapper-9">Your Store</div>
                      </div>

                      <div className="frame-15">
                        <img
                          className="img-2"
                          alt="People svgrepo com"
                          src="/img/people-svgrepo-com-4.svg"
                        />

                        <div className="text-wrapper-10">Collaborators</div>
                      </div>

                      <div className="frame-15">
                        <div className="group-4" />

                        <div className="text-wrapper-8">Checkout</div>
                      </div>

                      <div className="frame-15">
                        <div className="img-2">
                          <div className="email-svgrepo">
                            <div className="page" />
                          </div>
                        </div>

                        <div className="text-wrapper-8">Emails</div>
                      </div>

                      <div className="frame-15">
                        <img
                          className="img-2"
                          alt="Flow parallel"
                          src="/img/flow-parallel-svgrepo-com-14.svg"
                        />

                        <div className="text-wrapper-8">Workflows</div>
                      </div>

                      <div className="frame-15">
                        <img
                          className="img-2"
                          alt="Coin svgrepo com"
                          src="/img/coin-svgrepo-com-9.svg"
                        />

                        <div className="text-wrapper-8">Sales</div>
                      </div>

                      <div className="frame-15">
                        <img
                          className="img-2"
                          alt="Graph svgrepo com"
                          src="/img/graph-svgrepo-com.svg"
                        />

                        <div className="text-wrapper-8">Analytics</div>
                      </div>

                      <div className="frame-15">
                        <img
                          className="img-2"
                          alt="Coin svgrepo com"
                          src="/img/coin-svgrepo-com-9.svg"
                        />

                        <div className="text-wrapper-8">Payouts</div>
                      </div>

                      <div className="frame-15">
                        <img
                          className="img-2"
                          alt="Book bookmark"
                          src="/img/book-bookmark-minimalistic-svgrepo-com-14.svg"
                        />

                        <div className="text-wrapper-8">Library</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-15">
                  <img
                    className="img-2"
                    alt="Setting svgrepo"
                    src="/img/setting-2-svgrepo-com-2.svg"
                  />

                  <div className="text-wrapper-8">Settings</div>
                </div>

                <div className="frame-15">
                  <img
                    className="img-2"
                    alt="Open book svgrepo"
                    src="/img/open-book-svgrepo-com-6.svg"
                  />

                  <div className="text-wrapper-8">Help</div>
                </div>
              </div>
            </div>
          </div>

          <div className="frame-16">
            <div className="frame-17">
              <div className="frame-18">
                <div className="div">
                  <div className="text-wrapper-11">Real Estate</div>

                  <SearchNormal38 className="search-normal" color="#292929" />
                </div>
              </div>

              <div className="back-icon-button-2">
                <div className="img-2">
                  <div className="vuesax-linear">
                    <div className="notification">
                      <img
                        className="group-5"
                        alt="Group"
                        src="/img/group-33845-6.png"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="back-icon-button-2">
                <img
                  className="img-2"
                  alt="Messenger fill"
                  src="/img/messenger-fill-svgrepo-com-2.svg"
                />
              </div>

              <div className="frame-19">
                <div className="frame-20">
                  <img
                    className="ellipse"
                    alt="Ellipse"
                    src="/img/ellipse-52.png"
                  />

                  <div className="frame-21">
                    <div className="text-wrapper-12">Lenny White</div>
                  </div>
                </div>

                <img
                  className="search-normal"
                  alt="Expand more"
                  src="/img/expand-more-14.svg"
                />
              </div>
            </div>

            <div className="div-2">
              <div className="frame-22">
                <div className="div-2">
                  <div className="vuesax-outline-arrow-wrapper">
                    <div className="vuesax-outline-arrow" />
                  </div>

                  <div className="text-wrapper-13">Your Store</div>
                </div>

                <div className="text-wrapper-14">Store Title</div>

                <div className="frame-23">
                  <div className="element-solutions-card-v">
                    <img
                      className="image-3"
                      alt="Image"
                      src="/img/image-2x.png"
                    />

                    <div className="frame-3">
                      <div className="frame-4">
                        <div className="title-2">Real Estate Landing...</div>

                        <div className="text">
                          <div className="element-service">
                            <div className="description">$29.99</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-2">
                    <img
                      className="image-4"
                      alt="Image"
                      src="/img/image-1.png"
                    />

                    <div className="frame-5">
                      <div className="title-2">Business Pro Landing...</div>

                      <div className="text">
                        <div className="element-service">
                          <div className="description">$50</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-2">
                    <img
                      className="image-5"
                      alt="Image"
                      src="/img/image-4.png"
                    />

                    <div className="frame-3">
                      <div className="frame-4">
                        <div className="title-2">SaaS Starter Page</div>

                        <div className="text">
                          <div className="element-service">
                            <div className="description">$50</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-2">
                    <img
                      className="image-5"
                      alt="Image"
                      src="/img/image-5.png"
                    />

                    <div className="frame-5">
                      <div className="title-2">Minimal Portfolio</div>

                      <div className="text">
                        <div className="element-service">
                          <div className="description">$1.99</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-23">
                  <div className="element-solutions-card-2">
                    <img
                      className="image-5"
                      alt="Image"
                      src="/img/image-2.png"
                    />

                    <div className="frame-3">
                      <div className="frame-4">
                        <div className="title-2">Startup One-Pager</div>

                        <div className="text">
                          <div className="element-service">
                            <div className="description">$50</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-2">
                    <img
                      className="image-5"
                      alt="Image"
                      src="/img/image-3-2.png"
                    />

                    <div className="frame-5">
                      <div className="title-2">Event Promo Landing...</div>

                      <div className="text">
                        <div className="element-service">
                          <div className="description">$50</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-2">
                    <img
                      className="image-5"
                      alt="Image"
                      src="/img/image-4.png"
                    />

                    <div className="frame-3">
                      <div className="frame-4">
                        <div className="title-2">SaaS Starter Page</div>

                        <div className="text">
                          <div className="element-service">
                            <div className="description">$50</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="element-solutions-card-2">
                    <img
                      className="image-5"
                      alt="Image"
                      src="/img/image-5.png"
                    />

                    <div className="frame-5">
                      <div className="title-2">Minimal Portfolio</div>

                      <div className="text">
                        <div className="element-service">
                          <div className="description">$1.99</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="frame-24">
                  <div className="text-wrapper-15">Customize Website</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
