import React from "react";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const NotificationUnread = () => {
  return (
    <div className="notification-unread">
      <StatusBar
        actionClassName="status-bar-57"
        batteryClassName="status-bar-60"
        className="status-bar-56"
        combinedShape="/img/combined-shape-5.svg"
        containerClassName="status-bar-59"
        property1="dark"
        rectangleClassName="status-bar-61"
        timeClassName="status-bar-58"
        wiFi="/img/wi-fi-5.svg"
      />
      <div className="frame-349">
        <div className="back-icon-button-23">
          <div className="vuesax-outline-arrow-12" />
        </div>

        <div className="frame-350">
          <div className="text-wrapper-172">Notification</div>
        </div>

        <div className="group-53">
          <div className="search-normal-5">
            <div className="vuesax-linear-search-3">
              <div className="search-normal-6">
                <img
                  className="group-54"
                  alt="Group"
                  src="/img/group-33839.png"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="frame-351">
        <div className="frame-352">
          <div className="frame-353">
            <div className="text-wrapper-173">All</div>

            <img
              className="vector-45"
              alt="Vector"
              src="/img/vector-1-18.png"
            />
          </div>

          <div className="frame-353">
            <div className="text-wrapper-174">Unread</div>

            <img
              className="vector-46"
              alt="Vector"
              src="/img/vector-6762-4.svg"
            />
          </div>

          <div className="frame-353">
            <div className="text-wrapper-173">Read</div>

            <img
              className="vector-47"
              alt="Vector"
              src="/img/vector-1-18.png"
            />
          </div>
        </div>

        <div className="frame-352">
          <div className="frame-354">
            <div className="frame-355">
              <div className="group-55">
                <div className="frame-356">
                  <div className="ellipse-12" />

                  <div className="group-56" />
                </div>
              </div>

              <div className="frame-357">
                <div className="frame-358">
                  <div className="text-wrapper-175">John Doe</div>

                  <div className="frame-359">
                    <div className="commented-lorem-2">
                      Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                    </div>
                  </div>
                </div>

                <div className="text-wrapper-176">Friday 2:30 pm</div>
              </div>
            </div>
          </div>
        </div>

        <div className="frame-352">
          <div className="frame-354">
            <div className="frame-355">
              <div className="group-55">
                <div className="frame-356">
                  <div className="ellipse-12" />

                  <div className="group-57" />
                </div>
              </div>

              <div className="frame-357">
                <div className="frame-358">
                  <div className="text-wrapper-175">Lenny White</div>

                  <div className="frame-359">
                    <div className="commented-lorem-2">
                      Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                    </div>
                  </div>
                </div>

                <div className="text-wrapper-176">Friday 2:30 pm</div>
              </div>
            </div>
          </div>
        </div>

        <div className="frame-352">
          <div className="frame-354">
            <div className="frame-355">
              <div className="group-55">
                <div className="frame-356">
                  <div className="ellipse-12" />

                  <div className="group-58" />
                </div>
              </div>

              <div className="frame-357">
                <div className="frame-358">
                  <div className="text-wrapper-175">Precious Bennett</div>

                  <div className="frame-359">
                    <div className="commented-lorem-2">
                      Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                    </div>
                  </div>
                </div>

                <div className="text-wrapper-176">Friday 2:30 pm</div>
              </div>
            </div>
          </div>
        </div>

        <div className="frame-352">
          <div className="frame-354">
            <div className="frame-355">
              <div className="group-55">
                <div className="frame-356">
                  <div className="ellipse-12" />

                  <div className="group-59" />
                </div>
              </div>

              <div className="frame-357">
                <div className="frame-358">
                  <div className="text-wrapper-175">Lucas Park</div>

                  <div className="frame-359">
                    <div className="commented-lorem-2">
                      Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                    </div>
                  </div>
                </div>

                <div className="text-wrapper-176">Friday 2:30 pm</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <HomeIndicator
        className="home-indicator-23"
        lineClassName="home-indicator-24"
        property1="dark"
      />
    </div>
  );
};
