import React from "react";
import { HomeIndicator } from "../../components/HomeIndicator";
import { StatusBar } from "../../components/StatusBar";
import "./style.css";

export const NotificationAll = () => {
  return (
    <div className="notification-all">
      <StatusBar
        actionClassName="status-bar-63"
        batteryClassName="status-bar-66"
        className="status-bar-62"
        combinedShape="/img/combined-shape-5.svg"
        containerClassName="status-bar-65"
        property1="dark"
        rectangleClassName="status-bar-67"
        timeClassName="status-bar-64"
        wiFi="/img/wi-fi-5.svg"
      />
      <div className="frame-360">
        <div className="back-icon-button-24">
          <div className="vuesax-outline-arrow-13" />
        </div>

        <div className="frame-361">
          <div className="text-wrapper-177">Notification</div>
        </div>

        <div className="group-60">
          <div className="search-normal-7">
            <div className="vuesax-linear-search-4">
              <div className="search-normal-8">
                <img
                  className="group-61"
                  alt="Group"
                  src="/img/group-33839.png"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="frame-362">
        <div className="frame-363">
          <div className="frame-364">
            <div className="text-wrapper-178">All</div>

            <img
              className="vector-48"
              alt="Vector"
              src="/img/vector-6762.svg"
            />
          </div>

          <div className="frame-364">
            <div className="text-wrapper-179">Unread</div>

            <img
              className="vector-49"
              alt="Vector"
              src="/img/vector-1-18.png"
            />
          </div>

          <div className="frame-364">
            <div className="text-wrapper-179">Read</div>

            <img
              className="vector-50"
              alt="Vector"
              src="/img/vector-1-18.png"
            />
          </div>
        </div>

        <div className="frame-365">
          <div className="frame-366">
            <div className="frame-363">
              <div className="frame-367">
                <div className="frame-368">
                  <div className="group-62">
                    <div className="frame-369">
                      <div className="ellipse-13" />

                      <div className="group-63" />
                    </div>
                  </div>

                  <div className="frame-370">
                    <div className="frame-371">
                      <div className="text-wrapper-180">John Doe</div>

                      <div className="frame-372">
                        <div className="commented-lorem-3">
                          Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                        </div>
                      </div>
                    </div>

                    <div className="text-wrapper-181">Friday 2:30 pm</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-363">
              <div className="frame-367">
                <div className="frame-368">
                  <div className="group-62">
                    <div className="frame-369">
                      <div className="ellipse-13" />

                      <div className="group-64" />
                    </div>
                  </div>

                  <div className="frame-370">
                    <div className="frame-371">
                      <div className="text-wrapper-180">Lenny White</div>

                      <div className="frame-372">
                        <div className="commented-lorem-3">
                          Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                        </div>
                      </div>
                    </div>

                    <div className="text-wrapper-181">Friday 2:30 pm</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-363">
              <div className="frame-367">
                <div className="frame-368">
                  <div className="group-62">
                    <div className="frame-369">
                      <div className="ellipse-13" />

                      <div className="group-65" />
                    </div>
                  </div>

                  <div className="frame-370">
                    <div className="frame-371">
                      <div className="text-wrapper-180">Precious Bennett</div>

                      <div className="frame-372">
                        <div className="commented-lorem-3">
                          Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                        </div>
                      </div>
                    </div>

                    <div className="text-wrapper-181">Friday 2:30 pm</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-363">
              <div className="frame-367">
                <div className="frame-368">
                  <div className="group-62">
                    <div className="frame-369">
                      <div className="ellipse-13" />

                      <div className="group-66" />
                    </div>
                  </div>

                  <div className="frame-370">
                    <div className="frame-371">
                      <div className="text-wrapper-180">Lucas Park</div>

                      <div className="frame-372">
                        <div className="commented-lorem-3">
                          Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                        </div>
                      </div>
                    </div>

                    <div className="text-wrapper-181">Friday 2:30 pm</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-363">
              <div className="frame-367">
                <div className="frame-368">
                  <div className="group-62">
                    <div className="frame-369">
                      <div className="ellipse-14" />

                      <div className="group-67" />
                    </div>
                  </div>

                  <div className="frame-370">
                    <div className="frame-371">
                      <div className="text-wrapper-180">Lorraine Lim</div>

                      <div className="frame-372">
                        <div className="commented-lorem-3">
                          Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                        </div>
                      </div>
                    </div>

                    <div className="text-wrapper-181">Friday 2:30 pm</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-363">
              <div className="frame-367">
                <div className="frame-368">
                  <div className="group-62">
                    <div className="frame-369">
                      <div className="ellipse-14" />

                      <div className="group-68" />
                    </div>
                  </div>

                  <div className="frame-370">
                    <div className="frame-371">
                      <div className="text-wrapper-180">Aira Morgan</div>

                      <div className="frame-372">
                        <div className="commented-lorem-3">
                          Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                        </div>
                      </div>
                    </div>

                    <div className="text-wrapper-181">Friday 2:30 pm</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-363">
              <div className="frame-373">
                <div className="frame-367">
                  <div className="frame-368">
                    <div className="group-62">
                      <div className="frame-369">
                        <div className="ellipse-14" />

                        <div className="group-69" />
                      </div>
                    </div>

                    <div className="frame-370">
                      <div className="frame-371">
                        <div className="text-wrapper-180">Sienna Blake</div>

                        <div className="frame-372">
                          <div className="commented-lorem-3">
                            Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                          </div>
                        </div>
                      </div>

                      <div className="text-wrapper-181">Friday 2:30 pm</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-363">
              <div className="frame-373">
                <div className="frame-367">
                  <div className="frame-368">
                    <div className="group-62">
                      <div className="frame-369">
                        <div className="ellipse-14" />

                        <div className="group-70" />
                      </div>
                    </div>

                    <div className="frame-370">
                      <div className="frame-371">
                        <div className="text-wrapper-180">Noah Sinclair</div>

                        <div className="frame-372">
                          <div className="commented-lorem-3">
                            Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                          </div>
                        </div>
                      </div>

                      <div className="text-wrapper-181">Friday 2:30 pm</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-363">
              <div className="frame-373">
                <div className="frame-367">
                  <div className="frame-368">
                    <div className="group-62">
                      <div className="frame-369">
                        <div className="ellipse-14" />

                        <div className="group-71" />
                      </div>
                    </div>

                    <div className="frame-370">
                      <div className="frame-371">
                        <div className="text-wrapper-180">Leo Donovan</div>

                        <div className="frame-372">
                          <div className="commented-lorem-3">
                            Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                          </div>
                        </div>
                      </div>

                      <div className="text-wrapper-181">Friday 2:30 pm</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="frame-363">
              <div className="frame-373">
                <div className="frame-367">
                  <div className="frame-368">
                    <div className="group-62">
                      <div className="frame-369">
                        <div className="ellipse-14" />

                        <div className="group-72" />
                      </div>
                    </div>

                    <div className="frame-370">
                      <div className="frame-371">
                        <div className="text-wrapper-180">Caleb Monroe</div>

                        <div className="frame-372">
                          <div className="commented-lorem-3">
                            Commented:&nbsp;&nbsp;Lorem ipsum dolor sit
                          </div>
                        </div>
                      </div>

                      <div className="text-wrapper-181">Friday 2:30 pm</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <HomeIndicator
        className="home-indicator-25"
        lineClassName="home-indicator-26"
        property1="dark"
      />
    </div>
  );
};
