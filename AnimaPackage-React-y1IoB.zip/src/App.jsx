import React from "react";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { AddCollaborators } from "./screens/AddCollaborators";
import { Categories } from "./screens/Categories";
import { Collaborators } from "./screens/Collaborators";
import { CollaboratorsScreen } from "./screens/CollaboratorsScreen";
import { Home } from "./screens/Home";
import { Products } from "./screens/Products";
import { Reviews } from "./screens/Reviews";
import { SecurityComplete } from "./screens/SecurityComplete";
import { SecurityIdCheck } from "./screens/SecurityIdCheck";
import { SecurityPayout } from "./screens/SecurityPayout";
import { SecurityTax } from "./screens/SecurityTax";
import { SecurityTaxScreen } from "./screens/SecurityTaxScreen";
import { SecurityTrader } from "./screens/SecurityTrader";

const router = createBrowserRouter([
  {
    path: "/*",
    element: <AddCollaborators />,
  },
  {
    path: "/add-collaborators-1",
    element: <AddCollaborators />,
  },
  {
    path: "/collaborators-1",
    element: <Collaborators />,
  },
  {
    path: "/products-1",
    element: <Products />,
  },
  {
    path: "/reviews-1",
    element: <Reviews />,
  },
  {
    path: "/collaborators",
    element: <CollaboratorsScreen />,
  },
  {
    path: "/security-id-check-1",
    element: <SecurityIdCheck />,
  },
  {
    path: "/security-trader-status-declaration-1",
    element: <SecurityTrader />,
  },
  {
    path: "/security-payout-method-1",
    element: <SecurityPayout />,
  },
  {
    path: "/security-tax-information-1-1",
    element: <SecurityTax />,
  },
  {
    path: "/security-tax-information-1",
    element: <SecurityTaxScreen />,
  },
  {
    path: "/security-complete-your-profile-1",
    element: <SecurityComplete />,
  },
  {
    path: "/categories",
    element: <Categories />,
  },
  {
    path: "/home-1",
    element: <Home />,
  },
]);

export const App = () => {
  return <RouterProvider router={router} />;
};
