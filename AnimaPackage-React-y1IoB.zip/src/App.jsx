import React from "react";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { Categories } from "./screens/Categories";
import { Home } from "./screens/Home";
import { SecurityComplete } from "./screens/SecurityComplete";
import { SecurityPayout } from "./screens/SecurityPayout";
import { SecurityTax } from "./screens/SecurityTax";
import { SecurityTaxScreen } from "./screens/SecurityTaxScreen";

const router = createBrowserRouter([
  {
    path: "/*",
    element: <SecurityPayout />,
  },
  {
    path: "/security-payout-method-1",
    element: <SecurityPayout />,
  },
  {
    path: "/security-tax-information-1-1",
    element: <SecurityTax />,
  },
  {
    path: "/security-tax-information-1",
    element: <SecurityTaxScreen />,
  },
  {
    path: "/security-complete-your-profile-1",
    element: <SecurityComplete />,
  },
  {
    path: "/categories",
    element: <Categories />,
  },
  {
    path: "/home-1",
    element: <Home />,
  },
]);

export const App = () => {
  return <RouterProvider router={router} />;
};
