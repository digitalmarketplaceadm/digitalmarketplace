import React from "react";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { AddChannel } from "./screens/AddChannel";
import { AddCollaborators } from "./screens/AddCollaborators";
import { AddNewDigital } from "./screens/AddNewDigital";
import { AdvanceSettings } from "./screens/AdvanceSettings";
import { BillingInvoice } from "./screens/BillingInvoice";
import { Cart } from "./screens/Cart";
import { Categories } from "./screens/Categories";
import { ChannelReviews } from "./screens/ChannelReviews";
import { Chat } from "./screens/Chat";
import { Collaborators } from "./screens/Collaborators";
import { CollaboratorsScreen } from "./screens/CollaboratorsScreen";
import { Footsteps } from "./screens/Footsteps";
import { Home } from "./screens/Home";
import { HomeCartBalance } from "./screens/HomeCartBalance";
import { HomeScreen } from "./screens/HomeScreen";
import { LandingPage } from "./screens/LandingPage";
import { Login } from "./screens/Login";
import { Menu } from "./screens/Menu";
import { MyChannel } from "./screens/MyChannel";
import { NotificationAll } from "./screens/NotificationAll";
import { NotificationRead } from "./screens/NotificationRead";
import { NotificationUnread } from "./screens/NotificationUnread";
import { PaymentDetails } from "./screens/PaymentDetails";
import { Products } from "./screens/Products";
import { Reviews } from "./screens/Reviews";
import { SavedExperts } from "./screens/SavedExperts";
import { SecurityComplete } from "./screens/SecurityComplete";
import { SecurityIdCheck } from "./screens/SecurityIdCheck";
import { SecurityPayout } from "./screens/SecurityPayout";
import { SecurityTax } from "./screens/SecurityTax";
import { SecurityTaxScreen } from "./screens/SecurityTaxScreen";
import { SecurityTrader } from "./screens/SecurityTrader";
import { Taxes } from "./screens/Taxes";
import { YourStoreStore } from "./screens/YourStoreStore";

const router = createBrowserRouter([
  {
    path: "/*",
    element: <MyChannel />,
  },
  {
    path: "/my-channel-1",
    element: <MyChannel />,
  },
  {
    path: "/login1",
    element: <Login />,
  },
  {
    path: "/add-channel-1",
    element: <AddChannel />,
  },
  {
    path: "/channel-reviews-1",
    element: <ChannelReviews />,
  },
  {
    path: "/products-1",
    element: <Products />,
  },
  {
    path: "/security-complete-your-profile-1",
    element: <SecurityComplete />,
  },
  {
    path: "/add-new-digital-product-1",
    element: <AddNewDigital />,
  },
  {
    path: "/saved-experts-1",
    element: <SavedExperts />,
  },
  {
    path: "/footsteps",
    element: <Footsteps />,
  },
  {
    path: "/cart-1",
    element: <Cart />,
  },
  {
    path: "/home-cart-balance",
    element: <HomeCartBalance />,
  },
  {
    path: "/notification-read",
    element: <NotificationRead />,
  },
  {
    path: "/notification-unread",
    element: <NotificationUnread />,
  },
  {
    path: "/notification-all",
    element: <NotificationAll />,
  },
  {
    path: "/chat",
    element: <Chat />,
  },
  {
    path: "/your-store-store",
    element: <YourStoreStore />,
  },
  {
    path: "/menu-1",
    element: <Menu />,
  },
  {
    path: "/home-1",
    element: <Home />,
  },
  {
    path: "/home",
    element: <HomeScreen />,
  },
  {
    path: "/categories",
    element: <Categories />,
  },
  {
    path: "/advance-settings-1",
    element: <AdvanceSettings />,
  },
  {
    path: "/taxes-1",
    element: <Taxes />,
  },
  {
    path: "/billing-u38-invoice-1",
    element: <BillingInvoice />,
  },
  {
    path: "/payment-details-1",
    element: <PaymentDetails />,
  },
  {
    path: "/landing-page",
    element: <LandingPage />,
  },
  {
    path: "/collaborators-1",
    element: <Collaborators />,
  },
  {
    path: "/add-collaborators-1",
    element: <AddCollaborators />,
  },
  {
    path: "/reviews-1",
    element: <Reviews />,
  },
  {
    path: "/collaborators",
    element: <CollaboratorsScreen />,
  },
  {
    path: "/security-id-check-1",
    element: <SecurityIdCheck />,
  },
  {
    path: "/security-trader-status-declaration-1",
    element: <SecurityTrader />,
  },
  {
    path: "/security-payout-method-1",
    element: <SecurityPayout />,
  },
  {
    path: "/security-tax-information-1-1",
    element: <SecurityTax />,
  },
  {
    path: "/security-tax-information-1",
    element: <SecurityTaxScreen />,
  },
]);

export const App = () => {
  return <RouterProvider router={router} />;
};
