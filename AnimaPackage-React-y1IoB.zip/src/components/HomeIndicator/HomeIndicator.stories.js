import { HomeIndicator } from ".";

export default {
  title: "Components/HomeIndicator",
  component: HomeIndicator,

  argTypes: {
    property1: {
      options: ["dark", "light"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "dark",
    className: {},
    lineClassName: {},
  },
};
