/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const StatusBar = ({
  property1,
  className,
  timeClassName,
  containerClassName,
  batteryClassName,
  rectangleClassName,
  combinedShape = "/img/combined-shape-3.svg",
  wiFi = "/img/wi-fi-3.svg",
  actionClassName,
}) => {
  return (
    <div className={`status-bar ${className}`}>
      <div className={`action ${actionClassName}`}>
        <div className={`time ${property1} ${timeClassName}`}>9:41</div>
      </div>

      <div className={`container ${containerClassName}`}>
        <div className={`battery property-1-${property1} ${batteryClassName}`}>
          <div className={`rectangle ${rectangleClassName}`} />
        </div>

        <img
          className="combined-shape"
          alt="Combined shape"
          src={
            property1 === "light" ? "/img/combined-shape-4.svg" : combinedShape
          }
        />

        <img
          className="wi-fi"
          alt="Wi fi"
          src={property1 === "light" ? "/img/wi-fi-4.svg" : wiFi}
        />
      </div>
    </div>
  );
};

StatusBar.propTypes = {
  property1: PropTypes.oneOf(["dark", "light"]),
  combinedShape: PropTypes.string,
  wiFi: PropTypes.string,
};
