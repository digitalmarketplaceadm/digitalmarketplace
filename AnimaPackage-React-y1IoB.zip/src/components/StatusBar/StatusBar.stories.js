import { StatusBar } from ".";

export default {
  title: "Components/StatusBar",
  component: StatusBar,

  argTypes: {
    property1: {
      options: ["dark", "light"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "dark",
    className: {},
    containerClassName: {},
    batteryClassName: {},
    combinedShape: "/img/combined-shape-30.svg",
    wiFi: "/img/wi-fi-30.svg",
    timeClassName: {},
    rectangleClassName: {},
  },
};
