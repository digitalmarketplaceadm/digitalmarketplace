import { StatusBar } from ".";

export default {
  title: "Components/StatusBar",
  component: StatusBar,

  argTypes: {
    property1: {
      options: ["dark", "light"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "dark",
    className: {},
    timeClassName: {},
    containerClassName: {},
    batteryClassName: {},
    rectangleClassName: {},
    combinedShape: "/img/combined-shape-3.svg",
    wiFi: "/img/wi-fi-3.svg",
    actionClassName: {},
  },
};
