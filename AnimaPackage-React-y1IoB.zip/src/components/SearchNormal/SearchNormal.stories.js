import { SearchNormal } from ".";

export default {
  title: "Components/SearchNormal",
  component: SearchNormal,

  argTypes: {
    property1: {
      options: ["twotone", "broken", "outline", "bold", "linear", "bulk"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "twotone",
  },
};
