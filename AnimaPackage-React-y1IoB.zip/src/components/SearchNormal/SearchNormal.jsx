/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { Property1Broken } from "../../icons/Property1Broken";
import { Property1Bulk } from "../../icons/Property1Bulk";
import { Property1Outline } from "../../icons/Property1Outline";
import { Property1Twotone } from "../../icons/Property1Twotone";
import { SearchNormal38 } from "../../icons/SearchNormal38";
import "./style.css";

export const SearchNormal = ({ property1 }) => {
  return (
    <>
      {property1 === "linear" && (
        <SearchNormal38 className="instance-node" color="#292D32" />
      )}

      {["bold", "bulk"].includes(property1) && (
        <Property1Bulk
          className="instance-node"
          opacity={property1 === "bulk" ? "0.4" : undefined}
        />
      )}

      {property1 === "outline" && (
        <Property1Outline className="instance-node" />
      )}

      {property1 === "twotone" && (
        <Property1Twotone className="instance-node" />
      )}

      {property1 === "broken" && <Property1Broken className="instance-node" />}
    </>
  );
};

SearchNormal.propTypes = {
  property1: PropTypes.oneOf([
    "twotone",
    "broken",
    "outline",
    "bold",
    "linear",
    "bulk",
  ]),
};
