/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { Property1Broken8 } from "../../icons/Property1Broken8";
import { Property1Bulk8 } from "../../icons/Property1Bulk8";
import { Property1Outline8 } from "../../icons/Property1Outline8";
import { Property1Twotone8 } from "../../icons/Property1Twotone8";
import { SearchNormal24 } from "../../icons/SearchNormal24";
import "./style.css";

export const SearchNormal = ({ property1 }) => {
  return (
    <>
      {property1 === "linear" && (
        <SearchNormal24 className="instance-node" color="#292D32" />
      )}

      {["bold", "bulk"].includes(property1) && (
        <Property1Bulk8
          className="instance-node"
          opacity={property1 === "bulk" ? "0.4" : undefined}
        />
      )}

      {property1 === "outline" && (
        <Property1Outline8 className="instance-node" />
      )}

      {property1 === "twotone" && (
        <Property1Twotone8 className="instance-node" />
      )}

      {property1 === "broken" && <Property1Broken8 className="instance-node" />}
    </>
  );
};

SearchNormal.propTypes = {
  property1: PropTypes.oneOf([
    "twotone",
    "broken",
    "outline",
    "bold",
    "linear",
    "bulk",
  ]),
};
