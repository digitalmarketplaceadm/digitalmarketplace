import { Switch } from ".";

export default {
  title: "Components/Switch",
  component: Switch,

  argTypes: {
    size: {
      options: ["large", "medium", "small"],
      control: { type: "select" },
    },
    status: {
      options: ["off", "on"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    size: "large",
    status: "off",
    title: true,
    copy: true,
    className: {},
  },
};
