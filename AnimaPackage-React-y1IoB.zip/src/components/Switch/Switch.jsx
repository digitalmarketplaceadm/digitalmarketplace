/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const Switch = ({ size, status, title, copy, className }) => {
  return (
    <div
      className={`switch copy-${copy} title-${title} ${size} ${status} ${className}`}
    >
      {!title && <div className="div" />}

      {title && (
        <>
          <div className="switch-wrapper">
            <div className="div-2">{copy && <div className="button" />}</div>
          </div>

          <div className="title">
            <div className="text-wrapper">Title text goes here</div>

            {copy && <p className="p">Secondary text line goes here</p>}
          </div>
        </>
      )}
    </div>
  );
};

Switch.propTypes = {
  size: PropTypes.oneOf(["large", "medium", "small"]),
  status: PropTypes.oneOf(["off", "on"]),
  title: PropTypes.bool,
  copy: PropTypes.bool,
};
