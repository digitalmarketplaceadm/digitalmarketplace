<script lang="ts">
	import { NewProductModal } from '$modules/products/product-modal';
</script>

<div class="space-y-5">
	<div class="flex items-center justify-between">
		<NewProductModal />
	</div>
</div>
