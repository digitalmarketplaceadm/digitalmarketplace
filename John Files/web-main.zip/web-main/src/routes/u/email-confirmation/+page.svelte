<script lang="ts">
	import { EmailConfirmationForm } from '$modules/auth/email-confirmation';
</script>

<main class="flex min-h-screen flex-col items-center justify-center gap-3">
	<EmailConfirmationForm />
</main>
