<script lang="ts">
	import { ForgotPasswordRequestForm } from '$modules/auth/forgot-password-request';
</script>

<main class="flex min-h-screen flex-col items-center justify-center gap-3">
	<ForgotPasswordRequestForm />
</main>
