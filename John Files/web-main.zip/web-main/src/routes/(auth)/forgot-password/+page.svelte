<script>
	import { ForgotPasswordForm } from '$modules/auth/forgot-password';
</script>

<main class="container flex h-screen max-w-lg flex-col justify-center">
	<ForgotPasswordForm />
</main>
