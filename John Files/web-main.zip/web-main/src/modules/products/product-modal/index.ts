export { default as NewProductModal } from './new-product-modal..svelte';
