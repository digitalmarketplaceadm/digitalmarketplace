export { default as DataTable } from './data-table.svelte';
