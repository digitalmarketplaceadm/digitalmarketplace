import Root from './slider.svelte';

export {
	Root,
	//
	Root as Slider
};
