import { AspectRatio as AspectRatioPrimitive } from 'bits-ui';

const Root = AspectRatioPrimitive.Root;

export { Root, Root as AspectRatio };
