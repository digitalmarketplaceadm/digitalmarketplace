import Root from './switch.svelte';

export {
	Root,
	//
	Root as Switch
};
