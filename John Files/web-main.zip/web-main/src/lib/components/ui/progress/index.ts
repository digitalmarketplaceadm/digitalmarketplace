import Root from './progress.svelte';

export {
	Root,
	//
	Root as Progress
};
