package auth

import (
	"github.com/gorilla/sessions"
	"github.com/markbates/goth"
	"github.com/markbates/goth/gothic"
	"github.com/markbates/goth/providers/google"
)

const (
	key    = "api_key"
	MaxAge = 86400 * 30
	IsProd = false
)

func NewAuth(clientId, clientSecret string) {

	store := sessions.NewCookieStore(([]byte(key)))
	store.MaxAge(MaxAge)

	store.Options.Path = "/"
	store.Options.HttpOnly = true
	store.Options.Secure = IsProd

	gothic.Store = store

	goth.UseProviders(google.New(clientId, clientSecret, "http://localhost:3000/auth/google/callback"))
}
