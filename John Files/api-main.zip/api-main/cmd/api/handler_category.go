package main

import (
	"fmt"
	"net/http"

	"github.com/Digital-Market-Place/api/internal/database"
	"github.com/Digital-Market-Place/api/internal/request"
	"github.com/Digital-Market-Place/api/internal/response"
	"github.com/Digital-Market-Place/api/internal/validator"
	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"
)

func (app *application) handlerGetCategories(w http.ResponseWriter, r *http.Request) {

	categories, err := app.db.GetCategories(r.Context())
	if err != nil {
		app.notFound(w, r)
		return
	}

	if len(categories) == 0 {
		err = response.JSON(w, http.StatusOK, []any{})
		if err != nil {
			app.serverError(w, r, err)
		}
	}

	err = response.JSON(w, http.StatusOK, categories)
	if err != nil {
		app.serverError(w, r, err)
	}
}

func (app *application) handlerCreateCategory(w http.ResponseWriter, r *http.Request) {

	var input struct {
		Name      string              `json:"name"`
		Validator validator.Validator `json:"-"`
	}

	err := request.DecodeJSON(w, r, &input)
	if err != nil {
		app.badRequest(w, r, err)
		return
	}

	category, err := app.db.CreateCategory(r.Context(), input.Name)
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	err = response.JSON(w, http.StatusCreated, category)
	if err != nil {
		app.serverError(w, r, err)
	}
}

func (app *application) handlerUpdateCategory(w http.ResponseWriter, r *http.Request) {

	var input struct {
		Name      string              `json:"name"`
		Validator validator.Validator `json:"-"`
	}

	err := request.DecodeJSON(w, r, &input)
	if err != nil {
		app.badRequest(w, r, err)
		return
	}

	categoryId, err := uuid.Parse(chi.URLParam(r, "categoryId"))
	if err != nil {
		app.badRequest(w, r, fmt.Errorf("invalid category ID"))
		return
	}

	category, err := app.db.
		UpdateCategory(r.Context(), database.
			UpdateCategoryParams{
			ID:   categoryId,
			Name: input.Name,
		})
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	err = response.JSON(w, http.StatusOK, category)
	if err != nil {
		app.serverError(w, r, err)
	}
}

func (app *application) handlerDeleteCategory(w http.ResponseWriter, r *http.Request) {

	categoryId, err := uuid.Parse(chi.URLParam(r, "categoryId"))
	if err != nil {
		app.badRequest(w, r, fmt.Errorf("invalid category ID"))
		return
	}

	err = app.db.DeleteCategory(r.Context(), categoryId)
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	response.JSON(w, http.StatusOK, nil)
}
