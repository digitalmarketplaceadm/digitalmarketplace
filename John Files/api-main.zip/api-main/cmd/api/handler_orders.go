package main

import (
	"fmt"
	"net/http"

	"github.com/Digital-Market-Place/api/internal/database"
	"github.com/Digital-Market-Place/api/internal/request"
	"github.com/Digital-Market-Place/api/internal/response"
	"github.com/Digital-Market-Place/api/internal/validator"
	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"
	"github.com/jackc/pgx/v5/pgtype"
)

func (app *application) handlerGetUserOrders(w http.ResponseWriter, r *http.Request) {

	user := contextGetAuthenticatedUser(r)

	orders, err := app.db.GetUserOrders(r.Context(), user.ID)
	if err != nil {
		app.notFound(w, r)
		return
	}

	if len(orders) == 0 {
		err = response.JSON(w, http.StatusOK, []any{})
		if err != nil {
			app.serverError(w, r, err)
		}
	}

	err = response.JSON(w, http.StatusOK, orders)
	if err != nil {
		app.serverError(w, r, err)
	}
}

func (app *application) handlerCreateUserOrder(w http.ResponseWriter, r *http.Request) {
	user := contextGetAuthenticatedUser(r)

	var input struct {
		Status     database.StatusType `json:"status"`
		OrderItems []struct {
			Quantity  int32          `json:"quantity"`
			Price     pgtype.Numeric `json:"price"`
			ProductID uuid.UUID      `json:"product_id"`
		} `json:"order_items"`
		Validator validator.Validator `json:"-"`
	}

	err := request.DecodeJSON(w, r, &input)
	if err != nil {
		app.badRequest(w, r, err)
		return
	}

	status := database.StatusType(input.Status)

	tx, err := app.dbPool.Begin(r.Context())
	if err != nil {
		app.serverError(w, r, err)
		return
	}
	defer tx.Rollback(r.Context())

	qtx := app.db.WithTx(tx)

	order, err := qtx.CreateUserOrder(r.Context(), database.CreateUserOrderParams{
		UserID: user.ID,
		Status: status,
	})
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	var orderItems []database.OrderItem
	for _, item := range input.OrderItems {
		orderItem, err := qtx.CreateOrderItems(r.Context(), database.CreateOrderItemsParams{
			Quantity:  item.Quantity,
			Price:     item.Price,
			ProductID: item.ProductID,
			OrderID:   order.ID,
		})
		if err != nil {
			app.serverError(w, r, err)
			return
		}
		orderItems = append(orderItems, orderItem)
	}

	if err := tx.Commit(r.Context()); err != nil {
		app.serverError(w, r, err)
		return
	}

	result := struct {
		Order      database.Order       `json:"order"`
		OrderItems []database.OrderItem `json:"order_items"`
	}{
		Order:      order,
		OrderItems: orderItems,
	}

	response.JSON(w, http.StatusCreated, result)
}

func (app *application) handlerUpdateUserOrder(w http.ResponseWriter, r *http.Request) {
	user := contextGetAuthenticatedUser(r)

	var input struct {
		Status     database.StatusType `json:"status"`
		OrderItems []struct {
			ID        uuid.UUID      `json:"id"`
			Quantity  int32          `json:"quantity"`
			Price     pgtype.Numeric `json:"price"`
			ProductID uuid.UUID      `json:"product_id"`
			OrderID   uuid.UUID      `json:"order_id"`
		} `json:"order_items"`
		Validator validator.Validator `json:"-"`
	}

	err := request.DecodeJSON(w, r, &input)
	if err != nil {
		app.badRequest(w, r, err)
		return
	}

	orderId, err := uuid.Parse(chi.URLParam(r, "orderId"))
	if err != nil {
		app.badRequest(w, r, fmt.Errorf("invalid order ID"))
		return
	}

	if input.Status == "" {
		input.Validator.CheckField(false, "status", "status must be provided")
	}
	if len(input.OrderItems) == 0 {
		input.Validator.CheckField(false, "items", "at least one order item must be provided")
	}
	if input.Validator.HasErrors() {
		app.failedValidation(w, r, input.Validator)
		return
	}

	tx, err := app.dbPool.Begin(r.Context())
	if err != nil {
		app.serverError(w, r, err)
		return
	}
	defer tx.Rollback(r.Context())

	qtx := app.db.WithTx(tx)

	order, err := qtx.UpdateUserOrder(r.Context(), database.UpdateUserOrderParams{
		ID:     orderId,
		Status: input.Status,
		UserID: user.ID,
	})
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	for _, item := range input.OrderItems {
		_, err := qtx.UpdateOrderItems(r.Context(), database.UpdateOrderItemsParams{
			ID:        item.ID,
			Quantity:  item.Quantity,
			Price:     item.Price,
			ProductID: item.ProductID,
			OrderID:   orderId,
		})
		if err != nil {
			app.serverError(w, r, err)
			return
		}
	}

	err = tx.Commit(r.Context())
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	err = response.JSON(w, http.StatusOK, order)
	if err != nil {
		app.serverError(w, r, err)
	}
}

func (app *application) handlerDeleteUserOrder(w http.ResponseWriter, r *http.Request) {

	user := contextGetAuthenticatedUser(r)

	orderId, err := uuid.Parse(chi.URLParam(r, "orderId"))
	if err != nil {
		app.badRequest(w, r, fmt.Errorf("invalid order ID"))
		return
	}

	err = app.db.DeleteUserOrder(r.Context(), database.DeleteUserOrderParams{
		ID:     orderId,
		UserID: user.ID,
	})

	if err != nil {
		app.serverError(w, r, err)
		return
	}

	response.JSON(w, http.StatusOK, nil)
}
