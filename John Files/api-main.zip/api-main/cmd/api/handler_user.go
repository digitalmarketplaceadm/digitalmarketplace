package main

import (
	"errors"
	"net/http"
	"time"

	"github.com/Digital-Market-Place/api/internal/database"
	"github.com/Digital-Market-Place/api/internal/password"
	"github.com/Digital-Market-Place/api/internal/request"
	"github.com/Digital-Market-Place/api/internal/response"
	"github.com/Digital-Market-Place/api/internal/validator"

	"github.com/jackc/pgx/v5"
	"github.com/pascaldekloe/jwt"
)

func (app *application) handlerCreateBasicUser(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Email     string              `json:"email"`
		Password  string              `json:"password"`
		Validator validator.Validator `json:"-"`
	}

	err := request.DecodeJSON(w, r, &input)
	if err != nil {
		app.badRequest(w, r, err)
		return
	}

	_, err = app.db.GetUserByEmail(r.Context(), input.Email)
	nonExistingEmail := errors.Is(err, pgx.ErrNoRows)
	if err != nil && !nonExistingEmail {
		app.serverError(w, r, err)
		return
	}

	input.Validator.CheckField(input.Email != "", "email", "Email is required")
	input.Validator.CheckField(validator.Matches(input.Email, validator.RgxEmail), "email", "Must be a valid email address")
	input.Validator.CheckField(nonExistingEmail, "email", "Email is already in use")

	input.Validator.CheckField(input.Password != "", "password", "Password is required")
	input.Validator.CheckField(len(input.Password) >= 8, "password", "Password is too short")
	input.Validator.CheckField(len(input.Password) <= 72, "password", "Password is too long")
	input.Validator.CheckField(validator.NotIn(input.Password, password.CommonPasswords...), "password", "Password is too common")

	if input.Validator.HasErrors() {
		app.failedValidation(w, r, input.Validator)
		return
	}

	hashedPassword, err := password.Hash(input.Password)
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	user, err := app.db.CreateUser(r.Context(), database.CreateUserParams{
		Email:          input.Email,
		HashedPassword: hashedPassword,
	})
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	otp, err := app.generateOTP(6)
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	now := time.Now()

	err = app.db.CreateOTP(r.Context(), database.CreateOTPParams{
		Code:      otp,
		Type:      database.OtpTypeEmailVerification,
		UserID:    user.ID,
		CreatedAt: now,
		ExpiresAt: now.Add(time.Minute * 5),
	})
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	app.backgroundTask(r, func() error {
		type EmailData struct {
			Code string
		}

		err = app.mailer.Send(user.Email, EmailData{
			Code: otp,
		}, "email_confirmation.tmpl")
		if err != nil {
			return err
		}

		return nil
	})

	var claims jwt.Claims
	claims.Subject = user.ID.String()

	expiry := time.Now().Add(24 * time.Hour)
	claims.Issued = jwt.NewNumericTime(time.Now())
	claims.NotBefore = jwt.NewNumericTime(time.Now())
	claims.Expires = jwt.NewNumericTime(expiry)

	claims.Issuer = app.config.baseURL
	claims.Audiences = []string{app.config.baseURL}

	jwtBytes, err := claims.HMACSign(jwt.HS256, []byte(app.config.jwt.secretKey))
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	data := map[string]string{
		"token":        string(jwtBytes),
		"token_expiry": expiry.Format(time.RFC3339),
	}

	err = response.JSON(w, http.StatusOK, data)
	if err != nil {
		app.serverError(w, r, err)
	}
}

func (app *application) handlerGetCurrentUser(w http.ResponseWriter, r *http.Request) {
	user := contextGetAuthenticatedUser(r)

	user.HashedPassword = ""

	err := response.JSON(w, http.StatusOK, user)
	if err != nil {
		app.serverError(w, r, err)
	}
}
