package main

import (
	"fmt"
	"net/http"

	"github.com/Digital-Market-Place/api/internal/database"
	"github.com/Digital-Market-Place/api/internal/request"
	"github.com/Digital-Market-Place/api/internal/response"
	"github.com/Digital-Market-Place/api/internal/validator"
	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"
)

func (app *application) handlerGetProducts(w http.ResponseWriter, r *http.Request) {

	products, err := app.db.GetProducts(r.Context())
	if err != nil {
		app.notFound(w, r)
		return
	}

	if len(products) == 0 {
		err = response.JSON(w, http.StatusOK, []any{})
		if err != nil {
			app.serverError(w, r, err)
		}
		return
	}

	err = response.JSON(w, http.StatusOK, products)
	if err != nil {
		app.serverError(w, r, err)
	}
}

func (app *application) handlerGetProductById(w http.ResponseWriter, r *http.Request) {
	productId, err := uuid.Parse(chi.URLParam(r, "productId"))
	if err != nil {
		app.badRequest(w, r, fmt.Errorf("invalid product ID"))
		return
	}

	type ProductWithCategories struct {
		ID          uuid.UUID `json:"id"`
		Name        string    `json:"name"`
		Description string    `json:"description"`
		Categories  []string  `json:"categories"`
	}

	product, err := app.db.GetProductById(r.Context(), productId)
	if err != nil {
		app.notFound(w, r)
		return
	}

	categories, err := app.db.GetUserProductCategories(r.Context(), productId)
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	categoryNames := make([]string, len(categories))
	for i, cat := range categories {
		categoryNames[i] = cat.Name
	}

	result := ProductWithCategories{
		ID:          product.ID,
		Name:        product.Name,
		Description: product.Description,
		Categories:  categoryNames,
	}

	err = response.JSON(w, http.StatusOK, result)
	if err != nil {
		app.serverError(w, r, err)
	}
}

func (app *application) handlerGetUserProducts(w http.ResponseWriter, r *http.Request) {
	user := contextGetAuthenticatedUser(r)

	type ProductWithCategories struct {
		ID          uuid.UUID `json:"id"`
		Name        string    `json:"name"`
		Description string    `json:"description"`
		Categories  []string  `json:"categories"`
	}

	products, err := app.db.GetUserProducts(r.Context(), user.ID)
	if err != nil {
		app.notFound(w, r)
		return
	}

	if len(products) == 0 {
		err = response.JSON(w, http.StatusOK, []any{})
		if err != nil {
			app.serverError(w, r, err)
		}
		return
	}

	var result []ProductWithCategories

	for _, product := range products {
		categories, err := app.db.GetUserProductCategories(r.Context(), product.ID)
		if err != nil {
			app.serverError(w, r, err)
			return
		}

		categoryNames := make([]string, len(categories))
		for i, cat := range categories {
			categoryNames[i] = cat.Name
		}

		result = append(result, ProductWithCategories{
			ID:          product.ID,
			Name:        product.Name,
			Description: product.Description,
			Categories:  categoryNames,
		})
	}

	err = response.JSON(w, http.StatusOK, result)
	if err != nil {
		app.serverError(w, r, err)
	}
}

func (app *application) handlerCreateUserProduct(w http.ResponseWriter, r *http.Request) {
	user := contextGetAuthenticatedUser(r)

	var input struct {
		Name          string              `json:"name"`
		Description   string              `json:"description"`
		CategoryNames []string            `json:"categories"`
		Validator     validator.Validator `json:"-"`
	}

	err := request.DecodeJSON(w, r, &input)
	if err != nil {
		app.badRequest(w, r, err)
		return
	}

	tx, err := app.dbPool.Begin(r.Context())
	if err != nil {
		app.serverError(w, r, err)
		return
	}
	defer tx.Rollback(r.Context())

	qtx := app.db.WithTx(tx)

	if len(input.CategoryNames) == 0 {
		err = response.JSON(w, http.StatusOK, []any{})
		if err != nil {
			app.serverError(w, r, err)
		}
		return
	}

	product, err := qtx.CreateUserProduct(r.Context(), database.CreateUserProductParams{
		Name:        input.Name,
		Description: input.Description,
		UserID:      user.ID,
	})
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	categories := make([]database.ProductsCategory, 0, len(input.CategoryNames))

	for _, categoryName := range input.CategoryNames {
		category, err := qtx.GetCategoryByName(r.Context(), categoryName)
		if err != nil {
			app.serverError(w, r, err)
			return
		}

		pc, err := qtx.CreateUserProductCategories(r.Context(), database.CreateUserProductCategoriesParams{
			ProductID:  product.ID,
			CategoryID: category.ID,
		})
		if err != nil {
			app.serverError(w, r, err)
			return
		}
		categories = append(categories, pc)
	}

	if err := tx.Commit(r.Context()); err != nil {
		app.serverError(w, r, err)
		return
	}

	result := struct {
		Product    database.Product            `json:"product"`
		Categories []database.ProductsCategory `json:"categories"`
	}{
		Product:    product,
		Categories: categories,
	}

	err = response.JSON(w, http.StatusCreated, result)
	if err != nil {
		app.serverError(w, r, err)
	}
}

func (app *application) handlerUpdateUserProduct(w http.ResponseWriter, r *http.Request) {
	user := contextGetAuthenticatedUser(r)

	var input struct {
		Name          string              `json:"name"`
		Description   string              `json:"description"`
		CategoryNames []string            `json:"categories"`
		Validator     validator.Validator `json:"-"`
	}

	err := request.DecodeJSON(w, r, &input)
	if err != nil {
		app.badRequest(w, r, err)
		return
	}

	productId, err := uuid.Parse(chi.URLParam(r, "productId"))
	if err != nil {
		app.badRequest(w, r, fmt.Errorf("invalid product ID"))
		return
	}

	if len(input.CategoryNames) == 0 {
		err = response.JSON(w, http.StatusOK, []any{})
		if err != nil {
			app.serverError(w, r, err)
		}
	}

	tx, err := app.dbPool.Begin(r.Context())
	if err != nil {
		app.serverError(w, r, err)
		return
	}
	defer tx.Rollback(r.Context())

	qtx := app.db.WithTx(tx)

	product, err := qtx.UpdateUserProduct(r.Context(), database.UpdateUserProductParams{
		ID:          productId,
		Name:        input.Name,
		Description: input.Description,
		UserID:      user.ID,
	})
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	err = qtx.DeleteProductCategoriesByProductID(r.Context(), productId)
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	categories := make([]database.ProductsCategory, 0, len(input.CategoryNames))

	for _, categoryName := range input.CategoryNames {
		category, err := qtx.GetCategoryByName(r.Context(), categoryName)
		if err != nil {
			app.serverError(w, r, err)
			return
		}

		pc, err := qtx.CreateUserProductCategories(r.Context(), database.CreateUserProductCategoriesParams{
			ProductID:  product.ID,
			CategoryID: category.ID,
		})
		if err != nil {
			app.serverError(w, r, err)
			return
		}
		categories = append(categories, pc)
	}

	if err := tx.Commit(r.Context()); err != nil {
		app.serverError(w, r, err)
		return
	}

	result := struct {
		Product    database.Product            `json:"product"`
		Categories []database.ProductsCategory `json:"categories"`
	}{
		Product:    product,
		Categories: categories,
	}

	err = response.JSON(w, http.StatusOK, result)
	if err != nil {
		app.serverError(w, r, err)
	}
}

func (app *application) handlerDeleteUserProduct(w http.ResponseWriter, r *http.Request) {

	user := contextGetAuthenticatedUser(r)

	productId, err := uuid.Parse(chi.URLParam(r, "productId"))
	if err != nil {
		app.badRequest(w, r, fmt.Errorf("invalid product ID"))
		return
	}

	err = app.db.DeleteUserProduct(r.Context(), database.DeleteUserProductParams{
		ID:     productId,
		UserID: user.ID,
	})
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	response.JSON(w, http.StatusOK, nil)
}
