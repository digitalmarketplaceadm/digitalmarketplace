package main

import (
	"errors"
	"net/http"
	"time"

	"github.com/Digital-Market-Place/api/internal/database"
	"github.com/Digital-Market-Place/api/internal/password"
	"github.com/Digital-Market-Place/api/internal/request"
	"github.com/Digital-Market-Place/api/internal/response"
	"github.com/Digital-Market-Place/api/internal/validator"
	"github.com/google/uuid"

	"github.com/jackc/pgx/v5"
)

func (app *application) handlerEmailConfirmation(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Code      string              `json:"code"`
		Validator validator.Validator `json:"-"`
	}

	user := contextGetAuthenticatedUser(r)

	err := request.DecodeJSON(w, r, &input)
	if err != nil {
		app.badRequest(w, r, err)
		return
	}

	existingOTP, err := app.db.GetLatestOTP(r.Context(), database.GetLatestOTPParams{
		UserID: user.ID,
		Type:   database.OtpTypeEmailVerification,
	})
	if err != nil {
		app.notFound(w, r)
		return
	}

	if existingOTP.ExpiresAt.Before(time.Now()) {
		app.badRequest(w, r, errors.New("expired otp"))
		return
	}

	if existingOTP.Attempts >= existingOTP.MaxAttempts {
		app.badRequest(w, r, errors.New("too many failed attempts"))
		return
	}

	if input.Code != existingOTP.Code {
		input.Validator.CheckField(false, "code", "Invalid OTP")

		err = app.db.IncrementOTPAttempts(r.Context(), existingOTP.ID)
		if err != nil {
			app.serverError(w, r, err)
			return
		}
	}

	if input.Validator.HasErrors() {
		app.failedValidation(w, r, input.Validator)
		return
	}

	err = app.db.VerifyUser(r.Context(), database.VerifyUserParams{
		UserID:     user.ID,
		VerifiedAt: time.Now(),
	})
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	err = response.JSON(w, http.StatusNoContent, nil)
	if err != nil {
		app.serverError(w, r, err)
		return
	}
}

func (app *application) handlerNewEmailConfirmation(w http.ResponseWriter, r *http.Request) {
	user := contextGetAuthenticatedUser(r)

	existingOTP, err := app.db.GetLatestOTP(r.Context(), database.GetLatestOTPParams{
		UserID: user.ID,
		Type:   database.OtpTypeEmailVerification,
	})
	noExistingOTP := errors.Is(err, pgx.ErrNoRows)
	if err != nil && !noExistingOTP {
		app.serverError(w, r, err)
		return
	}

	if !noExistingOTP && !existingOTP.ExpiresAt.Before(time.Now()) {
		app.badRequest(w, r, errors.New("a valid otp is already active"))
		return
	}

	if !noExistingOTP {
		err = app.db.InvalidateExistingOTP(r.Context(), database.InvalidateExistingOTPParams{
			UserID: user.ID,
			Type:   database.OtpTypeEmailVerification,
		})
		if err != nil {
			app.serverError(w, r, err)
			return
		}
	}

	otp, err := app.generateOTP(6)
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	now := time.Now()

	err = app.db.CreateOTP(r.Context(), database.CreateOTPParams{
		Code:      otp,
		Type:      database.OtpTypeEmailVerification,
		UserID:    user.ID,
		CreatedAt: now,
		ExpiresAt: now.Add(time.Minute * 5),
	})
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	app.backgroundTask(r, func() error {
		type EmailData struct {
			Code string
		}

		err = app.mailer.Send(user.Email, EmailData{
			Code: otp,
		}, "email_confirmation.tmpl")
		if err != nil {
			return err
		}

		return nil
	})

	err = response.JSON(w, http.StatusNoContent, nil)
	if err != nil {
		app.serverError(w, r, err)
		return
	}
}

func (app *application) handlerForgotPasswordChange(w http.ResponseWriter, r *http.Request) {
	var input struct {
		UserID    uuid.UUID           `json:"id"`
		Code      string              `json:"code"`
		Password  string              `json:"password"`
		Validator validator.Validator `json:"-"`
	}

	err := request.DecodeJSON(w, r, &input)
	if err != nil {
		app.badRequest(w, r, err)
		return
	}

	input.Validator.CheckField(input.UserID != uuid.Nil, "id", "ID is required")
	input.Validator.CheckField(input.Code != "", "code", "Code is required")

	input.Validator.CheckField(input.Password != "", "password", "Password is required")
	input.Validator.CheckField(len(input.Password) >= 8, "password", "Password is too short")
	input.Validator.CheckField(len(input.Password) <= 72, "password", "Password is too long")

	if input.Validator.HasErrors() {
		app.failedValidation(w, r, input.Validator)
		return
	}

	existingOTP, err := app.db.GetLatestOTP(r.Context(), database.GetLatestOTPParams{
		Type:   database.OtpTypePasswordReset,
		UserID: input.UserID,
	})
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			input.Validator.AddFieldError("code", "Invalid OTP")
			err = app.db.IncrementOTPAttempts(r.Context(), existingOTP.ID)
			if err != nil {
				app.serverError(w, r, err)
				return
			}

			app.failedValidation(w, r, input.Validator)
			return
		}

		app.serverError(w, r, err)
		return
	}

	if existingOTP.ExpiresAt.Before(time.Now()) {
		app.badRequest(w, r, errors.New("expired otp"))
		return
	}

	if existingOTP.Attempts >= existingOTP.MaxAttempts {
		app.badRequest(w, r, errors.New("too many failed attempts"))
		return
	}

	hashedPassword, err := password.Hash(input.Password)
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	err = app.db.UpdatePassword(r.Context(), database.UpdatePasswordParams{
		ID:             existingOTP.UserID,
		HashedPassword: hashedPassword,
	})
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	err = response.JSON(w, http.StatusNoContent, nil)
	if err != nil {
		app.serverError(w, r, err)
	}
}

func (app *application) handlerForgotPasswordRequest(w http.ResponseWriter, r *http.Request) {
	var input struct {
		Email     string              `json:"email"`
		Validator validator.Validator `json:"-"`
	}

	err := request.DecodeJSON(w, r, &input)
	if err != nil {
		app.badRequest(w, r, err)
		return
	}

	input.Validator.CheckField(input.Email != "", "email", "Email is required")
	input.Validator.CheckField(validator.IsEmail(input.Email), "email", "Invalid email format")

	if input.Validator.HasErrors() {
		app.failedValidation(w, r, input.Validator)
		return
	}

	user, err := app.db.GetUserByEmail(r.Context(), input.Email)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			input.Validator.AddFieldError("email", "Email does not exist")
			app.failedValidation(w, r, input.Validator)
			return
		}

		app.serverError(w, r, err)
		return
	}

	otp, err := app.generateOTP(6)
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	now := time.Now()

	err = app.db.CreateOTP(r.Context(), database.CreateOTPParams{
		Code:      otp,
		Type:      database.OtpTypePasswordReset,
		UserID:    user.ID,
		CreatedAt: now,
		ExpiresAt: now.Add(time.Minute * 5),
	})
	if err != nil {
		app.serverError(w, r, err)
		return
	}

	app.backgroundTask(r, func() error {
		type EmailData struct {
			Code string
		}

		err = app.mailer.Send(user.Email, EmailData{
			Code: otp,
		}, "password_reset.tmpl")
		if err != nil {
			return err
		}

		return nil
	})

	data := map[string]any{
		"id": user.ID,
	}

	err = response.JSON(w, http.StatusOK, data)
	if err != nil {
		app.serverError(w, r, err)
		return
	}
}
