package main

import (
	"net/http"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/cors"
)

func (app *application) routes() http.Handler {
	mux := chi.NewRouter()

	mux.NotFound(app.notFound)
	mux.MethodNotAllowed(app.methodNotAllowed)

	mux.Use(cors.Handler(cors.Options{
		// AllowedOrigins:   []string{"https://foo.com"}, // Use this to allow specific origin hosts
		AllowedOrigins: []string{"https://*", "http://*"},
		// AllowOriginFunc:  func(r *http.Request, origin string) bool { return true },
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Accept", "Authorization", "Content-Type", "X-CSRF-Token"},
		ExposedHeaders:   []string{"Link"},
		AllowCredentials: false,
		MaxAge:           300, // Maximum value not ignored by any of major browsers
	}))

	mux.Use(app.logAccess)
	mux.Use(app.recoverPanic)
	mux.Use(app.authenticate)

	mux.Get("/status", app.status)

	mux.Post("/login", app.handlerLogin)

	mux.Post("/register", app.handlerCreateBasicUser)

	mux.Post("/forgot-password", app.handlerForgotPasswordChange)
	mux.Post("/forgot-password/request", app.handlerForgotPasswordRequest)

	mux.Get("/auth/{provider}", app.handlerBeginAuthProviderCallback)
	mux.Get("/auth/{provider}/callback", app.handlerGetAuthCallbackFunction)

	mux.Get("/public/categories", app.handlerGetCategories)
	mux.Get("/public/products", app.handlerGetProducts)

	mux.Group(func(mux chi.Router) {
		mux.Use(app.requireAuthenticatedUser)
		mux.Get("/users/me", app.handlerGetCurrentUser)

		mux.Post("/email-confirmation", app.handlerEmailConfirmation)
		mux.Post("/email-confirmation/request", app.handlerNewEmailConfirmation)

		mux.Get("/categories", app.handlerGetCategories)
		mux.Post("/categories", app.handlerCreateCategory)
		mux.Put("/categories/{categoryId}", app.handlerUpdateCategory)
		mux.Delete("/categories/{categoryId}", app.handlerDeleteCategory)

		mux.Get("/products", app.handlerGetUserProducts)
		mux.Post("/products", app.handlerCreateUserProduct)
		mux.Put("/products/{productId}", app.handlerUpdateUserProduct)
		mux.Delete("/products/{productId}", app.handlerDeleteUserProduct)

		mux.Get("/{productId}", app.handlerGetProductById)

		mux.Get("/orders", app.handlerGetUserOrders)
		mux.Post("/orders", app.handlerCreateUserOrder)
		mux.Put("/orders/{orderId}", app.handlerUpdateUserOrder)
		mux.Delete("/orders/{orderId}", app.handlerDeleteUserOrder)
	})

	return mux
}
