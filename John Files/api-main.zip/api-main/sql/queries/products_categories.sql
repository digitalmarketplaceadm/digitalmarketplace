-- name: GetUserProductCategories :many
SELECT c.*
FROM categories c
JOIN products_categories pc ON c.id = pc.category_id
WHERE pc.product_id = $1;

-- name: CreateUserProductCategories :one
INSERT INTO products_categories (product_id, category_id)
VALUES ($1, $2)
RETURNING *;

-- name: DeleteUserProductCategories :exec
DELETE FROM products_categories
WHERE id = $1 AND product_id = $2;

-- name: DeleteProductCategoriesByProductID :exec
DELETE FROM products_categories
WHERE product_id = $1;

-- name: UpdateUserProductCategories :one
UPDATE products_categories
SET category_id = $2
WHERE id = $1 AND product_id = $3
RETURNING *;