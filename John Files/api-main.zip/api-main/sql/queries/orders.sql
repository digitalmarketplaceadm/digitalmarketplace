-- name: GetUserOrders :many
SELECT orders.*, sqlc.embed(order_items)
FROM orders
LEFT JOIN order_items ON order_items.order_id = orders.id
WHERE orders.user_id = $1
ORDER BY orders.created_at DESC;

-- name: CreateUserOrder :one
INSERT INTO orders (user_id, status)
VALUES ($1, $2)
RETURNING *;

-- name: DeleteUserOrder :exec
DELETE FROM orders
WHERE id = $1 AND user_id = $2;

-- name: UpdateUserOrder :one
UPDATE orders
SET  status = $2
WHERE id = $1 AND user_id = $3
RETURNING *;