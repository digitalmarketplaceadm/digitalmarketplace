-- name: GetProducts :many
SELECT * FROM products;

-- name: GetUserProducts :many
SELECT * FROM products
WHERE user_id = $1
ORDER BY name;

-- name: GetProductById :one
SELECT * FROM products
WHERE id = $1
ORDER BY name;

-- name: CreateUserProduct :one
INSERT INTO products (name, description, user_id)
VALUES ($1, $2, $3)
RETURNING *;

-- name: DeleteUserProduct :exec
DELETE FROM products
WHERE id = $1 AND user_id = $2;

-- name: UpdateUserProduct :one
UPDATE products
SET name = $2, description = $3
WHERE id = $1 AND user_id = $4
RETURNING *;