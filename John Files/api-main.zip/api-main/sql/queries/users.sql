-- name: GetUsers :many
SELECT *
FROM users;

-- name: GetUser :one
SELECT *
FROM users
WHERE id = $1
LIMIT 1;

-- name: GetUserByEmail :one
SELECT *
FROM users
WHERE email = $1
LIMIT 1;

-- name: CreateUser :one
INSERT INTO users (email, hashed_password) 
VALUES ($1, $2)
RETURNING *;

-- name: UpdatePassword :exec
UPDATE users
SET hashed_password = $2
WHERE id = $1;

-- name: VerifyUser :exec
UPDATE users
SET verified_at = sqlc.arg(verified_at)::TIMESTAMPTZ
WHERE id = sqlc.arg(user_id)::UUID;