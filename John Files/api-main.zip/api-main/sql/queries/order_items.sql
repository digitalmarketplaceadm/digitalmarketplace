-- name: GetOrderItems :many
SELECT order_items.*, sqlc.embed(products)
FROM order_items
LEFT JOIN products ON products.id = order_items.product_id
WHERE order_items.order_id = $1
ORDER BY order_items.id DESC;

-- name: CreateOrderItems :one
INSERT INTO order_items (quantity, price, product_id, order_id)
VALUES ($1, $2, $3, $4)
RETURNING *;

-- name: DeleteOrderItems :exec
DELETE FROM order_items
WHERE id = $1 AND order_id = $2;

-- name: UpdateOrderItems :one
UPDATE order_items
SET quantity = $2, price = $3, product_id = $4
WHERE id = $1 AND order_id = $5
RETURNING *;