-- +goose Up
CREATE EXTENSION IF NOT EXISTS "uuid-ossp"; -- Required for uuid_generate_v4()
CREATE EXTENSION IF NOT EXISTS moddatetime;

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT NOT NULL UNIQUE,
    hashed_password TEXT NOT NULL,
    verified_at TIMESTAMPTZ,
    
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TRIGGER update_users_updated_at 
BEFORE UPDATE ON users 
FOR EACH ROW 
EXECUTE FUNCTION moddatetime (updated_at);

-- +goose Down
DROP TRIGGER update_users_updated_at ON users;
DROP TABLE users;
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS moddatetime;