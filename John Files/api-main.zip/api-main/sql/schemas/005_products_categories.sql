-- +goose Up
CREATE TABLE products_categories(
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    category_id UUID NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
    UNIQUE (category_id, product_id)
);

-- +goose Down
DROP TABLE products_categories;